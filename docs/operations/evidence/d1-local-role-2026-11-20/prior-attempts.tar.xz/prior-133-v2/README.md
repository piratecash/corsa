# Historical targeted QA v2: 133 outer /311 child passes

Actual attempt2b4fddc849ef4cad8c9bf0402fd2bdd8 on base1b97 plus exact33-file manifestb64befdc…. This PASS remains bound only to that subject. The later complete product run exposed two additional old forwarding fixtures using Off; the final34-file subject and147 selected executions are at the parent directory. Nothing here is relabeled as a later pass. Raw streams and independent original reviews remain exact. Old preparation manifests retain NOT_RUN labels; result.json is the later actual verdict.
