"""Bounded clean-snapshot ordinary macOS release product tests; overlaysim DEFERRED."""
from pathlib import Path
import hashlib
import importlib.util
import json
import os
import re
import shutil
import signal
import subprocess
import tarfile
import time
import uuid

HERE=Path(__file__).resolve().parent
REPO=HERE.parents[4]
ROLE=HERE.parent/'d1-directional-role-implementation-v2'
BASE='1b97da9a8c581f7a40664aa5b5eb78c59f104f3c'
ROLE_SHA='b64befdcb32d2974066a2e5c41c147af93e4fb30184c91e9773112360b37e607'
HELPER=HERE.parent/'d1-sg512-target-history-driver-build-v2/build_driver.py'
HELPER_SHA='1e703c9856b281979bb63f12df11a7c5f0d50152001ff8a557f1b44289a669cc'
GO='/usr/local/go/bin/go'
LOCK=Path('/private/tmp/corsa-heavy-run.lock')
RAW_LIMIT=8*1024**2


def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def load_bound(name,path,digest):
    assert sha(path)==digest,'bound helper changed'
    spec=importlib.util.spec_from_file_location(name,path);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    return module


def check_release(stdout,stderr):
    deferred='github.com/piratecash/corsa/internal/overlaysim'
    lines=stderr.decode().splitlines()
    assert lines.count('DEFERRED to D1 (not PASS): '+deferred)==1,'missing/duplicate explicit deferral'
    selected=[line.removeprefix('Release test package: ') for line in lines if line.startswith('Release test package: ')]
    assert selected and len(selected)==len(set(selected)) and deferred not in selected,'bad selected inventory'
    counts=[line for line in lines if re.fullmatch(r'Release test scope: [0-9]+ packages selected',line)]
    assert len(counts)==1 and int(counts[0].split()[3])==len(selected),'inventory count mismatch'
    completed=[]
    for line in stdout.decode().splitlines():
        assert not re.match(r'^(FAIL|--- FAIL:|panic:|fatal error:)',line),'release test failure'
        match=re.fullmatch(r'ok\s+(github\.com/piratecash/corsa(?:/[A-Za-z0-9_.-]+)*)\s+.+',line)
        empty=re.fullmatch(r'\?\s+(github\.com/piratecash/corsa(?:/[A-Za-z0-9_.-]+)*)\s+\[no test files\]',line)
        if match or empty:completed.append((match or empty).group(1))
    assert len(completed)==len(set(completed)) and set(completed)==set(selected),'missing/extra package completion'
    return dict(packages=len(selected),completed=completed,deferred=[deferred],individual_skip_accounting='not provided by unchanged nonverbose release script')


# These three exact source-owned MkdirTemp schemas are the only native AF_UNIX
# fixture listeners in the frozen default product suite. They intentionally use
# short /tmp names, not inherited TMPDIR. This is schema confinement, not an
# assertion that arbitrary matching pre-existing sockets belong to this job.
UNIX_SOCKET_PATTERNS=(
    r'^(/private)?/tmp/corsa-dl-[0-9]+/(corsa/)?deeplink-64646[.]sock$',
    r'^(/private)?/tmp/corsa-acl-[0-9]+/chat/deeplink-64646[.]sock$',
    r'^(/private)?/tmp/fence-io-[0-9]+/channel$',
)

def network_policy(source):
    unix=''.join('(allow network-bind network-inbound (local unix-socket (regex #'+json.dumps(pattern)+')))(allow network-outbound (remote unix-socket (regex #'+json.dumps(pattern)+')))' for pattern in UNIX_SOCKET_PATTERNS)
    return '(version 1)(allow default)(deny network*)(allow network-inbound (local ip "localhost:*"))(allow network-outbound (remote ip "localhost:*"))'+unix+'(deny file-write* (subpath '+json.dumps(str(source))+'))'

def group_absent(pid,probe=os.killpg):
    try:probe(pid,0)
    except ProcessLookupError:return True
    except OSError:return False
    return False


def main():
    os.umask(0o077)
    if os.getpid()!=os.getpgrp():os.setsid()
    origin=time.monotonic();work_end=origin+1800;cleanup_end=origin+1830
    manifest=json.loads((HERE/'HANDOFF.json').read_bytes())
    assert manifest['controller_sha256']==sha(__file__)
    assert sha(ROLE/'MANIFEST.json')==ROLE_SHA
    role=json.loads((ROLE/'MANIFEST.json').read_bytes());assert role['base_commit']==BASE
    for name,row in role['files'].items():
        assert sha(ROLE/'posts'/name)==row['after_sha256']==sha(REPO/name),'role/current applied source drift'
    helper=load_bound('accepted_role_job_helper',HELPER,HELPER_SHA)
    assert shutil.disk_usage('/private/tmp').free>=10*1024**3
    attempt=uuid.uuid4().hex;work=Path('/private/tmp/corsa-d1-closed-role-release-qa-'+attempt);work.mkdir(mode=0o700)
    LOCK.mkdir(mode=0o700);owner=f'name=d1-closed-role-release-qa-v3\npid={os.getpid()}\npgid={os.getpgrp()}\nattempt_id={attempt}\n'.encode();(LOCK/'owner').write_bytes(owner)
    custody=(helper.stamp(LOCK),helper.stamp(LOCK/'owner'));steps=[];artifacts={};child=None;known=True;error=None;initial=None
    env={**os.environ,'PATH':'/usr/local/go/bin:'+os.environ.get('PATH',''),'GO111MODULE':'on','GOROOT':'/usr/local/go','GOENV':'off','GOWORK':'off','GOVCS':'*:off','GODEBUG':'','GOTOOLCHAIN':'local','GOPROXY':'off','GOSUMDB':'off','GOTELEMETRY':'off','GOMAXPROCS':'2','GOMEMLIMIT':'768MiB','GOFLAGS':'-p=1 -mod=readonly -buildvcs=false','GO':GO,'GOCACHE':str(work/'cache'),'GOMODCACHE':str(REPO/'.gomodcache'),'TMPDIR':str(work/'tmp'),'GOOS':'darwin','GOARCH':'arm64','CGO_ENABLED':'1','GOARM64':'v8.0'}
    policy=network_policy(work/'source')
    def raw_size():return sum(Path(row[key]).stat().st_size for row in steps for key in ('stdout','stderr'))
    def absent():
        nonlocal known
        if not child:return True
        if group_absent(child.pid):return True
        known=False;return False
    def phase_files():
        # Only after process-group absence: no live Go temp/cache rglob/stat.
        assert helper.work_volume(work)<=6*1024**3 and raw_size()<=RAW_LIMIT,'phase file/RAW bound'
    def run(name,args,cwd,extra=None):
        nonlocal child
        assert time.monotonic()<work_end
        row=dict(phase=name,argv=args,pid=None,exit=None,stdout=str(work/(name+'.stdout')),stderr=str(work/(name+'.stderr')));steps.append(row)
        with Path(row['stdout']).open('xb') as out,Path(row['stderr']).open('xb') as err:
            child=subprocess.Popen(['/usr/bin/sandbox-exec','-p',policy,*args],cwd=cwd,env=env|(extra or {}),stdout=out,stderr=err,start_new_session=True);row['pid']=child.pid;row['pgid']=child.pid
            (work/'ACTIVE-COMMAND.json').write_text(json.dumps(dict(controller_pid=os.getpid(),controller_pgid=os.getpgrp(),attempt_id=attempt,phase=name,argv=args,pid=child.pid,pgid=child.pid),indent=2)+'\n')
            while child.poll() is None:
                assert time.monotonic()<work_end and raw_size()<=RAW_LIMIT,'work deadline/RAW bound'
                time.sleep(.1)
        row['exit']=child.returncode
        assert absent(),'owned command group remains'
        phase_files()
        assert child.returncode==0,name+' failed'
    try:
        (work/'tmp').mkdir();(work/'artifacts').mkdir();src=work/'source';src.mkdir()
        run('archive',['/usr/bin/git','archive','--format=tar','--output='+str(work/'base.tar'),BASE],REPO)
        assert (work/'base.tar').stat().st_size<=1024**3
        with tarfile.open(work/'base.tar','r:') as archive:
            for member in archive:
                parts=Path(member.name).parts;assert parts and not Path(member.name).is_absolute() and '..' not in parts
                target=src/member.name
                if member.isdir():target.mkdir(parents=True,exist_ok=True)
                else:
                    assert member.isfile(),'archive links/special entries refused';target.parent.mkdir(parents=True,exist_ok=True)
                    with archive.extractfile(member) as inp,target.open('xb') as out:shutil.copyfileobj(inp,out)
                    target.chmod(member.mode&0o777)
                assert time.monotonic()<work_end
        for name,row in role['files'].items():
            target=src/name;assert (sha(target) if target.exists() else None)==row['before_sha256'],'clean base mismatch'
            target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(ROLE/'posts'/name,target);assert sha(target)==row['after_sha256']
        initial=helper.inventory(src);(work/'SOURCE-MANIFEST.json').write_text(json.dumps(initial,sort_keys=True,indent=2)+'\n')
        (work/'INPUTS.json').write_text(json.dumps(dict(base_commit=BASE,base_tar_sha256=sha(work/'base.tar'),role_manifest_sha256=ROLE_SHA,role=role,helper_sha256=HELPER_SHA,release_script_sha256=manifest['release_script_sha256'],seatbelt=policy),indent=2)+'\n');phase_files()
        run('go-version',[GO,'version'],src);assert (work/'go-version.stdout').read_text().strip()=='go version go1.27.4 darwin/arm64'
        run('modules',[GO,'mod','verify'],src)
        assert sha(src/'scripts/test-release.sh')==manifest['release_script_sha256']==sha(REPO/'scripts/test-release.sh')
        run('release-tests',['/bin/bash','scripts/test-release.sh'],src)
        steps[-1]['release_scope']=check_release(Path(steps[-1]['stdout']).read_bytes(),Path(steps[-1]['stderr']).read_bytes())
        assert helper.inventory(src)==initial,'source modified during QA/compile'
        assert sha(ROLE/'MANIFEST.json')==ROLE_SHA and sha(HELPER)==HELPER_SHA
        for name,row in role['files'].items():assert sha(ROLE/'posts'/name)==row['after_sha256']==sha(REPO/name)
        assert time.monotonic()<work_end;phase_files()
    except BaseException as exc:
        error=repr(exc)
        if child and child.poll() is None:
            try:
                os.killpg(child.pid,signal.SIGTERM)
                try:child.wait(timeout=max(.001,min(10,cleanup_end-time.monotonic())))
                except subprocess.TimeoutExpired:
                    os.killpg(child.pid,signal.SIGKILL)
                    try:child.wait(timeout=max(.001,cleanup_end-time.monotonic()))
                    except subprocess.TimeoutExpired:known=False
            except OSError as cleanup_error:
                known=False;error+='; cleanup='+repr(cleanup_error)
        if child:
            absent()
            if steps and steps[-1]['pid']==child.pid:steps[-1]['exit']=child.poll()
    result=dict(status='CLOSED_ROLE_RELEASE_PRODUCT_TESTS_PASS_OVERLAYSIM_DEFERRED' if error is None else 'STOP',error=error,attempt_id=attempt,work=str(work),base_commit=BASE,role_manifest_sha256=ROLE_SHA,steps=steps,artifacts=artifacts,cleanup_confirmed=known,linux_ELF_executed=False,work_limit_s=1800,cleanup_end_s=1830)
    (work/'result.json').write_text(json.dumps(result,indent=2)+'\n');shutil.copyfile(work/'result.json',HERE/'RESULT.json')
    if known:
        assert custody==(helper.stamp(LOCK),helper.stamp(LOCK/'owner')) and (LOCK/'owner').read_bytes()==owner and set(x.name for x in LOCK.iterdir())=={'owner'}
        (LOCK/'owner').unlink();LOCK.rmdir()
    print(json.dumps(dict(status=result['status'],error=error,attempt_id=attempt,work=str(work),cleanup_confirmed=known)),flush=True)
    if not known:
        # Keep the exact own lock and controller live for separate factual recovery.
        (work/'HOLD.json').write_text(json.dumps(dict(status='UNKNOWN_RETAIN_LOCK',controller_pid=os.getpid(),controller_pgid=os.getpgrp(),attempt_id=attempt,last_command=steps[-1] if steps else None),indent=2)+'\n')
        while True:
            try:time.sleep(1)
            except KeyboardInterrupt:pass
    if error:raise SystemExit(1)


if __name__=='__main__':main()
