"""ROOT-invoked tiny ordinary-umask/direct-inner sandbox controls; no Go."""
from pathlib import Path
import hashlib,json,os,stat,subprocess,sys,tempfile

def child(work):
    observed=os.umask(0o022);os.umask(observed)
    descriptor=os.open(work/'fixture0644',os.O_CREAT|os.O_EXCL|os.O_WRONLY,0o644);os.close(descriptor)
    os.mkdir(work/'fixture0755',0o755)
    file_mode=stat.S_IMODE((work/'fixture0644').stat().st_mode);directory_mode=stat.S_IMODE((work/'fixture0755').stat().st_mode)
    assert observed==0o022 and file_mode==0o644 and directory_mode==0o755
    print(json.dumps(dict(child_umask=oct(observed),file_mode=oct(file_mode),directory_mode=oct(directory_mode))))

def main():
    if len(sys.argv)>1:
        assert len(sys.argv)==3 and sys.argv[1]=='--child';child(Path(sys.argv[2]));return
    os.umask(0o077);work=Path(tempfile.mkdtemp(prefix='corsa-d1-release-env-',dir='/private/tmp'))
    result=dict(status='STOP',work=str(work),steps=[])
    try:
        commands=[('umask',[sys.executable,str(Path(__file__).resolve()),'--child',str(work)]),('direct-inner',['/usr/bin/sandbox-exec','-p','(version 1)(allow default)(deny network*)','/usr/bin/true'])]
        for name,argv in commands:
            run=subprocess.run(argv,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=10,check=False,start_new_session=True,umask=0o022)
            assert len(run.stdout)+len(run.stderr)<=16384
            (work/(name+'.stdout')).write_bytes(run.stdout);(work/(name+'.stderr')).write_bytes(run.stderr)
            result['steps'].append(dict(name=name,argv=argv,exit=run.returncode,stdout_sha256=hashlib.sha256(run.stdout).hexdigest(),stderr_sha256=hashlib.sha256(run.stderr).hexdigest()))
            assert run.returncode==0 and not run.stderr
            if name=='umask':result['umask_proof']=json.loads(run.stdout)
            else:assert not run.stdout
        parent=os.umask(0o077);os.umask(parent);assert parent==0o077 and stat.S_IMODE(work.stat().st_mode)==0o700
        result.update(status='PASS',parent_umask=oct(parent),work_mode='0o700')
    except BaseException as exc:result['error']=repr(exc)
    (work/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n');Path(__file__).with_name('ENVIRONMENT-RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
    if result['status']!='PASS':raise SystemExit(1)

if __name__=='__main__':main()
