from pathlib import Path
import unittest

class Tests(unittest.TestCase):
    def test_one_fixed_non_go_child_and_parent_unfiltered(self):
        source=Path(__file__).with_name('init.c').read_text()
        self.assertEqual(source.count('execve('),1)
        self.assertIn('execve("/bin/profile-probe",arguments,environment)',source)
        self.assertIn('arguments[]={"/bin/profile-probe",NULL}',source)
        self.assertNotIn('--policy-controls',source)
        for forbidden in ('PR_SET_SECCOMP','capset','node.test','corsad','piratecashd','system('):self.assertNotIn(forbidden,source)
        self.assertIn('mode==0,"parent-unfiltered"',source)
    def test_independent_direct_poweroff_and_bounded_reap(self):
        source=Path(__file__).with_name('init.c').read_text()
        body=source[source.index('static void poweroff_now'):source.index('static void abrupt_failure')]
        self.assertIn('SYS_reboot',body);self.assertNotIn('line(',body)
        for expected in ('alarm(55)','UINT64_C(30000000000)','UINT64_C(50000000000)','waitpid(-1,&one,WNOHANG)','kill(pid,SIGKILL)'):self.assertIn(expected,source)
    def test_nonce_and_initial_lo_and_stopped_failure_fields(self):
        source=Path(__file__).with_name('init.c').read_text()
        self.assertIn('st.st_size==32',source);self.assertIn('O_NOFOLLOW',source)
        self.assertEqual(source.count('exact_lo();'),2)
        self.assertIn('child_reaped=%d all_children_reaped=%d killed=%d normal_exit=%d exit=%d',source)

    def test_original_tmpfs_mounts_before_fixed_child(self):
        source=Path(__file__).with_name('init.c').read_text()
        tmp='mount("tmpfs","/tmp","tmpfs",MS_NOSUID|MS_NODEV|MS_NOEXEC,"size=128m,mode=1777")'
        profiles='mount("tmpfs","/profiles","tmpfs",MS_NOSUID|MS_NODEV|MS_NOEXEC,"size=512m,mode=0755")'
        for mount in (tmp,profiles):
            self.assertEqual(source.count(mount),1)
            self.assertLess(source.index(mount),source.index('pid_t pid=fork()'))
        # Probe creates and fchmods its own fresh root1777 parent. PID1 must not
        # pre-create that exact name and turn the original mkdirat into EEXIST.
        self.assertNotIn('/profiles/loadstand-',source)

    def test_root_environment_fix_preserves_strict_audit_and_runs_before_mounts(self):
        source=Path(__file__).with_name('init.c').read_text()
        self.assertEqual(source.count('chmod("/",0755)'),1)
        self.assertEqual(source.count('normalize_guest_root();'),1)
        self.assertLess(source.index('normalize_guest_root();'),source.index('mkdir_exact("/tmp",01777)'))
        self.assertLess(source.index('normalize_guest_root();'),source.index('mkdir_exact("/profiles",0755)'))
        for required in ('S_ISDIR(before.st_mode)&&before.st_uid==0','(after.st_mode&07777)==0755','after.st_dev==before.st_dev&&after.st_ino==before.st_ino','O1A_PROFILE_ROOT attempt=%s stage=before','O1A_PROFILE_ROOT attempt=%s stage=after'):
            self.assertIn(required,source)

if __name__=='__main__':unittest.main()
