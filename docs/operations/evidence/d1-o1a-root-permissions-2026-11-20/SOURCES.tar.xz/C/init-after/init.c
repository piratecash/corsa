#define _GNU_SOURCE
/* Short unfiltered PID1 derived from accepted multicast init supervision.
   Exactly one fixed child: profile-probe, no arguments. No Go/application. */
#include <dirent.h>
#include <errno.h>
#include <fcntl.h>
#include <inttypes.h>
#include <linux/capability.h>
#include <linux/reboot.h>
#include <signal.h>
#include <stdarg.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <sys/mount.h>
#include <sys/prctl.h>
#include <sys/resource.h>
#include <sys/stat.h>
#include <sys/syscall.h>
#include <sys/wait.h>
#include <time.h>
#include <unistd.h>

static char attempt[33];
static unsigned output_bytes;
static const char *stage="boot";
static void poweroff_now(int sig) {
    (void)sig;
    /* No console operation before this independent shutdown attempt. */
    (void)syscall(SYS_reboot,LINUX_REBOOT_MAGIC1,LINUX_REBOOT_MAGIC2,LINUX_REBOOT_CMD_POWER_OFF,NULL);
    _exit(127);
}
static void abrupt_failure(void) {
    if(getpid()==1)poweroff_now(0);
    _exit(124);
}
static uint64_t mono(void) {
    struct timespec t;
    if(clock_gettime(CLOCK_MONOTONIC,&t))abrupt_failure();
    return (uint64_t)t.tv_sec*UINT64_C(1000000000)+(uint64_t)t.tv_nsec;
}
static void line(const char *fmt,...) {
    char buf[2048];va_list args;va_start(args,fmt);
    int n=vsnprintf(buf,sizeof(buf),fmt,args);va_end(args);
    if(n<0||(size_t)n>=sizeof(buf)||output_bytes+(unsigned)n>65536U)abrupt_failure();
    size_t at=0;
    while(at<(size_t)n) {
        ssize_t got=write(STDOUT_FILENO,buf+at,(size_t)n-at);
        if(got<0&&errno==EINTR)continue;
        if(got<=0)abrupt_failure();
        at+=(size_t)got;
    }
    output_bytes+=(unsigned)n;
}
static void die(const char *why) {
    int saved=errno;line("O1A_POLICY_INIT_FAIL attempt=%s stage=%s reason=%s errno=%d\n",attempt,stage,why,saved);
    if(getpid()==1)poweroff_now(0);
    _exit(125);
}
static void must(int yes,const char *why) {if(!yes){errno=EINVAL;die(why);}}
static void checked(int result,const char *why) {if(result<0)die(why);}
static void mkdir_exact(const char *path,mode_t mode) {
    if(mkdir(path,mode)&&errno!=EEXIST)die("mkdir");
    struct stat s;checked(lstat(path,&s),"directory-stat");
    must(S_ISDIR(s.st_mode)&&s.st_uid==0,"directory-kind-owner");checked(chmod(path,mode),"directory-mode");
}
static void normalize_guest_root(void) {
    struct stat before,after;checked(lstat("/",&before),"root-before-stat");
    must(S_ISDIR(before.st_mode)&&before.st_uid==0,"root-before-kind-owner");
    line("O1A_PROFILE_ROOT attempt=%s stage=before uid=%lu gid=%lu mode=%o dev=%" PRIu64 " ino=%" PRIu64 "\n",attempt,(unsigned long)before.st_uid,(unsigned long)before.st_gid,before.st_mode,(uint64_t)before.st_dev,(uint64_t)before.st_ino);
    checked(chmod("/",0755),"root-chmod0755");checked(lstat("/",&after),"root-after-stat");
    must(S_ISDIR(after.st_mode)&&after.st_uid==0&&(after.st_mode&07777)==0755&&after.st_dev==before.st_dev&&after.st_ino==before.st_ino,"root-after0755-readback");
    line("O1A_PROFILE_ROOT attempt=%s stage=after uid=%lu gid=%lu mode=%o dev=%" PRIu64 " ino=%" PRIu64 "\n",attempt,(unsigned long)after.st_uid,(unsigned long)after.st_gid,after.st_mode,(uint64_t)after.st_dev,(uint64_t)after.st_ino);
}
static void read_attempt(void) {
    int fd=open("/diag-attempt",O_RDONLY|O_CLOEXEC|O_NOFOLLOW);checked(fd,"attempt-open");
    struct stat st;checked(fstat(fd,&st),"attempt-stat");
    must(S_ISREG(st.st_mode)&&st.st_nlink==1&&st.st_uid==0&&(st.st_mode&07777)==0444&&st.st_size==32,"attempt-file");
    char buf[33];ssize_t n=read(fd,buf,sizeof(buf));must(n==32,"attempt-exact-length");checked(close(fd),"attempt-close");
    for(unsigned i=0;i<32;i++)must((buf[i]>='0'&&buf[i]<='9')||(buf[i]>='a'&&buf[i]<='f'),"attempt-lowerhex");
    memcpy(attempt,buf,32);attempt[32]=0;
}
static void exact_lo(void) {
    DIR *dir=opendir("/sys/class/net");if(!dir)die("interfaces-open");
    unsigned count=0;errno=0;struct dirent *entry;
    while((entry=readdir(dir))) {
        if(!strcmp(entry->d_name,".")||!strcmp(entry->d_name,".."))continue;
        must(!strcmp(entry->d_name,"lo")&&++count==1,"initial-only-lo");errno=0;
    }
    must(!errno&&count==1,"interfaces-complete");checked(closedir(dir),"interfaces-close");
}
static void parent_status(const char *when) {
    struct __user_cap_header_struct h={_LINUX_CAPABILITY_VERSION_3,0};
    struct __user_cap_data_struct d[2]={{0}};checked((int)syscall(SYS_capget,&h,d),"parent-capget");
    int mode=prctl(PR_GET_SECCOMP,0,0,0,0);must(mode==0,"parent-unfiltered");
    must(getuid()==0&&geteuid()==0&&getgid()==0&&getegid()==0&&(d[0].effective&(1U<<CAP_SYS_BOOT))&&prctl(PR_CAPBSET_READ,CAP_SYS_BOOT,0,0,0)==1,"parent-poweroff-authority");
    struct rlimit core;checked(getrlimit(RLIMIT_CORE,&core),"parent-core-read");must(!core.rlim_cur&&!core.rlim_max,"parent-core-zero");
    line("O1A_POLICY_PARENT attempt=%s stage=%s uid=0 euid=0 gid=0 egid=0 seccomp=0 boot_effective=1 boot_bounding=1 core_cur=0 core_max=0\n",attempt,when);
}
int main(int argc,char **argv) {
    (void)argv;must(argc==1&&getpid()==1&&getuid()==0&&geteuid()==0,"pid1-root-only");
    struct sigaction action={0};action.sa_handler=poweroff_now;checked(sigemptyset(&action.sa_mask),"signal-mask");checked(sigaction(SIGALRM,&action,NULL),"alarm-handler");alarm(55);
    int flags=fcntl(STDOUT_FILENO,F_GETFL);checked(flags,"stdout-flags");checked(fcntl(STDOUT_FILENO,F_SETFL,flags|O_NONBLOCK),"stdout-nonblock");
    umask(0);mkdir_exact("/proc",0555);checked(mount("proc","/proc","proc",MS_NOSUID|MS_NODEV|MS_NOEXEC|MS_RDONLY,NULL),"proc-mount");read_attempt();
    mkdir_exact("/sys",0555);checked(mount("sysfs","/sys","sysfs",MS_NOSUID|MS_NODEV|MS_NOEXEC|MS_RDONLY,NULL),"sys-mount");
    normalize_guest_root();
    mkdir_exact("/tmp",01777);checked(mount("tmpfs","/tmp","tmpfs",MS_NOSUID|MS_NODEV|MS_NOEXEC,"size=128m,mode=1777"),"tmp-mount");
    mkdir_exact("/profiles",0755);checked(mount("tmpfs","/profiles","tmpfs",MS_NOSUID|MS_NODEV|MS_NOEXEC,"size=512m,mode=0755"),"profiles-mount");
    struct rlimit core={0,0};checked(setrlimit(RLIMIT_CORE,&core),"parent-core-zero");stage="initial";exact_lo();parent_status("before");
    uint64_t start=mono();pid_t pid=fork();checked((int)pid,"fork");
    if(pid==0) {
        char *const arguments[]={"/bin/profile-probe",NULL};
        char *const environment[]={"PATH=/usr/bin:/bin","LC_ALL=C","HOME=/nonexistent",NULL};
        execve("/bin/profile-probe",arguments,environment);die("fixed-profile-probe-exec");
    }
    line("O1A_DIAG_PARENT attempt=%s child=%ld child_deadline_seconds=30 poweroff_alarm_seconds=55\n",attempt,(long)pid);
    int child_reaped=0,status=0,killed=0,all_reaped=0;
    while(mono()-start<UINT64_C(50000000000)) {
        int one=0;pid_t got=waitpid(-1,&one,WNOHANG);
        if(got==pid){child_reaped=1;status=one;}
        else if(got<0&&errno==ECHILD){all_reaped=1;break;}
        else if(got<0&&errno!=EINTR)break;
        if(!killed&&!child_reaped&&mono()-start>=UINT64_C(30000000000)){checked(kill(pid,SIGKILL),"deadline-kill");killed=1;}
        struct timespec pause={.tv_nsec=10000000};(void)nanosleep(&pause,NULL);
    }
    stage="after-child";exact_lo();parent_status("after");
    line("O1A_DIAG_PARENT_RESULT attempt=%s child_reaped=%d all_children_reaped=%d killed=%d normal_exit=%d exit=%d scope=DIAGNOSTIC_ONLY_NOT_O1A_PASS\n",attempt,child_reaped,all_reaped,killed,child_reaped&&WIFEXITED(status),child_reaped&&WIFEXITED(status)?WEXITSTATUS(status):-1);
    poweroff_now(0);return 127;
}
