#define _GNU_SOURCE
/* Reuse the accepted capability/seccomp code byte-for-byte; main below never
 * calls its original Go entry or accepts any executable/path arguments. */
static _Noreturn void fail(const char *stage);
#define main unused_frozen_capexec_main
#include "frozen_capexec.c"
#undef main
#include <grp.h>
#include <poll.h>
#include <time.h>
#include <stdarg.h>
#include <sys/statfs.h>
#include <sys/statvfs.h>
#include <sys/wait.h>
#include <sys/xattr.h>

#define PARENT "/profiles/loadstand-11111111111111111111111111111111"
#define MEMBER PARENT "/member-1"
static unsigned output_bytes;
static uint64_t output_deadline_ns;
static _Noreturn void log_failure(const char *reason,int code,int error) {
    /* stderr is explicitly NONBLOCK before normal events; if it cannot accept
     * this best-effort line, the distinct normal exit code remains evidence. */
    char line[192];int n=snprintf(line,sizeof(line),"O1A_PROFILE_LOG_FAIL reason=%s code=%d errno=%d\n",reason,code,error);
    int flags=fcntl(STDERR_FILENO,F_GETFL);
    if(n>0&&(size_t)n<sizeof(line)&&flags>=0&&(flags&O_NONBLOCK)) {
        ssize_t ignored=write(STDERR_FILENO,line,(size_t)n);(void)ignored;
    }
    _exit(code);
}
static uint64_t log_now(void) {
    struct timespec value;
    if(clock_gettime(CLOCK_MONOTONIC,&value))log_failure("clock",142,errno);
    return (uint64_t)value.tv_sec*UINT64_C(1000000000)+(uint64_t)value.tv_nsec;
}
static void log_setup(void) {
    if(output_deadline_ns)return; /* The same absolute deadline is inherited. */
    output_deadline_ns=log_now()+UINT64_C(15000000000);
    int flags=fcntl(STDOUT_FILENO,F_GETFL);
    if(flags<0)log_failure("stdout-flags",147,errno);
    if(!(flags&O_NONBLOCK))log_failure("stdout-not-nonblocking",147,0);
    flags=fcntl(STDERR_FILENO,F_GETFL);
    if(flags<0)log_failure("stderr-flags",147,errno);
    if(fcntl(STDERR_FILENO,F_SETFL,flags|O_NONBLOCK))log_failure("stderr-nonblock",147,errno);
}
static void write_event(const char *line,size_t size) {
    size_t at=0;int last_error=0;
    while(at<size) {
        uint64_t now=log_now();
        if(now>=output_deadline_ns)log_failure("absolute-deadline",145,last_error);
        ssize_t wrote=write(STDOUT_FILENO,line+at,size-at);
        if(wrote>0){at+=(size_t)wrote;continue;}
        if(wrote==0)log_failure("zero-write",146,0);
        int error=errno;last_error=error;
        if(error==EINTR)continue;
        if(error!=EAGAIN&&error!=EWOULDBLOCK)log_failure("write",143,error);
        now=log_now();if(now>=output_deadline_ns)log_failure("absolute-deadline",145,last_error);
        uint64_t ms=(output_deadline_ns-now+UINT64_C(999999))/UINT64_C(1000000);
        int timeout=(int)(ms>200?200:ms);
        struct pollfd descriptor={.fd=STDOUT_FILENO,.events=POLLOUT};
        int ready=poll(&descriptor,1,timeout);
        if(ready<0){if(errno==EINTR)continue;log_failure("poll",144,errno);}
        if(ready>0&&(descriptor.revents&(POLLERR|POLLHUP|POLLNVAL)))log_failure("poll-revents",144,0);
    }
}
static void event(const char *format, ...) {
    log_setup();char line[512];va_list ap;va_start(ap,format);
    int n=vsnprintf(line,sizeof(line),format,ap);va_end(ap);
    if(n<0||(size_t)n>=sizeof(line))log_failure("format",140,0);
    if(output_bytes+(unsigned)n>16384)log_failure("byte-budget",141,0);
    output_bytes+=(unsigned)n;write_event(line,(size_t)n);
}
static void reliable_status(struct status s) {
    event("O1A_CAPEXEC_STATUS uid=%lu euid=%lu gid=%lu egid=%lu threads=%u inh=%016" PRIx64 " prm=%016" PRIx64 " eff=%016" PRIx64 " bnd=%016" PRIx64 " amb=%016" PRIx64 " nnp=%u seccomp=%u filters=%u\n",(unsigned long)getuid(),(unsigned long)geteuid(),(unsigned long)getgid(),(unsigned long)getegid(),s.threads,s.inh,s.prm,s.eff,s.bnd,s.amb,s.nnp,s.seccomp,s.filters);
}
static void op(const char *stage,long rc,int error) {
    event("O1A_PROFILE_FS op=%s rc=%ld errno=%d\n",stage,rc,rc<0?error:0);
}
static long checked(const char *stage,long rc,int error) {
    op(stage,rc,error);if(rc<0)_exit(125);return rc;
}
static void pred(const char *stage,int ok) {
    event("O1A_PROFILE_FS predicate=%s ok=%d\n",stage,!!ok);if(!ok)_exit(125);
}
#define CALL(stage,expression) ({errno=0;long rc_=(long)(expression);int err_=errno;checked((stage),rc_,err_);})
static struct stat fdstat(const char *stage,int fd) {
    struct stat st;CALL(stage,fstat(fd,&st));
    event("O1A_PROFILE_FS stat=%s uid=%lu gid=%lu mode=%o dev=%" PRIu64 " ino=%" PRIu64 " nlink=%lu\n",stage,(unsigned long)st.st_uid,(unsigned long)st.st_gid,st.st_mode,(uint64_t)st.st_dev,(uint64_t)st.st_ino,(unsigned long)st.st_nlink);return st;
}
static void fsobserve(const char *label,int fd) {
    struct stat observed;errno=0;int sr=fstat(fd,&observed);int se=errno;op("observe-mountpoint-fstat",sr,se);
    if(!sr)event("O1A_PROFILE_FS mountstat=%s uid=%lu gid=%lu mode=%o dev=%" PRIu64 " ino=%" PRIu64 "\n",label,(unsigned long)observed.st_uid,(unsigned long)observed.st_gid,observed.st_mode,(uint64_t)observed.st_dev,(uint64_t)observed.st_ino);
    struct statfs fs;errno=0;int rc=fstatfs(fd,&fs);int error=errno;op(label,rc,error);
    if(!rc)event("O1A_PROFILE_FS fs=%s type=%lx flags=%lx block_size=%lu\n",label,(unsigned long)fs.f_type,(unsigned long)fs.f_flags,(unsigned long)fs.f_bsize);
    struct statvfs v;errno=0;rc=fstatvfs(fd,&v);error=errno;op("observe-statvfs",rc,error);
    if(!rc)event("O1A_PROFILE_FS capacity=%s bytes=%" PRIu64 " flags=%lu\n",label,(uint64_t)v.f_frsize*(uint64_t)v.f_blocks,(unsigned long)v.f_flag);
    /* Observational calls are not extra original profile predicates. */
}
static void auditfd(const char *label,int fd,int directory) {
    struct stat st=fdstat(label,fd);
    pred("final-mode-type-owner",(st.st_mode&07777)==(directory?0700:0600)&&((directory&&S_ISDIR(st.st_mode))||(!directory&&S_ISREG(st.st_mode)))&&st.st_uid==geteuid());
    errno=0;ssize_t rc=fgetxattr(fd,"system.posix_acl_access",NULL,0);int error=errno;
    op(directory?"member-fgetxattr-access-acl":"probe-fgetxattr-access-acl",rc,error);
    pred("original-access-acl-outcome",rc>=0||(rc==-1&&error==ENODATA));
}
static void inspect_path(const char *label,const char *path,struct stat *st) {
    CALL(label,lstat(path,st));
    event("O1A_PROFILE_FS pathstat=%s uid=%lu gid=%lu mode=%o dev=%" PRIu64 " ino=%" PRIu64 "\n",label,(unsigned long)st->st_uid,(unsigned long)st->st_gid,st->st_mode,(uint64_t)st->st_dev,(uint64_t)st->st_ino);
}
static void secret_location_mirror(int memberfd,const char *label,const char *name) {
    const char *paths[]={"/","/profiles",PARENT,MEMBER};
    const char *labels[]={"audit-root","audit-profiles","audit-parent","audit-member"};
    int parent_shared=0;
    for(unsigned i=0;i<4;i++) {
        struct stat st;inspect_path(labels[i],paths[i],&st);
        pred("ancestor-directory",S_ISDIR(st.st_mode));
        pred("ancestor-owner",st.st_uid==geteuid()||st.st_uid==0);
        pred("sticky-child-owned",!parent_shared||st.st_uid==geteuid());
        int writable=(st.st_mode&0022)!=0;
        pred("writable-directory-sticky",!writable||(st.st_mode&S_ISVTX));
        parent_shared=writable&&(st.st_mode&S_ISVTX);
    }
    struct stat file;errno=0;int rc=fstatat(memberfd,name,&file,AT_SYMLINK_NOFOLLOW);int error=errno;op(label,rc,error);
    if(rc<0)pred("missing-secret-file-allowed",error==ENOENT);
    else pred("existing-secret-file-private",S_ISREG(file.st_mode)&&file.st_uid==geteuid()&&(file.st_mode&0777)==0600);
    /* Linux secretfile auditPathACL/auditDescriptorACL are original no-ops. */
}
static void nonroot_profile(int parentfd,struct stat expected) {
    CALL("setgroups-empty",setgroups(0,NULL));CALL("setresgid",setresgid(65532,65532,65532));CALL("setresuid",setresuid(65532,65532,65532));CALL("helper-pdeathsig",prctl(PR_SET_PDEATHSIG,SIGKILL,0,0,0));
    struct status s=read_status();reliable_status(s);
    long groups=CALL("getgroups-count",getgroups(0,NULL));
    pred("same-helper-credentials",getuid()==65532&&geteuid()==65532&&getgid()==65532&&getegid()==65532&&groups==0);
    pred("same-helper-policy",s.threads==1&&s.inh==0&&s.prm==0&&s.eff==0&&s.amb==0&&s.bnd==ALLOWED&&s.nnp==1&&s.seccomp==2&&s.filters==1);
    struct rlimit core;CALL("getrlimit-core",getrlimit(RLIMIT_CORE,&core));pred("same-helper-core-zero",core.rlim_cur==0&&core.rlim_max==0);
    struct stat parent=fdstat("inherited-parent-fstat",parentfd);
    pred("original-parent-binding",parent.st_uid==0&&(parent.st_mode&07777)==01777&&parent.st_dev==expected.st_dev&&parent.st_ino==expected.st_ino);
    CALL("member-mkdirat",mkdirat(parentfd,"member-1",0700));
    int fd=(int)CALL("member-openat",openat(parentfd,"member-1",O_RDONLY|O_DIRECTORY|O_NOFOLLOW|O_CLOEXEC));
    auditfd("member-fstat",fd,1);fsobserve("member-filesystem",fd);
    struct stat byfd=fdstat("member-samefile-fstat",fd),bypath;inspect_path("member-lstat",MEMBER,&bypath);
    pred("original-samefile-directory",byfd.st_dev==bypath.st_dev&&byfd.st_ino==bypath.st_ino&&S_ISDIR(bypath.st_mode));
    int probe=(int)CALL("acl-probe-openat",openat(fd,".acl-probe",O_RDWR|O_CREAT|O_EXCL|O_NOFOLLOW|O_CLOEXEC,0600));
    auditfd("probe-fstat",probe,0);CALL("acl-probe-close",close(probe));CALL("acl-probe-unlinkat",unlinkat(fd,".acl-probe",0));
    /* Original MkdirAll sees existing member, then creates only member/tmp. */
    struct stat st;inspect_path("prepare-member-lstat",MEMBER,&st);pred("prepare-member0700",S_ISDIR(st.st_mode)&&(st.st_mode&0777)==0700);
    CALL("prepare-tmp-mkdirat",mkdirat(fd,"tmp",0700));inspect_path("prepare-tmp-lstat",MEMBER"/tmp",&st);pred("prepare-tmp0700",S_ISDIR(st.st_mode)&&(st.st_mode&0777)==0700);
    secret_location_mirror(fd,"audit-identity-missing","identity.json");
    secret_location_mirror(fd,"audit-intents-missing","identity-intents.json");
    secret_location_mirror(fd,"audit-childlog-missing","child.log");
    secret_location_mirror(fd,"audit-receipts-missing","receipts.jsonl");
    CALL("member-close",close(fd));CALL("parent-child-close",close(parentfd));
    event("O1A_PROFILE_FS result=MIRROR_PROFILE_COMPLETE not_original_Go_verdict=1\n");_exit(0);
}
int main(int argc,char **argv) {
    (void)argv;pred("fixed-no-argument-entry",argc==1);struct status before=read_status();pred("single-root-start",getuid()==0&&geteuid()==0&&before.threads==1);
    restrict_caps();install_policy_and_controls();
    int base=(int)CALL("root-profiles-open",open("/profiles",O_RDONLY|O_DIRECTORY|O_NOFOLLOW|O_CLOEXEC));fsobserve("profiles-filesystem",base);
    int tmp=(int)CALL("root-tmp-open",open("/tmp",O_RDONLY|O_DIRECTORY|O_NOFOLLOW|O_CLOEXEC));fsobserve("tmp-filesystem",tmp);CALL("root-tmp-close",close(tmp));
    CALL("root-parent-mkdirat",mkdirat(base,"loadstand-11111111111111111111111111111111",01777));
    int parent=(int)CALL("root-parent-openat",openat(base,"loadstand-11111111111111111111111111111111",O_RDONLY|O_DIRECTORY|O_NOFOLLOW|O_CLOEXEC));CALL("root-parent-fchmod",fchmod(parent,01777));struct stat expected=fdstat("root-parent-fstat",parent);CALL("root-base-close",close(base));
    fflush(NULL);pid_t pid=(pid_t)CALL("fork-nonroot",fork());
    if(pid==0)nonroot_profile(parent,expected);
    int status=0;CALL("waitpid-nonroot",waitpid(pid,&status,0));CALL("root-parent-close",close(parent));
    event("O1A_PROFILE_FS child_normal=%d child_exit=%d\n",WIFEXITED(status),WIFEXITED(status)?WEXITSTATUS(status):-1);
    return WIFEXITED(status)&&WEXITSTATUS(status)==0?0:1;
}
