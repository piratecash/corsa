"""Exact stopped-only ACK after ROOT+TESTER+REVIEWER DATA review; never launches."""
import json
import os
from pathlib import Path
import sys
from support import need,read_record,file_digest,hash_bytes,lock_identity,exclusive_json,LOCK,PROFILE,LIMITS
from verify import decode,check_lifecycle,guest_receipt

def read_raw(path,limit):
    need(not path.is_symlink() and path.is_file() and path.stat().st_size<=limit,'RAW file')
    with path.open('rb') as stream:raw=stream.read(limit+1)
    need(len(raw)<=limit,'RAW bound');return raw

def main():
    need(len(sys.argv)==2,'exact owned work path required')
    work=Path(sys.argv[1]);need(work.is_absolute() and work.resolve()==work,'canonical work')
    expected=decode(read_record(work/'expected.json'));receipt=decode(read_record(work/'receipt.json'))
    need(work.name=='corsa-d1-o1a-profile-fs-native-'+expected['attempt_id'],'exact own work')
    reviews=decode(read_record(work/'REVIEWS.json'))
    need(set(reviews)=={'ROOT','TESTER','REVIEWER'} and all(row['status']=='ACCEPTED_VM_STOPPED_ONLY' and row['work']==str(work) for row in reviews.values()),'three actual DATA reviews')
    raw={name:read_raw(work/file,limit) for name,file,limit in [('console','console.raw',4*1024**2),('native','native.jsonl',16384),('stderr','stderr.raw',4096)]}
    check_lifecycle(expected,receipt,raw['console'],raw['native'],raw['stderr']);guest=guest_receipt(expected,raw['console'])
    binding=decode(read_record(work/'lock-binding.json'));custody=lock_identity()
    need(list(custody[0])==binding['directory_stamp'] and list(custody[1])==binding['owner_stamp'] and hash_bytes(custody[2])==binding['owner_sha256'],'lock identity changed')
    owner=dict(line.split('=',1) for line in custody[2].decode('ascii').splitlines())
    need(owner['name']==PROFILE and owner['attempt_id']==expected['attempt_id'] and owner['grant_sha256']==expected['handoff_sha256'],'exact own lock metadata')
    handoff_raw=read_record(Path(__file__).resolve().parent/'HANDOFF.json');need(hash_bytes(handoff_raw)==expected['handoff_sha256'],'handoff changed');handoff=decode(handoff_raw)
    for name,row in handoff['inputs'].items():need(file_digest(Path(row['path']),LIMITS[name])[0]==file_digest(work/name,LIMITS[name])[0]==row['sha256']==expected[name+'_sha256'],'input/copy changed')
    start=decode(read_record(work/'worker-start.json'));need(start['attempt_id']==expected['attempt_id'] and start['pid']==receipt['worker_pid']==start['pgid'],'worker binding')
    pids={int(owner['pid']),int(start['pid'])};groups={int(owner['pgid']),int(start['pgid'])}
    need(all(value>1 for value in pids|groups) and os.getpid() not in pids and os.getpgrp() not in groups,'PID scope')
    for value in pids:
        try:os.kill(value,0)
        except ProcessLookupError:pass
        else:raise ValueError('own PID remains/reused; no action')
    for value in groups:
        try:os.killpg(value,0)
        except ProcessLookupError:pass
        else:raise ValueError('own PGID remains/reused; no action')
    need(custody==lock_identity() and {path.name for path in LOCK.iterdir()}=={'owner'},'lock changed')
    record={'scope':'NORMAL_VM_STOP_ACK_ONLY_NOT_O1A_PASS','attempt_id':expected['attempt_id'],'guest_parent':guest,'physical_XPC_resources':'UNKNOWN','reviews':reviews,'lock_binding':binding,'own_pids_absent':sorted(pids),'own_groups_absent':sorted(groups)}
    exclusive_json(work/'ACK.json',record);need(custody==lock_identity(),'lock changed during ACK')
    (LOCK/'owner').unlink();LOCK.rmdir()
    print(json.dumps({'scope':record['scope'],'own_lock_removed':True,'work':str(work)}))

if __name__=='__main__':main()
