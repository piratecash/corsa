import copy
import gzip
import hashlib
import json
import struct
import unittest
from unittest import mock
import assembly
import capture_worker
import decode_diag
import launch
import support
import verify

def elf(tag):
    raw=bytearray(128);raw[:16]=b'\x7fELF\x02\x01\x01'+bytes(9)
    struct.pack_into('<HHIQQQIHHHHHH',raw,16,2,183,1,0,64,0,0,64,56,1,0,0,0)
    struct.pack_into('<IIQQQQQQ',raw,64,1,5,0,0,0,len(raw),len(raw),4096);raw[-1]=tag;return bytes(raw)

def console(attempt='a'*32):
    base=f'attempt={attempt} uid=0 euid=0 gid=0 egid=0 seccomp=0 boot_effective=1 boot_bounding=1 core_cur=0 core_max=0'
    return (f'O1A_POLICY_PARENT {base} stage=before\n'
        f'O1A_DIAG_PARENT attempt={attempt} child=2 child_deadline_seconds=30 poweroff_alarm_seconds=55\n'
        'O1A_CAPEXEC_STATUS uid=0 euid=0 gid=0 egid=0 threads=1 inh=0000000000000000 prm=00000000002010c0 eff=00000000002010c0 bnd=00000000002010c0 amb=0000000000000000 nnp=1 seccomp=2 filters=1\n'
        'O1A_POLICY_CONTROLS pre_mode=0 post_mode=2 filters=1 unshare_pre=0 unshare_post_errno=1 setns_pre_errno=9 setns_post_errno=1 unix_socket_closed=1 netns_unchanged=1\n'
        'O1A_PROFILE_FS op=root-profiles-open rc=3 errno=0\n'
        'O1A_CAPEXEC_STATUS uid=65532 euid=65532 gid=65532 egid=65532 threads=1 inh=0000000000000000 prm=0000000000000000 eff=0000000000000000 bnd=00000000002010c0 amb=0000000000000000 nnp=1 seccomp=2 filters=1\n'
        'O1A_PROFILE_FS predicate=same-helper-policy ok=1\n'
        'O1A_PROFILE_FS result=MIRROR_PROFILE_COMPLETE not_original_Go_verdict=1\n'
        'O1A_PROFILE_FS child_normal=1 child_exit=0\n'
        f'O1A_POLICY_PARENT {base} stage=after\n'
        f'O1A_DIAG_PARENT_RESULT attempt={attempt} child_reaped=1 all_children_reaped=1 killed=0 normal_exit=1 exit=0 scope=DIAGNOSTIC_ONLY_NOT_O1A_PASS\n').encode()

class Tests(unittest.TestCase):
    def test_two_static_c_archive_complete_roundtrip(self):
        pair=(elf(1),elf(2));pins={name:{'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()} for name,data in zip(('init','bin/profile-probe'),pair)}
        with mock.patch.object(assembly,'pins',return_value=pins):
            raw=assembly.make(pair,'a'*32);report=assembly.readback(raw,pair,'a'*32)
            self.assertEqual(len(report['members']),8);self.assertEqual(assembly.readback(raw,None,'a'*32),report)
            with self.assertRaises(ValueError):assembly.readback(raw,pair,'b'*32)
            plain=gzip.decompress(raw)
            with self.assertRaises(ValueError):assembly.readback(gzip.compress(plain+b'extra'),pair,'a'*32)
    def test_changed_payload_mode_dynamic_elf_refused(self):
        pair=(elf(1),elf(2));pins={name:{'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()} for name,data in zip(('init','bin/profile-probe'),pair)}
        with mock.patch.object(assembly,'pins',return_value=pins):
            raw=assembly.make(pair,'a'*32);plain=gzip.decompress(raw)
            for changed in (plain.replace(b'0000816d',b'000081ed',1),plain.replace(pair[1],elf(3),1)):
                with self.assertRaises(ValueError):assembly.readback(gzip.compress(changed),None,'a'*32)
            changed=bytearray(pair[0]);struct.pack_into('<H',changed,16,3)
            changed=bytes(changed);pins['init']={'bytes':len(changed),'sha256':hashlib.sha256(changed).hexdigest()}
            with self.assertRaises(ValueError):assembly.make((changed,pair[1]),'a'*32)
    def test_actual_control_fields_and_order_pass(self):
        self.assertEqual(decode_diag.decode(console(),'a'*32)['outcome'],'MIRROR_PROFILE_COMPLETE_NOT_ORIGINAL_GO_VERDICT')
    def test_missing_changed_reordered_duplicate_or_failed_controls_refused(self):
        raw=console()
        for bad in (raw.replace(b'pre_mode=0',b'pre_mode=2'),raw.replace(b'netns_unchanged=1',b'netns_unchanged=0'),raw.replace(b'core_max=0',b'core_max=1'),raw.replace(b'filters=1',b'filters=0'),raw.replace(b'seccomp=0 boot',b'seccomp=2 boot'),raw.replace(b'unix_socket_closed=1',b'unix_socket_closed=0'),raw.replace(b'normal_exit=1 exit=0',b'normal_exit=1 exit=125'),raw+b'O1A_CAPEXEC_FAIL stage=failure errno=22\n',raw+raw,raw.replace(b'pre_mode=0 ',b'pre_mode=0 pre_mode=0 ')):
            with self.subTest(size=len(bad)),self.assertRaises(ValueError):decode_diag.decode(bad,'a'*32)
        with self.assertRaises(ValueError):decode_diag.decode(raw,'b'*32)
    def test_native_scope_and_full_lifecycle_are_required(self):
        expected,receipt,native=self.retained();out=verify.replay(expected,receipt,console(),native,b'')
        self.assertEqual(out['diagnostic']['outcome'],'MIRROR_PROFILE_COMPLETE_NOT_ORIGINAL_GO_VERDICT')
        for key,value in (('worker_exit',1),('owned_group_absent',False),('input_recheck',False),('worker_reaped_ns',400*10**9)):
            changed=copy.deepcopy(receipt);changed[key]=value
            with self.assertRaises(ValueError):verify.check_lifecycle(expected,changed,console(),native,b'')
    def test_stopped_only_ack_preserves_failed_child(self):
        failed=console().replace(b'normal_exit=1 exit=0',b'normal_exit=1 exit=125')
        self.assertEqual(verify.guest_receipt({'attempt_id':'a'*32},failed)['exit'],'125')
        with self.assertRaises(ValueError):decode_diag.decode(failed,'a'*32)
    def test_false_readiness_and_original_short_deadlines(self):
        with self.assertRaises(ValueError):launch.validate({'profile':support.PROFILE,'workload':'profile-fs-mirror','attempt_id':'a'*32,'files':{},'inputs':{},'assembly':{},'readiness':{'CODE':False,'QA':True,'ROOT':False}})
        self.assertEqual((capture_worker.Deadlines().work,capture_worker.Deadlines().kill,capture_worker.Deadlines().reap),(360*10**9,398*10**9,400*10**9))
    def test_real_mirror_failure_retains_errno_not_go_verdict(self):
        raw=console().replace(b'O1A_PROFILE_FS result=MIRROR_PROFILE_COMPLETE not_original_Go_verdict=1\n',b'O1A_PROFILE_FS op=member-fgetxattr-access-acl rc=-1 errno=95\nO1A_PROFILE_FS predicate=original-access-acl-outcome ok=0\n').replace(b'child_exit=0',b'child_exit=125').replace(b'normal_exit=1 exit=0',b'normal_exit=1 exit=1')
        data=decode_diag.decode(raw,'a'*32)
        self.assertEqual(data['outcome'],'MIRROR_FAILED_DIAGNOSTIC_ONLY');self.assertEqual(data['outer_exit'],1)
        self.assertEqual(data['negative_operation_or_predicate_observations'][0]['record']['errno'],'95')
        self.assertFalse(data['apps_or_Go_executed'])
    def test_observational_error_does_not_create_original_gate(self):
        raw=console().replace(b'O1A_PROFILE_FS predicate=same-helper-policy ok=1',b'O1A_PROFILE_FS op=observe-statvfs rc=-1 errno=95\nO1A_PROFILE_FS predicate=same-helper-policy ok=1')
        self.assertEqual(decode_diag.decode(raw,'a'*32)['outcome'],'MIRROR_PROFILE_COMPLETE_NOT_ORIGINAL_GO_VERDICT')
    def test_malformed_duplicate_fields_or_negative_success_predicate_refused(self):
        for raw in (console().replace(b'rc=3',b'rc=3 rc=3'),console().replace(b'ok=1',b'ok=0'),console().replace(b'errno=0',b'errno=5000'),console().replace(b'op=root-profiles-open',b'op=../../escape')):
            with self.assertRaises(ValueError):decode_diag.decode(raw,'a'*32)
    def retained(self):
        expected={'profile':support.PROFILE,'workload':'profile-fs-mirror','attempt_id':'a'*32,'handoff_sha256':'b'*64,'kernel_sha256':'c'*64,'initrd_sha256':'d'*64,'launcher_sha256':'e'*64}
        events=[dict(attempt_id='a'*32,seq=i,event=stage,elapsed_ns=i*10**9,**extra) for i,(stage,extra) in enumerate((('ready',{}),('start_ok',{}),('guest_stopped',{'guest_error':None}),('stop_complete',{'final_state':'stopped'})),1)]
        native=b''.join((json.dumps(row)+'\n').encode() for row in events)
        captures={name:{'received':len(raw),'retained':len(raw),'eof':True,'sha256':hashlib.sha256(raw).hexdigest()} for name,raw in (('console',console()),('native',native),('stderr',b''))}
        receipt=dict(expected,input_recheck=True,controller_stop=False,outer_kill=False,stop_reason=None,worker_reaped=True,owned_group_absent=True,capture_complete=True,worker_exit=0,worker_reaped_ns=5*10**9,captures=captures)
        return expected,receipt,native

if __name__=='__main__':unittest.main()
