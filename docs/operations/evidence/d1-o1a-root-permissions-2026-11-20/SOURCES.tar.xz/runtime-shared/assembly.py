"""Reuse the accepted tiny newc format, binding two compiled static C ELF data."""
from pathlib import Path
import gzip
import hashlib
import io
import json
import re
import stat
import struct

HERE=Path(__file__).resolve().parent

def need(ok,why):
    if not ok:raise ValueError(why)
def sha(raw):return hashlib.sha256(raw).hexdigest()
def pins():
    with (HERE/'ARTIFACTS.json').open('rb') as stream:raw=stream.read(32769)
    need(len(raw)<=32768,'artifact pin bound');out=json.loads(raw)
    need(out['policy_header_sha256']=='699c0a05f15cdf93c620326a2bc1112b53932f06dc08bd6a343076b22416162c' and out['pure_factory_controls']==52,'original compiled policy')
    need(set(out['binaries'])=={'init','bin/profile-probe'},'two fixed C artifacts')
    for row in out['binaries'].values():need(set(row)=={'bytes','sha256'} and type(row['bytes']) is int and 64<=row['bytes']<=1024**2 and re.fullmatch('[0-9a-f]{64}',row['sha256']),'artifact metadata')
    return out['binaries']

def elf_check(raw,name):
    wanted=pins()[name]
    need(type(raw) is bytes and len(raw)==wanted['bytes'] and sha(raw)==wanted['sha256'],'exact compiled fixed C ELF')
    need(raw[:7]==b'\x7fELF\x02\x01\x01','static AArch64 ELF')
    typ,machine,version,_,off,_,_,size,ents,count,_,_,_=struct.unpack_from('<HHIQQQIHHHHHH',raw,16)
    need(typ==2 and machine==183 and version==1 and size==64 and ents==56 and 0<count<=128 and 64<=off<=len(raw)-56*count,'static ET_EXEC header')
    for index in range(count):
        kind,_,start,_,_,filesz,_,_=struct.unpack_from('<IIQQQQQQ',raw,off+56*index)
        need(kind not in (2,3) and start<=len(raw) and filesz<=len(raw)-start,'static segment')

def entry(name,mode,data,ino):
    major,minor=(5,1) if name=='dev/console' else (0,0)
    fields=(ino,mode,0,0,2 if stat.S_ISDIR(mode) else 1,0,len(data),0,0,major,minor,len(name)+1,0)
    head=b'070701'+''.join(f'{x:08x}' for x in fields).encode()+name.encode()+b'\0'
    return head+bytes((-len(head))%4)+data+bytes((-len(data))%4)
def layout(pair,attempt):
    need(type(attempt) is str and re.fullmatch('[0-9a-f]{32}',attempt),'fresh attempt format')
    init,capexec=pair if pair is not None else (None,None)
    return [('dev',stat.S_IFDIR|0o755,b''),('dev/console',stat.S_IFCHR|0o600,b''),('proc',stat.S_IFDIR|0o555,b''),('sys',stat.S_IFDIR|0o555,b''),('bin',stat.S_IFDIR|0o555,b''),('diag-attempt',stat.S_IFREG|0o444,attempt.encode()),('init',stat.S_IFREG|0o555,init),('bin/profile-probe',stat.S_IFREG|0o555,capexec)]
def make(pair,attempt):
    need(type(pair) is tuple and len(pair)==2,'two C ELF data')
    elf_check(pair[0],'init');elf_check(pair[1],'bin/profile-probe')
    rows=layout(pair,attempt);raw=b''.join(entry(n,m,d,i) for i,(n,m,d) in enumerate(rows,1))
    raw+=entry('TRAILER!!!',0,b'',len(rows)+1);raw+=bytes((-len(raw))%512)
    return gzip.compress(raw,compresslevel=9,mtime=0)
def readback(archive,pair,attempt):
    need(type(archive) is bytes and 0<len(archive)<=2*1024**2,'gzip bound')
    with gzip.GzipFile(fileobj=io.BytesIO(archive)) as stream:raw=stream.read(4*1024**2+1)
    need(len(raw)<=4*1024**2,'newc bound');at=0;rows=[]
    for number,(name,wantmode,wantdata) in enumerate([*layout(pair,attempt),('TRAILER!!!',0,b'')],1):
        need(raw[at:at+6]==b'070701' and at+110<=len(raw),'newc header');fields=[int(raw[at+6+8*i:at+14+8*i],16) for i in range(13)]
        ino,mode,uid,gid,nlink,mtime,size,major,minor,rmajor,rminor,namesize,check=fields
        need(ino==number and size<=1024**2 and namesize==len(name)+1 and uid==gid==mtime==major==minor==check==0,'newc metadata')
        need(mode==wantmode and nlink==(2 if stat.S_ISDIR(mode) else 1),'newc mode/nlink')
        need((rmajor,rminor)==((5,1) if name=='dev/console' else (0,0)),'newc device')
        start=at+110;need(raw[start:start+namesize]==name.encode()+b'\0','newc name/order');end=start+namesize;need(not any(raw[end:(end+3)&~3]),'name padding');start=(end+3)&~3
        data=raw[start:start+size];need(len(data)==size,'newc complete data')
        if name in ('init','bin/profile-probe'):elf_check(data,name)
        if wantdata is not None:need(data==wantdata,'newc data')
        else:need(name in ('init','bin/profile-probe'),'only deferred C ELF')
        end=start+size;need(not any(raw[end:(end+3)&~3]),'data padding');at=(end+3)&~3
        if name!='TRAILER!!!':rows.append({'path':name,'mode':oct(mode),'bytes':size,'sha256':sha(data)})
    need(0<=len(raw)-at<512 and not any(raw[at:]),'newc trailer')
    return {'scope':'MINIMAL_PROFILE_FS_INITRD_DATA_READBACK_ONLY','attempt_id':attempt,'binaries':pins(),'archive':{'bytes':len(archive),'sha256':sha(archive)},'members':rows,'elf_or_vm_executed':False}
