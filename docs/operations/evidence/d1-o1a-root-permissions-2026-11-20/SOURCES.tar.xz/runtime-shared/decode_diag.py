"""Strict retained-console FS mirror diagnostic, never an original Go verdict."""
import re
FOUR=(1<<6)|(1<<7)|(1<<12)|(1<<21)
def need(ok,why):
    if not ok:raise ValueError(why)
def fields(line,prefix):
    need(line.startswith(prefix+b' ') and len(line)<=2048,'record prefix/size');out={}
    for word in line.decode('ascii').split()[1:]:
        need(word.count('=')==1,'field framing');k,v=word.split('=');need(k not in out,'duplicate field');out[k]=v
    return out
def integer(value):
    need(re.fullmatch(r'-?(0|[1-9][0-9]*)',value) is not None and len(value)<=21,'bounded numeric value');return int(value)
def fsrecord(row):
    schema={
      'op':{'op','rc','errno'},'predicate':{'predicate','ok'},
      'stat':{'stat','uid','gid','mode','dev','ino','nlink'},
      'mountstat':{'mountstat','uid','gid','mode','dev','ino'},
      'pathstat':{'pathstat','uid','gid','mode','dev','ino'},
      'fs':{'fs','type','flags','block_size'},'capacity':{'capacity','bytes','flags'},
      'result':{'result','not_original_Go_verdict'},'child_normal':{'child_normal','child_exit'}}
    kinds=set(row)&set(schema);need(len(kinds)==1,'one FS record kind');kind=next(iter(kinds));need(set(row)==schema[kind],'FS record fields')
    if kind=='result':need(row=={'result':'MIRROR_PROFILE_COMPLETE','not_original_Go_verdict':'1'},'C-only completion marker');return kind
    if kind=='child_normal':need(row['child_normal'] in ('0','1') and -1<=integer(row['child_exit'])<=255,'inner child result');return kind
    need(re.fullmatch('[a-z][a-z0-9-]{0,63}',row[kind]) is not None,'fixed safe stage label')
    for k,v in row.items():
        if k==kind:continue
        if k=='mode':need(re.fullmatch('[0-7]{1,7}',v) is not None,'octal mode')
        elif kind=='fs' and k in ('type','flags'):need(re.fullmatch('[0-9a-f]{1,16}',v) is not None,'hex fs scalar')
        else:integer(v)
    if kind=='op':need(-1<=integer(row['rc']) and 0<=integer(row['errno'])<=4095 and (row['rc']=='-1' or row['errno']=='0'),'operation errno')
    if kind=='predicate':need(row['ok'] in ('0','1'),'predicate result')
    return kind

def decode(raw,attempt):
    need(type(raw) is bytes and len(raw)<=4*1024**2 and re.fullmatch('[0-9a-f]{32}',attempt),'console/attempt bound');rows=raw.splitlines()
    need(not any(b'O1A_CAPEXEC_FAIL' in x or b'O1A_POLICY_INIT_FAIL' in x for x in rows),'native policy/init failure; not FS result')
    def selected(prefix):return [(i,fields(x,prefix)) for i,x in enumerate(rows) if x.startswith(prefix+b' ')]
    parents=selected(b'O1A_POLICY_PARENT');need(len(parents)==2,'two parent witnesses')
    expected={'attempt':attempt,'uid':'0','euid':'0','gid':'0','egid':'0','seccomp':'0','boot_effective':'1','boot_bounding':'1','core_cur':'0','core_max':'0'}
    for (_,r),stage in zip(parents,('before','after')):need(r==dict(expected,stage=stage),'parent unfiltered/BOOT/core0')
    status=selected(b'O1A_CAPEXEC_STATUS');need(1<=len(status)<=2,'root and optional nonroot status')
    root={'uid':'0','euid':'0','gid':'0','egid':'0','threads':'1','inh':'0000000000000000','prm':f'{FOUR:016x}','eff':f'{FOUR:016x}','bnd':f'{FOUR:016x}','amb':'0000000000000000','nnp':'1','seccomp':'2','filters':'1'}
    need(status[0][1]==root,'root exact caps/NNP/policy')
    nonroot=dict(root,uid='65532',euid='65532',gid='65532',egid='65532',prm='0000000000000000',eff='0000000000000000')
    if len(status)==2:need(status[1][1]==nonroot,'helper credentials/cap0/policy')
    controls=selected(b'O1A_POLICY_CONTROLS');need(len(controls)==1 and controls[0][1]=={'pre_mode':'0','post_mode':'2','filters':'1','unshare_pre':'0','unshare_post_errno':'1','setns_pre_errno':'9','setns_post_errno':'1','unix_socket_closed':'1','netns_unchanged':'1'},'original actual mode/effects controls')
    terminals=selected(b'O1A_DIAG_PARENT_RESULT');need(len(terminals)==1,'one terminal parent');ti,terminal=terminals[0]
    need(set(terminal)=={'attempt','child_reaped','all_children_reaped','killed','normal_exit','exit','scope'} and terminal['attempt']==attempt and terminal['child_reaped']==terminal['all_children_reaped']=='1' and terminal['killed']=='0' and terminal['normal_exit']=='1' and terminal['scope']=='DIAGNOSTIC_ONLY_NOT_O1A_PASS','normal complete outer child reap')
    code=integer(terminal['exit']);need(0<=code<=255,'outer exit')
    starts=selected(b'O1A_DIAG_PARENT');need(len(starts)==1,'one fixed child');si,start=starts[0]
    need(set(start)=={'attempt','child','child_deadline_seconds','poweroff_alarm_seconds'} and start['attempt']==attempt and integer(start['child'])>1 and start['child_deadline_seconds']=='30' and start['poweroff_alarm_seconds']=='55','fixed child/deadline')
    need(parents[0][0]<si<status[0][0]<controls[0][0]<parents[1][0]<ti,'parent/policy order')
    fs=selected(b'O1A_PROFILE_FS');need(0<len(fs)<=256 and all(si<i<parents[1][0] for i,_ in fs),'bounded child FS records');parsed=[(i,fsrecord(r),r) for i,r in fs]
    complete=[(i,r) for i,k,r in parsed if k=='result'];need(len(complete)<=1,'duplicate completion');inner=[r for _,k,r in parsed if k=='child_normal'];need(len(inner)<=1,'duplicate inner reap')
    failures=[{'line':i,'record':r} for i,k,r in parsed if (k=='predicate' and r['ok']=='0') or (k=='op' and r['rc']=='-1')]
    if code==0:
        need(len(status)==2 and len(complete)==len(inner)==1 and inner[0]=={'child_normal':'1','child_exit':'0'},'complete mirror normal result')
        need(not any(k=='predicate' and r['ok']=='0' for _,k,r in parsed),'failed predicate with exit0')
        outcome='MIRROR_PROFILE_COMPLETE_NOT_ORIGINAL_GO_VERDICT'
    else:
        need(not complete,'failed outer child cannot claim complete mirror');outcome='MIRROR_FAILED_DIAGNOSTIC_ONLY'
    return {'scope':'C_PRIVATE_PROFILE_FS_MIRROR_ONLY_NOT_O1A_PASS','outcome':outcome,'outer_exit':code,'policy_controls':controls[0][1],'child_status':[r for _,r in status],'parent_unfiltered_before_after':True,'all_children_reaped':True,'fs_records':[r for _,_,r in parsed],'negative_operation_or_predicate_observations':failures,'cause_interpretation':'C mirror only; observational errno is not automatically original Go failure','apps_or_Go_executed':False}
