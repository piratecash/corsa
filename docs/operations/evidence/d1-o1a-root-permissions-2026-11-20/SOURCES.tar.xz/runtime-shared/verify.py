"""Retained-byte native safety and standalone guest diagnostic replay."""
import hashlib
import json
from support import need,PROFILE
from decode_diag import decode as diagnostic
SECOND=10**9

def decode(raw):
    def pairs(rows):
        out={}
        for key,value in rows:need(key not in out,'duplicate JSON key');out[key]=value
        return out
    return json.loads(raw,object_pairs_hook=pairs)

def check_capture(row,raw,limit):
    need(type(row) is dict and set(row)=={'received','retained','eof','sha256'},'capture schema')
    need(type(raw) is bytes and len(raw)<=limit and row['eof'] is True,'RAW bound/EOF')
    need(all(type(row[k]) is int and row[k]==len(raw) for k in ('received','retained')) and row['sha256']==hashlib.sha256(raw).hexdigest(),'RAW coverage/hash')

def check_lifecycle(expected,receipt,console,native,stderr):
    need(expected.get('profile')==PROFILE and expected.get('workload')=='profile-fs-mirror','expected profile')
    need(receipt['input_recheck'] is True and all(receipt.get(k)==v for k,v in expected.items()),'input binding/recheck')
    need(receipt['controller_stop'] is False and receipt['outer_kill'] is False and receipt['stop_reason'] is None and receipt['worker_reaped'] is True and receipt['owned_group_absent'] is True and receipt['capture_complete'] is True,'intervention/group/RAW')
    need(type(receipt['worker_exit']) is int and receipt['worker_exit']==0,'worker normal exit0')
    need(set(receipt['captures'])=={'console','native','stderr'},'three RAW required')
    for name,raw,limit in [('console',console,4*1024**2),('native',native,16384),('stderr',stderr,4096)]:check_capture(receipt['captures'][name],raw,limit)
    need(not stderr and native.endswith(b'\n'),'native stderr/truncated JSONL')
    rows=[decode(line) for line in native.splitlines()];need(len(rows)==4,'native event count')
    stages=('ready','start_ok','guest_stopped','stop_complete');extra=({}, {}, {'guest_error':None},{'final_state':'stopped'});previous=-1
    for seq,(row,stage,evidence) in enumerate(zip(rows,stages,extra),1):
        need(type(row) is dict and set(row)=={'attempt_id','seq','event','elapsed_ns',*evidence},'native event schema')
        need(row['attempt_id']==expected['attempt_id'] and type(row['seq']) is int and row['seq']==seq and row['event']==stage and all(row[k]==v for k,v in evidence.items()),'native event identity/order')
        need(type(row['elapsed_ns']) is int and previous<row['elapsed_ns']<(380 if stage=='stop_complete' else 360)*SECOND,'native deadlines')
        previous=row['elapsed_ns']
    need(type(receipt['worker_reaped_ns']) is int and previous<=receipt['worker_reaped_ns']<398*SECOND,'normal reap fence')
    return rows

def guest_receipt(expected,console):
    prefix=b'O1A_DIAG_PARENT_RESULT '
    rows=[line for line in console.splitlines() if line.startswith(prefix)]
    need(len(rows)==1 and len(rows[0])<=2048,'one parent result')
    fields={}
    for token in rows[0].decode('ascii').split()[1:]:
        key,value=token.split('=',1);need(key not in fields,'duplicate parent field');fields[key]=value
    need(set(fields)=={'attempt','child_reaped','all_children_reaped','killed','normal_exit','exit','scope'},'parent fields')
    need(fields['attempt']==expected['attempt_id'] and fields['scope']=='DIAGNOSTIC_ONLY_NOT_O1A_PASS','parent binding/scope')
    need(fields['child_reaped']==fields['all_children_reaped']=='1' and fields['killed'] in ('0','1') and fields['normal_exit'] in ('0','1'),'parent child completion')
    need(-1<=int(fields['exit'])<=255,'parent exit bound')
    # Child failure/killing is preserved; stopped-only safety ACK does not call it success.
    return fields

def replay(expected,receipt,console,native,stderr):
    events=check_lifecycle(expected,receipt,console,native,stderr)
    guest=guest_receipt(expected,console)
    data=diagnostic(console,expected['attempt_id'])
    return {'scope':'PRIVATE_PROFILE_FS_MIRROR_NOT_O1A_PASS','native_events':events,'guest_parent':guest,'diagnostic':data,'original_failed_attempt_cause':'UNKNOWN_FIRST_PREDICATE_NOT_RECOVERED','physical_XPC_resources':'UNKNOWN'}
