# О‑1а: точный безопасный root mode приватного PID1

SOURCE ONLY. Новый PID1 не собран и не запускался. Сохраняются все исходные
продуктовые4 Go ELF, kernel9ffe, capexec8c5c, exporter36ed, исходные профили,
таймеры, namespace/policy/capability и secretfile oracle.

Фактический короткий C mirror048079… проверил предшествующие FS операции,
включая два Fgetxattr→ENODATA, SameFile-equivalent, probe close/unlink и tmp0700.
Затем показал root /01777 UID0 dev2ino1 и /profiles0755 UID0 под euid65532;
его sticky-child-owned predicate отказал. В исходном Go secretfile это
существующий ViolationStickyChildNotOwned: resolveRoute помечает /profiles
как ребёнка writable-sticky root, а judgeEntry требует ownership65532.
Это конкретный небезопасный ancestor этой диагностической среды.

В принятом original1f0 initrd1435 членов отсутствуют '.', '/' и пустой root
member; его PID1 ELF6f6f… соответствует точному старому device-fix source.
Там нет chmod/readback '/'. Короткий C init тоже не меняет root и использует
тот же kernel9ffe. Actual C counterexample поэтому применим к такой rootfs
среде; он не восстанавливает уникальный первый отказ предыдущего Go запуска,
где root stat/typed secretfile error отсутствовали. Это ограничение сохранено.

Узкое исправление собственной среды: прежде всех mount/child операций PID1
вызывает chmod("/",0755), затем Lstat проверяет ровно directory040755,
UID0/GID0. Ошибка не позволяет продолжить старт. Это не смена владельца
/profiles, не ослабление sticky-directory проверки и не новая capability.
Далее исполняется прежний mounts() и весь lifecycle без изменений.

Скопирован точный accepted d1-o1a-device-modes-fix-v1 helper snapshot.
Только3 source delta: wiring в main_linux.go, root_mode.go и root_mode_test.go.
Три новые Go pure-функции проверяют repair1777→0755, отказ неправильного
типа/mode/UID/GID и ошибки set/read. Callback tests не делают chmod корня
хоста. Старые7 Go-проверок и3новые выполняются Root при отдельной сборке.
Подготовительные Python fixtures здесь не исполняют Go или продуктовые ELF.

rebuild.py/common.py переиспользуют прежний single-PID1 builder. Локальный
Go1.27.4, offline/source-write-deny sandbox, GOMAXPROCS2/GOMEMLIMIT768MiB/-p1,
600с работы +30с очистки, heavy-lock, минимум10GiB, файл-фаза2GiB, RAW1MiB.
Host hard CPU/RAM/PID/no-swap и жёсткая disk quota не обеспечены. Только
host pure QA и cross-compile Linuxarm64/CGO0; metadata/static ELF/SHA readback.
Нет downloads, запуска ELF/Go application, Docker/VM или public network.
Ошибки/OOM/таймаут — STOP без идентичного повтора/роста лимитов; UNKNOWN
сохраняет owner-lock/controller. Новый артефакт ещё не известен/не придуман.

Сначала Root отдельно проверяет тот же environmental chmod/readback на
коротком C mirror. Затем собирает только изменённый Go PID1, привязывает
его реальный SHA к новым initrd без замены остальных членов и решает о
fresh original периодическом запуске. Результат предыдущего FAIL сохраняется;
source/env исправление само по себе не даёт О‑1а/D1/G2 или release PASS.
