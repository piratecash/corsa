import io,json,struct,tempfile,unittest
from pathlib import Path
import common,rebuild as host_build

class Tests(unittest.TestCase):
 def test_exact_go_cases_and_refuse_missing_failure_skip(self):
  rows=[dict(Package=p,Test=t,Action='pass') for p,tests in host_build.EXPECTED.items() for t in tests]
  raw=lambda value:b'\n'.join(json.dumps(row).encode() for row in value)
  host_build.go_passes(raw(rows))
  for bad in (rows[:-1],rows+[dict(Action='skip')],rows+[dict(Action='fail')]):
   with self.assertRaises(RuntimeError):host_build.go_passes(raw(bad))
 def test_static_arm64_guard(self):
  with tempfile.TemporaryDirectory() as temp:
   p=Path(temp)/'fixture';raw=bytearray(128);raw[:16]=b'\x7fELF\x02\x01\x01'+bytes(9)
   struct.pack_into('<HHIQQQIHHHHHH',raw,16,2,183,1,0,64,0,0,64,56,1,0,0,0);struct.pack_into('<IIQQQQQQ',raw,64,1,5,0,0,0,len(raw),len(raw),4096)
   p.write_bytes(raw);self.assertTrue(common.static_arm64(p)['static_arm64'])
   for kind in (2,3):
    bad=bytearray(raw);struct.pack_into('<I',bad,64,kind);p.write_bytes(bad)
    with self.assertRaises(RuntimeError):common.static_arm64(p)
 def test_snapshot_hash_and_file_bounds(self):
  with tempfile.TemporaryDirectory() as temp:
   root=Path(temp);p=root/'one';p.write_bytes(b'one')
   self.assertEqual(common.sha(p),'7692c3ad3540bb803c020b3aee66cd8887123234ea0c6e7143c0add73ff431ed')
   with self.assertRaises(RuntimeError):common.directory_bytes(root,2)
   (root/'linked').symlink_to(p)
   with self.assertRaises(RuntimeError):common.sha(root/'linked')
 def test_fixed_root_wiring_before_mounts_and_only_three_source_deltas(self):
  folder=Path(__file__).resolve().parent;old=folder.parent/"d1-o1a-device-modes-fix-v1/source";new=folder/"source"
  before={str(q.relative_to(old)):q.read_bytes() for q in old.rglob("*") if q.is_file() and q.name!="SHA256SUMS"};after={str(q.relative_to(new)):q.read_bytes() for q in new.rglob("*") if q.is_file() and q.name!="SHA256SUMS"}
  delta={name for name in before.keys()|after.keys() if before.get(name)!=after.get(name)}
  self.assertEqual(delta,{"cmd/o1a-init/main_linux.go","cmd/o1a-init/root_mode.go","cmd/o1a-init/root_mode_test.go"})
  source=after["cmd/o1a-init/main_linux.go"].decode();mounts=source[source.index("func mounts()error{"):source.index("func enableOnlyLo()")];self.assertLess(mounts.index("ensureRootMode("),mounts.index("for _,entry:="));self.assertIn('syscall.Chmod("/",mode)',mounts);self.assertIn('syscall.Lstat("/",&actual)',mounts)
 def test_source_test_inventory_declared_ten(self):
  self.assertEqual(sum(len(v) for v in host_build.EXPECTED.values()),10)

if __name__=='__main__':unittest.main()
