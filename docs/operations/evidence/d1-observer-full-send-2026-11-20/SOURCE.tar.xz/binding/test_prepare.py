import ast,copy,hashlib,json,re,unittest
from pathlib import Path
import prepare as p
HERE=Path(__file__).resolve().parent
class Tests(unittest.TestCase):
 def setUp(self):self.expected=json.loads((HERE/'FROZEN.PENDING.json').read_bytes())['expected_members']
 def fixture_members(self):
  before={n:dict(row,sha256='a'*64) for n,row in self.expected.items() if n not in p.NEW_SOURCE_PATHS|p.NEW_DIRECTORIES}
  before['config/boot.json']={'mode':'0o100644','bytes':123,'sha256':'b'*64};before['unrelated']={'mode':'0o100644','bytes':1,'sha256':'c'*64}
  after=copy.deepcopy(before);after.update(self.expected);after['config/boot.json']['sha256']='d'*64
  return before,after
 def test_exact_component_member_delta_and_foreign_changes_refuse(self):
  before,after=self.fixture_members();p.exact_member_delta(before,after,self.expected)
  for edit in (lambda x:x.pop(next(iter(self.expected))),lambda x:x['unrelated'].update(bytes=2),lambda x:x.update(foreign={'mode':'0o40755','bytes':0,'sha256':'e'*64}),lambda x:x['bin/loadstand-full'].update(mode='0o100755')):
   bad=copy.deepcopy(after);edit(bad)
   with self.assertRaises(ValueError):p.exact_member_delta(before,bad,self.expected)
 def fixture_boot(self):
  before={'attempt_id':'a'*32,'profile_sha256':'b'*64,'source_archive_sha256':'c'*64,'workload':'reconnect','unchanged':'retained','files':{}}
  for n,row in self.expected.items():
   if n!='init' and n not in p.NEW_SOURCE_PATHS|p.NEW_DIRECTORIES:before['files']['/'+n]={'sha256':'a'*64,'bytes':1}
  after=copy.deepcopy(before);after.update(attempt_id='d'*32,source_archive_sha256=p.NEW_SOURCE_SHA,profile_sha256=p.COMPONENT_PROFILE)
  for n,row in self.expected.items():
   if n!='init' and n not in p.NEW_DIRECTORIES:after['files']['/'+n]={k:row[k] for k in ('bytes','sha256')}
  return before,after
 def test_exact_component_boot_delta_and_unknown_fields_refuse(self):
  before,after=self.fixture_boot();p.exact_boot_delta(before,after,'d'*32,self.expected)
  for edit in (lambda x:x.update(profile_sha256='b'*64),lambda x:x.update(unchanged='foreign'),lambda x:x['files'].update({'/source/foreign.go':{'bytes':1,'sha256':'e'*64}}),lambda x:x['files'].pop('/bin/capexec')):
   bad=copy.deepcopy(after);edit(bad)
   with self.assertRaises(ValueError):p.exact_boot_delta(before,bad,'d'*32,self.expected)
 def test_runtime_lifecycle_ack_capture_code_unchanged(self):
  sources=p.runtime_sources();self.assertEqual(sources['support.py'],(p.OLD/'support.py').read_bytes());self.assertEqual(sources['ack.py'],(p.OLD/'ack.py').read_bytes())
  old=(p.OLD/'verify.py').read_bytes();new=sources['verify.py']
  for name,end in [('check_capture','check_lifecycle'),('check_lifecycle','guest_receipt'),('successful_guest','replay')]:
   start=('def '+name+'(').encode();stop=('def '+end+'(').encode();self.assertEqual(old[old.index(start):old.index(stop)],new[new.index(start):new.index(stop)])
  for raw in sources.values():compile(raw,'generated-runtime','exec')
  self.assertIn(b"'purpose':'DISPOSABLE_OBSERVER_FIRST_FAILURE_DIAGNOSTIC'",sources['launch.py']);self.assertIn(b"row['input_files']==1366",new)
 def test_generated_validate_component_only_and_readiness_guards(self):
  raw=p.runtime_sources()['launch.py'];tree=ast.parse(raw);fn=next(x for x in tree.body if isinstance(x,ast.FunctionDef) and x.name=='validate')
  assembly={'scope':'DISPOSABLE_OBSERVER_FIRST_FAILURE_DIAGNOSTIC_INITRAMFS_DATA_READBACK_ONLY','elf_or_vm_executed':False,'source_files':1348,'source_archive_sha256':p.NEW_SOURCE_SHA,'workload':'reconnect','attempt_id':'a'*32,'config_sha256':'b'*64,'archive':{'sha256':'c'*64}}
  ar=json.dumps(assembly).encode();files={'launch.py':Path('/fixture/launch.py')}
  ns={'re':re,'need':p.need,'PROFILE':'d1-o1a-native-v1','FILES':files,'LIMITS':{'kernel':1,'initrd':1,'launcher':1},'file_digest':lambda *a:('d'*64,1),'KERNEL':'e'*64,'WORKER':'f'*64,'read_record':lambda *a:ar,'hash_bytes':lambda x:hashlib.sha256(x).hexdigest(),'decode':json.loads,'Path':Path}
  exec(compile(ast.Module(body=[fn],type_ignores=[]),'validate-fixture','exec'),ns)
  h={'purpose':p.PURPOSE,'profile':'d1-o1a-native-v1','workload':'reconnect','attempt_id':'a'*32,'config_sha256':'b'*64,'files':{'launch.py':'d'*64},'inputs':{k:{'path':'/fixture/'+k,'sha256':v} for k,v in [('kernel','e'*64),('initrd','c'*64),('launcher','f'*64)]},'assembly':{'path':'/fixture/assembly','sha256':hashlib.sha256(ar).hexdigest()},'readiness':{'CODE':True,'QA':True,'ROOT':True}}
  self.assertEqual(ns['validate'](h),assembly)
  for edit in (lambda x:x.pop('purpose'),lambda x:x.update(purpose='O1A_METRIC'),lambda x:x.update(workload='periodic'),lambda x:x['readiness'].update(ROOT=False)):
   bad=copy.deepcopy(h);edit(bad)
   with self.assertRaises(ValueError):ns['validate'](bad)
if __name__=='__main__':unittest.main()
