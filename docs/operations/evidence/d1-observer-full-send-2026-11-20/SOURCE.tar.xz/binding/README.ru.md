# Coherent setup / same disposable observer diagnostic

SOURCE ONLY PENDING_ACTUAL_HELPERS_NOT_RUNNABLE: init/capexec pins intentionally null until actual builds. No guessed helper SHA, no pack/runtime/claim performed. Parent is actual9b75 archive4082/HANDOFFfc7, whose setup failure and stoppedACK remain immutable.

Same member set, no new directories. Exactly3fixture source+4app+init+capexec+boot=10members; same1348source/1366bootinputs. Sourcearchive50358/Core6409fb unchanged/stand7085aad from actual freshGoAPI. Expected eight bootinput rows change (PID1 is not in files) plus sourcearchiveSHA and freshnonce. Exporter7ef/profilef848/nft/audited0555/2helper lifecycle/worker7b75/kernel9ffe/caps/limits/purposeDISPOSABLE_OBSERVER_FIRST_FAILURE_DIAGNOSTIC unchanged.

Generated runtime support/verify/ACK byte-identical parent. Launch changes only sourcearchivepin. Existing conditional three-role stoppedACK and all success/lifecycle/RAW/capsule checks remain; no metric/512/baseline admission or480s repeat. Root binds actual helper results+rows, checks finalCODE/DATA, then may run data-only binder against actual accepted pack. CODE/ROOT flags generatedfalse.
