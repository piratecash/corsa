# Actual eb04 full-send family

Source loadstand_route_wire_full_send.go, nine original poison sites:

| Function / line | Existing condition family |
|---|---|
| startFullPass41 | reportSealed OR clock advance failure |
| startFullPass57 | zero epoch, invalid entry count, missing/invalid source cause |
| startFullPass64 | zero destination or invalid hops |
| startFullPass72 | duplicate destination identity |
| frame93 | sealed/missing/retired connection, different connection within a pass, malformed/nonfull/wrong-epoch/empty/overflow frame |
| frame101 | peer reflected as destination, identity/hops/sequence differ from original ordered entry |
| frame114 | overlapping active pass OR different destination count/hash/epoch from earlier same-connection projection |
| finish135 | reportSealed OR clock advance failure |
| finish142 | pass begins before/at window or ends at/after it, sender failure, no bound frame, or not all original entries offered |

start outside either boundary creates a pending pass but no tracked entries; finish outside the SAME side is a no-op, while a pre-window pass finishing inside fails. In-window same-connection projection cannot change count/hash/epoch. Table.Epoch() is a constant construction field. Full frame observer runs BEFORE actual inbound write/outbound enqueue; deferred finish receives the actual sender return. These ordering facts can distinguish proof refusal from a transport failure but do not determine the actual c01 subpredicate.

The saved capsule has all1348 sources/two original API manifests and a checksum-valid failed record, with no action/report body or pass clock/branch state. Therefore old480 exact cause, c01 sender subguard, affected direction/ConnID and epoch/timing remain UNKNOWN. No mutation or weakened check follows from this inventory.
