"""Bounded console transport for a complete O-1a journal after child reap.

A decoded capsule proves transport completeness. Go outcome, VM stop, route
rates and source stamps remain independent checks in the runtime verifier.
"""
import argparse
import base64
import gzip
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import stat
import tarfile
import zlib
from dataclasses import dataclass

MIB = 1024 ** 2
PREFIX = b"O1A_JOURNAL_CAPSULE_V1 "
FORMAT = "corsa-o1a-journal-capsule/v1"
SHA = re.compile(r"[0-9a-f]{64}")
COMMIT = re.compile(r"[0-9a-f]{40}")
ATTEMPT = re.compile(r"[0-9a-f]{32}")


@dataclass(frozen=True)
class Limits:
    console: int = 32 * MIB
    archive: int = 16 * MIB
    tar: int = 72 * MIB
    content: int = 64 * MIB
    file: int = 8 * MIB
    files: int = 4096
    directories: int = 4096
    depth: int = 32
    manifest: int = MIB
    chunk: int = 48 * 1024


LIMITS = Limits()


def need(ok, message):
    if not ok:
        raise ValueError(message)


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"),
                      ensure_ascii=True, allow_nan=False).encode("ascii")


def unique_pairs(pairs):
    result = {}
    for key, value in pairs:
        need(key not in result, "duplicate JSON key")
        result[key] = value
    return result


def decode_json(raw):
    return json.loads(raw.decode("ascii"), object_pairs_hook=unique_pairs,
                      parse_constant=lambda value: need(False, "nonfinite JSON"))


def metadata(value):
    need(type(value) is dict and set(value) == {
        "workload", "profile_sha256", "source_commit", "attempt_id"}, "wrong capsule metadata")
    need(value["workload"] in ("periodic", "reconnect"), "unknown workload")
    need(type(value["profile_sha256"]) is str and SHA.fullmatch(value["profile_sha256"]),
         "invalid profile SHA")
    need(type(value["source_commit"]) is str and COMMIT.fullmatch(value["source_commit"]),
         "invalid source commit")
    need(type(value["attempt_id"]) is str and ATTEMPT.fullmatch(value["attempt_id"]),
         "missing canonical runtime attempt ID")
    return dict(value)


def safe_path(name):
    need(type(name) is str and 0 < len(name.encode("utf-8")) <= 512,
         "invalid journal path length")
    path = PurePosixPath(name)
    need(path.parts and len(path.parts) <= LIMITS.depth
         and not path.is_absolute() and name == path.as_posix()
         and all(part not in ("", ".", "..") for part in path.parts)
         and not any(char in name for char in "\\\r\n\x00"), "unsafe journal path")
    return name


def stat_stamp(value):
    return (value.st_dev, value.st_ino, value.st_mode, value.st_size,
            value.st_mtime_ns, value.st_ctime_ns, value.st_nlink)


def read_owned_file(root_fd, name, limits):
    parts = safe_path(name).split("/")
    folder = os.dup(root_fd)
    try:
        for part in parts[:-1]:
            child = os.open(part, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW,
                            dir_fd=folder)
            os.close(folder)
            folder = child
        descriptor = os.open(parts[-1], os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK,
                             dir_fd=folder)
        with os.fdopen(descriptor, "rb") as stream:
            before = os.fstat(stream.fileno())
            need(stat.S_ISREG(before.st_mode) and before.st_nlink == 1
                 and 0 <= before.st_size <= limits.file, "irregular journal file")
            raw = stream.read(limits.file + 1)
            after = os.stat(parts[-1], dir_fd=folder, follow_symlinks=False)
            need(len(raw) == before.st_size and len(raw) <= limits.file
                 and stat_stamp(before) == stat_stamp(os.fstat(stream.fileno()))
                 == stat_stamp(after), "journal file changed during export")
            return raw
    finally:
        os.close(folder)


def pack(root, binding, limits=LIMITS):
    binding = metadata(binding)
    root = Path(root)
    need(root.is_absolute() and root.resolve(strict=True) == root
         and not root.is_symlink(), "noncanonical journal root")
    root_fd = os.open(root, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    try:
        names = []
        directory_count = 0

        def scan(folder_fd, prefix):
            nonlocal directory_count
            with os.scandir(folder_fd) as entries:
                for entry in entries:
                    name = safe_path(prefix + entry.name)
                    need(len(PurePosixPath(name).parts) <= limits.depth,
                         "journal depth exceeded")
                    info = entry.stat(follow_symlinks=False)
                    if stat.S_ISDIR(info.st_mode):
                        directory_count += 1
                        need(directory_count <= limits.directories,
                             "journal directory count exceeded")
                        child = os.open(entry.name, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW,
                                        dir_fd=folder_fd)
                        try:
                            scan(child, name + "/")
                        finally:
                            os.close(child)
                    else:
                        names.append(name)
                        need(len(names) <= limits.files, "journal file count exceeded")

        scan(root_fd, "")
        need(names and len(names) == len(set(names)), "empty or duplicate journal inventory")
        content = {}
        total = 0
        for name in sorted(names):
            raw = read_owned_file(root_fd, name, limits)
            total += len(raw)
            need(total <= limits.content, "journal content bound exceeded")
            content[name] = raw
    finally:
        os.close(root_fd)
    manifest = {"format": FORMAT, "metadata": binding,
                "files": {name: {"bytes": len(raw), "sha256": digest(raw)}
                          for name, raw in content.items()}}
    manifest_raw = canonical(manifest)
    need(len(manifest_raw) <= limits.manifest, "manifest bound exceeded")
    tar_buffer = io.BytesIO()
    with tarfile.open(fileobj=tar_buffer, mode="w", format=tarfile.USTAR_FORMAT) as archive:
        for name, raw in [("CAPSULE.json", manifest_raw)] + [
                ("journal/" + name, raw) for name, raw in content.items()]:
            entry = tarfile.TarInfo(name)
            entry.mode, entry.uid, entry.gid, entry.mtime = 0o600, 0, 0, 0
            entry.size = len(raw)
            archive.addfile(entry, io.BytesIO(raw))
            need(tar_buffer.tell() <= limits.tar, "tar bound exceeded")
    tar_raw = tar_buffer.getvalue()
    need(len(tar_raw) <= limits.tar, "tar padding exceeds bound")
    raw = gzip.compress(tar_raw, compresslevel=6, mtime=0)
    need(len(raw) <= limits.archive, "compressed archive bound exceeded")
    return raw


def frame(archive, binding, limits=LIMITS):
    binding = metadata(binding)
    need(type(archive) is bytes and 0 < len(archive) <= limits.archive,
         "archive bound exceeded")
    chunks = (len(archive) + limits.chunk - 1) // limits.chunk
    summary = {"bytes": len(archive), "sha256": digest(archive),
               "chunks": chunks, "metadata": binding}
    rows = [{"kind": "begin", **summary}]
    rows.extend({"kind": "chunk", "index": index,
                 "data": base64.b64encode(archive[offset:offset + limits.chunk]).decode("ascii")}
                for index, offset in enumerate(range(0, len(archive), limits.chunk)))
    rows.append({"kind": "end", **summary})
    raw = b"".join(PREFIX + canonical(row) + b"\n" for row in rows)
    need(len(raw) <= limits.console, "framed output bound exceeded")
    return raw


def unpack(archive, binding, limits=LIMITS):
    need(0 < len(archive) <= limits.archive, "archive bound exceeded")
    decoder = zlib.decompressobj(31)
    raw = decoder.decompress(archive, limits.tar + 1)
    need(len(raw) <= limits.tar and decoder.eof and not decoder.unused_data
         and not decoder.unconsumed_tail, "gzip truncated, concatenated or oversize")
    content = {}
    with tarfile.open(fileobj=io.BytesIO(raw), mode="r:") as tar:
        first = tar.next()
        need(first is not None and first.name == "CAPSULE.json" and first.isfile()
             and 0 < first.size <= limits.manifest
             and first.uid == first.gid == first.mtime == 0
             and first.mode == 0o600 and not first.pax_headers, "missing bounded capsule manifest")
        manifest = decode_json(tar.extractfile(first).read())
        need(type(manifest) is dict and set(manifest) == {"format", "metadata", "files"}
             and manifest["format"] == FORMAT and manifest["metadata"] == binding,
             "manifest binding mismatch")
        listing = manifest["files"]
        need(type(listing) is dict and 0 < len(listing) <= limits.files,
             "invalid manifest inventory")
        names = sorted(listing)
        total = 0
        directories = set()
        for name in names:
            safe_path(name)
            parts = PurePosixPath(name).parts
            need(len(parts) <= limits.depth, "journal depth exceeded")
            for depth in range(1, len(parts)):
                directories.add(parts[:depth])
                need(len(directories) <= limits.directories, "journal directory count exceeded")
            expected = listing[name]
            need(type(expected) is dict and set(expected) == {"bytes", "sha256"}
                 and type(expected["bytes"]) is int and 0 <= expected["bytes"] <= limits.file
                 and type(expected["sha256"]) is str and SHA.fullmatch(expected["sha256"]),
                 "invalid manifest file")
            member = tar.next()
            need(member is not None and member.name == "journal/" + name
                 and member.isfile() and member.size == expected["bytes"]
                 and member.uid == member.gid == member.mtime == 0
                 and member.mode == 0o600 and not member.pax_headers,
                 "tar file or metadata mismatch")
            total += member.size
            need(total <= limits.content, "journal content bound exceeded")
            body = tar.extractfile(member).read()
            need(digest(body) == expected["sha256"], "journal digest mismatch")
            content[name] = body
        need(tar.next() is None and not raw[tar.offset:].strip(b"\0"),
             "unexpected tar tail")
    return content


def decode(console, binding, limits=LIMITS):
    binding = metadata(binding)
    need(type(console) is bytes and len(console) <= limits.console,
         "console bound exceeded")
    rows = []
    for line in console.splitlines(keepends=True):
        if not line.startswith(PREFIX):
            continue
        need(line.endswith(b"\n") and len(line) <= max(4096, limits.chunk * 2),
             "truncated or oversize frame")
        rows.append(decode_json(line[len(PREFIX):-1]))
        need(len(rows) <= (limits.archive + limits.chunk - 1) // limits.chunk + 2,
             "too many frames")
    need(len(rows) >= 3, "incomplete capsule")
    begin, end = rows[0], rows[-1]
    summary_keys = {"kind", "bytes", "sha256", "chunks", "metadata"}
    need(type(begin) is dict and set(begin) == summary_keys and begin["kind"] == "begin"
         and type(end) is dict and set(end) == summary_keys and end["kind"] == "end"
         and {**begin, "kind": "end"} == end, "capsule boundaries disagree")
    need(begin["metadata"] == binding and type(begin["bytes"]) is int
         and 0 < begin["bytes"] <= limits.archive
         and type(begin["sha256"]) is str and SHA.fullmatch(begin["sha256"])
         and type(begin["chunks"]) is int and begin["chunks"] > 0
         and len(rows) == begin["chunks"] + 2, "invalid capsule declaration")
    blocks = []
    total = 0
    for index, row in enumerate(rows[1:-1]):
        need(type(row) is dict and set(row) == {"kind", "index", "data"}
             and row["kind"] == "chunk" and type(row["index"]) is int
             and row["index"] == index and type(row["data"]) is str,
             "chunk order or shape mismatch")
        block = base64.b64decode(row["data"], validate=True)
        need(0 < len(block) <= limits.chunk
             and base64.b64encode(block).decode("ascii") == row["data"],
             "invalid chunk encoding")
        total += len(block)
        need(total <= limits.archive, "archive bound exceeded")
        blocks.append(block)
    archive = b"".join(blocks)
    need(len(archive) == begin["bytes"] and digest(archive) == begin["sha256"],
         "archive digest or length mismatch")
    return unpack(archive, binding, limits)


def save_new_directory(directory, content):
    directory = Path(directory)
    directory.mkdir(mode=0o700)
    try:
        for name, raw in content.items():
            target = directory / safe_path(name)
            target.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
            with target.open("xb") as stream:
                stream.write(raw)
                stream.flush()
                os.fsync(stream.fileno())
            target.chmod(0o600)
    except BaseException:
        shutil.rmtree(directory)
        raise


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("operation", choices=("export", "decode"))
    parser.add_argument("--binding", type=Path, required=True)
    parser.add_argument("--input", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    binding = metadata(decode_json(args.binding.read_bytes()))
    if args.operation == "export":
        raw = frame(pack(args.input, binding), binding)
        with args.output.open("xb") as stream:
            stream.write(raw)
    else:
        with args.input.open("rb") as stream:
            console = stream.read(LIMITS.console + 1)
        save_new_directory(args.output, decode(console, binding))


if __name__ == "__main__":
    main()
