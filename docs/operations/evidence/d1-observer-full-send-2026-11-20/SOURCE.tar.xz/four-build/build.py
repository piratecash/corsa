"""Compile four private observer targets and fresh original source API; never run app ELF."""

import argparse
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import shutil
import signal
import stat
import sys
import tarfile
import time
import uuid

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
REPO = HERE.parents[4]
BASE = HERE.parents[1] / "2026-11-17/d1-o1a-v2672-baseline"
ORIGINAL = HERE.parents[1] / "2026-11-17/d1-o1a-v2672-build"
PLAN = HERE
QA = HERE.parent / "d1-o1a-initial-route-snapshot-source-v1"
BASE_TREE=Path('/private/tmp/corsa-o1a-observer-first-failure-elf-build-3e7567a7e3df45319f3abf139a6bdc4f/source')
BASE_SOURCE=Path('/private/tmp/corsa-o1a-observer-first-failure-elf-build-3e7567a7e3df45319f3abf139a6bdc4f/source-after.json')
BASE_RESULT=Path('/private/tmp/corsa-o1a-observer-first-failure-elf-build-3e7567a7e3df45319f3abf139a6bdc4f/result.json')
TESTED_SOURCE=HERE/'ARTIFACT-SOURCE-MANIFEST.json'
QA_RESULT=Path('/private/tmp/corsa-d1-o1a-namespace-coherent-snapshot-unit-4f0f6314cfab4b4093902ab8bb0f5213/RESULT.json')
QA_COMPILE_RESULT=Path('/private/tmp/corsa-d1-o1a-namespace-coherent-snapshot-test-build-a8cc7165e43f4030ac1b4ee72602ff11/RESULT.json')
API_MODULE=HERE/"source-api-module"
HELPERS = HERE.parents[1] / "2026-11-12"
TIMED = HELPERS / "d1-full512-timed-build-runner"
ELF = HELPERS / "d1-full512-native-inputs"
sys.path[:0] = list(map(str, (BASE, TIMED, ELF)))
from check_linux_graph import summarize
from package_initrd import require_static_arm64
sys.path.insert(0, str(HERE))
from process import UnconfirmedProcess, run

COMMIT = "4fcc2f7245095fc43d2225f0f0065f4ce3b26113"
GOROOT = Path("/usr/local/go")
GO = GOROOT / "bin/go"
LOCK = Path("/private/tmp/corsa-heavy-run.lock")
WORK = LOCK.parent / ("corsa-o1a-observer-coherent-snapshot-elf-build-" + uuid.uuid4().hex)
GIB, MIB = 1024**3, 1024**2
NODE = "github.com/piratecash/corsa/internal/core/node"
APPS = "github.com/piratecash/corsa/internal/testutil/loadstand/"
STAGES = (
    ("NODE", "node.test", ["test", "-c"], "./internal/core/node", NODE + ".test"),
    ("fullnode", "loadstand-full", ["build"], "./internal/testutil/loadstand/fullnode", APPS + "fullnode"),
    ("linuxhelper", "loadstand-linuxhelper", ["build"], "./internal/testutil/loadstand/linuxhelper", APPS + "linuxhelper"),
    ("sdkedge", "loadstand-sdkedge", ["build"], "./internal/testutil/loadstand/sdkedge", APPS + "sdkedge"),
)
OPTIONS = ["-mod=readonly", "-trimpath", "-buildvcs=false"]
TARGET = {"GOOS": "linux", "GOARCH": "arm64", "GOARM64": "v8.0", "CGO_ENABLED": "0"}


def digest(path):
    path=Path(path);before=path.lstat();need(stat.S_ISREG(before.st_mode) and 0<=before.st_size<=256*MIB,'bounded regular hash input')
    checksum=hashlib.sha256();remaining=before.st_size
    with path.open('rb') as f:
        while remaining:
            raw=f.read(min(MIB,remaining));need(raw,'short hash input');checksum.update(raw);remaining-=len(raw)
        need(not f.read(1),'growing hash input')
    key=lambda x:(x.st_dev,x.st_ino,x.st_uid,x.st_gid,x.st_mode,x.st_nlink,x.st_size,x.st_mtime_ns,x.st_ctime_ns)
    need(key(before)==key(path.lstat()),'hash input changed');return checksum.hexdigest()


def need(condition, reason):
    if not condition:
        raise ValueError(reason)


def bound_files():
    files=[HERE/name for name in ('build.py','process.py','test_build.py','PROFILE.ru.md','SOURCE-PLAN.json','GRAPH-EXPECTATIONS.json','measured.expected.manifest','stand.expected.manifest')]
    files += [QA/'MANIFEST.json',TESTED_SOURCE,BASE_SOURCE,BASE_RESULT,QA_RESULT,QA_COMPILE_RESULT,BASE/'check_linux_graph.py',ELF/'package_initrd.py',GO,GOROOT/'pkg/tool/darwin_arm64/compile',GOROOT/'pkg/tool/darwin_arm64/link',GOROOT/'pkg/tool/darwin_arm64/asm']
    files += sorted(p for p in API_MODULE.rglob('*') if p.is_file())
    files += [QA/'posts'/name for name in production_posts()]
    return files


def production_posts():
    return {n:r for n,r in json.loads((QA/'MANIFEST.json').read_bytes())['files'].items() if not n.endswith('_test.go')}


def artifact_map():
    need(digest(TESTED_SOURCE)=='eacba467ea5c7a35e9ace514ab64612e9cfe95e749220b48bc704f22c33faef9','exact disposable artifact map')
    rows=json.loads(TESTED_SOURCE.read_bytes());before=json.loads(BASE_SOURCE.read_bytes());posts=production_posts()
    need(len(rows)==len(before)==2450 and set(rows)==set(before) and len(posts)==3,'only three existing production fixture posts')
    need({n for n in rows if rows[n]!=before[n]}==set(posts),'extra source delta')
    for n,r in posts.items():need(before[n]==r['before_sha256'] and rows[n]==r['after_sha256'],'post preimage/result')
    return rows


def check_request(request_path):
    need(digest(QA/'MANIFEST.json')=='165b98bfeb864392e2ff90e323de39eaef94e7d504bd52e28c87ae8f54b1594d','setup source changed')
    need(digest(BASE_RESULT)=='f830721193c24c0bd7045c2ca9df614a3d166e7aa5d8f1bebabcf1eed0d75306' and digest(BASE_SOURCE)=='98859ec02ac3fcf6dabb6fadce7680ff99054030bc0985fefc53d869154d9f46','accepted actual base changed')
    need(digest(QA_RESULT)=='b4cde865aa24f57ec43bb7799b54c9d56d533b89e81a97d7cd5571e1950c752a' and digest(QA_COMPILE_RESULT)=='00823845cbe9cebf16b7a9cea9d90cf484f2bf120b213aa49a6977167e76977c','Linux pure QA receipts changed')
    result=json.loads(QA_RESULT.read_bytes());need(result['status']=='SEVENTEEN_FIXTURE_TESTS_PASSED' and result['error'] is None and not result['unknown'] and not result['lock_retained'] and result['tests_passed'] is True and result['owned_container_removed'] is True,'actual QA did not close')
    for name,value in json.loads(BASE_SOURCE.read_bytes()).items():need(digest(BASE_TREE/name)==value,'accepted old source bytes changed')
    artifact_map()
    raw=request_path.read_bytes();request=json.loads(raw)
    need(request=={'commit':COMMIT,'files':{str(p):digest(p) for p in bound_files()}},'build source/tools/input changed')
    return hashlib.sha256(raw).hexdigest()


def graph_matches(actual, expected):
    # The stream includes absolute paths under the new export and Go cache.
    return all(actual[key] == value for key, value in expected.items() if key != "graph_sha256")


def buildinfo_matches(info, package, modules):
    lines = info.splitlines()
    need(lines and lines[0].endswith(": go1.27.4") and f"\tpath\t{package}" in lines,
         "wrong toolchain or build path")
    dependencies, settings = {}, {}
    for line in lines[1:]:
        row = line.strip().split("\t")
        if row[0] == "dep":
            need(len(row) == 4 and row[1] not in dependencies, "invalid dependency metadata")
            dependencies[row[1]] = {"version": row[2], "sum": row[3]}
        if row[0] == "build":
            need(len(row) == 2 and "=" in row[1], "invalid build setting")
            name, value = row[1].split("=", 1)
            need(name not in settings, "duplicate build setting")
            settings[name] = value
    need(dependencies == modules, "compiled module closure changed")
    need(all(settings.get(k) == v for k, v in (TARGET | {"-trimpath": "true"}).items()),
         "wrong target or build flags")


def build_env(work):
    return TARGET | {
        "PATH": "/usr/bin:/bin", "GOROOT": str(GOROOT), "GOTOOLCHAIN": "local",
        "GOENV": "off", "GOWORK": "off", "GOTELEMETRY": "off", "GOPROXY": "off",
        "GOSUMDB": "off", "GOVCS": "*:off", "GOMAXPROCS": "2", "GOMEMLIMIT": "768MiB",
        "GOCACHE": str(work / "cache"), "GOMODCACHE": str(REPO / ".gomodcache"),
        "GOPATH": str(work / "gopath"), "GOTMPDIR": str(work / "tmp"), "TMPDIR": str(work / "tmp"),
        "LANG": "C", "LC_ALL": "C",
    }


def build_command(work, args):
    policy = '(version 1) (allow default) (deny network*) (deny file-write*) ' + (
        f'(allow file-write* (subpath {json.dumps(str(work))}) (literal "/dev/null")) '
        f'(deny file-write* (subpath {json.dumps(str(work / "source"))})) (deny file-write* (subpath {json.dumps(str(work / "source-api-module"))}))'
    )
    return ["/usr/bin/sandbox-exec", "-p", policy, str(GO), *args]


def check_space(work):
    need(shutil.disk_usage(work).free >= 10 * GIB, "less than 10 GiB free")
    if work != LOCK.parent:
        used = sum(p.stat().st_size for p in work.rglob("*") if p.is_file() and not p.is_symlink())
        need(used <= 6 * GIB, "workspace exceeded 6 GiB")


def inventory(source):
    result = {}
    for entry in source.rglob("*"):
        need(not entry.is_symlink(), "link appeared in source")
        if entry.is_file():
            result[entry.relative_to(source).as_posix()] = digest(entry)
        else:
            need(entry.is_dir(), "irregular source input")
    return dict(sorted(result.items()))


def export_source(work):
    source=work/'source';source.mkdir(mode=0o700);wanted=artifact_map()
    for name,value in wanted.items():
        path=PurePosixPath(name);need(path.parts and not path.is_absolute() and '..' not in path.parts and name==path.as_posix(),'source path')
        target=source/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(QA/'posts'/name if name in production_posts() else BASE_TREE/name,target);need(digest(target)==value,'snapshot copy differs');target.chmod(0o444)
    need(inventory(source)==wanted,'exact2450 copied source')
    for name in ('source-before.json','source-after.json'):(work/name).write_text(json.dumps(wanted,indent=2,sort_keys=True)+'\n')
    shutil.copytree(API_MODULE,work/'source-api-module')
    for p in (work/'source-api-module').rglob('*'):
        if p.is_file():need(digest(p)==digest(API_MODULE/p.relative_to(work/'source-api-module')),'original API module copy');p.chmod(0o444)
    return source


def execute(request, approved):
    origin = time.monotonic()
    need(check_request(request) == approved, "exact request hash required")
    check_space(LOCK.parent)
    need(not os.path.lexists(WORK), "work directory already exists")
    interrupted = False

    def stop(_sig, _frame):
        nonlocal interrupted
        interrupted = True

    for sig in (signal.SIGINT, signal.SIGTERM):
        signal.signal(sig, stop)
    LOCK.mkdir(mode=0o700)
    owner = LOCK / "owner"
    claim = f"{os.getpid()} {approved}\n"
    owner.write_text(claim)
    stamp = LOCK.stat().st_ino, owner.stat().st_ino
    safe, owned_work = True, False
    try:
        WORK.mkdir(mode=0o700)
        owned_work = True
        for name in ("cache", "tmp", "gopath", "raw"):
            (WORK / name).mkdir(mode=0o700)
        source = export_source(WORK)
        expected = {key:value["expected_semantic_graph"] for key,value in json.loads((PLAN / "GRAPH-EXPECTATIONS.json").read_bytes()).items()}
        env = build_env(WORK)
        absolute_end = origin + 600
        phase_end = absolute_end

        def go(label, args, limit=MIB, cwd=None, overrides=None):
            out, err = run(build_command(WORK, args), env=env | (overrides or {}), cwd=cwd or source, raw=WORK / "raw", label=label,
                           work_end=phase_end, cleanup_end=phase_end + 30,
                           stopped=lambda: interrupted, stdout_limit=limit)
            need(err.stat().st_size == 0, f"{label} emitted stderr")
            need(sum(p.stat().st_size for p in (WORK/"raw").glob("*.stdout"))+sum(p.stat().st_size for p in (WORK/"raw").glob("*.stderr"))<=64*MIB,"aggregate RAW limit")
            return out

        api_raw=go('original-source-api',['run','-mod=readonly','-buildvcs=false','-p=1','./cmd/source-api-readback','--source-tree',str(source),'--manifests',str(PLAN)],cwd=WORK/'source-api-module',overrides={'GOOS':'darwin','GOARCH':'arm64'})
        source_api=json.loads(api_raw.read_bytes())
        need(source_api.get('status')=='ORIGINAL_GO_SOURCE_API_MATCH' and source_api.get('service_or_ELF_execution') is False,'original Go source API unavailable')
        expected_groups={'measured':{'files':640,'sha256':'9fb7bba6dd77a128a634f0d6d26e67485b07f1178b9361166a754e0fb7d1268e','stamp':'9fb7bba6dd77a128','manifest_bytes_equal':True,'verify_tree':'PASS'},'stand':{'files':708,'sha256':'5aad60ae1d638ae27ebcafd518a31aab4f8c83bb926284e26a22a5117c0f8267','stamp':'5aad60ae1d638ae2','manifest_bytes_equal':True,'verify_tree':'PASS'}}
        need(source_api.get('groups')==expected_groups,'fresh canonical640/708 source differs')
        artifacts = {}
        for key, artifact, operation, target, package in STAGES:
            phase_end = min(time.monotonic() + 600, absolute_end)
            check_space(WORK)
            need(check_request(request) == approved, "request changed between build stages")
            list_flags = ["-test"] if key == "NODE" else []

            def check_graph(boundary):
                graph = go(f"{key}-{boundary}", ["list", *OPTIONS, "-deps", "-json", *list_flags, target], 4 * MIB)
                need(graph_matches(summarize(graph, source, WORK / "cache"), expected[key]),
                     f"{key} selected a different graph at {boundary}")

            check_graph("before")
            output = WORK / artifact
            go(f"{key}-compile", [*operation, "-p=1", *OPTIONS, "-o", str(output), target])
            need(output.resolve(strict=True) == output and output.is_file() and 0 < output.stat().st_size <= 96 * MIB,
                 f"{key} unexpected artifact")
            elf = output.read_bytes()
            require_static_arm64(elf)
            if key == "NODE":
                need((NODE + ".TestLoadStandLinuxRouteWireNative").encode() + b"\0" in elf,
                     "O-1a test symbol missing")
            info = go(f"{key}-metadata", ["version", "-m", str(output)]).read_text()
            buildinfo_matches(info, package, expected[key]["modules"])
            check_graph("after")
            check_space(WORK)
            need(check_request(request) == approved, "inputs changed during build")
            need(not interrupted and time.monotonic() < phase_end, "build phase expired")
            artifacts[artifact] = {"sha256": digest(output), "bytes": output.stat().st_size}
        need(inventory(source) == json.loads((WORK / "source-after.json").read_bytes()), "source changed during compilation")
        result = {"status": "BUILT_NOT_EXECUTED", "subject": "DISPOSABLE_PRIVATE_OBSERVER_COHERENT_SETUP_NOT_BASELINE_NOT_METRIC_NO512", "commit": COMMIT, "request": approved, "artifacts": artifacts, "source_groups_original_Go_API": source_api["groups"], "fresh_original_Go_API":source_api,"QA_artifact_manifest_sha256":digest(TESTED_SOURCE),"source_before_sha256": digest(WORK / "source-before.json"), "source_after_sha256": digest(WORK / "source-after.json"), "commands": [json.loads(path.read_bytes()) for path in sorted((WORK / "raw").glob("*.process.json"))]}
        (WORK / "result.json").write_text(json.dumps(result, indent=2) + "\n")
    except UnconfirmedProcess:
        safe = False
        (WORK / "result.json").write_text(json.dumps({"status":"RECOVERY_REQUIRED", "reason":"own process group closure UNKNOWN", "work":str(WORK), "lock":str(LOCK), "owner":claim})+"\n")
        raise
    except (OSError, ValueError, tarfile.TarError) as exc:
        if owned_work:
            (WORK / "result.json").write_text(json.dumps({"status": "REFUSED", "error": str(exc)}) + "\n")
        raise
    finally:
        if safe:
            need((LOCK.stat().st_ino, owner.stat().st_ino) == stamp and owner.read_text() == claim,
                 "lock ownership changed")
            owner.unlink()
            LOCK.rmdir()
        else:
            print(json.dumps({"status":"HOLD", "work":str(WORK), "reason":"own process group closure UNKNOWN; lock retained"}), flush=True)
            while True:
                time.sleep(1)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--execute", metavar="APPROVED_REQUEST_SHA256")
    args = parser.parse_args()
    request = HERE / "REQUEST.json"
    try:
        if args.execute:
            execute(request, args.execute)
        else:
            print(check_request(request))
    except (OSError, ValueError, tarfile.TarError, UnconfirmedProcess) as error:
        parser.exit(1, f"private observer build refused: {error}\n")
