"""Bounded command capture for the timed compile-only profile."""

import os
import json
import selectors
import signal
import subprocess
import time


class UnconfirmedProcess(RuntimeError):
    pass


def group_present(pid):
    try:
        os.killpg(pid, 0)
    except ProcessLookupError:
        return False
    except OSError:
        # Absence is not established. Recheck until the cleanup fence.
        return True
    return True


def send(pid, sig):
    try:
        os.killpg(pid, sig)
    except (ProcessLookupError, PermissionError):
        pass


def stop_and_reap(process, cleanup_end):
    if group_present(process.pid):
        send(process.pid, signal.SIGTERM)
        grace = min(time.monotonic() + 5, cleanup_end)
        while time.monotonic() < grace:
            process.poll()
            if not group_present(process.pid):
                break
            time.sleep(0.025)
    if group_present(process.pid):
        send(process.pid, signal.SIGKILL)
    while time.monotonic() < cleanup_end:
        if process.poll() is not None and not group_present(process.pid):
            return
        time.sleep(0.025)
    if process.poll() is None or group_present(process.pid):
        raise UnconfirmedProcess(f"process group {process.pid} did not close")


def run(argv, *, env, cwd, raw, label, work_end, cleanup_end, stopped, stdout_limit):
    if stopped() or time.monotonic() >= work_end:
        raise ValueError("command refused before spawn")
    with (raw / f"{label}.stdout").open("xb") as stdout, (raw / f"{label}.stderr").open("xb") as stderr:
        with selectors.DefaultSelector() as sel:
            process = subprocess.Popen(argv, env=env, cwd=cwd, stdin=subprocess.DEVNULL,
                                       stdout=subprocess.PIPE, stderr=subprocess.PIPE, start_new_session=True)
            streams = ((process.stdout, stdout, stdout_limit), (process.stderr, stderr, 1024 * 1024))
            record = {"pid":process.pid,"pgid":process.pid,"argv":argv,"returncode":None,"closure":"UNKNOWN"}
            receipt = raw / f"{label}.process.json"
            try:
                receipt.write_text(json.dumps(record, sort_keys=True)+"\n")
                for reader, writer, limit in streams:
                    os.set_blocking(reader.fileno(), False)
                    sel.register(reader, selectors.EVENT_READ, (writer, limit))
                while sel.get_map() or process.poll() is None:
                    if stopped() or time.monotonic() >= work_end:
                        raise ValueError(f"{label} interrupted or expired")
                    for key, _ in sel.select(0.05):
                        data = os.read(key.fd, 65536)
                        if not data:
                            sel.unregister(key.fileobj)
                            continue
                        writer, limit = key.data
                        remaining = limit - writer.tell()
                        writer.write(data[:remaining])
                        if len(data) > remaining:
                            raise ValueError(f"{label} exceeded raw limit")
                if process.returncode != 0:
                    raise ValueError(f"{label} exit {process.returncode}")
            finally:
                try:
                    stop_and_reap(process, cleanup_end)
                    record.update({"returncode":process.returncode,"closure":"CONFIRMED_ABSENT"})
                    receipt.write_text(json.dumps(record, sort_keys=True)+"\n")
                except OSError as error:
                    raise UnconfirmedProcess(f"could not verify process group {process.pid}") from error
                finally:
                    process.stdout.close()
                    process.stderr.close()
    return raw / f"{label}.stdout", raw / f"{label}.stderr"
