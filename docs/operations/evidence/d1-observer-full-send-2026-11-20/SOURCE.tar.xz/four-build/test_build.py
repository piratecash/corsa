import json,unittest,hashlib
from pathlib import Path
import build
class Tests(unittest.TestCase):
 def test_exact_three_post_overlay_excludes_new_QA_file(self):
  rows=build.artifact_map();posts=build.production_posts();self.assertEqual(len(rows),2450);self.assertEqual(len(posts),3)
  for n in json.loads((build.QA/'MANIFEST.json').read_bytes())['files']:
   if n.endswith('_test.go'):self.assertNotIn(n,rows)
 def test_graphs_preserve_packages_modules_generated_main_and_other_files(self):
  old=json.loads((build.HERE.parent/'d1-o1a-observer-first-failure-elf-build-v1/GRAPH-EXPECTATIONS.json').read_bytes());new=json.loads((build.HERE/'GRAPH-EXPECTATIONS.json').read_bytes());posts=build.production_posts()
  for k in old:
   a=old[k]['expected_semantic_graph'];z=new[k]['expected_semantic_graph'];self.assertEqual({n:v for n,v in a.items() if n!='tracked_files'},{n:v for n,v in z.items() if n!='tracked_files'});self.assertEqual(set(a['tracked_files']),set(z['tracked_files']));changed={n for n in a['tracked_files'] if a['tracked_files'][n]!=z['tracked_files'][n]};self.assertEqual(changed,set(posts)&set(a['tracked_files']))
   for n in changed:self.assertEqual(a['tracked_files'][n],posts[n]['before_sha256']);self.assertEqual(z['tracked_files'][n],posts[n]['after_sha256'])
 def test_original_API_implementation_only_stand_parameter_changed(self):
  old=build.HERE.parent/'d1-o1a-observer-first-failure-elf-build-v1/source-api-module'
  for p in old.rglob('*'):
   if p.is_file() and p.name!='main.go':self.assertEqual(p.read_bytes(),(build.API_MODULE/p.relative_to(old)).read_bytes())
  expected=(old/'cmd/source-api-readback/main.go').read_text().replace('982764418fc1cf30f59ff1b9bb71399763a91295bfd0c30b941e48f6cf1813b2','5aad60ae1d638ae27ebcafd518a31aab4f8c83bb926284e26a22a5117c0f8267')
  self.assertEqual(expected,(build.API_MODULE/'cmd/source-api-readback/main.go').read_text())
 def test_static_flags_and_total_budget_unchanged(self):
  self.assertEqual(build.OPTIONS,['-mod=readonly','-trimpath','-buildvcs=false']);self.assertEqual(build.TARGET,{'GOOS':'linux','GOARCH':'arm64','GOARM64':'v8.0','CGO_ENABLED':'0'});self.assertEqual(len(build.STAGES),4)
  text=(build.HERE/'build.py').read_text();self.assertIn('absolute_end = origin + 600',text);self.assertIn('phase_end + 30',text)
if __name__=='__main__':unittest.main()
