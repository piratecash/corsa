# Private observer coherent setup: source data preparation

SOURCE ONLY / PENDING_NOT_RUNNABLE. ARTIFACT-BINDING.json intentionally has null work/result SHA until Root provides the actual accepted dd7296 four-ELF result. No future artifact hashes are guessed. check() refuses before input enumeration/writes while pending. Final binding fills exact work/result SHA and regenerates INPUTS.json; no executable source changes are necessary.

Comparison source baseline is actual736d archiveB1, helpers from accepted observer-first-failure PID1/C sources. New compiled subject is exactly2450/1348 selected, differing ONLY three fixture production source files; new same-snapshot unit file is excluded. Stand708 canonicalSHA5aad changes; measuredCore6409fb stays unchanged. Fresh originalGoAPI result and full four ELF readback are mandatory in actual result; no use of old API verdict for new stand.

Same accepted data-only packer/inventory/template/header mechanics. New archive differs only three source payloads and stand manifest (measured manifest unchanged). PID1 changes only sourcearchive/fourartifact/sourcefile-record parameters; C only four inputSHA header and its testpin. Root0755, profilef848,120/570timeouts, policy699c147/52, all caps/lifecycle/deadlines/codec unchanged. Reuse exact exporter7ef3 through unchanged four-file dependency closure and actual compiled metadata. No downloads/compiler/app/Docker/VM; output <=64MiB ownprivate directory. Stage is disposablediagnostic, NOTbaseline/metric/512; no old480repeat or acceptance claim.

Five small Python fixture tests use explicitly synthetic future artifact rows (UNIT_FIXTURE_ONLY hashes), never an actual binary claim. Root executes only the final exact INPUTS hash after actual binding+CODE/DATA checks.
