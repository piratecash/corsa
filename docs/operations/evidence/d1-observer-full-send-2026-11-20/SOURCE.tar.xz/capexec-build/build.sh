set -eu
/usr/bin/gcc -std=c11 -static -no-pie -O2 -Wall -Wextra -Werror -Wl,--build-id=none -o /output/capexec /input/capexec.c
/usr/bin/gcc -std=c11 -static -no-pie -O2 -Wall -Wextra -Werror -Wl,--build-id=none -o /output/policy-dump /input/policy_dump.c
# Only this tiny pure factory data program runs. capexec is never executed here.
/output/policy-dump > /output/policy.bpf
