import copy,json,tempfile,struct,unittest
from unittest import mock
from pathlib import Path
import c_build

class Tests(unittest.TestCase):
 def fixture(self):
  work=Path('/private/tmp/owned-c-build-fixture');cid='a'*64;attempt='b'*32
  mounts=[{'Type':'bind','Destination':'/input','Source':'/host_mnt'+str(work/'input'),'RW':False},{'Type':'bind','Destination':'/output','Source':'/host_mnt'+str(work/'output'),'RW':True}]
  row={'Id':cid,'Image':c_build.IMAGE,'Config':{'Labels':{'corsa.o1a.build_attempt':attempt},'User':'501:20','Entrypoint':['/bin/sh'],'Cmd':c_build.ARGS,'WorkingDir':'/input'},'HostConfig':{'NetworkMode':'none','CgroupnsMode':'private','IpcMode':'private','PidMode':'','Binds':None,'Devices':[],'DeviceRequests':None,'PortBindings':{},'PublishAllPorts':False,'ReadonlyRootfs':True,'Privileged':False,'Memory':1024**3,'MemorySwap':1024**3,'NanoCpus':1000000000,'PidsLimit':64,'CapDrop':['ALL'],'CapAdd':None,'RestartPolicy':{'Name':'no'},'SecurityOpt':['no-new-privileges'],'Tmpfs':{'/tmp':c_build.TMPFS},'Mounts':[{'Type':'bind','Target':'/input','Source':str(work/'input'),'ReadOnly':True},{'Type':'bind','Target':'/output','Source':str(work/'output'),'ReadOnly':False}]},'Mounts':mounts,'NetworkSettings':{'Networks':{'none':{}}}}
  return row,cid,attempt,work
 def test_real_docker_shape_and_only_canonical_host_mnt_alias(self):
  row,cid,attempt,work=self.fixture();c_build.inspect_row(row,cid,attempt,work)
  row['Mounts'].append({'Type':'tmpfs','Destination':'/tmp','RW':True});c_build.inspect_row(row,cid,attempt,work)
  row['Mounts'][0]['Source']=str(work/'input');c_build.inspect_row(row,cid,attempt,work)
 def test_limits_capabilities_command_and_external_network_refuse(self):
  for key,value in [('MemorySwap',2*1024**3),('Privileged',True),('PidsLimit',128),('CapAdd',['CHOWN']),('NetworkMode','bridge'),('PidMode','host'),('CgroupnsMode','host'),('Devices',[{'PathOnHost':'/dev/foreign'}]),('PortBindings',{'80/tcp':[{}]}),('Binds',['/foreign:/foreign']),('SecurityOpt',['no-new-privileges','seccomp=unconfined'])]:
   row,cid,attempt,work=self.fixture();row['HostConfig'][key]=value
   with self.subTest(key=key),self.assertRaises(RuntimeError):c_build.inspect_row(row,cid,attempt,work)
  row,cid,attempt,work=self.fixture();row['Config']['Cmd']=['/bin/sh']
  with self.assertRaises(RuntimeError):c_build.inspect_row(row,cid,attempt,work)
 def test_foreign_extra_duplicate_or_writable_input_mounts_refuse(self):
  for mutate in [lambda r:r['Mounts'][0].update(Source='/foreign'),lambda r:r['Mounts'][0].update(RW=True),lambda r:r['Mounts'].append(copy.deepcopy(r['Mounts'][0])),lambda r:r['HostConfig']['Mounts'].__setitem__(1,copy.deepcopy(r['HostConfig']['Mounts'][0])),lambda r:r['HostConfig']['Tmpfs'].update({'/other':'size=1024'})]:
   row,cid,attempt,work=self.fixture();mutate(row)
   with self.assertRaises(RuntimeError):c_build.inspect_row(row,cid,attempt,work)
 def test_c_static_oracle_requires_et_exec(self):
  with tempfile.TemporaryDirectory() as temp:
   path=Path(temp)/'fixture';raw=bytearray(128);raw[:16]=b'\x7fELF\x02\x01\x01'+bytes(9)
   struct.pack_into('<HHIQQQIHHHHHH',raw,16,2,183,1,0,64,0,0,64,56,1,0,0,0);struct.pack_into('<IIQQQQQQ',raw,64,1,5,0,0,0,len(raw),len(raw),4096)
   path.write_bytes(raw);self.assertEqual(c_build.strict_capexec(path)['elf_type'],2)
   struct.pack_into('<H',raw,16,3);path.write_bytes(raw)
   with self.assertRaises(RuntimeError):c_build.strict_capexec(path)
 def test_exact_static_exec_flags(self):
  self.assertEqual(c_build.FLAGS[:4],['-std=c11','-static','-no-pie','-O2'])
  self.assertEqual(c_build.ARGS,['-eu','/input/build.sh'])
  self.assertIn('-Wall',c_build.FLAGS);self.assertIn('-Wextra',c_build.FLAGS);self.assertIn('-Werror',c_build.FLAGS)
 def test_script_is_two_exact_compiles_then_only_pure_dumper(self):
  import shlex
  lines=[x for x in (Path(c_build.__file__).parent/'build.sh').read_text().splitlines() if x and not x.startswith('#')]
  self.assertEqual(lines[0],'set -eu')
  self.assertEqual(shlex.split(lines[1]),['/usr/bin/gcc',*c_build.FLAGS,'-o','/output/capexec','/input/capexec.c'])
  self.assertEqual(shlex.split(lines[2]),['/usr/bin/gcc',*c_build.FLAGS,'-o','/output/policy-dump','/input/policy_dump.c'])
  self.assertEqual(lines[3:],['/output/policy-dump > /output/policy.bpf'])
 def test_foreign_owned_identity_refuse(self):
  row,cid,attempt,work=self.fixture();row['Config']['Labels']['corsa.o1a.build_attempt']='foreign'
  with self.assertRaises(RuntimeError):c_build.inspect_row(row,cid,attempt,work)

if __name__=='__main__':unittest.main()
