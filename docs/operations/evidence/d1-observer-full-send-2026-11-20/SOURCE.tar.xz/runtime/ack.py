"""Release only a stopped O1a attempt's exact lock after actual three-role DATA review."""
import json,os,sys
from pathlib import Path
from support import need,read_record,file_digest,hash_bytes,lock_identity,exclusive_json,LOCK
from verify import decode,check_lifecycle,guest_receipt

def read_raw(path,limit):
    need(not path.is_symlink() and path.is_file() and path.stat().st_size<=limit,'RAW file')
    with path.open('rb') as stream:raw=stream.read(limit+1)
    need(len(raw)<=limit,'RAW bound');return raw

def main():
    need(len(sys.argv)==2,'exact owned work path required')
    work=Path(sys.argv[1]);need(work.is_absolute() and work.resolve()==work,'canonical work')
    expected=decode(read_record(work/'expected.json'));receipt=decode(read_record(work/'receipt.json'))
    need(work.name=='corsa-d1-o1a-native-'+expected['attempt_id'],'exact work binding')
    reviews=decode(read_record(work/'REVIEWS.json'))
    need(set(reviews)=={'ROOT','TESTER','REVIEWER'} and all(r['status']=='ACCEPTED_VM_STOPPED_ONLY' and r['work']==str(work) for r in reviews.values()),'actual independent reviews required')
    raw={name:read_raw(work/file,limit) for name,file,limit in [('console','console.raw',32*1024**2),('native','native.jsonl',16384),('stderr','stderr.raw',4096)]}
    check_lifecycle(expected,receipt,raw['console'],raw['native'],raw['stderr'])
    guest=guest_receipt(expected,raw['console']);need(guest['all_children_reaped'] is True,'guest children not reaped')
    binding=decode(read_record(work/'lock-binding.json'));custody=lock_identity()
    need(list(custody[0])==binding['directory_stamp'] and list(custody[1])==binding['owner_stamp'] and hash_bytes(custody[2])==binding['owner_sha256'],'initial lock identity changed')
    owner=dict(line.split('=',1) for line in custody[2].decode('ascii').splitlines())
    need(owner['name']=='d1-o1a-native-v1' and owner['attempt_id']==expected['attempt_id'] and owner['grant_sha256']==expected['handoff_sha256'],'own lock metadata')
    handoff=decode(read_record(Path(__file__).resolve().parent/'HANDOFF.json'))
    need(hash_bytes(read_record(Path(__file__).resolve().parent/'HANDOFF.json'))==expected['handoff_sha256'],'handoff changed')
    for name,row in handoff['inputs'].items():
        limit={'kernel':96,'initrd':128,'launcher':16}[name]*1024**2
        need(file_digest(Path(row['path']),limit)[0]==file_digest(work/name,limit)[0]==row['sha256']==expected[name+'_sha256'],'input/copy changed')
    start=decode(read_record(work/'worker-start.json'));need(start['attempt_id']==expected['attempt_id'] and start['pid']==receipt['worker_pid']==start['pgid'],'worker start binding')
    pids={int(owner['pid']),int(start['pid'])};groups={int(owner['pgid']),int(start['pgid'])}
    need(all(x>1 for x in pids|groups) and os.getpid() not in pids and os.getpgrp() not in groups,'PID scope')
    for pid in pids:
        try:os.kill(pid,0)
        except ProcessLookupError:pass
        else:raise ValueError('own original PID remains or was reused; no action')
    for pgid in groups:
        try:os.killpg(pgid,0)
        except ProcessLookupError:pass
        else:raise ValueError('own original process group remains; no action')
    need(custody==lock_identity() and {p.name for p in LOCK.iterdir()}=={'owner'},'lock changed before release')
    record={'scope':'NORMAL_VM_STOP_ACK_ONLY','attempt_id':expected['attempt_id'],'guest_result':guest['state'],'guest_stage':guest['stage'],'go_fail_preserved':guest['state']!='TEST_EXIT_ZERO_CAPSULE_EXPORTED','physical_XPC_resources':'UNKNOWN','own_original_pids_absent':sorted(pids),'own_original_groups_absent':sorted(groups),'reviews':reviews,'lock_binding':binding}
    exclusive_json(work/'ACK.json',record)
    need(custody==lock_identity(),'lock changed during ACK')
    (LOCK/'owner').unlink();LOCK.rmdir()
    print(json.dumps({'scope':record['scope'],'guest_result':guest['state'],'own_lock_removed':True,'work':str(work)}))

if __name__=='__main__':main()
