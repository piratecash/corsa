"""Byte-copied reviewed Full512 input/lock utilities; new O1a profile only."""
import os,stat,json,hashlib
from pathlib import Path
LOCK=Path("/private/tmp/corsa-heavy-run.lock")
PROFILE="d1-o1a-native-v1"
MIB=1024**2
LIMITS={"kernel":96*MIB,"initrd":128*MIB,"launcher":16*MIB}
def need(condition, message):
    if not condition:
        raise ValueError(message)

def stamp(info):
    return (info.st_dev, info.st_ino, info.st_uid, info.st_gid, info.st_mode,
            info.st_size, info.st_mtime_ns, info.st_ctime_ns)

def safe_open(path, limit):
    need(path.is_absolute() and path.resolve(strict=True) == path, f"noncanonical path {path.name}")
    stream = os.fdopen(os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC), "rb")
    try:
        info = os.fstat(stream.fileno())
        need(stat.S_ISREG(info.st_mode) and info.st_uid == os.getuid() and info.st_nlink == 1
             and not info.st_mode & 0o022 and 0 < info.st_size <= limit, f"unsafe input {path.name}")
        return stream
    except BaseException:
        stream.close()
        raise

def read_record(path, limit=32768):
    with safe_open(path, limit) as stream:
        before = stamp(os.fstat(stream.fileno()))
        raw = stream.read(limit + 1)
        need(0 < len(raw) <= limit and before == stamp(os.fstat(stream.fileno())) == stamp(path.lstat()),
             f"changed record {path.name}")
        return raw

def file_digest(path, limit, output=None, check=lambda: None):
    with safe_open(path, limit) as stream:
        before = stamp(os.fstat(stream.fileno()))
        digest = hashlib.sha256()
        size = 0
        while block := stream.read(128 * 1024):
            check()
            size += len(block)
            need(size <= limit, f"oversize input {path.name}")
            digest.update(block)
            if output is not None:
                output.write(block)
        need(before == stamp(os.fstat(stream.fileno())) == stamp(path.lstat()) and size == before[5],
             f"changed input {path.name}")
    return digest.hexdigest(), size

def exclusive_json(path, value):
    with path.open("xb") as stream:
        stream.write((json.dumps(value, sort_keys=True, indent=2) + "\n").encode())
        stream.flush()
        os.fsync(stream.fileno())

def hash_bytes(raw):
    return hashlib.sha256(raw).hexdigest()

def validate_kernel(path):
    import gzip
    import io

    raw = read_record(path, LIMITS["kernel"])
    need(len(raw) >= 64 and raw[56:60] == b"ARMd", "kernel is not an ARM64 Image")
    begin = raw.find(b"IKCFG_ST")
    end = raw.find(b"IKCFG_ED", begin + 8)
    need(begin >= 0 and end > begin + 8, "kernel embedded config missing")
    with gzip.GzipFile(fileobj=io.BytesIO(raw[begin + 8:end])) as stream:
        config = stream.read(MIB + 1)
    need(len(config) <= MIB, "kernel config exceeds bound")
    required = {"ARM64", "BINFMT_ELF", "BLK_DEV_INITRD", "RD_GZIP", "PROC_FS", "SYSFS", "TMPFS",
                "INET", "VIRTIO", "VIRTIO_MMIO", "VIRTIO_CONSOLE"}
    rows = set(config.decode("utf-8").splitlines())
    missing = sorted(name for name in required if f"CONFIG_{name}=y" not in rows)
    need(not missing, "kernel lacks built-in " + ", ".join(missing))

def start_lock(attempt, grant_sha):
    need(os.getpid() == os.getpgrp(), "controller must lead its own process group")
    LOCK.mkdir(mode=0o700)
    with (LOCK / "owner").open("x", encoding="ascii") as stream:
        for key, value in {"name": PROFILE, "pid": os.getpid(), "pgid": os.getpgrp(),
                           "attempt_id": attempt, "grant_sha256": grant_sha}.items():
            stream.write(f"{key}={value}\n")
        stream.flush()
        os.fsync(stream.fileno())
    return lock_identity()

def lock_identity():
    owner = LOCK / "owner"
    return stamp(LOCK.lstat()), stamp(owner.lstat()), read_record(owner)

def sync_directory(path):
    descriptor = os.open(path, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    try:
        os.fsync(descriptor)
    finally:
        os.close(descriptor)
