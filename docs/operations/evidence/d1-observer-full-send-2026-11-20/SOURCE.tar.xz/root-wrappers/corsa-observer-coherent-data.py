import os,sys,json,shutil
from pathlib import Path
sys.path.insert(0,'/Users/hades/Documents/repos/corsa/docs/_internal/d1-artifacts/2026-11-20/d1-o1a-capexec-seccomp-build-v1')
from common import Job,need
R=Path('/Users/hades/Documents/repos/corsa');P=R/'docs/_internal/d1-artifacts/2026-11-20/d1-o1a-observer-coherent-snapshot-input-rebind-v1/prepare.py'
os.umask(0o077)
if os.getpid()!=os.getpgrp():os.setsid()
j=Job('observer-coherent-source-data',60,64*1024**2);err=None;result=None
try:
 need(shutil.disk_usage('/private/tmp').free>=10*1024**3,'host free')
 raw=j.run('prepare',['/usr/bin/sandbox-exec','-p','(version 1)(allow default)(deny network*)','/usr/bin/python3',str(P),'--execute','82487ecf373989996b15dab338003e9daa07b9e473e290a42fc8f7f5c1c55c93'],cwd=R)
 result=json.loads(raw.decode().splitlines()[-1])
except BaseException as e:err=str(e)
j.finish({'status':'DISPOSABLE_OBSERVER_SOURCE_DATA_PREPARED' if err is None else 'FAILED','error':err,'data':result,'applications_executed':False})
if err:raise SystemExit(1)
