package main

import (
	"bytes"
	_ "embed"
	"encoding/binary"
	"encoding/json"
	"errors"
	"fmt"
)

//go:embed network-profile.json
var embeddedNetworkProfile []byte

type attributeRule struct {
	Hex *string `json:"hex"`
	Size int `json:"size"`
	Format string `json:"format"`
	Children map[string]attributeRule `json:"children"`
}
type linkRule struct {
	Kind *string `json:"kind"`
	Flags uint32 `json:"flags"`
	Hardware uint16 `json:"hardware_type"`
	Attrs map[string]attributeRule `json:"attrs"`
}
type linkProfile struct { Contract string `json:"contract"`; Links map[string]linkRule `json:"links"` }
type linkIdentity struct { Index int; PermanentAddress string }

func sameLinkIdentities(a,b map[string]linkIdentity) bool {
	if len(a)!=len(b){return false};for name,identity:=range a {if other,found:=b[name];!found||other!=identity{return false}};return true
}

func decodeAttributes(raw []byte) (map[string][]byte,error) {
	result:=map[string][]byte{}
	for len(raw)>0 {
		if len(raw)<4 {return nil,errors.New("short attribute header")}
		size,kind:=int(binary.LittleEndian.Uint16(raw)),binary.LittleEndian.Uint16(raw[2:])
		aligned:=(size+3)&^3
		if size<4||aligned>len(raw) {return nil,errors.New("invalid attribute length")}
		key:=fmt.Sprint(kind)
		if _,found:=result[key];found{return nil,errors.New("duplicate attribute")}
		for _,value:=range raw[size:aligned] {if value!=0{return nil,errors.New("nonzero attribute padding")}}
		result[key]=raw[4:size];raw=raw[aligned:]
		if len(result)>128{return nil,errors.New("attribute count exceeds bound")}
	}
	return result,nil
}

func validateAttributes(raw []byte,rules map[string]attributeRule) error {
	attrs,err:=decodeAttributes(raw);if err!=nil{return err}
	if len(attrs)!=len(rules){return errors.New("unknown or missing structural attribute")}
	for key,rule:=range rules {
		value,found:=attrs[key];if !found{return errors.New("missing structural attribute")}
		switch {
		case rule.Hex!=nil:
			if fmt.Sprintf("%x",value)!=*rule.Hex{return fmt.Errorf("structural attribute changed: %s",key)}
		case rule.Children!=nil:
			if err:=validateAttributes(value,rule.Children);err!=nil{return err}
		case rule.Format=="local-unicast-mac16":
			if rule.Size!=16||len(value)!=16||value[0]&3!=2{return errors.New("invalid permanent address shape/local-unicast MAC")}
			for _,b:=range value[6:] {if b!=0{return errors.New("permanent address nonzero tail")}}
		default:
			width:=4;if rule.Format=="u64"{width=8}else if rule.Format!="u32"{return errors.New("unknown volatile schema")}
			if rule.Size<=0||rule.Size%width!=0||len(value)!=rule.Size{return errors.New("counter/cache format changed")}
		}
	}
	return nil
}

func validateLinkPayloads(payloads [][]byte) (map[string]linkIdentity,error) {
	var profile linkProfile
	if err:=json.Unmarshal(embeddedNetworkProfile,&profile);err!=nil{return nil,err}
	if profile.Contract!="SG512_INERT_DEFAULT_TUNNELS-v2"||len(payloads)!=len(profile.Links){return nil,errors.New("finite interface inventory differs")}
	indices:=map[string]linkIdentity{};seen:=map[int]bool{}
	for _,raw:=range payloads {
		if len(raw)<16||raw[0]!=0||raw[1]!=0||binary.LittleEndian.Uint32(raw[12:16])!=0{return nil,errors.New("invalid link header")}
		attrs,err:=decodeAttributes(raw[16:]);if err!=nil{return nil,err}
		nameBytes:=attrs["3"]
		if len(nameBytes)<2||len(nameBytes)>16||nameBytes[len(nameBytes)-1]!=0||bytes.IndexByte(nameBytes[:len(nameBytes)-1],0)>=0{return nil,errors.New("invalid interface name")}
		name:=string(nameBytes[:len(nameBytes)-1]);rule,found:=profile.Links[name]
		index:=int(int32(binary.LittleEndian.Uint32(raw[4:8])))
		if !found||index<=0||seen[index]||indices[name].Index!=0{return nil,errors.New("unknown/duplicate interface identity")}
		if binary.LittleEndian.Uint16(raw[2:4])!=rule.Hardware||binary.LittleEndian.Uint32(raw[8:12])!=rule.Flags{return nil,errors.New("interface hardware/flags changed")}
		if err:=validateAttributes(raw[16:],rule.Attrs);err!=nil{return nil,fmt.Errorf("%s: %w",name,err)}
		identity:=linkIdentity{Index:index}
		if rule.Attrs["54"].Format=="local-unicast-mac16" {identity.PermanentAddress=fmt.Sprintf("%x",attrs["54"])}
		seen[index]=true;indices[name]=identity
	}
	return indices,nil
}

// Pure framing validator used by the Linux collector and refusal tests.
func decodeLinkDatagram(raw []byte,seq,port uint32) ([][]byte,bool,error) {
	var payloads [][]byte
	for len(raw)>0 {
		if len(raw)<16{return nil,false,errors.New("short netlink header")}
		size:=int(binary.LittleEndian.Uint32(raw));aligned:=(size+3)&^3
		if size<16||aligned>len(raw)||binary.LittleEndian.Uint32(raw[8:12])!=seq||binary.LittleEndian.Uint32(raw[12:16])!=port{return nil,false,errors.New("netlink length/sequence/port")}
		kind,flags:=binary.LittleEndian.Uint16(raw[4:6]),binary.LittleEndian.Uint16(raw[6:8])
		if flags!=2{return nil,false,errors.New("netlink multipart interrupted/filtered/unexpected flags")}
		for _,b:=range raw[size:aligned]{if b!=0{return nil,false,errors.New("netlink padding")}}
		body:=raw[16:size]
		if kind==3 {
			if len(body)!=4||binary.LittleEndian.Uint32(body)!=0||aligned!=len(raw){return nil,false,errors.New("invalid/trailing terminal netlink message")}
			return payloads,true,nil
		}
		if kind!=16{return nil,false,errors.New("unexpected/error netlink message")}
		payloads=append(payloads,append([]byte(nil),body...));raw=raw[aligned:]
	}
	return payloads,false,nil
}
