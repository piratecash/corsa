package main

import (
	"net/netip"
	"strings"
	"testing"
)

func TestFixedSourcePlanAndStrictReadback(t *testing.T) {
	hosts:=sourceHosts();if len(hosts)!=768{t.Fatal(len(hosts))};seen:=map[netip.Addr]bool{}
	prefixes:=[]netip.Prefix{netip.MustParsePrefix("127.0.0.1/8"),netip.MustParsePrefix("::1/128")}
	for _,host:=range hosts {if seen[host]||!host.IsPrivate()||host.IsLoopback(){t.Fatal(host)};seen[host]=true;prefixes=append(prefixes,netip.PrefixFrom(host,32))}
	if hosts[0].String()!="10.77.0.1"||hosts[767].String()!="10.77.3.6"{t.Fatal("slot plan changed")}
	if err:=checkLoopbackAddresses(prefixes,hosts);err!=nil{t.Fatal(err)}
	for _,bad:=range [][]netip.Prefix{prefixes[:len(prefixes)-1],append(append([]netip.Prefix{},prefixes...),prefixes[2]),append(append([]netip.Prefix{},prefixes...),netip.MustParsePrefix("192.0.2.1/32"))} {
		if err:=checkLoopbackAddresses(bad,hosts);err==nil{t.Fatal("incomplete/duplicate/foreign address admitted")}
	}
}

func TestOnlyNetAdminAndNoNewPrivileges(t *testing.T) {
	good:="CapEff:\t0000000000001000\nCapPrm:\t0000000000001000\nCapBnd:\t0000000000001000\nCapInh:\t0000000000000000\nCapAmb:\t0000000000000000\nNoNewPrivs:\t1\n"
	if err:=fixedPrivileges([]byte(good));err!=nil{t.Fatal(err)}
	for _,bad:=range []string{"",strings.Replace(good,"1000","1001",1),strings.Replace(good,"1000","0000",1),strings.Replace(good,"CapAmb:\t0000000000000000","CapAmb:\t0000000000001000",1),strings.Replace(good,"NoNewPrivs:\t1","NoNewPrivs:\t0",1)} {
		if err:=fixedPrivileges([]byte(bad));err==nil{t.Fatal("missing/excess capabilities or privileges admitted")}
	}
}
