package main

import (
	"fmt"
	"net/netip"
	"strconv"
	"strings"
)

const sourceCount = 768

func fixedPrivileges(status []byte) error {
	fields:=map[string]string{}
	for _,line:=range strings.Split(string(status),"\n") {pair:=strings.Fields(line);if len(pair)==2{fields[pair[0]]=pair[1]}}
	for _,key:=range []string{"CapEff:","CapPrm:","CapBnd:"} {v,err:=strconv.ParseUint(fields[key],16,64);if err!=nil||v!=1<<12{return fmt.Errorf("helper must hold only NET_ADMIN: %s",key)}}
	for _,key:=range []string{"CapInh:","CapAmb:"} {v,err:=strconv.ParseUint(fields[key],16,64);if err!=nil||v!=0{return fmt.Errorf("unexpected inherited/ambient capability: %s",key)}}
	if fields["NoNewPrivs:"]!="1" {return fmt.Errorf("no-new-privileges unavailable")}
	return nil
}

func sourceHosts() []netip.Addr {
	hosts := make([]netip.Addr, sourceCount)
	for slot := range hosts {
		hosts[slot] = netip.AddrFrom4([4]byte{10, 77, byte(slot / 254), byte(slot%254 + 1)})
	}
	return hosts
}

// Exact same required-address semantics as Full512 guest init, with a smaller
// fixed 768-source plan. No arbitrary interface, prefix or address input exists.
func checkLoopbackAddresses(addresses []netip.Prefix, hosts []netip.Addr) error {
	required := map[netip.Prefix]bool{netip.MustParsePrefix("127.0.0.1/8"): true}
	for _, host := range hosts { required[netip.PrefixFrom(host,32)] = true }
	seenV6 := false
	for _, address := range addresses {
		if address == netip.MustParsePrefix("::1/128") && !seenV6 { seenV6 = true; continue }
		if !required[address] { return fmt.Errorf("unexpected or duplicate lo prefix %s",address) }
		delete(required,address)
	}
	if len(required)!=0 { return fmt.Errorf("%d required lo prefixes missing",len(required)) }
	return nil
}
