package main

import (
	_ "embed"
	"encoding/binary"
	"encoding/hex"
	"encoding/json"
	"testing"
)

//go:embed testdata/links.json
var fixtureLinks []byte

func linkFixtures(t *testing.T) [][]byte {
	t.Helper();var values []string;if err:=json.Unmarshal(fixtureLinks,&values);err!=nil{t.Fatal(err)}
	var out [][]byte;for _,value:=range values {raw,err:=hex.DecodeString(value);if err!=nil{t.Fatal(err)};out=append(out,raw)};return out
}
func nla(kind uint16,value []byte) []byte {n:=4+len(value);raw:=make([]byte,(n+3)&^3);binary.LittleEndian.PutUint16(raw,uint16(n));binary.LittleEndian.PutUint16(raw[2:],kind);copy(raw[4:],value);return raw}
func rewrite(raw []byte,path []uint16,value []byte) []byte {
	var out []byte;found:=false
	for len(raw)>0 {n:=int(binary.LittleEndian.Uint16(raw));kind:=binary.LittleEndian.Uint16(raw[2:]);body:=raw[4:n]
		if kind==path[0] {found=true;if len(path)>1{body=rewrite(body,path[1:],value)}else{body=value}}
		out=append(out,nla(kind,body)...);raw=raw[(n+3)&^3:]
	};if !found{out=append(out,nla(path[0],value)...)};return out
}
func TestFiniteInertLinkInventory(t *testing.T) {
	rows:=linkFixtures(t);ids,err:=validateLinkPayloads(rows);if err!=nil||len(ids)!=10{t.Fatalf("actual finite inventory: %v %v",ids,err)}
	// IDs are minted afresh per namespace; later before/after equality binds them.
	for _,row:=range rows {binary.LittleEndian.PutUint32(row[4:8],binary.LittleEndian.Uint32(row[4:8])+100)}
	if _,err:=validateLinkPayloads(rows);err!=nil{t.Fatal("fresh nonaliased indices refused",err)}
}
func TestFiniteLinkRefusals(t *testing.T) {
	for _,tc:=range []struct{name string;alter func([][]byte)}{
		{"UP",func(r [][]byte){binary.LittleEndian.PutUint32(r[1][8:12],0x81)}},
		{"different-hardware",func(r [][]byte){binary.LittleEndian.PutUint16(r[1][2:4],1)}},
		{"duplicate-index",func(r [][]byte){copy(r[1][4:8],r[0][4:8])}},
		{"unknown-interface",func(r [][]byte){r[1]=append(r[1][:16],rewrite(r[1][16:],[]uint16{3},[]byte("eth0\x00"))...)}},
		{"master",func(r [][]byte){r[1]=append(r[1],nla(10,[]byte{1,0,0,0})...)}},
		{"peer-netns",func(r [][]byte){r[1]=append(r[1],nla(37,[]byte{1,0,0,0})...)}},
		{"tunnel-remote",func(r [][]byte){a,_:=decodeAttributes(r[1][16:]);v:=append([]byte(nil),a["18"]...);v[len(v)-1]^=1;r[1]=append(r[1][:16],rewrite(r[1][16:],[]uint16{18},v)...)}},
		{"unknown-nested",func(r [][]byte){r[0]=append(r[0][:16],rewrite(r[0][16:],[]uint16{26,10,999},[]byte{0})...)}},
		{"configuration",func(r [][]byte){r[0]=append(r[0][:16],rewrite(r[0][16:],[]uint16{26,2,1},[]byte{1,0,0,0})...)}},
		{"token",func(r [][]byte){v:=make([]byte,16);v[15]=1;r[0]=append(r[0][:16],rewrite(r[0][16:],[]uint16{26,10,7},v)...)}},
		{"counter-shape",func(r [][]byte){r[0]=append(r[0][:16],rewrite(r[0][16:],[]uint16{23},[]byte{0})...)}},
		{"duplicate-attribute",func(r [][]byte){r[1]=append(r[1],nla(3,[]byte("tunl0\x00"))...)}},
	} {t.Run(tc.name,func(t *testing.T){rows:=linkFixtures(t);tc.alter(rows);if _,err:=validateLinkPayloads(rows);err==nil{t.Fatal("unsafe inventory accepted")}})}
}
func TestPermanentMACShapeAndAttemptIdentity(t *testing.T) {
	original:=linkFixtures(t);before,err:=validateLinkPayloads(original);if err!=nil{t.Fatal(err)}
	changed:=linkFixtures(t);attrs,_:=decodeAttributes(changed[6][16:]);mac:=append([]byte(nil),attrs["54"]...);mac[0]^=4
	changed[6]=append(changed[6][:16],rewrite(changed[6][16:],[]uint16{54},mac)...)
	after,err:=validateLinkPayloads(changed);if err!=nil{t.Fatal("fresh locally-administered identity rejected",err)}
	if sameLinkIdentities(before,after){t.Fatal("PERM_ADDRESS changed within attempt without refusal")}
	for _,bad:=range [][]byte{make([]byte,15),append([]byte{3},make([]byte,15)...),make([]byte,16),append(append([]byte{2},make([]byte,14)...),1)} {
		rows:=linkFixtures(t);rows[6]=append(rows[6][:16],rewrite(rows[6][16:],[]uint16{54},bad)...)
		if _,err:=validateLinkPayloads(rows);err==nil{t.Fatal("wrong-length/multicast/global/nonzero-tail permanent address accepted")}
	}
}
func datagram(kind,flags uint16,seq,port uint32,body []byte) []byte {
	raw:=make([]byte,(16+len(body)+3)&^3);binary.LittleEndian.PutUint32(raw,uint32(16+len(body)));binary.LittleEndian.PutUint16(raw[4:],kind);binary.LittleEndian.PutUint16(raw[6:],flags);binary.LittleEndian.PutUint32(raw[8:],seq);binary.LittleEndian.PutUint32(raw[12:],port);copy(raw[16:],body);return raw
}
func TestStrictLinkMultipartFraming(t *testing.T) {
	good:=append(datagram(16,2,71,99,linkFixtures(t)[0]),datagram(3,2,71,99,[]byte{0,0,0,0})...)
	rows,done,err:=decodeLinkDatagram(good,71,99);if err!=nil||!done||len(rows)!=1{t.Fatal(err)}
	for _,bad:=range [][]byte{datagram(3,2,72,99,[]byte{0,0,0,0}),datagram(3,2,71,100,[]byte{0,0,0,0}),datagram(3,0x12,71,99,[]byte{0,0,0,0}),datagram(2,2,71,99,[]byte{0,0,0,0}),append(good,datagram(3,2,71,99,[]byte{0,0,0,0})...),datagram(3,2,71,99,[]byte{1,0,0,0})} {
		if _,_,err:=decodeLinkDatagram(bad,71,99);err==nil{t.Fatal("invalid/extra terminal frame accepted")}
	}
}
