//go:build linux && arm64

package main

import (
	"errors"
	"fmt"
	"io"
	"crypto/sha256"
	"encoding/json"
	"os"
	"regexp"
	"time"
)

func main() {
	if err:=prepareTopology();err!=nil {fmt.Fprintln(os.Stderr,"D1_CHURN512_TOPOLOGY_REFUSED",err);os.Exit(2)}
}

func prepareTopology() error {
	deadline:=time.Now().Add(15*time.Second)
	if os.Geteuid()!=0 || os.Getegid()!=0 || len(os.Args)!=1 {return errors.New("expected root0:0 fixed no-argument topology helper")}
	expected:=os.Getenv("D1_CHURN512_EXPECTED_NETNS")
	if !regexp.MustCompile(`^net:\[[1-9][0-9]*\]$`).MatchString(expected) {return errors.New("missing exact owned service netns")}
	checkNamespace:=func()error{actual,err:=os.Readlink("/proc/self/ns/net");if err!=nil{return err};if actual!=expected{return errors.New("network namespace mismatch")};return nil}
	if err:=checkNamespace();err!=nil{return err}
	f,err:=os.Open("/proc/self/status");if err!=nil{return err};status,err:=io.ReadAll(io.LimitReader(f,8193));_ = f.Close();if err!=nil{return err};if len(status)>8192{return errors.New("status oversized")}
	if err:=fixedPrivileges(status);err!=nil{return err}
	baseline,err:=readInertLinks(deadline);if err!=nil{return fmt.Errorf("inert pre-link proof: %w",err)}
	network:=localNetwork{routeFD:-1,deadline:deadline};defer network.close()
	if err:=network.enable();err!=nil{return err}
	if err:=network.readback(nil);err!=nil{return fmt.Errorf("initial lo addresses: %w",err)}
	for _,host:=range sourceHosts() {if err:=network.addHost(host);err!=nil{return err}}
	if err:=network.readback(sourceHosts());err!=nil{return err}
	after,err:=readInertLinks(deadline);if err!=nil{return fmt.Errorf("inert post-link proof: %w",err)}
	if !sameLinkIdentities(baseline,after){return errors.New("interface incarnation changed during topology mutation")}
	if err:=checkNamespace();err!=nil{return err}
	if !time.Now().Before(deadline){return errors.New("topology deadline elapsed")}
	indices,permanent:=map[string]int{},map[string]string{}
	for name,identity:=range after {indices[name]=identity.Index;if identity.PermanentAddress!=""{permanent[name]=identity.PermanentAddress}}
	packet,err:=json.Marshal(map[string]any{"contract":"SG512_INERT_DEFAULT_TUNNELS-v2","sources":sourceCount,"netns":expected,"indices":indices,"permanent_addresses":permanent,"profile_sha256":fmt.Sprintf("%x",sha256.Sum256(embeddedNetworkProfile))});if err!=nil{return err}
	fmt.Printf("D1_CHURN512_TOPOLOGY_READY %s\n",packet)
	return nil
}
