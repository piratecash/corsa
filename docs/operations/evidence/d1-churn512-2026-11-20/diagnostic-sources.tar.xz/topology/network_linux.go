//go:build linux && arm64

package main

import (
	"encoding/binary"
	"errors"
	"fmt"
	"net"
	"net/netip"
	"syscall"
	"time"

	"golang.org/x/sys/unix"
)

type localNetwork struct {
	index    int
	routeFD  int
	sequence uint32
	deadline time.Time
}

func (n *localNetwork) enable() error {
	lo, err := isolatedLoopback()
	if err != nil {
		return err
	}
	n.index = lo.Index
	if lo.Flags&net.FlagUp == 0 {
		fd, err := unix.Socket(unix.AF_INET, unix.SOCK_DGRAM|unix.SOCK_CLOEXEC, 0)
		if err != nil {
			return err
		}
		defer unix.Close(fd)
		request, err := unix.NewIfreq(lo.Name)
		if err != nil {
			return err
		}
		if err := unix.IoctlIfreq(fd, unix.SIOCGIFFLAGS, request); err != nil {
			return err
		}
		request.SetUint16(request.Uint16() | unix.IFF_UP)
		if err := unix.IoctlIfreq(fd, unix.SIOCSIFFLAGS, request); err != nil {
			return err
		}
	}
	fd, err := unix.Socket(unix.AF_NETLINK, unix.SOCK_RAW|unix.SOCK_CLOEXEC, unix.NETLINK_ROUTE)
	if err != nil {
		return err
	}
	n.routeFD = fd
	return unix.Bind(n.routeFD, &unix.SockaddrNetlink{Family: unix.AF_NETLINK})
}

func (n *localNetwork) close() {
	if n.routeFD >= 0 {
		_ = unix.Close(n.routeFD)
		n.routeFD = -1
	}
}

func (n *localNetwork) addHost(host netip.Addr) error {
	if n.index <= 0 || n.routeFD < 0 || !host.Is4() || !host.IsPrivate() {
		return errors.New("guest lo is unavailable or address is invalid")
	}
	n.sequence++
	request := addressRequest(n.sequence, uint32(n.index), host.As4())
	if err := n.setTimeout(unix.SO_SNDTIMEO); err != nil {
		return err
	}
	if err := unix.Sendto(n.routeFD, request, 0, &unix.SockaddrNetlink{Family: unix.AF_NETLINK}); err != nil {
		return err
	}
	if err := n.setTimeout(unix.SO_RCVTIMEO); err != nil {
		return err
	}
	var response [4096]byte
	size, _, flags, source, err := unix.Recvmsg(n.routeFD, response[:], nil, 0)
	if err != nil {
		return err
	}
	sender, ok := source.(*unix.SockaddrNetlink)
	if flags&unix.MSG_TRUNC != 0 || !ok || sender.Family != unix.AF_NETLINK || sender.Pid != 0 || sender.Groups != 0 {
		return errors.New("unexpected route acknowledgment sender or size")
	}
	return addressAck(response[:size], request)
}

func (n *localNetwork) setTimeout(option int) error {
	left := time.Until(n.deadline)
	if left <= 0 {
		return errors.New("guest work deadline elapsed during address setup")
	}
	timeout := unix.NsecToTimeval(left.Nanoseconds())
	return unix.SetsockoptTimeval(n.routeFD, unix.SOL_SOCKET, option, &timeout)
}

func addressRequest(sequence, link uint32, host [4]byte) []byte {
	const attrs = unix.NLMSG_HDRLEN + unix.SizeofIfAddrmsg
	const attributeLength = unix.SizeofRtAttr + len(host)
	request := make([]byte, attrs+2*attributeLength)
	binary.NativeEndian.PutUint32(request[0:4], uint32(len(request)))
	binary.NativeEndian.PutUint16(request[4:6], unix.RTM_NEWADDR)
	binary.NativeEndian.PutUint16(request[6:8], unix.NLM_F_REQUEST|unix.NLM_F_ACK|unix.NLM_F_CREATE|unix.NLM_F_EXCL)
	binary.NativeEndian.PutUint32(request[8:12], sequence)
	body := request[unix.NLMSG_HDRLEN:attrs]
	body[0], body[1], body[3] = unix.AF_INET, 32, unix.RT_SCOPE_HOST
	binary.NativeEndian.PutUint32(body[4:8], link)
	for i, kind := range []uint16{unix.IFA_LOCAL, unix.IFA_ADDRESS} {
		attr := request[attrs+i*attributeLength:]
		binary.NativeEndian.PutUint16(attr[0:2], uint16(attributeLength))
		binary.NativeEndian.PutUint16(attr[2:4], kind)
		copy(attr[4:8], host[:])
	}
	return request
}

func addressAck(raw, request []byte) error {
	messages, err := syscall.ParseNetlinkMessage(raw)
	if err != nil {
		return err
	}
	const echoHeaderEnd = 4 + unix.NLMSG_HDRLEN
	if len(messages) != 1 || messages[0].Header.Type != unix.NLMSG_ERROR ||
		messages[0].Header.Seq != binary.NativeEndian.Uint32(request[8:12]) ||
		len(messages[0].Data) < echoHeaderEnd {
		return errors.New("unexpected route acknowledgment")
	}
	data := messages[0].Data
	// The netlink core may fill the echoed request's port ID.
	if string(data[4:16]) != string(request[:12]) {
		return errors.New("route acknowledgment refers to a different request")
	}
	switch errno := int32(binary.NativeEndian.Uint32(data[:4])); {
	case errno < 0:
		return syscall.Errno(-int64(errno))
	case errno > 0:
		return errors.New("invalid route acknowledgment errno")
	default:
		return nil
	}
}

func (n *localNetwork) readback(hosts []netip.Addr) error {
	lo, err := isolatedLoopback()
	if err != nil {
		return err
	}
	if lo.Index != n.index || lo.Flags&net.FlagUp == 0 {
		return errors.New("guest lo changed or is down")
	}
	actual, err := lo.Addrs()
	if err != nil {
		return err
	}
	prefixes := make([]netip.Prefix, 0, len(actual))
	for _, addr := range actual {
		prefix, err := netip.ParsePrefix(addr.String())
		if err != nil {
			return err
		}
		prefixes = append(prefixes, prefix)
	}
	return checkLoopbackAddresses(prefixes, hosts)
}

func isolatedLoopback() (net.Interface, error) {
	links, err := net.Interfaces()
	if err != nil {
		return net.Interface{}, err
	}
	var lo net.Interface
	for _, link := range links {
		if link.Name == "lo" && link.Flags&net.FlagLoopback != 0 && lo.Index == 0 {
			lo = link
			continue
		}
		if link.Flags&(net.FlagUp|net.FlagLoopback) != 0 {
			return net.Interface{}, fmt.Errorf("unexpected active or loopback link %s", link.Name)
		}
		addresses, err := link.Addrs()
		if err != nil {
			return net.Interface{}, err
		}
		if len(addresses) != 0 {
			return net.Interface{}, fmt.Errorf("other guest link %s has addresses", link.Name)
		}
	}
	if lo.Index <= 0 {
		return net.Interface{}, errors.New("guest lo not found")
	}
	return lo, nil
}
