//go:build linux && arm64

package main

import (
	"encoding/binary"
	"errors"
	"time"

	"golang.org/x/sys/unix"
)

func readInertLinks(deadline time.Time) (map[string]linkIdentity,error) {
	fd,err:=unix.Socket(unix.AF_NETLINK,unix.SOCK_RAW|unix.SOCK_CLOEXEC,unix.NETLINK_ROUTE);if err!=nil{return nil,err};defer unix.Close(fd)
	if err:=unix.Bind(fd,&unix.SockaddrNetlink{Family:unix.AF_NETLINK});err!=nil{return nil,err}
	name,err:=unix.Getsockname(fd);if err!=nil{return nil,err};local,ok:=name.(*unix.SockaddrNetlink);if !ok||local.Pid==0||local.Groups!=0{return nil,errors.New("invalid netlink local port")}
	request:=make([]byte,32);binary.LittleEndian.PutUint32(request,uint32(len(request)));binary.LittleEndian.PutUint16(request[4:6],18);binary.LittleEndian.PutUint16(request[6:8],0x301);binary.LittleEndian.PutUint32(request[8:12],71);binary.LittleEndian.PutUint32(request[12:16],local.Pid)
	if err:=unix.Sendto(fd,request,0,&unix.SockaddrNetlink{Family:unix.AF_NETLINK});err!=nil{return nil,err}
	var payloads [][]byte;total:=0
	for {
		left:=time.Until(deadline);if left<=0{return nil,errors.New("link dump deadline")}
		timeout:=unix.NsecToTimeval(left.Nanoseconds());if err:=unix.SetsockoptTimeval(fd,unix.SOL_SOCKET,unix.SO_RCVTIMEO,&timeout);err!=nil{return nil,err}
		var buffer [65536]byte
		n,_,flags,source,err:=unix.Recvmsg(fd,buffer[:],nil,0);if err!=nil{return nil,err}
		peer,ok:=source.(*unix.SockaddrNetlink)
		if !ok||peer.Family!=unix.AF_NETLINK||peer.Pid!=0||peer.Groups!=0||flags!=0||n==0{return nil,errors.New("netlink peer/truncation/empty datagram")}
		total+=n;if total>256*1024{return nil,errors.New("link dump byte bound")}
		rows,done,err:=decodeLinkDatagram(buffer[:n],71,local.Pid);if err!=nil{return nil,err};payloads=append(payloads,rows...)
		if len(payloads)>16{return nil,errors.New("link dump count bound")}
		if done {
			_,_,_,_,extra:=unix.Recvmsg(fd,buffer[:],nil,unix.MSG_DONTWAIT)
			if extra!=unix.EAGAIN&&extra!=unix.EWOULDBLOCK{return nil,errors.New("extra datagram after terminal link dump")}
			return validateLinkPayloads(payloads)
		}
	}
}
