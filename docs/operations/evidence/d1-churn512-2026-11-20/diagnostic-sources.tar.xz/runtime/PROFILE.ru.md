# SOURCE ONLY · standalone churn512 под общей памятью 512 MB

Это подготовка следующего полезного измерения, не готовый runtime-пакет.
Приложения, Docker, helper и Go ещё не собирались и не запускались.
Нет утверждения полной D1/G2/выпуска или пригодности 512 MB по одному
низкому пику. Исходный срез для наложения: `93eb8fe75d2a90710d21409c535276c6c7ed28f2`.

## Подтверждённая работа

Драйвер происходит из `2026-11-17/d1-churn32-after-g2-identity/driver.go.txt`.
Его циклы дают 512→256→512→0 TLSv2/F1, 768 различных proof identity и
**896** подписанных ответов: 256 initial, 128 survivors, 512 replacement.
Это не 224 старого Common32: старый закрытый FIND_NODE driver давал 56.
На первых двух этапах каждый живой пир участвует ровно в одном lookup;
на третьем каждый из 512 является и источником, и целью. Проверяются
исходный request ID, challenge, identity цели и криптографическая подпись.
Полезная работа последовательна, таймеры/токены/подписи не меняются.

Service независимо подтверждает четыре точных состава. 256 survivors
сохраняют ConnID, 256 новых identity получают новые ConnID, после закрытия
состав пуст. Пустота membership не считается retirement/drain barrier.
Финальный intake: Offered=Committed=Taken=Answered=896;
Refused=Replaced=Violations=0, Saturated=false.

## Почему нужен подготовитель сети

Штатный loopback-класс ограничен 64 активными и 100 новыми за 10 секунд
(`internal/core/node/loopback_inbound.go`). 512 источников 127.0.0.1
должны получить отказ. Эти проверки **не ослабляются**.

Сервис продолжает слушать только 127.0.0.1:64646 в собственном `network=none`
namespace. Для источников используются 768 различных private /32 адресов
10.77.0.1…10.77.3.6 на lo; адрес выбирается по порядку создания identity,
включая 256 замен. Как в Full512, peer source классифицируется обычным
clearnet-путём, без изменения его per-IP, TLS, handshake или connection gates.
Внешних NIC, маршрутов, портов или Docker bridge не добавляется.

Оригинальный secret-preparer с **только CHOWN** и его передача секрета
501:20/0600/read-only сохраняются. Он завершается normal0, reap и удаляется
до нового отдельного topology-helper. Service keeper уже ждёт CONTINUE;
это ожидание входит в общий cgroup peak.

Credential/secret/handoff алгоритм сохранён. В изолированной копии добавлены
новые input-файлы worker/topology; единственная правка функции preparer —
включить topology в список исполняемых входов mode0555. Точный diff:
`CANONICAL-INVENTORY.diff`; auth остаётся 0600/501:20.

Topology-helper: root0:0, CapDropALL и только NET_ADMIN, 0,25 CPU /128 MiB /
32 PID без swap; read-only root, без host mounts, использует только свою
проверенную ELF и namespace собственного ожидающего service-контейнера.
Проверяет exact namespace, ровно lo и исходные стандартные адреса, effective/
permitted/bounding capabilities=NET_ADMIN, NoNewPrivs=1; добавляет фиксированные
768 /32 netlink с EXCL/ACK и строгим readback. Нет произвольных адресов,
интерфейсов, sysctl, сетевых mount или аргументов. Внутренний deadline15 с,
host-фаза20 с; исходный общий таймер не перезапускается. Helper обязан
завершиться normal0, reap и быть подтверждённо удалён **до CONTINUE**.

## Неизменяемые рабочие пределы

| Роль | CPU | RAM | PID | swap |
|---|---:|---:|---:|---:|
| corsad + keeper + sampler вместе | 1 | 512 000 000 B | 64 | 0 |
| driver отдельно | 1 | 256 MiB | 32 | 0 |
| secret-preparer, затем topology-helper | 0,25 | 128 MiB | 32 | 0 |

Не больше двух работающих контейнеров: waiting service+один preparer/helper,
затем service+driver. Helper-бюджет никогда не прибавляется к service peak.
Driver/service получают явный nofile4096:4096 с readback; closed service
фиксирует MaxIncoming512, MaxOutgoing8 и общий B520 с резервом8. Это
параметры изолированного экземпляра, не изменение production defaults.

Общее work180 с с копиями, подготовкой и очисткой ролей внутри окна;
отдельно cleanup30 с. Фазовые fences по общей шкале: secret20, topology45,
driver должен закончиться не позже165, daemon+sampler reap и final capture
до180. Go driver timeout120 с; никакого автоматического роста при нехватке.
Первый FAIL/OOM/таймаут/недостоверный обязательный показатель — STOP.

Heavy-lock, свежие SHA/preflight, минимум10 GiB свободно плюс входы.
Закреплённый canonical Python Linux arm64 образ
`sha256:45ccc728acf675888bde399354b6c8338accfc591e35496f9413a3742f3ae313`;
его наличие требует readonly preflight, без pull или сети. Только
собственные свежие volumes, tmpfs секрета≤1 MiB, state≤64 MiB по фазовым
проверкам. Жёсткой дисковой квоты и общих host hard caps/no-swap нет;
свободное место хоста не доказывает Docker-store free. RAW service≤36 MiB,
driver≤4 MiB по фазовым проверкам; все streams/EOF и отсутствие ротации
должны проверяться. Насыщение — неполные данные, не успех.

## Измерение

Основной показатель: kernel charged `memory.peak` **общей** service-cgroup
с момента её создания, включая ожидание keeper, daemon и sampler. До
финального чтения должны быть подтверждены daemon reap и sampler reap.
Keeper затем читает final peak/events/CPU/PID; ничего не вычитается.
Поздний keeper-only tail и неподтверждённая shared-page attribution UNKNOWN.
Пик драйвера и расходы обоих подготовителей отражаются отдельно; отсутствие
их полной метрики — UNKNOWN. CPU inclusive, не стоимость одного handshake.

Sampler — отдельный ограниченный Python-процесс внутри service-cgroup;
его стоимость целиком входит в общий бюджет. Период0,5 с, обязательный
gap не более2 с; финальный peak читает keeper после остановки sampler. Readout goroutine daemon с membership
остается включённой; сериализация512 rows входит в измеренную стоимость.
Её mutex waits не дают гарантированного wall-clock deadline.

Полный успех требует всей работы896/768, четырёх составов, ConnID-проверок,
обязательных полных RAW, лимитов, нулевых max/OOM/OOM-kill и normal exits.
Недостаточный ресурс driver256 MiB также останавливает попытку; он не
оправдывает повышение лимитов или вывод о service по незавершённой работе.
Неопределённое завершение удерживает heavy-lock до восстановления;
программные сроки не гарантируют остановку зависшего Docker/FS.

Адреса lo создаёт отдельный helper: атрибуция оставшихся kernel network
allocations после его удаления также UNKNOWN. Service peak — charged
cgroup metric, а не физический расход всех страниц общего netns.
