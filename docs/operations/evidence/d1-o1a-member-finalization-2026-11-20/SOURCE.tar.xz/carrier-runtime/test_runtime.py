import copy
import gzip
import hashlib
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest
from unittest import mock
import assembly
import capture_worker
import launch
import support
import verify

HERE=Path(__file__).resolve().parent
fixture_module=HERE.parent/'d1-o1a-carrier-route-diagnostic-source-v1'/'test_decode.py'
spec=importlib.util.spec_from_file_location('source_fixtures',fixture_module)
# The source fixture module imports decode by its source-folder name.
import sys
sys.path.insert(0,str(fixture_module.parent))
fixtures=importlib.util.module_from_spec(spec);spec.loader.exec_module(fixtures)

class Tests(unittest.TestCase):
    def test_tiny_newc_roundtrip_and_mode_attempt_payload_refusal(self):
        elf=b'synthetic-static-fixture';attempt='a'*32
        with mock.patch.object(assembly,'elf_check',lambda value:None):
            archive=assembly.make(elf,attempt);out=assembly.readback(archive,elf,attempt)
            self.assertEqual(len(out['members']),5)
            self.assertEqual(assembly.readback(archive,None,attempt),out)
            with self.assertRaises(ValueError):assembly.readback(archive,elf,'b'*32)
            plain=gzip.decompress(archive)
            for changed in (plain.replace(b'0000816d',b'000081ed',1),plain.replace(elf,b'x'*len(elf)),plain+b'extra'):
                if changed==plain:continue
                with self.assertRaises(ValueError):assembly.readback(gzip.compress(changed,mtime=0),elf,attempt)

    def test_production_elf_pin_is_not_relaxed(self):
        with self.assertRaises(ValueError):assembly.make(b'synthetic-static-fixture','a'*32)
        with self.assertRaises(ValueError):assembly.make(b'', '../escape')

    def test_normal_native_and_diagnostic_data_replay(self):
        expected,receipt,console,native=self.retained()
        out=verify.replay(expected,receipt,console,native,b'')
        self.assertEqual(out['diagnostic']['outcome'],'LATE_OWNED_MULTICAST_RECREATED')
        self.assertEqual(out['physical_XPC_resources'],'UNKNOWN')

    def test_native_raw_and_lifecycle_fail_closed(self):
        expected,receipt,console,native=self.retained()
        for key,value in [('worker_exit',1),('controller_stop',True),('input_recheck',False),('owned_group_absent',False),('worker_reaped_ns',400*10**9)]:
            bad=copy.deepcopy(receipt);bad[key]=value
            with self.subTest(key=key),self.assertRaises(ValueError):verify.check_lifecycle(expected,bad,console,native,b'')
        with self.assertRaises(ValueError):verify.check_lifecycle(expected,receipt,console+b'x',native,b'')
        bad=copy.deepcopy(receipt);bad['captures']['native']['eof']=False
        with self.assertRaises(ValueError):verify.check_lifecycle(expected,bad,console,native,b'')

    def test_stopped_ack_keeps_child_failure_without_calling_success(self):
        expected,receipt,console,native=self.retained()
        failed=console.replace(b'normal_exit=1 exit=0',b'normal_exit=1 exit=125')
        self.assertEqual(verify.guest_receipt(expected,failed)['exit'],'125')
        with self.assertRaises(ValueError):verify.guest_receipt(expected,failed.replace(b'all_children_reaped=1',b'all_children_reaped=0'))

    def test_runtime_not_ready_blocks_before_any_worker(self):
        with self.assertRaises(ValueError):launch.validate({'profile':support.PROFILE,'workload':'carrier-kernel-diag','attempt_id':'a'*32,'files':{},'inputs':{},'assembly':{},'readiness':{'CODE':False,'QA':True,'ROOT':False}})
        self.assertEqual((capture_worker.Deadlines().work,capture_worker.Deadlines().kill,capture_worker.Deadlines().reap),(360*10**9,398*10**9,400*10**9))

    def test_input_digest_is_bounded_and_stable_for_small_owned_file(self):
        with tempfile.TemporaryDirectory() as temp:
            path=Path(temp).resolve()/'input';path.write_bytes(b'input');path.chmod(0o400)
            self.assertEqual(support.file_digest(path,8),(hashlib.sha256(b'input').hexdigest(),5))
            with self.assertRaises(ValueError):support.file_digest(path,4)
            link=Path(temp).resolve()/'link';link.symlink_to(path)
            with self.assertRaises(ValueError):support.file_digest(link,8)

    def retained(self):
        console=fixtures.fixture();expected={'profile':support.PROFILE,'workload':'carrier-kernel-diag','attempt_id':'a'*32,'handoff_sha256':'b'*64,'kernel_sha256':'c'*64,'initrd_sha256':'d'*64,'launcher_sha256':'e'*64}
        events=[]
        for seq,(name,extra) in enumerate([('ready',{}),('start_ok',{}),('guest_stopped',{'guest_error':None}),('stop_complete',{'final_state':'stopped'})],1):events.append(dict(attempt_id=expected['attempt_id'],seq=seq,elapsed_ns=seq*10**9,event=name,**extra))
        native=b''.join((json.dumps(row)+'\n').encode() for row in events)
        captures={name:{'received':len(raw),'retained':len(raw),'eof':True,'sha256':hashlib.sha256(raw).hexdigest()} for name,raw in [('console',console),('native',native),('stderr',b'')]}
        receipt=dict(expected,input_recheck=True,controller_stop=False,outer_kill=False,stop_reason=None,worker_reaped=True,owned_group_absent=True,capture_complete=True,worker_exit=0,worker_reaped_ns=5*10**9,captures=captures)
        return expected,receipt,console,native

if __name__=='__main__':unittest.main()
