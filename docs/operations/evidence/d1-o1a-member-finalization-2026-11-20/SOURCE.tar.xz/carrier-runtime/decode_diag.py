"""Bounded retained-RAW diagnostic decoder; no guest/product oracle changes."""
import ipaddress
import re
import struct

MAX_CONSOLE=4*1024*1024
MAX_RAW=512*1024
PATTERN=re.compile(rb'O1A_DGRAM attempt=([0-9a-f]{32}) stage=([a-z0-9-]{1,64}) id=([0-9]+) seq=([0-9]+) sender=([0-9]+) groups=([0-9]+) recvflags=([0-9]+) total=([0-9]+) offset=([0-9]+) hex=([0-9a-f]+)')

def need(ok,reason):
    if not ok:raise ValueError(reason)

def attrs(raw):
    result=[]
    while raw:
        need(len(raw)>=4,'attribute header')
        n,kind=struct.unpack_from('<HH',raw);align=(n+3)&~3
        need(4<=n<=len(raw) and align<=len(raw),'attribute size')
        need(not any(raw[n:align]),'attribute padding')
        result.append({'type':kind,'value_hex':raw[4:n].hex()})
        raw=raw[align:]
    return result

def route(body,owned):
    need(len(body)>=12,'rtmsg length')
    family,dstbits,srcbits,tos,table,protocol,scope,kind,flags=struct.unpack_from('<8BI',body)
    a=attrs(body[12:]);values={};problems=[]
    need(family==10 and tos==0,'original IPv6 rtmsg family/tos')
    for row in a:
        t=row['type'];v=bytes.fromhex(row['value_hex'])
        need(t not in values and t&0xc000==0,'duplicate or flagged attribute')
        values[t]=v
    for t,n in ((15,4),(6,4),(4,4),(20,1),(12,32)):
        need(t in values and len(values[t])==n,'original required attribute '+str(t))
    need(set(values)<={1,2,15,6,4,20,12},'original unknown routing attribute')
    need(all(t not in values or len(values[t])==16 for t in (1,2)),'prefix attribute length')
    need((dstbits==0 or 1 in values) and (srcbits==0 or 2 in values),'missing prefix attribute')
    need(values[20][0] in (0,1,3),'preference value')
    destination=ipaddress.IPv6Network((ipaddress.IPv6Address(values.get(1,bytes(16))),dstbits),strict=True)
    source=ipaddress.IPv6Network((ipaddress.IPv6Address(values.get(2,bytes(16))),srcbits),strict=True)
    bigtable,metric,index=[struct.unpack('<I',values[t])[0] for t in (15,6,4)]
    need(bigtable==table and 0<index<=0x7fffffff,'original table/index')
    out={'destination':str(destination),'source':str(source),'table':table,'protocol':protocol,'scope':scope,'kind':kind,'flags':flags,'metric':metric,'index':index,'preference':values[20][0],'attrs':a}
    if destination==ipaddress.IPv6Network('::1/128'):
        out.update(classification='ORIGINAL_LOOPBACK_SKIP',failed_predicates=[])
        return out
    expected={'destination':'ff00::/8','source':'::/0','table':255,'protocol':2,'kind':5,'scope':0,'metric':256,'flags':0,'preference':0}
    problems=[field for field,value in expected.items() if out[field]!=value]
    if index not in owned:problems.append('unowned_oif')
    out.update(classification='ORIGINAL_CANDIDATE' if not problems else 'ORIGINAL_CANDIDATES_WOULD_REFUSE',failed_predicates=problems)
    return out

def link(body):
    need(len(body)>=16,'ifinfomsg length');family,pad,kind,index,flags,change=struct.unpack_from('<BBHiII',body)
    a=attrs(body[16:]);out={'index':index,'family':family,'kind':kind,'flags':flags,'change':change,'attrs':a}
    for name,t in (('name',3),('alias',20)):
        rows=[bytes.fromhex(x['value_hex']) for x in a if x['type']&0x3fff==t]
        need(len(rows)<=1,'duplicate link label')
        if rows:
            v=rows[0];need(v and v[-1]==0 and b'\0' not in v[:-1],'link string')
            out[name]=v[:-1].decode('ascii')
    return out

def transport_decode(console,attempt):
    need(type(console) is bytes and len(console)<=MAX_CONSOLE,'console bound')
    need(type(attempt) is str and re.fullmatch('[0-9a-f]{32}',attempt),'attempt')
    # Retained partial diagnostics stay partial, never silently success.
    chunks={};owned=None;owned_line=None;markers=[];metadata=[];requests={};parent=None;caps=None
    for line in console.splitlines():
        need(len(line)<=2048 or not line.startswith(b'O1A_'),'diagnostic line bound')
        if line.startswith(b'O1A_DGRAM '):
            m=PATTERN.fullmatch(line);need(m is not None,'malformed raw chunk')
            a,stage,*nums,hexdata=m.groups();need(a.decode()==attempt,'raw attempt')
            identity,seq,sender,groups,flags,total,offset=map(int,nums)
            need(0<identity<=128 and 0<seq<2**32 and 0<total<65536 and sender==groups==0 and flags&0x28==0,'raw sender/header/bound')
            part=bytes.fromhex(hexdata.decode());need(0<len(part)<=512 and offset%512==0 and offset+len(part)<=total,'raw chunk range')
            key=(identity,stage.decode(),seq,sender,groups,flags,total)
            old=[k for k in chunks if k[0]==identity];need(not old or old==[key],'datagram identity reused')
            data=chunks.setdefault(key,{})
            need(offset not in data,'duplicate raw chunk');data[offset]=part
        elif line.startswith(b'O1A_'):
            need(('attempt='+attempt).encode() in line.split(b' '),'metadata attempt')
            metadata.append(line.decode('ascii'))
            if line.startswith(b'O1A_REQUEST '):
                fields=dict(x.split('=',1) for x in line.decode().split()[1:])
                need(set(fields)=={'attempt','stage','seq','kind','flags','mono_ns'} and int(fields['mono_ns'])>0,'request schema')
                key=(fields['stage'],int(fields['seq']))
                need(key not in requests,'duplicate request')
                requests[key]={'kind':int(fields['kind']),'flags':int(fields['flags']),'mono_ns':int(fields['mono_ns'])}
            if line.startswith(b'O1A_DIAG_PARENT_RESULT '):
                need(parent is None,'duplicate parent result');parent=dict(x.split('=',1) for x in line.decode().split()[1:])
            if line.startswith(b'O1A_DIAG_CAPS '):
                need(caps is None,'duplicate caps result');caps=dict(x.split('=',1) for x in line.decode().split()[1:])
            if line.startswith(b'O1A_OWNED '):
                need(owned is None,'duplicate ownership')
                fields=dict(x.split('=',1) for x in line.decode().split()[1:])
                need(fields['peer_name']=='o1ap' and fields['alias']=='corsa-o1a-diag-'+attempt and fields['lo_owned']=='false','owned labels')
                peer=int(fields['peer']);lo=int(fields['lo']);need(peer>0 and lo>0 and peer!=lo,'owned indices')
                owned={peer};owned_line=fields
            if line.startswith(b'O1A_SNAPSHOT_COMPLETE '):markers.append(line.decode().split('stage=',1)[1].split()[0])
    result=[];raw_total=0;routes=[];links=[]
    for key,parts in sorted(chunks.items()):
        identity,stage,seq,sender,groups,flags,total=key;data=bytearray()
        for offset,value in sorted(parts.items()):need(offset==len(data),'raw chunk gap');data.extend(value)
        need(len(data)==total,'incomplete datagram');raw_total+=total;need(raw_total<=MAX_RAW,'total raw bound');at=0;messages=[]
        while at<len(data):
            need(len(data)-at>=16,'nlmsg header');n,kind,flags,s,pid=struct.unpack_from('<IHHII',data,at);align=(n+3)&~3
            need(n>=16 and align<=len(data)-at and s==seq and flags&0x10==0,'nlmsg framing/seq/interrupted')
            body=bytes(data[at+16:at+n]);row={'length':n,'kind':kind,'flags':flags,'seq':s,'pid':pid,'body_hex':body.hex()}
            if kind==24:
                try:parsed=route(body,owned if stage.startswith('member-') and owned is not None else set());parsed.update(stage=stage,datagram=identity)
                except (ValueError,struct.error) as error:parsed={'classification':'ORIGINAL_ROUTE_PARSER_WOULD_REFUSE','reason':str(error),'stage':stage,'datagram':identity}
                routes.append(parsed);row['route']=parsed
            elif kind==16:
                parsed=link(body);parsed.update(stage=stage,datagram=identity);links.append(parsed);row['link']=parsed
            messages.append(row);at+=align
        result.append({'id':identity,'stage':stage,'seq':seq,'messages':messages})
    # Original parser rejects duplicate route identities before candidate selection.
    for stage in set(row['stage'] for row in routes):
        seen=set()
        for row in (x for x in routes if x['stage']==stage and 'index' in x):
            identity=tuple(row[k] for k in ('destination','source','table','protocol','scope','kind','flags','metric','index','preference'))
            if identity in seen:row['classification']='ORIGINAL_ROUTE_PARSER_WOULD_REFUSE';row['reason']='duplicate original route identity'
            seen.add(identity)
    required={'member-created-lo-up','outer-created','member-before-addrgen','member-after-addrgen','member-before-up','member-after-up','member-pre-bridge-clean','member-post-bridge-0ms','member-post-bridge-25ms','member-post-bridge-100ms','member-post-bridge-250ms'}
    complete=required<=set(markers) and any(x.startswith('O1A_DIAG_CHILD_COMPLETE ') for x in metadata)
    if complete:
        need(parent is not None and all(parent.get(k)==v for k,v in {'child_reaped':'1','all_children_reaped':'1','killed':'0','normal_exit':'1','exit':'0','scope':'DIAGNOSTIC_ONLY_NOT_O1A_PASS'}.items()),'parent normal/reap result')
        need(caps is not None and all(caps.get(k)==v for k,v in {'threads':'1','uid':'0','nnp':'1','eff':'00000000002010c0','prm':'00000000002010c0','bnd':'00000000002010c0','inh':'0','amb':'0'}.items()),'exact four capability result')
        need(owned is not None,'missing ownership label')
        for stage in required:
            stage_requests=[(key,row) for key,row in requests.items() if key[0]==stage]
            need([row['kind'] for _,row in stage_requests]==[18,22,26] and all(row['flags']==0x300 for _,row in stage_requests),'snapshot requests incomplete')
            for key,request in stage_requests:
                messages=[m for d in result if (d['stage'],d['seq'])==key for m in d['messages']]
                need(messages and messages[-1]['kind']==3 and sum(m['kind']==3 for m in messages)==1,'snapshot DONE missing')
                need(all(m['kind'] in (request['kind']-2,3) for m in messages),'snapshot reply kind')
                for m in messages:
                    if m['kind']==3:need(m['body_hex'] in ('','00000000'),'snapshot DONE status')
            if stage.startswith('member-'):
                inventory=[x for x in links if x['stage']==stage]
                if stage=='member-created-lo-up':
                    need(len(inventory)==1 and inventory[0].get('name')=='lo' and inventory[0]['flags']&1,'initial member lo UP')
                    continue
                need(len(inventory)==2 and {x.get('name') for x in inventory}=={'lo','o1ap'},'member exact two links')
                peer=next(x for x in inventory if x.get('name')=='o1ap')
                need(peer['index']==int(owned_line['peer']),'member OIF binding')
                need(peer.get('alias')==owned_line['alias'],'member alias binding')
    final=[x for x in routes if x['stage']=='member-after-up']
    reproduced=any(x['classification']=='ORIGINAL_CANDIDATES_WOULD_REFUSE' for x in final)
    return {'scope':'SIMPLIFIED_KERNEL_DIAGNOSTIC_ONLY_NOT_O1A_PASS','attempt_id':attempt,'capture_complete_markers':complete,'outcome':'REPRODUCED_CANDIDATE_REFUSAL' if complete and reproduced else 'NOT_REPRODUCED' if complete else 'INCOMPLETE','ownership_label':owned_line,'routes':routes,'links':links,'datagrams':result,'metadata':metadata,'requests':[dict(row,stage=key[0],seq=key[1]) for key,row in requests.items()],'raw_bytes':raw_total,'original_failed_attempt_cause':'UNKNOWN_UNTIL_MATCHED_TO_SAME_BOUNDARY_FIELDS'}

def signature(row):
    return tuple(row[k] for k in ('destination','source','table','protocol','scope','kind','flags','metric','index','preference'))

def delete_body(index):
    def a(kind,raw):
        size=len(raw)+4
        return struct.pack('<HH',size,kind)+raw+bytes((-size)%4)
    return struct.pack('<8BI',10,8,0,0,255,2,0,5,0)+a(1,bytes.fromhex('ff000000000000000000000000000000'))+b''.join(a(k,struct.pack('<I',v)) for k,v in ((15,255),(6,256),(4,index)))

def decode(console,attempt):
    out=transport_decode(console,attempt);out['scope']='SIMPLIFIED_FINITE_CARRIER_DIAGNOSTIC_ONLY_NOT_O1A_PASS';out['source_installs_seccomp_filter']=False;out['actual_seccomp_mode']='NOT_SAMPLED'
    if not out['capture_complete_markers']:
        out['outcome']='INCOMPLETE';return out
    def metadata(prefix):
        selected=[]
        for i,line in enumerate(out['metadata']):
            if not line.startswith(prefix+' '):continue
            fields={}
            for word in line.split()[1:]:
                need(word.count('=')==1,'carrier field framing');key,value=word.split('=');need(key not in fields,'duplicate carrier field');fields[key]=value
            need(fields.get('attempt')==attempt,'carrier attempt');selected.append((i,fields))
        return selected
    def one(prefix,keys):
        rows=metadata(prefix);need(len(rows)==1 and set(rows[0][1])==set(keys)|{'attempt'},prefix+' exact record');return rows[0]
    def routes(stage):return [r for r in out['routes'] if r['stage']==stage]
    def owned_links(stage):
        rows=[r for r in out['links'] if r['stage']==stage];need(len(rows)==2 and {r.get('name') for r in rows}=={'lo','o1ap'},'predelete exact link inventory')
        peer=next(r for r in rows if r.get('name')=='o1ap');need(peer['index']==int(out['ownership_label']['peer']) and peer.get('alias')=='corsa-o1a-diag-'+attempt,'predelete original nonce/name/index')
    ei,early=one('O1A_EARLY_CANDIDATES',{'candidates','routes','peer','table','mono_ns'})
    ri,reconciled=one('O1A_EARLY_RECONCILED',{'candidates','deletions','remaining','mono_ns'})
    bi,bridge=one('O1A_BRIDGE_UP_RETURNED',{'index','mono_ns'})
    count=int(early['candidates']);need(count in (0,1) and early['table']=='255' and early['peer']==out['ownership_label']['peer'],'early candidate bound')
    before=routes('member-predelete-qualify');owned_links('member-predelete-qualify')
    need(len(before)==int(early['routes']) and all(r['classification'] in ('ORIGINAL_LOOPBACK_SKIP','ORIGINAL_CANDIDATE') for r in before),'entire predelete dump qualification')
    candidates=[r for r in before if r['classification']=='ORIGINAL_CANDIDATE'];need(len(candidates)==count,'actual complete candidate count')
    # Every predelete identity is unique; the original parser already checks duplicates.
    need(len(set(map(signature,before)))==len(before),'duplicate predelete route')
    requests=[r for r in out['requests'] if r['kind']==25];bound=metadata('O1A_DELETE_BOUND')
    need(reconciled['candidates']==early['candidates'] and int(reconciled['deletions'])==count and ei<ri<bi and int(early['mono_ns'])<=int(reconciled['mono_ns'])<=int(bridge['mono_ns']),'one finite reconciliation/order')
    if count:
        need(len(requests)==len(bound)==1,'exactly one owned deletion')
        di,fields=bound[0];need(set(fields)=={'attempt','peer','table','destination','source','metric','protocol','scope','kind','flags','preference','body_hex','mono_ns'},'delete metadata shape')
        expected={'peer':early['peer'],'table':'255','destination':'ff00::/8','source':'::/0','metric':'256','protocol':'2','scope':'0','kind':'5','flags':'0','preference':'0'}
        need(all(fields[k]==v for k,v in expected.items()) and bytes.fromhex(fields['body_hex'])==delete_body(int(early['peer'])),'exact original delete identity/body')
        need(ei<di<ri and int(early['mono_ns'])<=int(fields['mono_ns'])<=int(reconciled['mono_ns']),'delete before readback')
        request=requests[0];need(request['stage']=='member-one-owned-delete' and request['flags']==4,'fixed single ACK-only deletion')
        replies=[m for d in out['datagrams'] if d['stage']==request['stage'] and d['seq']==request['seq'] for m in d['messages']]
        need(len(replies)==1 and replies[0]['kind']==2 and len(bytes.fromhex(replies[0]['body_hex']))>=4 and bytes.fromhex(replies[0]['body_hex'])[:4]==bytes(4),'one successful delete ACK')
        owned_links('member-predelete-ownership');fresh=routes('member-predelete-ownership')
        need(all(r['classification'] in ('ORIGINAL_LOOPBACK_SKIP','ORIGINAL_CANDIDATE') for r in fresh) and sorted(map(signature,fresh))==sorted(map(signature,before)),'fresh full predelete identity binding')
    else:need(not requests and not bound,'zero candidates means no deletion')
    after=routes('member-delete-readback');owned_links('member-delete-readback')
    remaining=[r for r in before if r['classification']=='ORIGINAL_LOOPBACK_SKIP']
    need(sorted(map(signature,after))==sorted(map(signature,remaining)) and len(after)==int(reconciled['remaining']),'exact remaining readback')
    clean=routes('member-pre-bridge-clean');need(sorted(map(signature,clean))==sorted(map(signature,remaining)),'prebridge snapshot still clean')
    timings=metadata('O1A_TIMED_SNAPSHOT');need(len(timings)==4,'four fixed timed snapshots')
    previous=bi
    for (i,row),offset in zip(timings,(0,25,100,250)):
        need(set(row)=={'attempt','stage','scheduled_offset_ms','bridge_up_ns','begin_ns','end_ns'} and row['stage']==f'member-post-bridge-{offset}ms' and row['scheduled_offset_ms']==str(offset) and row['bridge_up_ns']==bridge['mono_ns'],'fixed observation windows')
        need(previous<i and int(row['begin_ns'])>=int(bridge['mono_ns'])+offset*10**6 and int(row['end_ns'])>=int(row['begin_ns']),'actual snapshot brackets');previous=i
    late=[r for r in out['routes'] if r['stage'].startswith('member-post-bridge-')]
    exact=[r for r in late if r['classification']=='ORIGINAL_CANDIDATE'];other=[r for r in late if r['classification'] not in ('ORIGINAL_LOOPBACK_SKIP','ORIGINAL_CANDIDATE')]
    outcome=('LATE_OWNED_MULTICAST_RECREATED' if count else 'LATE_OWNED_MULTICAST_CREATED') if exact else 'OTHER_POSTBRIDGE_ROUTE_REFUSAL' if other else 'NOT_REPRODUCED_IN_FIXED_WINDOW'
    out.update(outcome=outcome,early_candidates=count,actual_deletions=count,bridge_up=bridge,timed_snapshots=[r for _,r in timings],late_owned_routes=exact,original_readonly_guard4_would_refuse=bool(exact),original_failed_attempt_cause='TIMING_MECHANISM_OBSERVATION_ONLY; original651767 lacks route identity/time dump')
    return out
