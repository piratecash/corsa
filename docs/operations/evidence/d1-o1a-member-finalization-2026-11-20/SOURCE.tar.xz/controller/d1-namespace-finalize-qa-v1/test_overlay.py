import hashlib,tempfile,unittest
from pathlib import Path
import qa_build
class Overlay(unittest.TestCase):
 def test_readonly_archive_copy_replaced_original_input_preserved(self):
  with tempfile.TemporaryDirectory() as d:
   p=Path(d);source=p/'source';name='internal/testutil/loadstand/unit.go';target=source/name;target.parent.mkdir(parents=True);target.write_bytes(b'before');target.chmod(0o444);post=p/'post';post.write_bytes(b'after');post.chmod(0o444)
   qa_build.apply_posts(source,{name:{'path':str(post),'before_sha256':qa_build.sha(target),'after_sha256':qa_build.sha(post)}})
   self.assertEqual(target.read_bytes(),b'after');self.assertEqual(target.stat().st_mode&0o777,0o444);self.assertEqual(post.read_bytes(),b'after');self.assertEqual(post.stat().st_mode&0o777,0o444)
 def test_mismatched_before_after_or_foreign_path_never_writes_destination(self):
  for fault in ('before','after','path'):
   with self.subTest(fault=fault),tempfile.TemporaryDirectory() as d:
    p=Path(d);source=p/'source';name='internal/testutil/loadstand/unit.go';target=source/name;target.parent.mkdir(parents=True);target.write_bytes(b'before');target.chmod(0o444);post=p/'post';post.write_bytes(b'after')
    row={'path':str(post),'before_sha256':qa_build.sha(target),'after_sha256':qa_build.sha(post)}
    if fault=='before':row['before_sha256']='0'*64
    if fault=='after':row['after_sha256']='0'*64
    if fault=='path':name='internal/testutil/loadstand/../../foreign'
    with self.assertRaises(RuntimeError):qa_build.apply_posts(source,{name:row})
    self.assertEqual(target.read_bytes(),b'before');self.assertEqual(target.stat().st_mode&0o777,0o444)
if __name__=='__main__':unittest.main()
