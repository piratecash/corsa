import os,sys,json,subprocess,hashlib
from pathlib import Path
sys.path.insert(0,'/Users/hades/Documents/repos/corsa/docs/_internal/d1-artifacts/2026-11-20/d1-o1a-capexec-seccomp-build-v1')
from common import Job,need,sha
R=Path('/Users/hades/Documents/repos/corsa');P=R/'docs/_internal/d1-artifacts/2026-11-20/d1-o1a-member-setup-finalize-v1';m=json.loads((P/'MANIFEST.json').read_text())
for n,x in m['files'].items():need(sha(R/n)==x['after_sha256'],'applied source drift')
os.umask(0o077)
if os.getpid()!=os.getpgrp():os.setsid()
j=Job('namespace-finalize-linux-lint',600,6*1024**3);error=None
try:
 for n in ('gocache','lintcache','tmp'):(j.work/n).mkdir()
 env=os.environ.copy();env.update(GOCACHE=str(j.work/'gocache'),GOMODCACHE=str(R/'.gomodcache'),GOLANGCI_LINT_CACHE=str(j.work/'lintcache'),TMPDIR=str(j.work/'tmp'),GOPROXY='file://'+str(R/'.gomodcache/cache/download'),GOSUMDB='off',GOTOOLCHAIN='local',GOTELEMETRY='off',GOMAXPROCS='2',GOMEMLIMIT='768MiB',GOFLAGS='-p=1',GOOS='darwin',GOARCH='arm64',CGO_ENABLED='0')
 # Compile the native lint tool, then set the analyzed Go target in its exec environment.
 policy='(version 1)(allow default)(deny network*)'
 args=['/usr/bin/sandbox-exec','-p',policy,'/usr/local/go/bin/go','run','-exec=/usr/bin/env GOOS=linux GOARCH=arm64 CGO_ENABLED=0','github.com/golangci/golangci-lint/v2/cmd/golangci-lint@v2.14.0','run','./internal/testutil/loadstand','--timeout=7m','--color=never','--allow-serial-runners']
 j.run('linux-lint',args,cwd=R,env=env)
 for n,x in m['files'].items():need(sha(R/n)==x['after_sha256'],'lint changed source')
except BaseException as e:error=str(e)
r=j.finish({'status':'LINUX_FIXTURE_LINT_PASS' if error is None else 'FAILED','error':error,'source_manifest_sha256':sha(P/'MANIFEST.json'),'target':'linux/arm64 CGO0','lint_tool_host':'darwin/arm64','app_or_test_ELF_executed':False})
if error:raise SystemExit(1)
