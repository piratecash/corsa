import copy,importlib.util,json,sys,unittest
from pathlib import Path
import unit_run
old=Path(__file__).resolve().parent.parent/'d1-o1a-profile-fs-init-build-v2/test_c_preparation.py'
sys.modules['c_build']=unit_run
s=importlib.util.spec_from_file_location('inherited_fixture_inspect_tests',old);module=importlib.util.module_from_spec(s);s.loader.exec_module(module)
class Unit(unittest.TestCase):
 def fixture(self):
  r,c,a,w=module.Tests.fixture(self);r['Config'].update(Entrypoint=['/input/loadstand.test'],WorkingDir='/input/internal/testutil/loadstand',Labels={'corsa.o1a.fixture_unit_test_attempt':a});r['HostConfig'].update(Memory=512000000,MemorySwap=512000000);return r,c,a,w
 def test_real_docker_shape(self):module.Tests.test_real_docker_shape_and_only_canonical_host_mnt_alias(self)
 def test_limits_caps_external_network(self):module.Tests.test_limits_capabilities_command_and_external_network_refuse(self)
 def test_foreign_extra_writable_input_mounts(self):module.Tests.test_foreign_extra_duplicate_or_writable_input_mounts_refuse(self)
 def test_static_elf_refusal(self):module.Tests.test_c_static_oracle_requires_et_exec(self)
 def test_foreign_container_label(self):
  r,c,a,w=self.fixture();r['Config']['Labels']['corsa.o1a.fixture_unit_test_attempt']='foreign'
  with self.assertRaises(RuntimeError):unit_run.inspect_row(r,c,a,w)
 def test_complete_named_test_evidence(self):
  names=json.loads((Path(__file__).parent/'FROZEN.json').read_text())['tests'];raw=('\n'.join('=== RUN   '+n+'\n--- PASS: '+n+' (0.00s)' for n in names)+'\nPASS\n').encode();self.assertEqual(unit_run.qualify_tests(raw,names)['outer_pass'],14)
  for bad in (raw.replace(names[0].encode(),b'Unexpected'),raw.replace(b'--- PASS:',b'--- SKIP:',1),raw+b'--- FAIL: other (0.00s)\n',raw.replace(b'PASS\n',b''),raw.replace(b'--- PASS: '+names[0].encode()+b' (0.00s)\n',b''),raw+b'--- PASS: '+names[0].encode()+b' (0.00s)\n'):
   with self.subTest(rawlen=len(bad)),self.assertRaises(RuntimeError):unit_run.qualify_tests(bad,names)
if __name__=='__main__':unittest.main()
