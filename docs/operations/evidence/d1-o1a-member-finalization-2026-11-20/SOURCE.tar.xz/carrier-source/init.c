#define _GNU_SOURCE
/* Standalone initrd diagnostic. No Corsa/shell/public socket; at most one strictly owned multicast delete. */
#include <errno.h>
#include <fcntl.h>
#include <inttypes.h>
#include <linux/capability.h>
#include <linux/if_addr.h>
#include <linux/if_link.h>
#include <linux/netlink.h>
#include <linux/rtnetlink.h>
#include <linux/reboot.h>
#include <net/if.h>
#include <sched.h>
#include <signal.h>
#include <stdarg.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mount.h>
#include <sys/ioctl.h>
#include <sys/prctl.h>
#include <sys/reboot.h>
#include <sys/resource.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <sys/syscall.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <time.h>
#include <unistd.h>

#define FOUR ((UINT64_C(1)<<CAP_SETUID)|(UINT64_C(1)<<CAP_SETGID)|(UINT64_C(1)<<CAP_NET_ADMIN)|(UINT64_C(1)<<CAP_SYS_ADMIN))
#define RAW_MAX (512U*1024U)
#define OUTPUT_MAX (2U*1024U*1024U)
#define EXCHANGE_MAX (128U*1024U)
#define MESSAGE_MAX 65536U
#define PACKET_MAX 4096U
static unsigned output_bytes,raw_bytes,datagrams;
static char attempt[33];
static const char *stage="boot";
static void die(const char *why);
static void poweroff_now(int sig);
static void abrupt_failure(void) {
    if (getpid()==1) poweroff_now(0);
    _exit(124);
}

static uint64_t mono(void) {
    struct timespec t;
    if (clock_gettime(CLOCK_MONOTONIC,&t)) abrupt_failure();
    return (uint64_t)t.tv_sec*UINT64_C(1000000000)+(uint64_t)t.tv_nsec;
}
/* A full console stalls neither the parent deadline nor poweroff path. */
static void line(const char *fmt,...) {
    char buf[2048];
    va_list args;
    va_start(args,fmt);
    int n=vsnprintf(buf,sizeof(buf),fmt,args);
    va_end(args);
    if (n<0||(size_t)n>=sizeof(buf)||output_bytes+(unsigned)n>OUTPUT_MAX) abrupt_failure();
    size_t at=0;
    while (at<(size_t)n) {
        ssize_t got=write(STDOUT_FILENO,buf+at,(size_t)n-at);
        if (got<0&&errno==EINTR) continue;
        if (got<=0) abrupt_failure();
        at+=(size_t)got;
    }
    output_bytes+=(unsigned)n;
}
static void die(const char *why) {
    int saved=errno;
    line("O1A_DIAG_FAIL attempt=%s stage=%s reason=%s errno=%d\n",attempt,stage,why,saved);
    if (getpid()==1) poweroff_now(0);
    _exit(125);
}
static void must(int yes,const char *why) {
    if (!yes) { errno=EINVAL;die(why); }
}
static void checked(int result,const char *why) {
    if (result<0) die(why);
}
static void poweroff_now(int sig) {
    (void)sig;
    /* Must precede any possibly blocking diagnostic/console operation. */
    (void)syscall(SYS_reboot,LINUX_REBOOT_MAGIC1,LINUX_REBOOT_MAGIC2,LINUX_REBOOT_CMD_POWER_OFF,NULL);
    _exit(127);
}
static void mkdir_exact(const char *path,mode_t mode) {
    if (mkdir(path,mode)&&errno!=EEXIST) die("mkdir");
    struct stat s;
    checked(lstat(path,&s),"directory-stat");
    must(S_ISDIR(s.st_mode)&&s.st_uid==0,"directory-kind-owner");
    checked(chmod(path,mode),"directory-mode");
}
static void read_attempt(void) {
    int fd=open("/diag-attempt",O_RDONLY|O_CLOEXEC|O_NOFOLLOW);
    checked(fd,"attempt-open");struct stat st;checked(fstat(fd,&st),"attempt-stat");
    must(S_ISREG(st.st_mode)&&st.st_nlink==1&&st.st_uid==0&&(st.st_mode&07777)==0444&&st.st_size==32,"attempt-file");
    char buf[33];ssize_t n=read(fd,buf,sizeof(buf));must(n==32,"attempt-exact-length");
    checked(close(fd),"attempt-close");
    for (unsigned i=0;i<32;i++) must((buf[i]>='0'&&buf[i]<='9')||(buf[i]>='a'&&buf[i]<='f'),"attempt-lowerhex");
    memcpy(attempt,buf,32);attempt[32]=0;
}
static void exact_four(void) {
    unsigned last=0;char extra;
    FILE *f=fopen("/proc/sys/kernel/cap_last_cap","re");
    if (!f) die("lastcap-open");
    int n=fscanf(f,"%u %c",&last,&extra);
    checked(fclose(f),"lastcap-close");must(n==1&&last<64,"lastcap-bound");
    struct rlimit core={0,0};checked(setrlimit(RLIMIT_CORE,&core),"core-zero");
    checked(prctl(PR_CAP_AMBIENT,PR_CAP_AMBIENT_CLEAR_ALL,0,0,0),"ambient-clear");
    for (unsigned i=0;i<=last;i++) {
        if (!(FOUR&(UINT64_C(1)<<i))) checked(prctl(PR_CAPBSET_DROP,i,0,0,0),"bounding-drop");
    }
    struct __user_cap_header_struct h={_LINUX_CAPABILITY_VERSION_3,0};
    struct __user_cap_data_struct d[2]={{0}};
    d[0].effective=d[0].permitted=(uint32_t)FOUR;
    d[1].effective=d[1].permitted=(uint32_t)(FOUR>>32);
    checked((int)syscall(SYS_capset,&h,d),"capset");
    checked(prctl(PR_SET_NO_NEW_PRIVS,1,0,0,0),"nnp");
    f=fopen("/proc/self/status","re");if (!f) die("status-open");
    uint64_t inh=0,prm=0,eff=0,bnd=0,amb=0;unsigned threads=0,nnp=0,seen=0;char buf[512];
    while (fgets(buf,sizeof(buf),f)) {
        if (sscanf(buf,"CapInh: %" SCNx64,&inh)==1) seen|=1;
        else if (sscanf(buf,"CapPrm: %" SCNx64,&prm)==1) seen|=2;
        else if (sscanf(buf,"CapEff: %" SCNx64,&eff)==1) seen|=4;
        else if (sscanf(buf,"CapBnd: %" SCNx64,&bnd)==1) seen|=8;
        else if (sscanf(buf,"CapAmb: %" SCNx64,&amb)==1) seen|=16;
        else if (sscanf(buf,"Threads: %u",&threads)==1) seen|=32;
        else if (sscanf(buf,"NoNewPrivs: %u",&nnp)==1) seen|=64;
    }
    must(!ferror(f),"status-read");checked(fclose(f),"status-close");
    must(seen==127&&inh==0&&amb==0&&prm==FOUR&&eff==FOUR&&bnd==FOUR&&threads==1&&nnp==1&&getuid()==0&&geteuid()==0,"exact-four-readback");
    line("O1A_DIAG_CAPS attempt=%s threads=1 uid=0 nnp=1 eff=%016" PRIx64 " prm=%016" PRIx64 " bnd=%016" PRIx64 " inh=0 amb=0\n",attempt,eff,prm,bnd);
}

struct packet { unsigned char b[PACKET_MAX];size_t n; };
static struct packet link_body(int index,unsigned flags,unsigned change) {
    struct packet p={{0},sizeof(struct ifinfomsg)};
    struct ifinfomsg x={0};x.ifi_index=index;x.ifi_flags=flags;x.ifi_change=change;memcpy(p.b,&x,sizeof(x));return p;
}
static void attr(struct packet *p,unsigned short type,const void *value,size_t n) {
    must(n<=UINT16_MAX-sizeof(struct rtattr)&&p->n+RTA_ALIGN(n+sizeof(struct rtattr))<=sizeof(p->b),"attribute-bound");
    struct rtattr h={.rta_len=(unsigned short)(n+sizeof(h)),.rta_type=type};
    size_t whole=RTA_ALIGN(h.rta_len);memset(p->b+p->n,0,whole);memcpy(p->b+p->n,&h,sizeof(h));memcpy(p->b+p->n+sizeof(h),value,n);p->n+=whole;
}
static void string_attr(struct packet *p,unsigned short type,const char *value) { attr(p,type,value,strlen(value)+1); }
static void u32_attr(struct packet *p,unsigned short type,uint32_t value) { attr(p,type,&value,sizeof(value)); }
static void hexlog(const unsigned char *p,size_t n,uint32_t seq,const struct sockaddr_nl *from,int flags) {
    must(n<=MESSAGE_MAX&&raw_bytes+n<=RAW_MAX&&datagrams<128,"raw-budget");raw_bytes+=(unsigned)n;unsigned id=++datagrams;
    for (size_t at=0;at<n;at+=512) {
        size_t part=n-at<512?n-at:512;char hex[1025];
        for (size_t i=0;i<part;i++) (void)snprintf(hex+2*i,3,"%02x",p[at+i]);
        hex[2*part]=0;
        line("O1A_DGRAM attempt=%s stage=%s id=%u seq=%u sender=%u groups=%u recvflags=%d total=%zu offset=%zu hex=%s\n",attempt,stage,id,seq,from->nl_pid,from->nl_groups,flags,n,at,hex);
    }
}
struct connection { int fd;uint32_t seq; };
static struct connection open_route(void) {
    struct connection s={.fd=socket(AF_NETLINK,SOCK_RAW|SOCK_CLOEXEC,NETLINK_ROUTE),.seq=0};checked(s.fd,"route-socket");
    struct sockaddr_nl a={.nl_family=AF_NETLINK};checked(bind(s.fd,(struct sockaddr *)&a,sizeof(a)),"route-bind");
    struct timeval t={.tv_sec=2};checked(setsockopt(s.fd,SOL_SOCKET,SO_RCVTIMEO,&t,sizeof(t)),"recv-timeout");checked(setsockopt(s.fd,SOL_SOCKET,SO_SNDTIMEO,&t,sizeof(t)),"send-timeout");return s;
}
typedef void (*consume)(const struct nlmsghdr *);
static void exchange(struct connection *s,unsigned short kind,unsigned short flags,const struct packet *body,consume read_one) {
    unsigned char request[PACKET_MAX+NLMSG_HDRLEN];struct nlmsghdr h={.nlmsg_len=(uint32_t)(NLMSG_HDRLEN+body->n),.nlmsg_type=kind,.nlmsg_flags=(unsigned short)(flags|NLM_F_REQUEST),.nlmsg_seq=++s->seq};
    must(s->seq>0,"sequence-overflow");memcpy(request,&h,sizeof(h));memcpy(request+NLMSG_HDRLEN,body->b,body->n);
    line("O1A_REQUEST attempt=%s stage=%s seq=%u kind=%u flags=%u mono_ns=%" PRIu64 "\n",attempt,stage,s->seq,kind,(unsigned)flags,mono());
    struct sockaddr_nl kernel={.nl_family=AF_NETLINK};ssize_t sent=sendto(s->fd,request,h.nlmsg_len,0,(struct sockaddr *)&kernel,sizeof(kernel));must(sent==(ssize_t)h.nlmsg_len,"send-exact");
    unsigned total=0;int done=0,ack=0,echo=0;int dump=(flags&NLM_F_DUMP)==NLM_F_DUMP;
    for (unsigned tries=0;tries<32;tries++) {
        _Alignas(struct nlmsghdr) unsigned char buffer[MESSAGE_MAX];struct sockaddr_nl from={0};struct iovec iov={buffer,sizeof(buffer)};struct msghdr m={.msg_name=&from,.msg_namelen=sizeof(from),.msg_iov=&iov,.msg_iovlen=1};
        ssize_t n=recvmsg(s->fd,&m,0);if (n<0) die("recvmsg");
        must(n>0&&(size_t)n<sizeof(buffer)&&total+(unsigned)n<=EXCHANGE_MAX,"exchange-bound");total+=(unsigned)n;
        hexlog(buffer,(size_t)n,s->seq,&from,m.msg_flags);
        must(m.msg_namelen==sizeof(from)&&from.nl_family==AF_NETLINK&&from.nl_pid==0&&from.nl_groups==0&&!(m.msg_flags&(MSG_TRUNC|MSG_CTRUNC)),"kernel-complete-datagram");
        size_t at=0;
        while (at<(size_t)n) {
            must((size_t)n-at>=sizeof(struct nlmsghdr),"message-header");struct nlmsghdr *r=(struct nlmsghdr *)(void *)(buffer+at);
            must(r->nlmsg_len>=NLMSG_HDRLEN&&r->nlmsg_len<=(size_t)n-at&&NLMSG_ALIGN(r->nlmsg_len)<=(size_t)n-at&&r->nlmsg_seq==s->seq&&!(r->nlmsg_flags&NLM_F_DUMP_INTR),"message-framing-sequence");
            if (r->nlmsg_type==NLMSG_ERROR) {
                must(r->nlmsg_len>=NLMSG_HDRLEN+sizeof(int32_t)&&!ack,"ack-format");int32_t code;memcpy(&code,NLMSG_DATA(r),sizeof(code));if (code) {errno=code<0?-code:EINVAL;die("netlink-ack-error");}ack=1;
            } else if (r->nlmsg_type==NLMSG_DONE) {
                must(dump&&!done,"done-format");size_t tail=r->nlmsg_len-NLMSG_HDRLEN;must(tail==0||tail==4,"done-length");if (tail) {int32_t code;memcpy(&code,NLMSG_DATA(r),4);must(code==0,"done-error");}done=1;
            } else {
                must(!done&&r->nlmsg_type==(dump?kind-2:kind),"reply-type");echo++;
                if (read_one) read_one(r);
            }
            at+=NLMSG_ALIGN(r->nlmsg_len);
        }
        if (dump?done:(ack&&(!(flags&NLM_F_ECHO)||echo==1))) return;
    }
    die("exchange-datagrams");
}
static void link_set(struct connection *s,int index,unsigned short type,uint32_t value) {struct packet p=link_body(index,0,0);u32_attr(&p,type,value);exchange(s,RTM_NEWLINK,NLM_F_ACK,&p,NULL);}
static void up(struct connection *s,int index) {struct packet p=link_body(index,IFF_UP,IFF_UP);exchange(s,RTM_NEWLINK,NLM_F_ACK,&p,NULL);}
static void create_link(struct connection *s,const char *kind,const char *name,const char *peer,const char *alias) {
    struct packet p=link_body(0,0,0),info={{0},0};string_attr(&p,IFLA_IFNAME,name);string_attr(&p,IFLA_IFALIAS,alias);string_attr(&info,IFLA_INFO_KIND,kind);
    if (peer) {struct packet pair=link_body(0,0,0),data={{0},0};string_attr(&pair,IFLA_IFNAME,peer);string_attr(&pair,IFLA_IFALIAS,alias);attr(&data,1|NLA_F_NESTED,pair.b,pair.n);attr(&info,IFLA_INFO_DATA|NLA_F_NESTED,data.b,data.n);}
    attr(&p,IFLA_LINKINFO|NLA_F_NESTED,info.b,info.n);exchange(s,RTM_NEWLINK,NLM_F_CREATE|NLM_F_EXCL|NLM_F_ACK,&p,NULL);
}
static int link_index(const char *name) {unsigned i=if_nametoindex(name);must(i>0&&i<=INT32_MAX,"link-index");return (int)i;}
static void ns_record(const char *name) {struct stat st;checked(stat("/proc/self/ns/net",&st),"namespace-stat");line("O1A_NAMESPACE attempt=%s stage=%s name=%s dev=%ju inode=%ju mono_ns=%" PRIu64 "\n",attempt,stage,name,(uintmax_t)st.st_dev,(uintmax_t)st.st_ino,mono());}
static void snapshot(struct connection *s,const char *name) {
    stage=name;ns_record(name);struct packet p=link_body(0,0,0);exchange(s,RTM_GETLINK,NLM_F_DUMP,&p,NULL);
    struct packet a={{0},sizeof(struct ifaddrmsg)};a.b[0]=AF_INET6;exchange(s,RTM_GETADDR,NLM_F_DUMP,&a,NULL);
    struct packet r={{0},sizeof(struct rtmsg)};r.b[0]=AF_INET6;exchange(s,RTM_GETROUTE,NLM_F_DUMP,&r,NULL);
    line("O1A_SNAPSHOT_COMPLETE attempt=%s stage=%s seq=%u\n",attempt,stage,s->seq);
}
struct saved_address {int index;unsigned char prefix,address[16];};
static struct saved_address addresses[32];static unsigned address_count;
static void save_address(const struct nlmsghdr *h) {
    must(h->nlmsg_type==RTM_NEWADDR&&h->nlmsg_len>=NLMSG_HDRLEN+sizeof(struct ifaddrmsg),"address-header");const struct ifaddrmsg *a=NLMSG_DATA(h);must(a->ifa_family==AF_INET6&&a->ifa_prefixlen<=128&&a->ifa_index>0,"address-family");
    size_t at=sizeof(*a),n=h->nlmsg_len-NLMSG_HDRLEN;const unsigned char *b=NLMSG_DATA(h);int found=0;struct saved_address row={.index=(int)a->ifa_index,.prefix=a->ifa_prefixlen,.address={0}};
    while (at<n) {must(n-at>=sizeof(struct rtattr),"address-attr-header");struct rtattr x;memcpy(&x,b+at,sizeof(x));must(x.rta_len>=4&&x.rta_len<=n-at&&RTA_ALIGN(x.rta_len)<=n-at,"address-attr-bound");if (x.rta_type==IFA_ADDRESS) {must(!found&&x.rta_len==20,"address-attr-value");memcpy(row.address,b+at+4,16);found=1;}at+=RTA_ALIGN(x.rta_len);}
    must(found&&address_count<32,"address-count");addresses[address_count++]=row;
}
static void addrgen_none(struct connection *s,int index) {
    struct packet p=link_body(index,0,0),ipv6={{0},0},af={{0},0};unsigned char one=1;attr(&ipv6,IFLA_INET6_ADDR_GEN_MODE,&one,1);attr(&af,AF_INET6|NLA_F_NESTED,ipv6.b,ipv6.n);attr(&p,IFLA_AF_SPEC|NLA_F_NESTED,af.b,af.n);exchange(s,RTM_NEWLINK,NLM_F_ACK,&p,NULL);
    address_count=0;struct packet query={{0},sizeof(struct ifaddrmsg)};query.b[0]=AF_INET6;exchange(s,RTM_GETADDR,NLM_F_DUMP,&query,save_address);
    for (unsigned i=0;i<address_count;i++) {struct saved_address *a=&addresses[i];if (a->index!=index) continue;struct packet d={{0},sizeof(struct ifaddrmsg)};struct ifaddrmsg x={.ifa_family=AF_INET6,.ifa_prefixlen=a->prefix,.ifa_index=(uint32_t)index};memcpy(d.b,&x,sizeof(x));attr(&d,IFA_ADDRESS,a->address,16);exchange(s,RTM_DELADDR,NLM_F_ACK,&d,NULL);}
}
static void initial_lo_only(struct connection *s,const char *name);
static unsigned initial_links;
static void check_initial_link(const struct nlmsghdr *h) {
    must(h->nlmsg_len>=NLMSG_HDRLEN+sizeof(struct ifinfomsg),"initial-link-header");const struct ifinfomsg *x=NLMSG_DATA(h);must(x->ifi_index==link_index("lo"),"initial-foreign-link");initial_links++;
}
static void initial_lo_only(struct connection *s,const char *name) {stage=name;initial_links=0;struct packet p=link_body(0,0,0);exchange(s,RTM_GETLINK,NLM_F_DUMP,&p,check_initial_link);must(initial_links==1,"initial-exact-lo");}
static void enable_member_loopback(void) {
    int fd=socket(AF_INET,SOCK_DGRAM|SOCK_CLOEXEC,0);checked(fd,"lo-ioctl-socket");
    struct ifreq request={0};memcpy(request.ifr_name,"lo",3);
    checked(ioctl(fd,SIOCGIFFLAGS,&request),"lo-getflags");
    request.ifr_flags=(short)(request.ifr_flags|IFF_UP);
    checked(ioctl(fd,SIOCSIFFLAGS,&request),"lo-setflags");checked(close(fd),"lo-ioctl-close");
}
/* All identity fields below match frozen plannedMulticastRoutes/Candidates.
   Cache counters are read-only observations, never deletion identity. */
struct route_key {
    unsigned char destination[16],source[16];
    uint32_t table,metric,index,flags;
    unsigned char destination_bits,source_bits,protocol,scope,kind,preference;
};
static struct route_key route_rows[32];
static unsigned route_count,delete_count;
static int owned_peer,owned_lo;
static const char *owned_alias;
static unsigned owned_links;
static int same_route(const struct route_key *a,const struct route_key *b) {
    return !memcmp(a->destination,b->destination,16)&&!memcmp(a->source,b->source,16)&&a->table==b->table&&a->metric==b->metric&&a->index==b->index&&a->flags==b->flags&&a->destination_bits==b->destination_bits&&a->source_bits==b->source_bits&&a->protocol==b->protocol&&a->scope==b->scope&&a->kind==b->kind&&a->preference==b->preference;
}
static void canonical_prefix(const unsigned char *bytes,unsigned bits) {
    must(bits<=128,"route-prefix-width");
    for(unsigned bit=bits;bit<128;bit++)must(!(bytes[bit/8]&(1U<<(7-bit%8))),"route-prefix-canonical");
}
static void read_route(const struct nlmsghdr *header) {
    must(header->nlmsg_type==RTM_NEWROUTE&&header->nlmsg_len>=NLMSG_HDRLEN+sizeof(struct rtmsg)&&route_count<32,"route-header-bound");
    struct rtmsg message;memcpy(&message,NLMSG_DATA(header),sizeof(message));
    must(message.rtm_family==AF_INET6&&message.rtm_tos==0,"route-family-tos");
    struct route_key key;memset(&key,0,sizeof(key));
    key.destination_bits=message.rtm_dst_len;key.source_bits=message.rtm_src_len;
    key.table=message.rtm_table;key.protocol=message.rtm_protocol;key.scope=message.rtm_scope;key.kind=message.rtm_type;key.flags=message.rtm_flags;
    const unsigned char *bytes=(const unsigned char *)NLMSG_DATA(header)+sizeof(message);
    size_t left=header->nlmsg_len-NLMSG_HDRLEN-sizeof(message);uint32_t seen=0;
    while(left) {
        must(left>=sizeof(struct rtattr),"route-attribute-header");struct rtattr a;memcpy(&a,bytes,sizeof(a));
        size_t whole=RTA_ALIGN(a.rta_len);unsigned kind=a.rta_type;
        must(a.rta_len>=sizeof(a)&&a.rta_len<=left&&whole<=left&&(kind&0xc000)==0&&kind<=20,"route-attribute-bound");
        must(!(seen&(1U<<kind)),"route-attribute-duplicate");seen|=1U<<kind;
        size_t size=a.rta_len-sizeof(a);const unsigned char *v=bytes+sizeof(a);uint32_t number=0;
        switch(kind) {
        case RTA_DST:case RTA_SRC:
            must(size==16,"route-address-size");memcpy(kind==RTA_DST?key.destination:key.source,v,16);break;
        case RTA_TABLE:case RTA_PRIORITY:case RTA_OIF:
            must(size==4,"route-scalar-size");memcpy(&number,v,4);
            if(kind==RTA_TABLE){must(number==key.table,"route-table-consistency");key.table=number;}
            else if(kind==RTA_PRIORITY)key.metric=number;
            else key.index=number;
            break;
        case RTA_PREF:
            must(size==1&&(v[0]==0||v[0]==1||v[0]==3),"route-preference");key.preference=v[0];break;
        case RTA_CACHEINFO:must(size==32,"route-cacheinfo-size");break;
        default:must(0,"route-unknown-attribute");
        }
        for(size_t i=a.rta_len;i<whole;i++)must(bytes[i]==0,"route-attribute-padding");
        bytes+=whole;left-=whole;
    }
    uint32_t required=(1U<<RTA_TABLE)|(1U<<RTA_PRIORITY)|(1U<<RTA_OIF)|(1U<<RTA_PREF)|(1U<<RTA_CACHEINFO);
    must((seen&required)==required&&(!key.destination_bits||(seen&(1U<<RTA_DST)))&&(!key.source_bits||(seen&(1U<<RTA_SRC)))&&key.index>0&&key.index<=INT32_MAX,"route-required-fields");
    canonical_prefix(key.destination,key.destination_bits);canonical_prefix(key.source,key.source_bits);
    for(unsigned i=0;i<route_count;i++)must(!same_route(&route_rows[i],&key),"route-identity-duplicate");
    route_rows[route_count++]=key;
}
static int loopback_route(const struct route_key *row) {
    const unsigned char loopback[16]={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1};
    return row->destination_bits==128&&!memcmp(row->destination,loopback,16);
}
static int qualify_all(void) {
    const unsigned char multicast[16]={0xff},zero[16]={0};int selected=-1;
    for(unsigned i=0;i<route_count;i++) {
        const struct route_key *r=&route_rows[i];if(loopback_route(r))continue;
        must(r->destination_bits==8&&!memcmp(r->destination,multicast,16)&&r->source_bits==0&&!memcmp(r->source,zero,16)&&r->table==RT_TABLE_LOCAL&&r->protocol==RTPROT_KERNEL&&r->scope==RT_SCOPE_UNIVERSE&&r->kind==RTN_MULTICAST&&r->metric==256&&r->flags==0&&r->preference==0,"entire-dump-original-candidate-fields");
        must(r->index==(uint32_t)owned_peer&&selected<0,"entire-dump-owned-single-oif");selected=(int)i;
    }
    return selected;
}
static void read_owned_link(const struct nlmsghdr *header) {
    must(header->nlmsg_type==RTM_NEWLINK&&header->nlmsg_len>=NLMSG_HDRLEN+sizeof(struct ifinfomsg),"owned-link-header");
    struct ifinfomsg info;memcpy(&info,NLMSG_DATA(header),sizeof(info));
    const unsigned char *bytes=(const unsigned char *)NLMSG_DATA(header)+sizeof(info);size_t left=header->nlmsg_len-NLMSG_HDRLEN-sizeof(info);
    char name[64]={0},alias[128]={0};unsigned names=0,aliases=0;
    while(left) {
        must(left>=sizeof(struct rtattr),"owned-link-attribute-header");struct rtattr a;memcpy(&a,bytes,sizeof(a));size_t whole=RTA_ALIGN(a.rta_len);
        must(a.rta_len>=sizeof(a)&&a.rta_len<=left&&whole<=left,"owned-link-attribute-bound");unsigned kind=a.rta_type&0x3fff;const unsigned char *v=bytes+sizeof(a);size_t n=a.rta_len-sizeof(a);
        if(kind==IFLA_IFNAME||kind==IFLA_IFALIAS) {
            char *dst=kind==IFLA_IFNAME?name:alias;size_t cap=kind==IFLA_IFNAME?sizeof(name):sizeof(alias);
            must(n>0&&n<=cap&&v[n-1]==0&&!memchr(v,0,n-1),"owned-link-label");memcpy(dst,v,n);
            if(kind==IFLA_IFNAME)must(++names==1,"owned-name-duplicate");else must(++aliases==1,"owned-alias-duplicate");
        }
        bytes+=whole;left-=whole;
    }
    must(names==1,"owned-link-name-required");
    if(!strcmp(name,"lo")){must(info.ifi_index==owned_lo&&!(owned_links&1U),"owned-lo-identity");owned_links|=1U;}
    else {must(!strcmp(name,"o1ap")&&info.ifi_index==owned_peer&&aliases==1&&!strcmp(alias,owned_alias)&&!(owned_links&2U),"owned-peer-nonce-name-index");owned_links|=2U;}
}
static void member_namespace(int member) {
    struct stat expected,actual;checked(fstat(member,&expected),"member-owned-fd-stat");checked(stat("/proc/self/ns/net",&actual),"member-current-ns-stat");
    must(expected.st_dev==actual.st_dev&&expected.st_ino==actual.st_ino,"member-current-namespace-binding");
}
static void owned_dump(struct connection *s,int member) {
    member_namespace(member);owned_links=0;struct packet links=link_body(0,0,0);exchange(s,RTM_GETLINK,NLM_F_DUMP,&links,read_owned_link);must(owned_links==3,"complete-two-owned-links");
    route_count=0;struct packet routes={{0},sizeof(struct rtmsg)};routes.b[0]=AF_INET6;exchange(s,RTM_GETROUTE,NLM_F_DUMP,&routes,read_route);
}
static void reconcile_once(struct connection *s,int member,int peer,int lo,const char *alias) {
    owned_peer=peer;owned_lo=lo;owned_alias=alias;stage="member-predelete-qualify";ns_record(stage);owned_dump(s,member);int selected=qualify_all();
    struct route_key remaining[32];unsigned count=0;
    for(unsigned i=0;i<route_count;i++)if((int)i!=selected)remaining[count++]=route_rows[i];
    line("O1A_EARLY_CANDIDATES attempt=%s candidates=%d routes=%u peer=%d table=255 mono_ns=%" PRIu64 "\n",attempt,selected>=0,route_count,peer,mono());
    if(selected>=0) {
        struct route_key target=route_rows[selected];stage="member-predelete-ownership";owned_dump(s,member);int now=qualify_all();must(now>=0&&same_route(&route_rows[now],&target),"fresh-delete-candidate-binding");
        struct packet body={{0},sizeof(struct rtmsg)};struct rtmsg r={.rtm_family=AF_INET6,.rtm_dst_len=target.destination_bits,.rtm_src_len=target.source_bits,.rtm_table=(unsigned char)target.table,.rtm_protocol=target.protocol,.rtm_scope=target.scope,.rtm_type=target.kind};memcpy(body.b,&r,sizeof(r));
        attr(&body,RTA_DST,target.destination,16);u32_attr(&body,RTA_TABLE,target.table);u32_attr(&body,RTA_PRIORITY,target.metric);u32_attr(&body,RTA_OIF,target.index);
        must(delete_count==0,"one-delete-only");delete_count++;stage="member-one-owned-delete";
        char hex[PACKET_MAX*2+1];must(body.n<=256,"delete-identity-body-bound");
        for(size_t i=0;i<body.n;i++){(void)snprintf(hex+2*i,3,"%02x",body.b[i]);}
        hex[2*body.n]=0;
        line("O1A_DELETE_BOUND attempt=%s peer=%d table=255 destination=ff00::/8 source=::/0 metric=256 protocol=2 scope=0 kind=5 flags=0 preference=0 body_hex=%s mono_ns=%" PRIu64 "\n",attempt,peer,hex,mono());
        exchange(s,RTM_DELROUTE,NLM_F_ACK,&body,NULL);
    }
    stage="member-delete-readback";owned_dump(s,member);must(route_count==count,"exact-remaining-route-count");
    for(unsigned i=0;i<count;i++){unsigned hits=0;for(unsigned j=0;j<route_count;j++)hits+=(unsigned)same_route(&remaining[i],&route_rows[j]);must(hits==1,"exact-remaining-route-identity");}
    line("O1A_EARLY_RECONCILED attempt=%s candidates=%d deletions=%u remaining=%u mono_ns=%" PRIu64 "\n",attempt,selected>=0,delete_count,route_count,mono());
}
static void timed_snapshot(struct connection *s,const char *name,unsigned offset_ms,uint64_t bridge_up) {
    uint64_t target=bridge_up+(uint64_t)offset_ms*UINT64_C(1000000);struct timespec at={.tv_sec=(time_t)(target/UINT64_C(1000000000)),.tv_nsec=(long)(target%UINT64_C(1000000000))};
    int rc;do{rc=clock_nanosleep(CLOCK_MONOTONIC,TIMER_ABSTIME,&at,NULL);}while(rc==EINTR);if(rc){errno=rc;die("fixed-snapshot-clock");}
    uint64_t begin=mono();snapshot(s,name);line("O1A_TIMED_SNAPSHOT attempt=%s stage=%s scheduled_offset_ms=%u bridge_up_ns=%" PRIu64 " begin_ns=%" PRIu64 " end_ns=%" PRIu64 "\n",attempt,name,offset_ms,bridge_up,begin,mono());
}

static void child(void) {
    exact_four();stage="outer-unshare";checked(unshare(CLONE_NEWNET),"outer-unshare");int outer=open("/proc/self/ns/net",O_RDONLY|O_CLOEXEC);checked(outer,"outer-fd");struct connection s=open_route();initial_lo_only(&s,"outer-initial-lo");ns_record("outer");
    char alias[64];int count=snprintf(alias,sizeof(alias),"corsa-o1a-diag-%s",attempt);must(count>0&&(size_t)count<sizeof(alias),"alias-bound");
    stage="bridge-create";create_link(&s,"bridge","o1abr",NULL,alias);
    checked(close(s.fd),"outer-pre-namespace-close");
    stage="member-unshare";checked(unshare(CLONE_NEWNET),"member-unshare");
    stage="member-enable-lo";enable_member_loopback();
    int member=open("/proc/self/ns/net",O_RDONLY|O_CLOEXEC);checked(member,"member-fd");ns_record("member-created");
    s=open_route();snapshot(&s,"member-created-lo-up");checked(close(s.fd),"member-early-close");
    checked(setns(outer,CLONE_NEWNET),"return-outer");s=open_route();
    stage="veth-create";create_link(&s,"veth","o1ah","o1ap",alias);
    int bridge=link_index("o1abr"),host=link_index("o1ah"),peer=link_index("o1ap");stage="peer-explicit-alias";struct packet aliasbody=link_body(peer,0,0);string_attr(&aliasbody,IFLA_IFALIAS,alias);exchange(&s,RTM_NEWLINK,NLM_F_ACK,&aliasbody,NULL);stage="host-addrgen";addrgen_none(&s,host);stage="host-attach";link_set(&s,host,IFLA_MASTER,(uint32_t)bridge);stage="host-up";up(&s,host);snapshot(&s,"outer-created");checked(close(s.fd),"outer-socket-close");
    s=open_route();stage="peer-move";link_set(&s,peer,IFLA_NET_NS_FD,(uint32_t)member);checked(close(s.fd),"outer-close-after-move");checked(setns(member,CLONE_NEWNET),"enter-member");
    s=open_route();peer=link_index("o1ap");int lo=link_index("lo");line("O1A_OWNED attempt=%s peer=%d peer_name=o1ap alias=%s lo=%d lo_owned=false\n",attempt,peer,alias,lo);snapshot(&s,"member-before-addrgen");
    /* Original namespace operation: disableIPv6 for both links, then IPv4, up. */
    stage="member-addrgen-lo";addrgen_none(&s,lo);stage="member-addrgen-peer";addrgen_none(&s,peer);snapshot(&s,"member-after-addrgen");
    stage="member-address-v4";struct packet p={{0},sizeof(struct ifaddrmsg)};struct ifaddrmsg a={.ifa_family=AF_INET,.ifa_prefixlen=4,.ifa_index=(uint32_t)peer};memcpy(p.b,&a,sizeof(a));const unsigned char address[4]={240,0,0,1};attr(&p,IFA_LOCAL,address,4);attr(&p,IFA_ADDRESS,address,4);exchange(&s,RTM_NEWADDR,NLM_F_CREATE|NLM_F_EXCL|NLM_F_ACK,&p,NULL);snapshot(&s,"member-before-up");stage="member-up";up(&s,peer);snapshot(&s,"member-after-up");
    reconcile_once(&s,member,peer,lo,alias);snapshot(&s,"member-pre-bridge-clean");checked(close(s.fd),"member-before-bridge-close");
    checked(setns(outer,CLONE_NEWNET),"enter-own-outer-for-bridge");s=open_route();stage="outer-final-bridge-addrgen";ns_record(stage);addrgen_none(&s,bridge);stage="outer-final-bridge-up";up(&s,bridge);uint64_t bridge_up=mono();line("O1A_BRIDGE_UP_RETURNED attempt=%s index=%d mono_ns=%" PRIu64 "\n",attempt,bridge,bridge_up);checked(close(s.fd),"outer-post-bridge-close");
    checked(setns(member,CLONE_NEWNET),"return-own-member-after-bridge");member_namespace(member);s=open_route();
    timed_snapshot(&s,"member-post-bridge-0ms",0,bridge_up);timed_snapshot(&s,"member-post-bridge-25ms",25,bridge_up);timed_snapshot(&s,"member-post-bridge-100ms",100,bridge_up);timed_snapshot(&s,"member-post-bridge-250ms",250,bridge_up);
    checked(close(s.fd),"member-close");checked(close(member),"member-owned-fd-close");checked(close(outer),"outer-owned-fd-close");
    line("O1A_DIAG_CHILD_COMPLETE attempt=%s raw_bytes=%u datagrams=%u classification=OFFLINE_REQUIRED simplified_repro=true\n",attempt,raw_bytes,datagrams);_exit(0);
}
int main(int argc,char **argv) {
    (void)argv;must(argc==1&&getpid()==1&&getuid()==0&&geteuid()==0,"pid1-root-only");
    struct sigaction action={0};action.sa_handler=poweroff_now;checked(sigemptyset(&action.sa_mask),"signal-mask");checked(sigaction(SIGALRM,&action,NULL),"alarm-handler");alarm(55);
    int flags=fcntl(STDOUT_FILENO,F_GETFL);checked(flags,"stdout-flags");checked(fcntl(STDOUT_FILENO,F_SETFL,flags|O_NONBLOCK),"stdout-nonblock");
    umask(0);mkdir_exact("/proc",0555);checked(mount("proc","/proc","proc",MS_NOSUID|MS_NODEV|MS_NOEXEC|MS_RDONLY,NULL),"proc-mount");read_attempt();
    struct rlimit core={0,0};checked(setrlimit(RLIMIT_CORE,&core),"parent-core-zero");
    stage="parent-initial";struct connection initial=open_route();initial_lo_only(&initial,"initial-lo");checked(close(initial.fd),"parent-route-close");
    uint64_t start=mono();pid_t pid=fork();checked((int)pid,"fork");if (pid==0) child();
    line("O1A_DIAG_PARENT attempt=%s child=%ld child_deadline_seconds=30 poweroff_alarm_seconds=55\n",attempt,(long)pid);
    int child_reaped=0,status=0,killed=0,all_reaped=0;
    while (mono()-start<UINT64_C(50000000000)) {
        int one=0;pid_t got=waitpid(-1,&one,WNOHANG);
        if (got==pid) {child_reaped=1;status=one;}
        else if (got<0&&errno==ECHILD) {all_reaped=1;break;}
        else if (got<0&&errno!=EINTR) break;
        if (!killed&&!child_reaped&&mono()-start>=UINT64_C(30000000000)) {checked(kill(pid,SIGKILL),"deadline-kill");killed=1;}
        struct timespec pause={.tv_nsec=10000000};(void)nanosleep(&pause,NULL);
    }
    line("O1A_DIAG_PARENT_RESULT attempt=%s child_reaped=%d all_children_reaped=%d killed=%d normal_exit=%d exit=%d scope=DIAGNOSTIC_ONLY_NOT_O1A_PASS\n",attempt,child_reaped,all_reaped,killed,child_reaped&&WIFEXITED(status),child_reaped&&WIFEXITED(status)?WEXITSTATUS(status):-1);
    poweroff_now(0);return 127;
}
