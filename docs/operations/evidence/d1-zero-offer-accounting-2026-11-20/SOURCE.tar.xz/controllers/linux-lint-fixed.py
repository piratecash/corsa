import os,sys,json,subprocess,hashlib
from pathlib import Path
sys.path.insert(0,'/Users/hades/Documents/repos/corsa/docs/_internal/d1-artifacts/2026-11-20/d1-o1a-capexec-seccomp-build-v1')
from common import Job,need,sha
R=Path('/Users/hades/Documents/repos/corsa');P=R/'docs/_internal/d1-artifacts/2026-11-20/d1-o1a-zero-offer-fix-v1';m=json.loads((P/'MANIFEST.json').read_text())
for n,x in m['files'].items():need(sha(R/n)==x['after_sha256'],'applied source drift')
m2=json.loads((R/'docs/_internal/d1-artifacts/2026-11-20/d1-hmix-interop-lint-fix-v1/MANIFEST.json').read_bytes())
for n,x in m2['files'].items():need(sha(R/n)==x['after_sha256'],'interop source drift')
files=sorted(set(subprocess.check_output(['git','ls-files','--','*.go','go.mod','go.sum'],cwd=R).decode().splitlines()+list(m['files'])))
before={n:sha(R/n) for n in files}
os.umask(0o077)
if os.getpid()!=os.getpgrp():os.setsid()
j=Job('zero-offer-linux-lint-fixed',600,6*1024**3);error=None
try:
 (j.work/'SOURCE-BEFORE.json').write_text(json.dumps(before,sort_keys=True,indent=2)+'\n')
 for n in ('gocache','lintcache','tmp'):(j.work/n).mkdir()
 env=os.environ.copy();env.update(GOCACHE='/private/tmp/corsa-d1-o1a-zero-offer-linux-lint-5fabecfd98794fc7b4d8213b08236e06/gocache',GOMODCACHE=str(R/'.gomodcache'),GOLANGCI_LINT_CACHE='/private/tmp/corsa-d1-o1a-zero-offer-linux-lint-5fabecfd98794fc7b4d8213b08236e06/lintcache',TMPDIR=str(j.work/'tmp'),GOPROXY='file://'+str(R/'.gomodcache/cache/download'),GOSUMDB='off',GOTOOLCHAIN='local',GOTELEMETRY='off',GOMAXPROCS='2',GOMEMLIMIT='768MiB',GOFLAGS='-p=1',GOOS='darwin',GOARCH='arm64',CGO_ENABLED='0')
 # Compile the native lint tool, then set the analyzed Go target in its exec environment.
 policy='(version 1)(allow default)(deny network*)'
 args=['/usr/bin/sandbox-exec','-p',policy,'/usr/local/go/bin/go','run','-exec=/usr/bin/env GOOS=linux GOARCH=amd64 CGO_ENABLED=0','github.com/golangci/golangci-lint/v2/cmd/golangci-lint@v2.14.0','run','./internal/core/node','--build-tags=interop,d1_owned_guest_interop','--timeout=7m','--color=never','--allow-serial-runners']
 j.run('linux-lint',args,cwd=R,env=env)
 for n,x in m['files'].items():need(sha(R/n)==x['after_sha256'],'lint changed source')
 after={n:sha(R/n) for n in files};need(after==before,'selected Go source drift');(j.work/'SOURCE-AFTER.json').write_text(json.dumps(after,sort_keys=True,indent=2)+'\n')
except BaseException as e:error=str(e)
r=j.finish({'status':'LINUX_FIXTURE_LINT_PASS' if error is None else 'FAILED','error':error,'source_manifest_sha256':sha(P/'MANIFEST.json'),'interop_test_manifest_sha256':sha(R/'docs/_internal/d1-artifacts/2026-11-20/d1-hmix-interop-lint-fix-v1/MANIFEST.json'),'selected_source_files':len(files),'previous_own_lint_cache_reused':True,'target':'linux/amd64 CGO0 tags interop,d1_owned_guest_interop','lint_tool_host':'darwin/arm64','app_or_test_ELF_executed':False})
if error:raise SystemExit(1)
