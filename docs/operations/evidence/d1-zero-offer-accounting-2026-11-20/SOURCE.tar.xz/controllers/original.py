import os,sys,json,hashlib,subprocess,shutil
from pathlib import Path
R=Path('/Users/hades/Documents/repos/corsa');P=R/'docs/_internal/d1-artifacts/2026-11-20/d1-o1a-sender-refusal-unit-v1'
sys.path.insert(0,str(R/'docs/_internal/d1-artifacts/2026-11-20/d1-o1a-capexec-seccomp-build-v1'))
from common import Job,need,sha
M=json.loads((P/'MANIFEST.json').read_text());need(subprocess.check_output(['git','rev-parse','HEAD'],cwd=R).decode().strip()=='cecc9b709e00fbecbbc91c0920f101f7e3b7729b','HEAD drift')
for n,x in M['relevant_source_proof'].items():need(sha(R/n)==x['current_sha256'],'relevant sender source drift')
name,row=next(iter(M['files'].items()));post=P/'posts'/name;need(len(M['files'])==1 and row['before_sha256'] is None and not(R/name).exists() and sha(post)==row['after_sha256'],'single test overlay')
pattern='^(TestLoadStandRouteWireFullSendMatchesOriginalWriter|TestLoadStandRouteWireFullPassRefusesConnectionOrBoundaryChange|TestLoadStandRouteWireSenderRefusalMechanisms)$'
expected={'TestLoadStandRouteWireFullPassRefusesConnectionOrBoundaryChange', 'TestLoadStandRouteWireFullSendMatchesOriginalWriter', 'TestLoadStandRouteWireSenderRefusalMechanisms'}
files=subprocess.check_output(['git','ls-files','--','*.go','go.mod','go.sum'],cwd=R).decode().splitlines()
files=sorted(set(files+['internal/core/node/find_node_published31_guest_linux_test.go']))
def sources():return {n:sha(R/n) for n in files}
before=sources();os.umask(0o077)
if os.getpid()!=os.getpgrp():os.setsid()
j=Job('sender-refusal-unit',600,2*1024**3);error=None;counts=None
try:
 need(shutil.disk_usage('/private/tmp').free>=10*1024**3,'host free')
 for n in ('cache','tmp'):(j.work/n).mkdir()
 (j.work/'SOURCE-BEFORE.json').write_text(json.dumps(before,sort_keys=True,indent=2)+'\n')
 overlay=j.work/'overlay.json';overlay.write_text(json.dumps({'Replace':{str(R/name):str(post)}})+'\n')
 env=os.environ.copy();env.update(GOCACHE=str(j.work/'cache'),GOMODCACHE=str(R/'.gomodcache'),TMPDIR=str(j.work/'tmp'),GOPROXY='off',GOSUMDB='off',GOTOOLCHAIN='local',GOTELEMETRY='off',GOMAXPROCS='2',GOMEMLIMIT='768MiB',GOFLAGS='-p=1',GOOS='darwin',GOARCH='arm64',CGO_ENABLED='0',GOENV='off',GOWORK='off')
 policy='(version 1)(allow default)(deny network*)(deny file-write* (subpath '+json.dumps(str(R))+'))'
 raw=j.run('selected-tests',['/usr/bin/sandbox-exec','-p',policy,'/usr/local/go/bin/go','test','-overlay='+str(overlay),'-mod=readonly','-p=1','-count=1','-timeout=90s','-json','./internal/core/node','-run',pattern],cwd=R,env=env)
 events=[json.loads(x) for x in raw.splitlines()];need(not any(x.get('Action') in ('fail','skip') for x in events),'Go FAIL/SKIP')
 passed=[x['Test'] for x in events if x.get('Action')=='pass' and x.get('Test')];need({n for n in passed if '/' not in n}==expected,'test inventory')
 counts={'outer':len(expected),'child':sum('/' in n for n in passed)}
 after=sources();need(after==before and sha(post)==row['after_sha256'],'source changed');(j.work/'SOURCE-AFTER.json').write_text(json.dumps(after,sort_keys=True,indent=2)+'\n')
except BaseException as e:error=str(e)
j.finish({'status':'FULL_SEND_UNIT_MECHANISM_PASS' if error is None else 'FAILED','error':error,'tests':counts,'base':'cecc9b709e00fbecbbc91c0920f101f7e3b7729b','manifest_sha256':sha(P/'MANIFEST.json'),'scope':'UNIT_MECHANISM_ONLY_NOT_NATIVE_CAUSE_PROOF','app_or_Linux_ELF_executed':False,'virtual_test_path':name,'overlay_sha256':row['after_sha256']})
if error:raise SystemExit(1)
