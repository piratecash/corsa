import os,sys,json,hashlib,subprocess,shutil
from pathlib import Path
R=Path('/Users/hades/Documents/repos/corsa');P=R/'docs/_internal/d1-artifacts/2026-11-20/d1-o1a-zero-offer-fix-v1';sys.path.insert(0,str(R/'docs/_internal/d1-artifacts/2026-11-20/d1-o1a-capexec-seccomp-build-v1'))
from common import Job,need,sha
M=json.loads((P/'MANIFEST.json').read_bytes());need(subprocess.check_output(['git','rev-parse','HEAD'],cwd=R).decode().strip()==M['base_commit'],'HEAD drift')
for n,row in M['files'].items():need((not(R/n).exists() if row['before_sha256'] is None else sha(R/n)==row['before_sha256']) and sha(P/'posts'/n)==row['after_sha256'],'overlay source drift')
expected={'TestLoadStandRouteWireFullSendMatchesOriginalWriter','TestLoadStandRouteWireFullPassRefusesConnectionOrBoundaryChange','TestLoadStandRouteWireFullSendPreWindowCrossingMechanism','TestLoadStandRouteWireFullSendProjectionReuseMechanism','TestLoadStandRouteWireSenderRefusalMechanisms','TestLoadStandRouteWireZeroOfferThenActualCompletePass','TestLoadStandRouteWireZeroOfferKeepsFailureGuards','TestLoadStandRouteWirePairsRequireReciprocalReports'};pattern='^('+'|'.join(sorted(expected))+')$';files=sorted(set(subprocess.check_output(['git','ls-files','--','*.go','go.mod','go.sum'],cwd=R).decode().splitlines()+['internal/core/node/find_node_published31_guest_linux_test.go']));before={n:sha(R/n) for n in files};os.umask(0o077)
if os.getpid()!=os.getpgrp():os.setsid()
j=Job('zero-offer-fix-unit',600,2*1024**3);error=None;counts=None
try:
 need(shutil.disk_usage('/private/tmp').free>=10*1024**3,'host free')
 for n in ('cache','tmp'):(j.work/n).mkdir()
 (j.work/'SOURCE-BEFORE.json').write_text(json.dumps(before,sort_keys=True,indent=2)+'\n');overlay=j.work/'overlay.json';overlay.write_text(json.dumps({'Replace':{str(R/n):str(P/'posts'/n) for n in M['files']}})+'\n')
 env=os.environ.copy();env.update(GOCACHE=str(j.work/'cache'),GOMODCACHE=str(R/'.gomodcache'),TMPDIR=str(j.work/'tmp'),GOPROXY='off',GOSUMDB='off',GOTOOLCHAIN='local',GOTELEMETRY='off',GOMAXPROCS='2',GOMEMLIMIT='768MiB',GOFLAGS='-p=1',GOOS='darwin',GOARCH='arm64',CGO_ENABLED='0',GOENV='off',GOWORK='off');policy='(version 1)(allow default)(deny network*)(deny file-write* (subpath '+json.dumps(str(R))+'))';raw=j.run('selected-tests',['/usr/bin/sandbox-exec','-p',policy,'/usr/local/go/bin/go','test','-overlay='+str(overlay),'-mod=readonly','-p=1','-count=1','-timeout=90s','-json','./internal/core/node','-run',pattern],cwd=R,env=env);events=[json.loads(x) for x in raw.splitlines()];need(not any(x.get('Action') in ('fail','skip') for x in events),'Go FAIL/SKIP');passed=[x['Test'] for x in events if x.get('Action')=='pass' and x.get('Test')];need({n for n in passed if '/' not in n}==expected,'test inventory');counts={'outer':len(expected),'child':sum('/' in n for n in passed)};after={n:sha(R/n) for n in files};need(after==before,'source changed');(j.work/'SOURCE-AFTER.json').write_text(json.dumps(after,sort_keys=True,indent=2)+'\n')
 for n,row in M['files'].items():need(sha(P/'posts'/n)==row['after_sha256'],'post changed')
except BaseException as e:error=str(e)
j.finish({'status':'ZERO_OFFER_FIX_UNIT_PASS' if error is None else 'FAILED','error':error,'tests':counts,'base':M['base_commit'],'manifest_sha256':sha(P/'MANIFEST.json'),'scope':'ZERO_OFFER_ACCOUNTING_ONLY_NOT_NATIVE_CAUSE_PROOF','app_or_Linux_ELF_executed':False,'Root_source_changed':False})
if error:raise SystemExit(1)
