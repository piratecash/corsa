from pathlib import Path
import hashlib,json,re,struct,subprocess
R=Path('/Users/hades/Documents/repos/corsa');D=R/'docs/_internal/d1-artifacts/2026-11-20';P=D/'d1-o1a-zero-offer-fix-v1'
W={'before':Path('/private/tmp/corsa-d1-o1a-sender-refusal-unit-c51403d5f58347e39c104d5851c604f1'),'fixed':Path('/private/tmp/corsa-d1-o1a-zero-offer-fix-unit-6875c1480f4f4fc6b8fb5937b6494564'),'compile':Path('/private/tmp/corsa-d1-o1a-zero-offer-linux-compile-dc7706294f834840b5d1a43f63d642dc')}
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
M=json.loads((P/'MANIFEST.json').read_bytes());out={'status':'ACCEPTED_ZERO_SUPPLIED_FRAME_ACCOUNTING_UNIT_AND_COMPILE_ONLY','reviewer':'TESTER','scope':'Not native cause proof, O1a acceptance, D1 activation or release. No artifact was executed in this review.','works':{},'checks':[]}
for label,w in W.items():
 r=json.loads((w/'RESULT.json').read_bytes()); assert r['error']is None and not r['unknown']and not r['lock_retained'];a=json.loads((w/'SOURCE-BEFORE.json').read_bytes());b=json.loads((w/'SOURCE-AFTER.json').read_bytes());assert a==b
 raw=0
 for s in r['steps']:
  assert s['exit']==0 and s['owned_group_absent']and s['pipe_threads_finished']and s['reason']is None
  raw+=sum(Path(s[k]).stat().st_size for k in ('stdout','stderr'));assert Path(s['stderr']).stat().st_size==0
 assert raw==r['raw_bytes']; row={'work':str(w),'result_sha256':sha(w/'RESULT.json'),'status':r['status'],'raw_bytes':raw,'source_files':len(a),'source_before_after_equal':True,'steps_exit0_full_EOF_groups_absent':len(r['steps'])}
 if label!='compile':
  ev=[json.loads(x) for x in Path(r['steps'][0]['stdout']).read_bytes().splitlines()];assert not any(e.get('Action')in('fail','skip')for e in ev)
  tests=[e['Test']for e in ev if e.get('Action')=='pass' and e.get('Test')];outer={t for t in tests if '/'not in t};names=set(re.search(r'^\^\((.*)\)\$$',r['steps'][0]['argv'][-1])[1].split('|'));assert outer==names and len(tests)-len(outer)==r['tests']['child']; row['tests']=r['tests'];row['exact_outer_names']=sorted(outer)
  overlay=json.loads((w/'overlay.json').read_bytes())['Replace'];row['overlay']={str(Path(n).relative_to(R)):sha(p) for n,p in overlay.items()}
  if label=='fixed':assert row['overlay']=={n:x['after_sha256']for n,x in M['files'].items()}
 else:
  art={}
  for arch,v in r['artifacts'].items():
   p=Path(v['path']);assert p.stat().st_size==v['bytes']and sha(p)==v['sha256']and not v['executed']
   with p.open('rb')as f:
    h=f.read(64);assert h[:6]==b'\x7fELF\x02\x01';assert struct.unpack_from('<H',h,16)[0]==2;assert struct.unpack_from('<H',h,18)[0]=={'arm64':183,'amd64':62}[arch];off=struct.unpack_from('<Q',h,32)[0];ents,num=struct.unpack_from('<HH',h,54);f.seek(off);types=[struct.unpack_from('<I',f.read(ents),0)[0]for _ in range(num)];assert 2 not in types and 3 not in types
   meta=(w/({'arm64':'02-metadata-arm64.stdout','amd64':'04-metadata-amd64.stdout'}[arch])).read_text(); assert 'go1.27.4\n'in meta and '\tbuild\tCGO_ENABLED=0\n'in meta and '\tbuild\tGOOS=linux\n'in meta and '\tbuild\tGOARCH='+arch+'\n'in meta and '\tbuild\t-tags='+v['tags']+'\n'in meta;deps=[l for l in meta.splitlines()if l.startswith('\tdep\t')];assert len(deps)==26
   art[arch]={**v,'metadata_dep_count':len(deps),'ELF_machine_checked':True,'no_PT_INTERP_or_PT_DYNAMIC':True}
  row['artifacts']=art
 out['works'][label]=row
A=json.loads((W['before']/'SOURCE-BEFORE.json').read_bytes());B=json.loads((W['fixed']/'SOURCE-BEFORE.json').read_bytes());C=json.loads((W['compile']/'SOURCE-BEFORE.json').read_bytes());assert A==B
changed={n:{'before':A.get(n),'after':C.get(n)}for n in sorted(A.keys()|C.keys())if A.get(n)!=C.get(n)};assert changed=={n:{'before':v['before_sha256'],'after':v['after_sha256']}for n,v in M['files'].items()};assert all(sha(R/n)==digest for n,digest in C.items());assert all(sha(P/'posts'/n)==v['after_sha256']for n,v in M['files'].items())
base='22aaabc2f8035b8d287ce4181a997d1725efa722';names=subprocess.check_output(['git','ls-tree','-r','--name-only',base],cwd=R).decode().splitlines();names=[n for n in names if n.endswith('.go')or n in('go.mod','go.sum')];assert set(names)==set(A)
p=subprocess.Popen(['git','cat-file','--batch'],cwd=R,stdin=subprocess.PIPE,stdout=subprocess.PIPE)
for n in names:
 p.stdin.write((base+':'+n+'\n').encode());p.stdin.flush();header=p.stdout.readline().split();size=int(header[-1]);body=p.stdout.read(size);assert p.stdout.read(1)==b'\n';assert hashlib.sha256(body).hexdigest()==A[n]
p.stdin.close();assert p.wait()==0
out['checks']=['Original 3 outer/34 child and fixed 8 outer/62 child named JSON executions PASS with no FAIL/SKIP.','All 2107 unit source/module payloads exactly equal committed Hmix checkpoint 22aaabc2, despite older controller base label cecc9b7; virtual overlays are separately bound.','Final 2109 source/module map differs only by exact three fix posts and equals current Root; both unit and compile before/after maps unchanged.','Both static Linux ELF file hashes, sizes, machine/ET_EXEC/program headers and actual Go1.27.4/CGO0/26-dependency BuildInfo checked read-only.','Original refusal and boundary negatives retained; no inference about actual earlier native sender-false cause.'];out['source_delta']=changed
out['historical_native_cause']='UNKNOWN_NOT_RETROACTIVELY_FIXED';out['native_or_O1a_metric_PASS']=False
T=D/'d1-o1a-zero-offer-actual-tester-v1';T.mkdir(exist_ok=True);(T/'REVIEW.json').write_text(json.dumps(out,indent=2,sort_keys=True)+'\n');print(json.dumps({'review':str(T/'REVIEW.json'),'sha256':sha(T/'REVIEW.json'),'results':{k:v.get('tests',len(v.get('artifacts',{})))for k,v in out['works'].items()},'source':len(C)},indent=2))
