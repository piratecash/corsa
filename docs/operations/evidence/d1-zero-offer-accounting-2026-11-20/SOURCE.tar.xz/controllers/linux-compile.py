import os,sys,json,hashlib,subprocess,shutil,struct
from pathlib import Path
R=Path('/Users/hades/Documents/repos/corsa');P=R/'docs/_internal/d1-artifacts/2026-11-20/d1-o1a-zero-offer-fix-v1';sys.path.insert(0,str(R/'docs/_internal/d1-artifacts/2026-11-20/d1-o1a-capexec-seccomp-build-v1'));from common import Job,need,sha
M=json.loads((P/'MANIFEST.json').read_bytes());need(subprocess.check_output(['git','rev-parse','HEAD'],cwd=R).decode().strip()=='22aaabc2f8035b8d287ce4181a997d1725efa722','HEAD drift')
for n,row in M['files'].items():need(sha(R/n)==row['after_sha256'],'tested post drift')
files=sorted(set(subprocess.check_output(['git','ls-files','--','*.go','go.mod','go.sum'],cwd=R).decode().splitlines()+list(M['files'])));before={n:sha(R/n) for n in files};os.umask(0o077)
if os.getpid()!=os.getpgrp():os.setsid()
j=Job('zero-offer-linux-compile',600,4*1024**3);error=None;artifacts={}
try:
 need(shutil.disk_usage('/private/tmp').free>=10*1024**3,'host free')
 for n in ('cache','tmp','artifacts'):(j.work/n).mkdir()
 (j.work/'SOURCE-BEFORE.json').write_text(json.dumps(before,sort_keys=True,indent=2)+'\n');baseenv=os.environ.copy();baseenv.update(GOCACHE=str(j.work/'cache'),GOMODCACHE=str(R/'.gomodcache'),TMPDIR=str(j.work/'tmp'),GOPROXY='off',GOSUMDB='off',GOTOOLCHAIN='local',GOTELEMETRY='off',GOMAXPROCS='2',GOMEMLIMIT='768MiB',GOFLAGS='-p=1',GOOS='linux',CGO_ENABLED='0',GOENV='off',GOWORK='off');policy='(version 1)(allow default)(deny network*)(deny file-write* (subpath '+json.dumps(str(R))+'))'
 for arch,tags in [('arm64','d1_o1a_native_responder'),('amd64','interop,d1_owned_guest_interop')]:
  env=dict(baseenv,GOARCH=arch);env.update({'GOARM64':'v8.0'} if arch=='arm64' else {'GOAMD64':'v1'});out=j.work/'artifacts'/('node-'+arch+'.test');j.run('compile-'+arch,['/usr/bin/sandbox-exec','-p',policy,'/usr/local/go/bin/go','test','-c','-mod=readonly','-buildvcs=false','-p=1','-trimpath','-ldflags=-buildid=','-tags='+tags,'-o',str(out),'./internal/core/node'],cwd=R,env=env);need(out.stat().st_size<=128*1024**2,'ELF bound')
  with out.open('rb') as f:head=f.read(64);need(head[:7]==b'\x7fELF\x02\x01\x01','ELF header');kind,machine,version,entry,offset,shoff,flags,size,entsize,count,*rest=struct.unpack_from('<HHIQQQIHHHHHH',head,16);need(kind==2 and machine==({'arm64':183,'amd64':62}[arch]) and entsize==56 and 0<count<=128,'static target');f.seek(offset);ph=f.read(count*56);need(len(ph)==count*56 and all(struct.unpack_from('<I',ph,i*56)[0] not in (2,3) for i in range(count)),'dynamic ELF')
  meta=j.run('metadata-'+arch,['/usr/local/go/bin/go','version','-m',str(out)],cwd=R,env=dict(baseenv,GOOS='darwin',GOARCH='arm64')).decode();need(all(s in meta for s in ('go1.27.4','GOOS=linux','GOARCH='+arch,'CGO_ENABLED=0')),'metadata target');artifacts[arch]={'path':str(out),'sha256':sha(out),'bytes':out.stat().st_size,'tags':tags,'static':True,'executed':False}
 after={n:sha(R/n) for n in files};need(after==before,'source changed');(j.work/'SOURCE-AFTER.json').write_text(json.dumps(after,sort_keys=True,indent=2)+'\n')
except BaseException as e:error=str(e)
j.finish({'status':'LINUX_COMPILE_ONLY_PASS' if error is None else 'FAILED','error':error,'base':'22aaabc2f8035b8d287ce4181a997d1725efa722','artifacts':artifacts,'ELF_executed':False,'source_files':len(files)})
if error:raise SystemExit(1)
