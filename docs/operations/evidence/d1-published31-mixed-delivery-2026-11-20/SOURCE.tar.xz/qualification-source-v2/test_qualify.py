import copy,json,unittest
from pathlib import Path
import probe_profile as p
import qualify as q
from verify_console import verify

class Tests(unittest.TestCase):
 def fixture(self):
  nonce='a'*32;cid='b'*64
  return {'Id':cid,'Image':q.IMAGE,'Name':'/corsa-d1-sg32-'+nonce+'-service','Mounts':[],
   'State':{'Status':'created','Running':False,'Pid':0},'Config':{'Labels':{'corsa.sg32.owner':nonce,'corsa.sg32.role':'service','corsa.loadstand':''},'User':'501:20','Entrypoint':[p.QEMU],'Cmd':p.guest_args(),'Tty':False,'OpenStdin':False,'Volumes':None},
   'HostConfig':{'NetworkMode':'none','ReadonlyRootfs':True,'Privileged':False,'NanoCpus':1000000000,'Memory':p.MEMORY,'MemorySwap':p.MEMORY,'PidsLimit':64,'CapDrop':['ALL'],'RestartPolicy':{'Name':'no'},'SecurityOpt':['no-new-privileges'],'CgroupnsMode':'private','IpcMode':'private','LogConfig':copy.deepcopy(p.LOG)}}
 def test_original_profile_and_verifier_are_byte_exact(self):
  old=q.HERE.parents[1]/'2026-11-13/s6-amd64-lo-only-guest-v2'
  for n in ['probe_profile.py','verify_console.py']:self.assertEqual((old/n).read_bytes(),(q.HERE/n).read_bytes())
 def test_strict_profile_rejects_foreign_resource_or_config(self):
  row=self.fixture();p.check_created(row,'b'*64,'a'*32,q.IMAGE)
  edits=[lambda r:r.update(Mounts=[{'Source':'/host'}]),lambda r:r['HostConfig'].update(CapAdd=['SYS_ADMIN']),lambda r:r['HostConfig'].update(MemorySwap=0),lambda r:r['HostConfig'].update(NetworkMode='bridge'),lambda r:r['HostConfig'].update(PidMode='host'),lambda r:r['HostConfig'].update(Tmpfs={'/tmp':'rw'}),lambda r:r['Config']['Cmd'].extend(['-nic','user']),lambda r:r['Config'].update(User='0:0')]
  for edit in edits:
   bad=copy.deepcopy(row);edit(bad)
   with self.assertRaises(ValueError):p.check_created(bad,'b'*64,'a'*32,q.IMAGE)
 def test_original_serial_proof_exact_namespaces_glibc_and_lo(self):
  raw=b'S6-AMD64-ARCH x86_64\nS6-AMD64-LIBC glibc 2.34\nS6-AMD64-NETNS boot net:[11]\nS6-AMD64-INTERFACES boot\nlo\nS6-AMD64-NETNS fresh net:[12]\nS6-AMD64-INTERFACES fresh\nlo\nS6-AMD64-RESULT PASS\n'
  self.assertEqual(verify(raw)['interfaces'],['lo'])
  for bad in [raw.replace(b'2.34',b'2.33'),raw.replace(b'net:[12]',b'net:[11]'),raw.replace(b'boot\nlo',b'boot\nlo\neth0'),raw[:-1],raw+b'S6-AMD64-RESULT PASS\n']:
   with self.assertRaises(ValueError):verify(bad)
 def test_later_profile_check_preserves_real_state_and_refuses_foreign_identity(self):
  row=self.fixture();row['State'].update(Status='running',Running=True,Pid=42);before=copy.deepcopy(row);q.owned(row,'b'*64,'a'*32);self.assertEqual(row,before)
  for key,value in [('Id','c'*64),('Image','sha256:'+'c'*64),('Name','/foreign')]:
   bad=copy.deepcopy(row);bad[key]=value
   with self.assertRaises(ValueError):q.owned(bad,'b'*64,'a'*32)
 def test_fixed_corrected_image_descriptor_is_strict(self):
  f=json.loads((q.HERE/'FROZEN.json').read_bytes());row=copy.deepcopy(f['image_immutable']);q.image_check(row,f)
  for edit in [lambda r:r.update(Architecture='amd64'),lambda r:r['Config'].update(Entrypoint=['/foreign']),lambda r:r['RootFS']['Layers'].append('sha256:'+'0'*64)]:
   bad=copy.deepcopy(row);edit(bad)
   with self.assertRaises(ValueError):q.image_check(bad,f)
 def test_failed_guest_logs_preserved_before_exit_gate(self):
  calls=[]
  def run(*args,**kwargs):calls.append((args,kwargs));return b'guest failed\n'
  raw,error=q.capture_console(run)
  self.assertEqual(raw,b'guest failed\n');self.assertIsNone(error);self.assertEqual(calls[0][0],('console','container','logs'))
  # Guest status is checked only AFTER capture, so a nonzero exit cannot lose RAW.
  source=(q.HERE/'qualify.py').read_text();self.assertLess(source.index('console_attempted=True;console,console_error=capture_console'),source.index("need(exit_code==b'0'"))
 def test_log_capture_failure_does_not_replace_first_failure_or_unknown(self):
  class Fake:
   unknown=True
   def run(self,*args,**kwargs):raise RuntimeError('bounded raw stop')
  job=Fake();original='ValueError: guest failed';raw,error=q.capture_console(job.run,cleanup=True)
  self.assertIsNone(raw);self.assertEqual(error,'RuntimeError: bounded raw stop');self.assertTrue(job.unknown)
  self.assertEqual(q.preserve_first_error(original,error),original)
  self.assertEqual(q.preserve_first_error(None,error),'console capture: RuntimeError: bounded raw stop')
  raw,error=q.capture_console(lambda *a,**k:b'x'*(q.MAX_BYTES+1));self.assertIsNone(raw);self.assertIn('console bound',error)
  removed=[]
  with self.assertRaises(ValueError):
   q.need(not job.unknown,'cleanup UNKNOWN; preserve owned container and lock before rm')
   removed.append(True)
  self.assertEqual(removed,[])
  source=(q.HERE/'qualify.py').read_text();self.assertLess(source.index("need(not job.unknown,'cleanup UNKNOWN"),source.index("run('remove-owned'"))
if __name__=='__main__':unittest.main()
