"""Authenticate the pinned Alpine APKv2 index and read requested package versions."""
import argparse
import hashlib
import io
import json
from pathlib import Path
import re
import subprocess
import tarfile
from tempfile import TemporaryDirectory
import zlib


MIB = 1024**2
KEY = "alpine-devel@lists.alpinelinux.org-616ae350.rsa.pub"
ROOTS = ("bash", "bc", "bison", "build-base", "coreutils", "diffutils", "elfutils-dev",
         "findutils", "flex", "gzip", "linux-headers", "nftables", "openssl-dev", "python3", "tar", "xz")
NAME = re.compile(r"[a-z0-9][a-z0-9+_.-]*\Z")
VERSION = re.compile(r"[0-9][a-zA-Z0-9+_.-]*-r[0-9]+\Z")


def need(condition, message):
    if not condition:
        raise ValueError(message)


def gzip_member(raw, limit):
    decoder = zlib.decompressobj(31)
    data = decoder.decompress(raw, limit + 1)
    need(decoder.eof and not decoder.unconsumed_tail and len(data) <= limit,
         "invalid or oversized gzip member")
    return data, decoder.unused_data


def tar_members(raw):
    with tarfile.open(fileobj=io.BytesIO(raw), mode="r:") as archive:
        result = {}
        for member in archive:
            need(member.isfile() and member.name not in result, "unexpected index tar member")
            handle = archive.extractfile(member)
            result[member.name] = handle.read()
    return result


def verify_signature(raw, key, openssl):
    need(0 < len(raw) <= 4 * MIB and 0 < len(key) <= 4096, "index or key exceeds bound")
    signatures, signed = gzip_member(raw, 64 * 1024)
    files = tar_members(signatures + bytes(1024))
    label = f".SIGN.RSA.{KEY}"
    need(files.keys() == {label} and len(files[label]) == 512 and signed, "unexpected APK signature member")
    with TemporaryDirectory() as directory:
        tmp = Path(directory)
        (tmp / "index.data").write_bytes(signed)
        (tmp / "index.sig").write_bytes(files[label])
        (tmp / "key.pub").write_bytes(key)
        result = subprocess.run([openssl, "dgst", "-sha1", "-verify", "key.pub",
                                 "-signature", "index.sig", "index.data"], cwd=tmp,
                                capture_output=True, text=True, timeout=10)
        need(result.returncode == 0, "APK index signature refused")
    return signed


def package_rows(raw, roots=ROOTS):
    found = {}
    for block in raw.decode("utf-8").split("\n\n"):
        fields = {}
        for line in block.splitlines():
            name, sep, value = line.partition(":")
            if sep and name in {"P", "V", "A", "C"}:
                need(name not in fields, "duplicate APK index field")
                fields[name] = value
        name = fields.get("P")
        if name not in roots:
            continue
        need(name not in found and fields.keys() == {"P", "V", "A", "C"}, f"ambiguous APK index entry: {name}")
        need(NAME.fullmatch(name) and VERSION.fullmatch(fields["V"]) and fields["A"] in {"aarch64", "noarch"} and
             bool(re.fullmatch(r"Q1[A-Za-z0-9+/=]+", fields["C"])), f"invalid APK index entry: {name}")
        found[name] = {"version": fields["V"], "architecture": fields["A"], "apk_index_identity": fields["C"]}
    missing = sorted(set(roots) - found.keys())
    need(not missing, "requested packages absent: " + ", ".join(missing))
    return dict(sorted(found.items()))


def read_bounded(path, limit):
    with path.open("rb") as stream:
        raw = stream.read(limit + 1)
    need(0 < len(raw) <= limit, f"unexpected size for {path.name}")
    return raw


def verify_index(raw, key, openssl):
    signed = verify_signature(raw, key, openssl)
    unpacked, extra = gzip_member(signed, 8 * MIB)
    need(not extra, "unexpected trailing APK index streams")
    files = tar_members(unpacked)
    need(files.keys() == {"APKINDEX", "DESCRIPTION"}, "unexpected signed index members")
    return {"index_sha256": hashlib.sha256(raw).hexdigest(),
            "key_sha256": hashlib.sha256(key).hexdigest(), "key_file": KEY,
            "index_description": files["DESCRIPTION"].decode("utf-8").strip(),
            "packages": package_rows(files["APKINDEX"])}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--index", type=Path, required=True)
    parser.add_argument("--key", type=Path, required=True)
    parser.add_argument("--openssl", default="/opt/local/bin/openssl")
    args = parser.parse_args()
    try:
        receipt = verify_index(read_bounded(args.index, 4 * MIB), read_bounded(args.key, 4096), args.openssl)
    except (ValueError, OSError, tarfile.TarError, zlib.error, subprocess.SubprocessError) as error:
        parser.exit(2, f"APK index refused: {error}\n")
    print(json.dumps(receipt, indent=2, sort_keys=True))
