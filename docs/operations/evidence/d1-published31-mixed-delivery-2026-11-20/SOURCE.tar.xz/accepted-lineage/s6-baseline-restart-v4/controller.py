"""One admitted, offline baseline restart attempt through the pinned image."""

import hashlib
import os
from pathlib import Path
import re
import secrets
import signal
import stat
import sys
import time
import types

import host_stage as stage


PACKAGE = Path(__file__).resolve().parent
PROFILE = "s6-baseline-v2571-restart-v4"
WORK = Path("/private/tmp") / PROFILE
SMOKE = PACKAGE.parent / "s6-baseline-v2571-published-linux-amd64/amd64-smoke-only-v2/RESULT.json"
SMOKE_RECEIPT_SHA = "0d617fef719631b24b751d7e1a08ab81c1119ef58365694484ee640b1b26777a"
SHARED = PACKAGE.parents[1] / "2026-10-28/s6-common32-both31-runtime-source-v2/runtime"
HELPERS = {
    "sg32_common": "d40b8bd29deb0cc87bef457552f1b6dbe6cf58699d67c35d1d8c184656889cee",
    "sg32_host": "a7dedc45f266f6354b7be6f5b081bb92f9b6c23d286b92042a0b4de2cec5d0a3",
}
WRAPPER_SHA = "c1a435095e05d4e95613faf4b6961a446e995c3a1d49da39e81c27402d844e45"


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def load_host():
    for name, expected in HELPERS.items():
        path = SHARED / (name + ".py")
        raw = path.read_bytes()
        stage.need(digest(raw) == expected and name not in sys.modules, "host helper differs")
        module = types.ModuleType(name)
        module.__file__ = str(path)
        sys.modules[name] = module
        exec(compile(raw, str(path), "exec"), module.__dict__)
    return sys.modules["sg32_host"]


def admission(host, directory):
    raw = host.read_owned(directory / "HANDOFF.json", 65536)
    handoff = host.strict_json(raw)
    decision = host.read_owned(directory / "OWNER-DECISION.txt", 65536)
    grant = host.strict_json(host.read_owned(directory / "OWNER-ADMISSION.json", 65536))
    stage.need(handoff["profile"] == PROFILE and decision.strip() and grant.get("one_attempt") is True and grant == {
        "profile": PROFILE, "one_attempt": True, "handoff_sha256": digest(raw),
        "owner_decision_sha256": digest(decision),
    }, "exact owner admission missing")
    for name in ("controller.py", "host_stage.py", "PROFILE.ru.md"):
        stage.need(digest((directory / name).read_bytes()) == handoff["files"][name], "handoff input differs")
    return digest(raw)


def read_output(host, directory, name, limit):
    def stamp(info):
        return (info.st_dev, info.st_ino, info.st_mode, info.st_uid, info.st_nlink,
                info.st_size, info.st_mtime_ns, info.st_ctime_ns)

    path = directory / name
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    with os.fdopen(fd, "rb") as stream:
        before = os.fstat(stream.fileno())
        stage.need(stat.S_ISREG(before.st_mode) and before.st_uid == os.getuid()
                   and before.st_nlink == 1 and not before.st_mode & 0o022
                   and 0 < before.st_size <= limit, "output custody differs")
        raw = stream.read(limit + 1)
        after = os.fstat(stream.fileno())
        stage.need(stamp(before) == stamp(after) == stamp(path.lstat())
                   and len(raw) == before.st_size, "output changed")
    return host.strict_json(raw), digest(raw)


def clock_domain(record, sample, raw_sha, snapshot_window):
    process = sample["before_process"]
    namespace, identity = record["time_namespace"], record["namespace_device_inode"]
    start, end = record["before_tick"], record["after_tick"]
    first, last = snapshot_window(sample)
    stage.need(record["capture_sha256"] == raw_sha and record["clock"] == "CLOCK_BOOTTIME"
               and type(record["pid"]) is int and record["pid"] == process["pid"]
               and record["boot_id"] == process["boot_id"]
               and re.fullmatch(r"[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}", record["boot_id"])
               and type(identity) is list and len(identity) == 2 and all(type(value) is int for value in identity)
               and identity[0] >= 0 and identity[1] > 0 and namespace == f"time:[{identity[1]}]"
               and type(start) is int and type(end) is int and 0 <= start <= first <= last <= end,
               "guest clock witness differs from capture")
    return (record["boot_id"], namespace, *identity), (start, end)


def verify_output(host, inputs, output):
    stage.verify_inputs(inputs)
    modules = ("collector", "counters", "check_pair", "check_run")
    stage.need(all(name not in sys.modules for name in modules), "output verifier namespace differs")
    sys.path.insert(0, str(inputs))
    try:
        from check_run import MAX_CAPTURE_BYTES, MAX_LIFECYCLE_BYTES, snapshot_window, verify

        stage.need(not os.path.lexists(output / "failure.json"), "guest failure record present")
        captures, hashes = [], {}
        for name in ("first.json", "second.json", "restarted.json", "lifecycle.json", "result.json"):
            limit = MAX_CAPTURE_BYTES if name in ("first.json", "second.json", "restarted.json") else MAX_LIFECYCLE_BYTES
            record, hashes[name] = read_output(host, output, name, limit)
            captures.append(record)
        report = verify(*captures[:4])
        stage.need(report == captures[4], "guest and host results differ")
        domains, windows = [], []
        for index, name in enumerate(("first", "second", "restarted")):
            clock_name = name + "-clock.json"
            witness, hashes[clock_name] = read_output(host, output, clock_name, MAX_LIFECYCLE_BYTES)
            domain, window = clock_domain(witness, captures[index], hashes[name + ".json"], snapshot_window)
            domains.append(domain)
            windows.append(window)
        lifecycle = captures[3]
        stage.need(domains[0] == domains[1] == domains[2]
                   and windows[0][1] < windows[1][0] <= windows[1][1] < lifecycle["old_reap"]["boottime_ns"]
                   < lifecycle["new_start"]["boottime_ns"] < windows[2][0]
                   <= windows[2][1] < lifecycle["new_reap"]["boottime_ns"],
                   "clock domain or witness chronology changed across restart")
        return {"result": report, "guest_evidence_sha256": hashes,
                "local_clock_domain": {"boot_id": domains[0][0], "time_namespace": domains[0][1],
                                       "namespace_device_inode": list(domains[0][2:]), "clock": "CLOCK_BOOTTIME"}}
    finally:
        sys.path.pop(0)
        for name in modules:
            sys.modules.pop(name, None)


def run_attempt(host, engine, root, smoke, deadline, cleanup_deadline, stopping):
    nonce, ids = secrets.token_hex(16), []
    result = {"status": "INCOMPLETE", "nonce": nonce, "external_utc_qualified": False}
    try:
        endpoint = host.strict_json(engine.command(
            ["context", "inspect", "--format", "{{json .Endpoints.docker.Host}}", "desktop-linux"], deadline))
        stage.need(endpoint == host.ENDPOINT and not stopping(), "wrong Docker endpoint or interrupted")
        inputs, output = root / "inputs", root / "output"
        stage.stage_inputs(inputs)
        output.mkdir(mode=0o700)
        result["container"] = stage.execute_stage(engine, nonce, ids, inputs, output, smoke, deadline)
        result.update(verify_output(host, inputs, output))
        stage.need(not stopping() and time.monotonic() < deadline, "evidence outside work deadline")
        result["status"] = "LOCAL_RPC_AND_RESTART_VERIFIED"
    except (OSError, ValueError, KeyError, TypeError, IndexError, RecursionError, host.Fault) as exc:
        result["failure_type"] = type(exc).__name__
        if isinstance(exc, (ValueError, host.Fault)):
            result["failure"] = str(exc)[:256]
    finally:
        engine.cleaning = True
        try:
            closed = host.cleanup(engine, nonce, ids, [], cleanup_deadline)
        except Exception:
            closed = False
        result["closure"] = "KNOWN" if closed else "UNKNOWN"
        if not closed:
            result["status"] = "RECOVERY_REQUIRED"
        elif stopping() or engine.output_failed or time.monotonic() >= cleanup_deadline:
            result["status"] = "INCOMPLETE"
    return result


def main():
    origin = time.monotonic()
    os.umask(0o077)
    host = load_host()
    grant_hash = admission(host, PACKAGE)
    stage.need(digest(host.WRAPPER.read_bytes()) == WRAPPER_SHA, "heavy-run wrapper differs")
    stage.need(len(sys.argv) == 1 and (os.getuid(), os.getgid()) == (501, 20)
               and os.getpid() == os.getpgrp(), "wrong controller identity or process group")
    while True:
        owner = dict(line.split("=", 1) for line in host.read_owned(host.LOCK / "owner", 8192).decode().splitlines()
                     if "=" in line)
        stage.need(owner.get("name") == PROFILE and time.monotonic() < origin + 3, "wrong heavy-lock owner")
        if owner.get("pgid") == str(os.getpgrp()):
            break
        time.sleep(0.05)
    smoke_raw = host.read_owned(SMOKE, 65536)
    stage.need(digest(smoke_raw) == SMOKE_RECEIPT_SHA, "smoke receipt bytes differ")
    smoke = host.strict_json(smoke_raw)
    stage.validate_smoke(smoke)
    disk = os.statvfs(WORK.parent)
    stage.need(disk.f_bavail * disk.f_frsize >= 11 * stage.GIB, "insufficient host free space")
    WORK.mkdir(mode=0o700)
    interrupted = False

    def stop(_signum, _frame):
        nonlocal interrupted
        interrupted = True

    class BoundedEngine(host.Engine):
        cleaning = False

        def pump_until(self, predicate, deadline):
            super().pump_until(lambda: predicate() or (interrupted and not self.cleaning), deadline)
            stage.need(not interrupted or self.cleaning, "host interrupted")

    signal.signal(signal.SIGTERM, stop)
    signal.signal(signal.SIGINT, stop)
    engine = BoundedEngine()
    engine.root = WORK
    closed = False
    try:
        result = run_attempt(host, engine, WORK, smoke, origin + 180, origin + 210, lambda: interrupted)
        closed = result["closure"] == "KNOWN"
        result.update(handoff_sha256=grant_hash, smoke_receipt_sha256=digest(smoke_raw))
        engine.put("commands.json", engine.commands)
        engine.put("result.json", result)
    finally:
        if not closed:
            while True:
                time.sleep(60)
        engine.selector.close()
    return 0 if result["status"] == "LOCAL_RPC_AND_RESTART_VERIFIED" else 2


if __name__ == "__main__":
    raise SystemExit(main())
