"""Container stage for the isolated published-baseline restart check."""

import hashlib
import json
import os
from pathlib import Path
import re
import stat


IMAGE = "sha256:313cf8f190a1abab00472c1f0c950c10486c22114bcd8aef2a8198fb587a6d18"
MANIFEST = "sha256:0f086103b026048cc50cb5da25ec435c023c5241a83fc44daea593377abc61c4"
SMOKE_HANDOFF = "6d346f60bbc87b7e03d82921966c21609a1f4ae1f1f216971e69e064279011e6"
MEMORY = 512_000_000
GIB = 1024**3
ENTRYPOINT = "/usr/local/bin/python3"
BOOTSTRAP = ("import runpy,sys;sys.path.insert(0,'/inputs');"
             "runpy.run_path('/inputs/worker.py',run_name='__main__')")
COMMAND = ["-I", "-S", "-B", "-c", BOOTSTRAP, "/inputs/corsa-node", "/work"]
LOG = {"Type": "json-file", "Config": {"max-size": "1m", "max-file": "1"}}
DAY = Path(__file__).resolve().parent.parent
INPUTS = {
    "corsa-node": ("s6-baseline-v2571-published-linux-amd64/binaries/corsa-node",
                   "06e26f9b30594d19fb7da9782921f3ef2e7d297da3441d521a8e2c6343d2fade", 0o500),
    "worker.py": ("s6-baseline-restart-v4/worker.py",
                  "52297de6e47aef3cad939a668727a32576b1cfb98077474cfc4f29350e347b30", 0o400),
    "witness.py": ("s6-baseline-rpc-clock-witness/witness.py",
                   "73c85e30afae31d0438a768113f603613d18e5810c04cfe533e514ffd69cd425", 0o400),
    "check_run.py": ("s6-baseline-restart/check_run.py",
                     "1416bad78cf9f14d440b668396a9b660b15a3086396b4122fe4b1798c867b1d6", 0o400),
    "check_pair.py": ("s6-baseline-rpc-listener/check_pair.py",
                      "eaefc001cbc27e2c879ff1311cd6e48c04bbfa915f563dd445ff81200ea7530b", 0o400),
    "collector.py": ("s6-baseline-rpc-listener/collector.py",
                     "13ca7b98639f796e50fce6ddc1164094f4699ad36e8208e0912e4b5c9c82bfe0", 0o400),
    "counters.py": ("s6-session-counter-evidence/counters.py",
                    "99ee8249ef02e88dfa5f52a9193f84bbe0f9171bd1de5e66c02fc6c4820a03b1", 0o400),
}


def need(condition, message):
    if not condition:
        raise ValueError(message)


def validate_smoke(receipt):
    proof = receipt["smoke"]
    libc = re.fullmatch(r"glibc ([0-9]+)\.([0-9]+)(?:\.[0-9]+)?", proof["libc"])
    need(receipt["status"] == "IMAGE_AND_PYTHON_SMOKE_VERIFIED" and receipt["closure"] == "KNOWN"
         and receipt["handoff_sha256"] == SMOKE_HANDOFF and receipt["image_id"] == IMAGE
         and receipt["platform_manifest"] == MANIFEST
         and type(receipt["image_bytes"]) is int and 0 < receipt["image_bytes"] <= GIB
         and proof["machine"] == "x86_64" and proof["python"] == [3, 12, 16]
         and proof["boottime"] is True and proof["http_client"] == "HTTPConnection"
         and proof["proc_exe"] == {"elf_machine": 62, "matched_python_inode": True}
         and libc and tuple(map(int, libc.groups())) >= (2, 34), "AMD64 smoke evidence differs")


def stage_inputs(directory):
    directory.mkdir(mode=0o700)
    for name, (relative, expected, mode) in INPUTS.items():
        with (DAY / relative).open("rb") as source:
            raw = source.read(32 * 1024**2 + 1)
        need(len(raw) <= 32 * 1024**2 and hashlib.sha256(raw).hexdigest() == expected, "input differs: " + name)
        path = directory / name
        with path.open("xb") as destination:
            destination.write(raw)
            os.fchmod(destination.fileno(), mode)
    verify_inputs(directory)


def verify_inputs(directory):
    need(set(entry.name for entry in directory.iterdir()) == set(INPUTS), "input inventory differs")
    for name, (_, expected, mode) in INPUTS.items():
        fd = os.open(directory / name, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
        with os.fdopen(fd, "rb") as stream:
            info = os.fstat(stream.fileno())
            need(stat.S_ISREG(info.st_mode) and stat.S_IMODE(info.st_mode) == mode and info.st_nlink == 1
                 and info.st_uid == os.getuid() and 0 < info.st_size <= 32 * 1024**2
                 and hashlib.file_digest(stream, "sha256").hexdigest() == expected, "staged input differs: " + name)


def create_argv(nonce, inputs, output):
    need(re.fullmatch(r"[0-9a-f]{32}", nonce) is not None, "invalid owner nonce")
    need(inputs.name == "inputs" and output.name == "output" and inputs.parent == output.parent,
         "bind sources must be separate owned job directories")
    for path in (inputs.parent, inputs, output):
        need(path == path.resolve(strict=True) and "," not in str(path), "invalid bind source")
        info = path.stat(follow_symlinks=False)
        need(stat.S_ISDIR(info.st_mode) and info.st_uid == os.getuid()
             and stat.S_IMODE(info.st_mode) == 0o700, "bind source is not a private owned directory")
    return [
        "create", "--pull=never", "--platform=linux/amd64", "--name=corsa-d1-sg32-" + nonce + "-service",
        "--label=corsa.loadstand", "--label=corsa.sg32.owner=" + nonce, "--label=corsa.sg32.role=service",
        "--network=none", "--restart=no", "--read-only", "--cgroupns=private", "--ipc=private",
        "--cpus=1", f"--memory={MEMORY}", f"--memory-swap={MEMORY}", "--pids-limit=64", "--user=501:20",
        "--cap-drop=ALL", "--security-opt=no-new-privileges", "--log-driver=json-file",
        "--log-opt=max-size=1m", "--log-opt=max-file=1",
        "--mount", f"type=bind,src={inputs},dst=/inputs,readonly",
        "--mount", f"type=bind,src={output},dst=/work",
        "--entrypoint=" + ENTRYPOINT, IMAGE, *COMMAND,
    ]


def check_created(meta, ident, nonce, inputs, output):
    cfg, host, labels = meta["Config"], meta["HostConfig"], meta["Config"]["Labels"]
    mounts = sorted((m["Destination"], m["Type"], m["Source"], m["RW"], m["Propagation"]) for m in meta["Mounts"])
    need(mounts == [("/inputs", "bind", str(inputs), False, "rprivate"),
                    ("/work", "bind", str(output), True, "rprivate")], "container mount scope differs")
    need(meta["Id"] == ident and meta["Name"] == "/corsa-d1-sg32-" + nonce + "-service"
         and meta["Image"] == IMAGE and meta["State"]["Status"] == "created"
         and labels.get("corsa.sg32.owner") == nonce and labels.get("corsa.sg32.role") == "service"
         and "corsa.loadstand" in labels and cfg["User"] == "501:20"
         and cfg["Entrypoint"] == [ENTRYPOINT] and cfg["Cmd"] == COMMAND
         and host["NetworkMode"] == "none" and host["CgroupnsMode"] == "private" and host["IpcMode"] == "private"
         and host["NanoCpus"] == 1_000_000_000 and host["Memory"] == host["MemorySwap"] == MEMORY
         and host["PidsLimit"] == 64 and host["ReadonlyRootfs"] is True and host["Privileged"] is False
         and not host["CapAdd"] and host["CapDrop"] == ["ALL"]
         and host["SecurityOpt"] in (["no-new-privileges"], ["no-new-privileges=true"])
         and not any(host.get(key) for key in ("Binds", "PortBindings", "PublishAllPorts", "Devices",
                                              "DeviceRequests", "DeviceCgroupRules", "PidMode", "UsernsMode",
                                              "Tmpfs", "VolumesFrom", "CgroupParent"))
         and host["LogConfig"] == LOG and host["RestartPolicy"]["Name"] == "no",
         "container isolation or resource profile differs")


def execute_stage(engine, nonce, ids, inputs, output, smoke, deadline):
    validate_smoke(smoke)
    argv = create_argv(nonce, inputs, output)
    verify_inputs(inputs)
    need(not any(output.iterdir()), "output directory is not empty")
    image = json.loads(engine.command(["image", "inspect", "--format", "{{json .}}", IMAGE], deadline))
    need(image["Id"] == IMAGE and image["Os"] == "linux" and image["Architecture"] == "amd64"
         and any(ref.endswith("@" + MANIFEST) for ref in image["RepoDigests"])
         and not image["Config"].get("Volumes") and image["Size"] == smoke["image_bytes"], "local image differs")
    ident = engine.command(argv, deadline, mutation=True).decode().strip()
    need(re.fullmatch(r"[0-9a-f]{64}", ident) is not None, "invalid created container ID")
    ids.append(ident)
    check_created(engine.inspect(ident, deadline), ident, nonce, inputs, output)
    # A successful detached start proves Docker accepted the mutation.
    # The guest exit code is reported separately by docker wait.
    engine.command(["start", ident], deadline, mutation=True)
    exit_code = engine.command(["wait", ident], deadline).strip()
    state = engine.inspect(ident, deadline)["State"]
    need(state["Status"] == "exited" and state["Running"] is False
         and type(state["ExitCode"]) is int and exit_code == str(state["ExitCode"]).encode(),
         "guest wait and inspect differ")
    engine.command(["logs", ident], deadline)
    need(state["ExitCode"] == 0 and state["OOMKilled"] is False,
         "guest did not exit normally")
    verify_inputs(inputs)
    return ident
