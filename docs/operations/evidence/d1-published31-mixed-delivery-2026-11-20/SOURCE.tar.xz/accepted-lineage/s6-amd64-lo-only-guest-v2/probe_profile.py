"""Build and validate the offline probe's Docker and QEMU configuration."""

import re


QEMU = "/usr/bin/qemu-system-x86_64"
MEMORY = 1536 * 1024**2
LOG = {"Type": "json-file", "Config": {"max-size": "1m", "max-file": "1"}}
KERNEL = "/s6-preparation/extracted/vmlinuz"
INITRD = "/s6-preparation/initramfs.cpio.gz"


def guest_args():
    return [
        "-machine", "pc,usb=off", "-accel", "tcg,thread=single", "-cpu", "max",
        "-smp", "1", "-m", "768M", "-nodefaults", "-no-user-config",
        "-nic", "none", "-display", "none", "-serial", "stdio", "-monitor", "none",
        "-parallel", "none", "-no-reboot",
        "-kernel", KERNEL, "-initrd", INITRD,
        "-append", "console=ttyS0 quiet rdinit=/init panic=1",
    ]


def create_args(nonce, image):
    if not re.fullmatch(r"[0-9a-f]{32}", nonce) or not re.fullmatch(r"sha256:[0-9a-f]{64}", image):
        raise ValueError("invalid probe nonce or prepared image ID")
    return [
        "create", "--pull=never", "--platform=linux/arm64", "--name=corsa-d1-sg32-" + nonce + "-service",
        "--label=corsa.loadstand", "--label=corsa.sg32.owner=" + nonce, "--label=corsa.sg32.role=service",
        "--network=none", "--restart=no", "--read-only", "--cgroupns=private", "--ipc=private",
        "--cpus=1", f"--memory={MEMORY}", f"--memory-swap={MEMORY}", "--pids-limit=64",
        "--user=501:20", "--cap-drop=ALL", "--security-opt=no-new-privileges",
        "--log-driver=json-file", "--log-opt=max-size=1m", "--log-opt=max-file=1",
        "--entrypoint=" + QEMU, image, *guest_args(),
    ]


def check_created(meta, ident, nonce, image):
    cfg, host, state = meta["Config"], meta["HostConfig"], meta["State"]
    labels = cfg["Labels"]
    if not (
        meta["Id"] == ident and meta["Image"] == image
        and meta["Name"] == f"/corsa-d1-sg32-{nonce}-service"
        and labels.get("corsa.sg32.owner") == nonce and labels.get("corsa.sg32.role") == "service"
        and "corsa.loadstand" in labels and cfg["User"] == "501:20"
        and cfg["Entrypoint"] == [QEMU] and cfg["Cmd"] == guest_args()
        and not cfg["Tty"] and not cfg["OpenStdin"]
        and state["Status"] == "created" and state["Running"] is False
        and meta["Mounts"] == [] and not cfg.get("Volumes")
        and host["NetworkMode"] == "none" and host["ReadonlyRootfs"] is True
        and host["Privileged"] is False and host["NanoCpus"] == 1_000_000_000
        and host["Memory"] == host["MemorySwap"] == MEMORY and host["PidsLimit"] == 64
        and host["CapDrop"] == ["ALL"] and host["RestartPolicy"]["Name"] == "no"
        and host["SecurityOpt"] in (["no-new-privileges"], ["no-new-privileges=true"])
        and host["CgroupnsMode"] == "private" and host["IpcMode"] == "private"
        and host["LogConfig"] == LOG
        and not any(host.get(key) for key in (
            "Binds", "Tmpfs", "VolumesFrom", "CapAdd", "Devices", "DeviceRequests",
            "DeviceCgroupRules", "PortBindings", "PublishAllPorts", "PidMode", "UsernsMode",
            "CgroupParent",
        ))
    ):
        raise ValueError("offline QEMU container profile differs")
