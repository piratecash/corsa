"""Pack only the explicit S6 boot probe inputs into a gzip newc archive."""

import argparse
import gzip
from hashlib import sha256
import json
from pathlib import Path
import stat


FILES = {
    "init": ("init", 0o755),
    "busybox": ("bin/busybox", 0o755),
    "getconf": ("usr/bin/getconf", 0o755),
    "loader": ("lib64/ld-linux-x86-64.so.2", 0o755),
    "libc": ("lib/x86_64-linux-gnu/libc.so.6", 0o644),
}
DIRECTORIES = ("bin", "dev", "lib", "lib/x86_64-linux-gnu", "lib64", "proc", "usr", "usr/bin")
MAX_FILE = 16 * 1024**2


def entry(stream, inode, name, mode, data=b"", device=(0, 0)):
    path = name.encode("ascii") + b"\0"
    fields = (inode, mode, 0, 0, 2 if stat.S_ISDIR(mode) else 1, 0,
              len(data), 0, 0, *device, len(path), 0)
    header = b"070701" + "".join(f"{number:08x}" for number in fields).encode("ascii")
    stream.write(header + path)
    stream.write(b"\0" * (-(len(header) + len(path)) % 4))
    stream.write(data)
    stream.write(b"\0" * (-len(data) % 4))


def build(paths, output):
    payload = []
    for label, (name, mode) in FILES.items():
        with paths[label].open("rb") as stream:
            data = stream.read(MAX_FILE + 1)
        if not 0 < len(data) <= MAX_FILE:
            raise ValueError(f"{label}: invalid file size")
        payload.append((name, stat.S_IFREG | mode, data))
    if not payload[0][2].startswith(b"#!/bin/busybox sh\n"):
        raise ValueError("unexpected init interpreter")

    with output.open("xb") as raw:
        with gzip.GzipFile(filename="", fileobj=raw, mode="wb", mtime=0) as archive:
            for inode, name in enumerate(DIRECTORIES, 1):
                entry(archive, inode, name, stat.S_IFDIR | 0o755)
            inode = len(DIRECTORIES) + 1
            # Linux opens the initial console before it executes /init.
            entry(archive, inode, "dev/console", stat.S_IFCHR | 0o600, device=(5, 1))
            for inode, (name, mode, data) in enumerate(payload, inode + 1):
                entry(archive, inode, name, mode, data)
            entry(archive, 0, "TRAILER!!!", 0)
    with output.open("rb") as stream:
        archive_sha = sha256(stream.read()).hexdigest()
    return {
        "initramfs_sha256": archive_sha,
        "initramfs_bytes": output.stat().st_size,
        "files": {name: sha256(data).hexdigest() for name, _, data in payload},
        "directories": list(DIRECTORIES),
        "device": {"path": "dev/console", "major": 5, "minor": 1},
    }


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    for name in (*FILES, "output"):
        parser.add_argument(f"--{name}", type=Path, required=True)
    args = vars(parser.parse_args())
    output = args.pop("output")
    try:
        print(json.dumps(build(args, output), indent=2))
    except (OSError, ValueError) as error:
        parser.exit(2, f"Initramfs refused: {error}\n")
