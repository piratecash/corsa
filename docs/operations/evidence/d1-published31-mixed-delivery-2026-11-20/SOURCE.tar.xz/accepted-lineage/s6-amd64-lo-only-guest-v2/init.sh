#!/bin/busybox sh
set -eu
export PATH=/bin:/usr/bin
bb=/bin/busybox

fail() {
    printf 'S6-AMD64-FAIL %s\n' "$1"
    "$bb" poweroff -f
    exit 1
}

check_interfaces() {
    phase=$1
    names=$("$bb" awk 'NR > 2 {name=$0; sub(/:.*/, "", name); gsub(/^[ \t]+|[ \t]+$/, "", name); print name}' /proc/net/dev) || return 1
    printf 'S6-AMD64-INTERFACES %s\n%s\n' "$phase" "$names"
    [ "$names" = lo ]
}

if [ "${1:-}" = check-fresh ]; then
    fresh=$("$bb" readlink /proc/self/ns/net)
    [ "$fresh" != "$2" ] || exit 1
    printf 'S6-AMD64-NETNS fresh %s\n' "$fresh"
    check_interfaces fresh
    exit $?
fi

"$bb" mount -t proc proc /proc || fail mount-proc
arch=$("$bb" uname -m) || fail uname
[ "$arch" = x86_64 ] || fail wrong-arch
printf 'S6-AMD64-ARCH %s\n' "$arch"
libc=$(/usr/bin/getconf GNU_LIBC_VERSION) || fail glibc-unavailable
printf 'S6-AMD64-LIBC %s\n' "$libc"
printf '%s\n' "$libc" | "$bb" awk '
    /^glibc [0-9]+\.[0-9]+$/ {
        split($2, version, ".")
        if (version[1] > 2 || (version[1] == 2 && version[2] >= 34)) ok=1
    }
    END { exit !ok }
' || fail glibc-version
boot=$("$bb" readlink /proc/self/ns/net) || fail boot-netns
printf 'S6-AMD64-NETNS boot %s\n' "$boot"
check_interfaces boot || fail boot-lo-only
"$bb" unshare -n /bin/busybox sh /init check-fresh "$boot" || fail fresh-lo-only
printf 'S6-AMD64-RESULT PASS\n'
"$bb" poweroff -f
