"""Run one admitted Debian preparation, without starting a guest."""

import hashlib
import json
import os
from pathlib import Path
import re
import secrets
import shutil
import signal
import sys
import time

PACKAGE = Path(__file__).resolve().parent
sys.path.insert(0, str(PACKAGE.parents[1] / "2026-11-12/s6-baseline-restart-v4"))
import controller as shared

PROFILE = "s6-amd64-lo-only-prepare-v2"
ROOT = Path("/private/tmp") / PROFILE
GIB = 1024**3
RAM = GIB
LOG_LIMIT = 1024**2
BASE_REF = re.compile(r"docker\.io/library/debian@sha256:[0-9a-f]{64}")
IMAGE_ID = re.compile(r"sha256:[0-9a-f]{64}")
SOURCES = (
    "prepare_container.sh", "init.sh", "select_packages.py", "extract_guest_files.py",
    "check_kernel_config.py", "check_boot_inputs.py", "build_initramfs.py",
)
LOG_CONFIG = {"Type": "json-file", "Config": {"max-size": "1m", "max-file": "1"}}
# Package installation needs ordinary file ownership/permission changes.
CAPS = {"CHOWN", "DAC_OVERRIDE", "FOWNER", "FSETID", "SETGID", "SETUID"}


def need(condition, message):
    if not condition:
        raise ValueError(message)


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def admission(host):
    manifest_raw = host.read_owned(PACKAGE / "PREPARATION-HANDOFF.json", 65536)
    manifest = host.strict_json(manifest_raw)
    decision = host.read_owned(PACKAGE / "PREPARATION-OWNER-DECISION.txt", 65536)
    grant = host.strict_json(host.read_owned(PACKAGE / "PREPARATION-OWNER-ADMISSION.json", 65536))
    need(decision.strip() and manifest.get("profile") == PROFILE and grant == {
        "profile": PROFILE, "one_attempt": True, "handoff_sha256": digest(manifest_raw),
        "owner_decision_sha256": digest(decision),
    }, "exact preparation admission missing")
    need(BASE_REF.fullmatch(manifest["base"]), "expected official Debian base digest")
    need(set(manifest["files"]) == {*SOURCES, "PROFILE.ru.md", "run_preparation.py", "prep_docker.sh", "DEBIAN-BASE.json",
                                   "DEBIAN-INDEX.raw", "DEBIAN-ARM64-MANIFEST.raw"},
         "unexpected preparation source set")
    files = {name: host.read_owned(PACKAGE / name, 65536) for name in manifest["files"]}
    need(all(digest(raw) == manifest["files"][name] for name, raw in files.items()),
         "preparation source changed")
    base = host.strict_json(files["DEBIAN-BASE.json"])
    image = host.strict_json(files["DEBIAN-ARM64-MANIFEST.raw"])
    index = host.strict_json(files["DEBIAN-INDEX.raw"])
    matching = [row for row in index["manifests"] if row.get("platform", {}).get("os") == "linux"
                and row["platform"].get("architecture") == "arm64"
                and row["platform"].get("variant") in (None, "v8")]
    need(base["source"] == "docker.io/library/debian:trixie-slim"
         and base["platform"] == "linux/arm64" and base["base"] == manifest["base"]
         and base["metadata_only"] is True and base["index_digest"] == "sha256:" + digest(files["DEBIAN-INDEX.raw"])
         and base["manifest_digest"] == "sha256:" + digest(files["DEBIAN-ARM64-MANIFEST.raw"])
         and base["base"] == "docker.io/library/debian@" + base["manifest_digest"]
         and len(matching) == 1 and matching[0]["digest"] == base["manifest_digest"]
         and matching[0]["size"] == len(files["DEBIAN-ARM64-MANIFEST.raw"])
         and base["config_digest"] == image["config"]["digest"]
         and IMAGE_ID.fullmatch(base["config_digest"]), "registry metadata binding differs")
    return base, {name: files[name] for name in SOURCES}, files["prep_docker.sh"], digest(manifest_raw)


def create_args(nonce, image):
    return ["create", "--pull=never", "--platform=linux/arm64",
            "--name=corsa-d1-sg32-" + nonce + "-preparer", "--label=corsa.loadstand",
            "--label=corsa.sg32.owner=" + nonce, "--label=corsa.sg32.role=preparer",
            "--network=bridge", "--restart=no", "--user=0:0", "--cpus=1",
            f"--memory={RAM}", f"--memory-swap={RAM}", "--pids-limit=128",
            "--cap-drop=ALL", *("--cap-add=" + cap for cap in sorted(CAPS)),
            "--security-opt=no-new-privileges", "--log-driver=json-file",
            "--log-opt=max-size=1m", "--log-opt=max-file=1", "--entrypoint=/bin/sh",
            image, "/s6-source/prepare_container.sh", "/s6-source"]


def check_created(meta, ident, nonce, image):
    config, host, state = meta["Config"], meta["HostConfig"], meta["State"]
    labels = config["Labels"]
    caps = {value.removeprefix("CAP_") for value in host.get("CapAdd") or []}
    need(meta["Id"] == ident and meta["Image"] == image
         and meta["Name"] == f"/corsa-d1-sg32-{nonce}-preparer"
         and labels.get("corsa.sg32.owner") == nonce and labels.get("corsa.sg32.role") == "preparer"
         and "corsa.loadstand" in labels and meta["Mounts"] == []
         and config["User"] == "0:0" and config["Entrypoint"] == ["/bin/sh"]
         and config["Cmd"] == ["/s6-source/prepare_container.sh", "/s6-source"]
         and state["Status"] == "created" and state["Running"] is False, "created container differs")
    need((host["NanoCpus"], host["Memory"], host["MemorySwap"], host["PidsLimit"]) ==
         (1_000_000_000, RAM, RAM, 128) and host["NetworkMode"] == "bridge"
         and host["RestartPolicy"]["Name"] == "no" and host["Privileged"] is False
         and host["ReadonlyRootfs"] is False and host["CapDrop"] == ["ALL"] and caps == CAPS
         and host["LogConfig"] == LOG_CONFIG
         and host["SecurityOpt"] in (["no-new-privileges"], ["no-new-privileges=true"])
         and not any(host.get(key) for key in (
             "Binds", "Tmpfs", "VolumesFrom", "PortBindings", "PublishAllPorts", "Devices",
             "DeviceRequests", "DeviceCgroupRules", "PidMode", "UsernsMode", "CgroupParent",
         )), "preparation limits or isolation differ")


def image_info(host, engine, image, deadline):
    row = host.strict_json(engine.command(["image", "inspect", "--format", "{{json .}}", image], deadline))
    need(IMAGE_ID.fullmatch(row["Id"]) and (row["Os"], row["Architecture"]) == ("linux", "arm64")
         and not row["Config"].get("Volumes") and type(row["Size"]) is int and row["Size"] > 0,
         "unexpected image metadata")
    return row


def prepare(host, engine, registry, nonce, ids, deadline):
    base = registry["base"]
    engine.command(["pull", "--platform=linux/arm64", base], deadline, mutation=True)
    base_info = image_info(host, engine, base, deadline)
    need(base_info["Id"] == registry["config_digest"]
         and any(ref.endswith("@" + base.split("@", 1)[1]) for ref in base_info["RepoDigests"])
         and base_info["Size"] <= 512 * 1024**2, "base digest or size differs")
    image = base_info["Id"]
    ident = engine.command(create_args(nonce, image), deadline, mutation=True).decode().strip()
    need(re.fullmatch(r"[0-9a-f]{64}", ident), "invalid preparation container ID")
    ids.append(ident)
    check_created(engine.inspect(ident, deadline), ident, nonce, image)
    engine.command(["cp", str(ROOT / "source"), f"{ident}:/s6-source"], deadline, mutation=True)
    engine.command(["start", ident], deadline, mutation=True)
    exit_code = engine.command(["wait", ident], deadline).strip()
    state = engine.inspect(ident, deadline)["State"]
    engine.command(["logs", ident], deadline)
    need(exit_code == b"0" and state["Status"] == "exited" and state["Running"] is False
         and state["ExitCode"] == 0 and state["OOMKilled"] is False, "preparation container failed")
    writable = host.strict_json(engine.command(
        ["inspect", "--size", "--format", "{{json .SizeRw}}", ident], deadline))
    # Account for the working layer and the second copy retained by commit.
    need(type(writable) is int and 0 < writable and base_info["Size"] + 2 * writable + LOG_LIMIT <= 4 * GIB,
         "preparation exceeds disk profile")

    evidence = ROOT / "evidence"
    engine.command(["cp", f"{ident}:/s6-preparation/evidence", str(evidence)], deadline)
    qemu = host.read_owned(evidence / "qemu-version.txt", 4096).decode("ascii").strip()
    qemu_binary = host.read_owned(evidence / "qemu-binary.sha256", 4096).decode("ascii")
    qemu_match = re.fullmatch(r"([0-9a-f]{64})  /usr/bin/qemu-system-x86_64\n", qemu_binary)
    boot_hashes = host.read_owned(evidence / "boot-files.sha256", 4096).decode("ascii")
    boot_access = host.read_owned(evidence / "boot-access.txt", 4096).decode("ascii").splitlines()
    need(boot_access == ["711 0 0 /s6-preparation", "711 0 0 extracted",
                         "644 0 0 extracted/vmlinuz", "644 0 0 initramfs.cpio.gz"],
         "boot input access differs")
    need(re.fullmatch(r"[0-9][0-9A-Za-z.+:~_-]*", qemu) and qemu_match and re.fullmatch(
        r"[0-9a-f]{64}  extracted/vmlinuz\n[0-9a-f]{64}  extracted/kernel.config\n"
        r"[0-9a-f]{64}  initramfs.cpio.gz\n", boot_hashes), "missing QEMU or guest input evidence")
    tag = f"corsa-s6-amd64-probe:{nonce}"
    need(not engine.command(["image", "ls", "-q", "--filter", "reference=" + tag], deadline).strip(),
         "image tag already exists")
    output = engine.command(["commit", ident, tag], deadline, mutation=True).decode().strip()
    need(IMAGE_ID.fullmatch(output) and output != image, "invalid final image ID")
    prepared = image_info(host, engine, output, deadline)
    need(prepared["Id"] == output and tag in prepared["RepoTags"]
         and prepared["Size"] + writable + LOG_LIMIT <= 4 * GIB, "prepared image differs")
    return {"base_digest": base, "base_id": image, "image_id": output, "tag": tag,
            "image_bytes": prepared["Size"], "writable_bytes": writable,
            "qemu_package_version": qemu, "qemu_binary_sha256": qemu_match[1],
            "boot_files_sha256": boot_hashes.splitlines(),
            "boot_access": boot_access}


def main():
    origin = time.monotonic()
    os.umask(0o077)
    host = shared.load_host()
    registry, files, launcher, handoff = admission(host)
    need(shared.digest(host.WRAPPER.read_bytes()) == shared.WRAPPER_SHA, "heavy-run wrapper differs")
    need((os.getuid(), os.getgid()) == (501, 20) and os.getpid() == os.getpgrp(), "wrong process group")
    while True:
        owner = dict(line.split("=", 1) for line in host.read_owned(host.LOCK / "owner", 8192).decode().splitlines()
                     if "=" in line)
        need(owner.get("name") == PROFILE and time.monotonic() < origin + 3, "wrong heavy-lock owner")
        if owner.get("pgid") == str(os.getpgrp()):
            break
        time.sleep(.05)
    need(shutil.disk_usage(ROOT.parent).free >= 15 * GIB, "insufficient host free space")
    need(os.access("/Applications/Docker.app/Contents/Resources/bin/docker-credential-desktop", os.X_OK),
         "Docker Desktop credential helper is unavailable")
    ROOT.mkdir(mode=0o700)
    executable = ROOT / "prep_docker.sh"
    with executable.open("xb") as stream:
        stream.write(launcher)
    executable.chmod(0o700)
    host.DOCKER = str(executable)
    source = ROOT / "source"
    source.mkdir(mode=0o700)
    for name, raw in files.items():
        with (source / name).open("xb") as stream:
            stream.write(raw)

    stopping = False

    def stop(_signum, _frame):
        nonlocal stopping
        stopping = True

    class BoundedEngine(host.Engine):
        cleaning = False

        def charge(self, role, count):
            need(self.cleaning or sum(self.used.values()) + count <= LOG_LIMIT, "preparation log cap")
            super().charge(role, count)

        def pump_until(self, predicate, deadline):
            super().pump_until(lambda: predicate() or (stopping and not self.cleaning), deadline)
            need(not stopping or self.cleaning, "preparation stopped")

    signal.signal(signal.SIGTERM, stop)
    signal.signal(signal.SIGINT, stop)
    engine = BoundedEngine()
    engine.root = ROOT
    nonce, ids = secrets.token_hex(16), []
    result = {"status": "INCOMPLETE", "handoff_sha256": handoff, "nonce": nonce}
    end, cleanup_end = origin + 600, origin + 630
    try:
        endpoint = host.strict_json(engine.command(
            ["context", "inspect", "--format", "{{json .Endpoints.docker.Host}}", "desktop-linux"], end))
        need(endpoint == host.ENDPOINT, "unexpected Docker endpoint")
        result.update(prepare(host, engine, registry, nonce, ids, end))
        need(not stopping and time.monotonic() < end, "preparation work deadline")
        result["status"] = "PREPARED_NOT_BOOTED"
    except Exception as error:
        result["failure"] = str(error)[:256]
    finally:
        engine.cleaning = True
        try:
            closed = host.cleanup(engine, nonce, ids, [], cleanup_end)
        except Exception:
            closed = False
        result["closure"] = "KNOWN" if closed else "UNKNOWN"
        if not closed:
            result["status"] = "RECOVERY_REQUIRED"
        elif stopping or engine.output_failed or time.monotonic() >= cleanup_end:
            result["status"] = "INCOMPLETE"
        try:
            engine.put("commands.json", engine.commands)
            engine.put("result.json", result)
        finally:
            if not closed:
                while True:
                    time.sleep(60)
            engine.selector.close()
    return 0 if result["status"] == "PREPARED_NOT_BOOTED" else 2


if __name__ == "__main__":
    sys.exit(main())
