"""Single-purpose bounded helper-build runner; imported without side effects."""
import hashlib,json,os,signal,subprocess,threading,time,uuid
from pathlib import Path
LOCK=Path('/private/tmp/corsa-heavy-run.lock')
RAW_LIMIT=1024**2

def need(ok,why):
 if not ok:raise RuntimeError(why)
def sha(path):
 path=Path(path);before=path.stat();need(not path.is_symlink() and path.is_file() and 0<=before.st_size<=256*1024**2,'irregular hash input')
 h=hashlib.sha256();remaining=before.st_size
 with path.open('rb') as f:
  while remaining:
   block=f.read(min(1024**2,remaining));need(block,'short hash input');h.update(block);remaining-=len(block)
  need(f.read(1)==b'','growing hash input')
 need(stamp(path)==(before.st_dev,before.st_ino,before.st_mode,before.st_uid,before.st_gid,before.st_size,before.st_mtime_ns,before.st_ctime_ns),'hash input changed')
 return h.hexdigest()

def stamp(path):
 s=path.lstat();return(s.st_dev,s.st_ino,s.st_mode,s.st_uid,s.st_gid,s.st_size,s.st_mtime_ns,s.st_ctime_ns)
def directory_bytes(root,limit):
 total=0;count=0
 for folder,dirs,files in os.walk(root,followlinks=False):
  for name in dirs+files:
   p=Path(folder)/name;need(not p.is_symlink(),'linked work inventory')
   count+=1;need(count<=100000,'work inventory count')
  for name in files:
   total+=(Path(folder)/name).stat().st_size;need(total<=limit,'work file byte limit')
 return total

def static_arm64(path):
 import struct
 raw=Path(path).read_bytes();need(64<=len(raw)<=64*1024**2,'artifact size')
 need(raw[:7]==b'\x7fELF\x02\x01\x01','ELF64LE required')
 typ,machine,version,_,off,_,_,size,ents,count,_,_,_=struct.unpack_from('<HHIQQQIHHHHHH',raw,16)
 need(typ in (2,3) and machine==183 and version==1 and size==64 and ents==56 and 0<count<=128 and 64<=off and off+56*count<=len(raw),'AArch64 ELF header')
 for index in range(count):
  kind,_,start,_,_,length,_,_=struct.unpack_from('<IIQQQQQQ',raw,off+56*index)
  need(start<=len(raw) and length<=len(raw)-start and kind not in (2,3),'dynamic/invalid ELF segment')
 return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'static_arm64':True,'executed':False}

class Job:
 def __init__(self,name,budget,file_limit):
  self.origin=time.monotonic();self.deadline=self.origin+budget;self.cleanup=self.deadline+30
  self.attempt=uuid.uuid4().hex;self.work=Path('/private/tmp/corsa-d1-o1a-'+name+'-'+self.attempt)
  self.work.mkdir(mode=0o700);self.steps=[];self.raw_bytes=0;self.raw_mutex=threading.Lock();self.child=None;self.unknown=False;self.file_limit=file_limit
  self.owner=('name=d1-o1a-'+name+'\npid='+str(os.getpid())+'\npgid='+str(os.getpgrp())+'\nattempt_id='+self.attempt+'\n').encode()
  LOCK.mkdir(mode=0o700)
  with (LOCK/'owner').open('xb') as f:f.write(self.owner)
  self.custody=(stamp(LOCK),stamp(LOCK/'owner'))
 def check_lock(self):need(self.custody==(stamp(LOCK),stamp(LOCK/'owner')) and (LOCK/'owner').read_bytes()==self.owner and set(p.name for p in LOCK.iterdir())=={'owner'},'lock ownership changed')
 def run(self,name,argv,cwd=None,env=None,cleanup=False):
  self.check_lock();limit=self.cleanup if cleanup else self.deadline
  need(time.monotonic()<limit,'job deadline before command')
  number=len(self.steps)+1;prefix=f'{number:02}-{name}';fault=threading.Event();threads=[]
  outputs=[self.work/(prefix+'.stdout'),self.work/(prefix+'.stderr')]
  def pump(pipe,path):
   try:
    with path.open('xb') as f:
     while True:
      block=pipe.read(32768)
      if not block:break
      with self.raw_mutex:
       left=RAW_LIMIT-self.raw_bytes
       take=min(left,len(block));self.raw_bytes+=take
       if take:f.write(block[:take])
       if take!=len(block):fault.set();break
   except BaseException:fault.set()
   finally:pipe.close()
  p=subprocess.Popen(argv,cwd=cwd,env=env,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True);self.child=p
  for pipe,path in zip((p.stdout,p.stderr),outputs):
   thread=threading.Thread(target=pump,args=(pipe,path),daemon=True);thread.start();threads.append(thread)
  reason=None
  while p.poll() is None:
   if fault.is_set() or time.monotonic()>=limit:
    reason='RAW bound' if fault.is_set() else 'deadline';break
   time.sleep(.05)
  if reason:
   self.stop_child()
  else:p.wait()
  for thread in threads:thread.join(timeout=max(0,self.cleanup-time.monotonic()))
  group_absent=self.group_absent(p.pid)
  if not group_absent or any(t.is_alive() for t in threads):self.unknown=True
  row={'phase':name,'argv':list(argv),'pid':p.pid,'exit':p.returncode,'reason':reason,'owned_group_absent':group_absent,'pipe_threads_finished':not any(t.is_alive() for t in threads),'stdout':str(outputs[0]),'stderr':str(outputs[1])};self.steps.append(row)
  (self.work/(prefix+'.json')).write_text(json.dumps(row,indent=2)+'\n')
  need(not self.unknown,'unknown process/output completion')
  directory_bytes(self.work,self.file_limit)
  need(reason is None and not fault.is_set() and p.returncode==0,'command failed: '+name)
  return outputs[0].read_bytes()
 @staticmethod
 def group_absent(pgid):
  try:os.killpg(pgid,0)
  except ProcessLookupError:return True
  except PermissionError:return False
  return False
 def stop_child(self):
  p=self.child
  if p is None:return
  if p.returncode is None:
   try:os.killpg(p.pid,signal.SIGTERM)
   except ProcessLookupError:pass
   try:p.wait(timeout=min(5,max(0,self.cleanup-time.monotonic())))
   except subprocess.TimeoutExpired:
    try:os.killpg(p.pid,signal.SIGKILL)
    except ProcessLookupError:pass
    try:p.wait(timeout=max(0,self.cleanup-time.monotonic()))
    except subprocess.TimeoutExpired:self.unknown=True
  if not self.group_absent(p.pid):self.unknown=True
 def finish(self,result):
  self.stop_child();self.check_lock();result.update(attempt_id=self.attempt,work=str(self.work),steps=self.steps,raw_bytes=self.raw_bytes,unknown=self.unknown,lock_retained=self.unknown)
  (self.work/'RESULT.json').write_text(json.dumps(result,sort_keys=True,indent=2)+'\n')
  print(json.dumps(result,sort_keys=True),flush=True)
  if self.unknown:
   # Hold exact own lock/controller for operator recovery, never auto-repeat.
   while True:time.sleep(60)
  (LOCK/'owner').unlink();LOCK.rmdir()
  return result
