from pathlib import Path
import json,hashlib,os,tarfile,struct
D=Path('/Users/hades/Documents/repos/corsa/docs/_internal/d1-artifacts/2026-11-20');P=D/'d1-hmix-published31-goqa-v1';S=D/'d1-hmix-published31-linux-guest-source-v1';W=Path('/private/tmp/corsa-d1-o1a-hmix-published31-goqa-2b1dcc00713d42b1bf26d9a9919f73a8');r=json.loads((W/'RESULT.json').read_bytes());assert hashlib.sha256((W/'RESULT.json').read_bytes()).hexdigest()=='01f4519511dbc046232f6e44097bda68400736b3387bf7aba774e561f20fcf96';assert not r['error'] and not r['unknown'] and not r['lock_retained'] and not r['Service_Run_or_Linux_ELF_or_Docker_VM_executed'];f=json.loads((P/'FROZEN.json').read_bytes());m=json.loads((S/'MANIFEST.json').read_bytes());assert hashlib.sha256((S/'MANIFEST.json').read_bytes()).hexdigest()==r['subject_manifest_sha256']==f['subject_manifest_sha256'];assert m['production_changes']==0 and all(n.endswith('_test.go') for n in m['files'])
base=json.loads((P/'BASE-FILES.json').read_bytes());before={}
with tarfile.open(W/'source.tar') as t:
 for i in t:
  if i.isdir():continue
  assert i.isfile() and not i.linkname and i.name in base and i.name not in before;row=base[i.name];assert i.size==row['bytes'] and i.mode==int(row['mode'],8)&0o777;b=t.extractfile(i).read();assert hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==row['blob_sha1'];before[i.name]=hashlib.sha256(b).hexdigest()
assert set(before)==set(base);expected=dict(before)
for n,row in m['files'].items():assert before.get(n)==row['before_sha256'];b=(S/row['post']).read_bytes();assert hashlib.sha256(b).hexdigest()==row['after_sha256'];expected[n]=row['after_sha256']
assert json.loads((W/'SOURCE-BEFORE.json').read_bytes())==before;assert json.loads((W/'SOURCE-EXPECTED.json').read_bytes())==json.loads((W/'SOURCE-AFTER.json').read_bytes())==expected;assert len(expected)==2727
for n,sha in expected.items():assert hashlib.sha256((W/'source'/n).read_bytes()).hexdigest()==sha
raw=0
for step in r['steps']:
 assert step['exit']==0 and step['owned_group_absent'] and step['pipe_threads_finished'] and step['reason'] is None
 for key in ['stdout','stderr']:raw+=Path(step[key]).stat().st_size
 assert not Path(step['stderr']).read_bytes()
 for call in [os.kill,os.killpg]:
  try:call(step['pid'],0)
  except ProcessLookupError:pass
  else:raise ValueError('live or reused own process/group')
assert raw==r['raw_bytes']==26354
counts={}
for label,name in [('findnode','04-findnode-guards.stdout'),('pilot','05-pilot-guards.stdout')]:
 rows=[json.loads(x) for x in (W/name).read_text().splitlines()];assert not any(x.get('Action') in ('fail','skip') for x in rows);passed=[x['Test'] for x in rows if x.get('Action')=='pass' and 'Test'in x];outer=[x for x in passed if '/'not in x];assert set(outer)==set(r['checks'][label]['outer']);child=sum('/'in x for x in passed);assert child==r['checks'][label]['child'];counts[label]={'outer':len(outer),'child':child}
assert sum(x['outer'] for x in counts.values())==7 and sum(x['child'] for x in counts.values())==15
artifact=r['artifact'];b=Path(artifact['path']).read_bytes();assert len(b)==artifact['bytes']==75315642 and hashlib.sha256(b).hexdigest()==artifact['sha256']=='6b31bbdcab39095727e00389d94b75638433e3e5c1a84e796223f514bf0baf65';assert b[:6]==b'\x7fELF\x02\x01' and struct.unpack_from('<HH',b,16)==(2,62);off=struct.unpack_from('<Q',b,32)[0];ents,n=struct.unpack_from('<HH',b,54);assert all(struct.unpack_from('<I',b,off+j*ents)[0] not in (2,3) for j in range(n))
info=(W/'07-build-info.stdout').read_text();assert info.splitlines()[0].endswith(': go1.27.4');deps={};settings={}
for line in info.splitlines()[1:]:
 row=line.strip().split('\t')
 if row[0]=='dep':assert len(row)==4 and row[1] not in deps;deps[row[1]]={'version':row[2],'sum':row[3]}
 if row[0]=='build':k,v=row[1].split('=',1);assert k not in settings;settings[k]=v
expecteddeps=json.loads((D/'d1-o1a-observer-coherent-snapshot-elf-build-v1/GRAPH-EXPECTATIONS.json').read_bytes())['NODE']['expected_semantic_graph']['modules'];assert deps==expecteddeps and len(deps)==26;assert all(settings.get(k)==v for k,v in {'GOOS':'linux','GOARCH':'amd64','GOAMD64':'v1','CGO_ENABLED':'0','-trimpath':'true','-tags':'interop,d1_owned_guest_interop'}.items())
assert '-ldflags=-buildid=' in next(x for x in r['steps'] if x['phase']=='compile-linux-amd64')['argv']
out=D/'d1-hmix-published31-architect-data-v1';out.mkdir(exist_ok=True);(out/'REVIEW.json').write_text(json.dumps({'status':'ACCEPTED_SOURCE_GUARDS_AND_COMPILE_DATA_ONLY','scope':'NOT_INTEROP_RUNTIME_NOT_HMIX_PASS','result_sha256':hashlib.sha256((W/'RESULT.json').read_bytes()).hexdigest(),'base_commit':r['base_commit'],'source_files_exact':2727,'test_only_posts':len(m['files']),'counts':counts,'commands_normal':7,'RAW_bytes':raw,'all_stderr_empty':True,'fresh_PID_PGID_absent':True,'artifact':artifact,'dependencies_exact':26,'Linux_ELF_apps_VM_or_resource_jobs_by_reviewer':False},sort_keys=True,indent=2)+'\n');print(hashlib.sha256((out/'REVIEW.json').read_bytes()).hexdigest())
