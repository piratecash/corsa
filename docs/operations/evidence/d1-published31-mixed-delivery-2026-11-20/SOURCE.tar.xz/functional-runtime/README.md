# Hmix published31: qualified environment rebind only

SOURCE/PREPARED; not executed. Clone of linux-guest-source-v1 host with exactly new image450 and exact accepted strict lo/glibc qualification3ed22 instead of historical image120/old proof. The assembly is reused unchanged fa517/nonce3abb, current test6b31, published06e26. init.sh, decode.py and build_guest.py are byte identical. Original180+30 host,90 test,120+10 BusyBox,1CPU/1536MiB/64PID/noSwap, guest1CPU/768MiB/noNIC/noDisk, one own readonly archive mount, original functional assertions and lifecycle/UNKNOWN cleanup unchanged.

QUALIFICATION.json pins successful16-command normal0/noOOM/strict x86_64/glibc2.36/boot and independent netns exactly{lo}, complete console, exact image descriptor and source/handoff. It qualifies the environment only. Runtime input preflight rechecks these frozen proofs and exact whole image metadata before create. No downloads or image mutations.

RUNTIME.PREPARED.json is deliberately not RUNTIME.json and status is not runnable. Root reviews/promotes exactly that record to READY_FOR_ONE_FUNCTIONAL_ATTEMPT and invokes the existing heavy wrapper/profile. No reassembly or recompilation. The one test remains Off then privateR with original packet/receipt/decryption checks, not metric/D1/G2/public activation proof. Original source/package/RAW unchanged.
