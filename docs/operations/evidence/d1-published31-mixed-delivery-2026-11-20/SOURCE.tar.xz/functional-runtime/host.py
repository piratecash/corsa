"""Run only the fixed published31 functional comparison in the original offline Debian guest."""
import hashlib
import json
import os
from pathlib import Path
import re
import secrets
import shutil
import signal
import sys
import time
import base64

HERE = Path(__file__).resolve().parent
PACKAGE = HERE.parent.parent / "2026-11-13/s6-amd64-lo-only-guest-v2"
sys.path.insert(0, str(PACKAGE))
from run_preparation import need, shared
import probe_profile
sys.path.insert(0, str(HERE))
from decode import verify_console

NAME = "d1-hmix-published31-linux-guest-v1"
WORK = None
IMAGE = "sha256:45009926747bc2be5493d1d28f84f8a40b358f9bb600f5ff9c1724ff201913e1"
QUALIFICATION_SHA = "311e4b91edcb38eb716bd20b05da92edea45c87b641158cf3063e318f6e7ada8"
DEPENDENCIES = {
    '/Users/hades/Documents/repos/corsa/docs/_internal/d1-artifacts/2026-11-13/s6-amd64-lo-only-guest-v2/probe_profile.py': '15e923d93306788d69a54a22d56b1387998f058f2f2657c5cc584228404e5946',
    '/Users/hades/Documents/repos/corsa/docs/_internal/d1-artifacts/2026-11-13/s6-amd64-lo-only-guest-v2/run_preparation.py': '2009c921e38ff26d5ad32e18a4a37b59b51e3a2f575611bf12e51f8c1cd5d108',
    '/Users/hades/Documents/repos/corsa/docs/_internal/d1-artifacts/2026-11-12/s6-baseline-restart-v4/controller.py': 'd5801dc16c4da115c154f6466053d879c89473eacc852907da5f741e09ca0ca0',
    '/Users/hades/Documents/repos/corsa/docs/_internal/d1-artifacts/2026-11-12/s6-baseline-restart-v4/host_stage.py': '62d088c7116c2fa68e7acd1dc7df86da677107176c84c2629d4da5f83e60a3bf',
}


def digest(path, limit):
    path = Path(path)
    before = path.lstat()
    need(not path.is_symlink() and path.is_file() and before.st_nlink == 1 and 0 < before.st_size <= limit, "input metadata")
    value = hashlib.sha256()
    with path.open("rb") as stream:
        left = before.st_size
        while left:
            block = stream.read(min(left, 1024**2))
            need(block, "short input")
            value.update(block)
            left -= len(block)
        need(stream.read(1) == b"", "growing input")
    after = path.lstat()
    keys = ("st_dev", "st_ino", "st_uid", "st_gid", "st_mode", "st_nlink", "st_size", "st_mtime_ns", "st_ctime_ns")
    need(tuple(getattr(before, k) for k in keys) == tuple(getattr(after, k) for k in keys), "input custody changed")
    return value.hexdigest()


def qualification():
    need(digest(HERE / "QUALIFICATION.json", 65536) == QUALIFICATION_SHA, "new qualification binding changed")
    proof = json.loads((HERE / "QUALIFICATION.json").read_bytes())
    need(proof["schema"] == 1 and proof["status"] == "ACTUAL_STRICT_LO_GLIBC_QUALIFICATION_ACCEPTED_ENVIRONMENT_ONLY" and proof["image_id"] == IMAGE, "new qualification identity")
    for name in ("result", "ready_handoff", "frozen_source", "console"):
        fixed = proof[name]
        need(digest(fixed["path"], 1024**2) == fixed["sha256"] and Path(fixed["path"]).stat().st_size == fixed["bytes"], "new qualification evidence changed")
    result = json.loads(Path(proof["result"]["path"]).read_bytes())
    ready = json.loads(Path(proof["ready_handoff"]["path"]).read_bytes())
    need(result["status"] == "AMD64_GLIBC_AND_LO_ONLY_VERIFIED" and result["error"] is None and result["unknown"] is False and result["lock_retained"] is False and result["owned_container_removed"] is True and result["console_complete"] is True and result["console_capture_error"] is None and result["image_id"] == IMAGE and result["guest"] == proof["guest"], "new qualification not successful/closed")
    need(result["handoff_sha256"] == proof["ready_handoff"]["sha256"] and ready["image_id"] == IMAGE and ready["readiness"] == {"CODE": True, "QA": True, "ROOT": True} and ready["FROZEN_sha256"] == proof["frozen_source"]["sha256"], "new qualification source/handoff pairing")
    need(all(step["exit"] == 0 and step["reason"] is None and step["owned_group_absent"] is True and step["pipe_threads_finished"] is True for step in result["steps"]), "new qualification incomplete command")
    return proof


def qualified_image(row, proof):
    need(all(row.get(key) == value for key, value in proof["image_immutable"].items()), "exact qualified QEMU image changed")


def inputs():
    raw = (HERE / "RUNTIME.json").read_bytes()
    need(len(raw) <= 65536, "runtime binding size")
    row = json.loads(raw)
    need(row["schema"] == 1 and row["status"] == "READY_FOR_ONE_FUNCTIONAL_ATTEMPT" and row["purpose"] == "HMIX_PUBLISHED31_FUNCTIONAL", "runtime not ready")
    need(re.fullmatch("[0-9a-f]{32}", row["nonce"]), "runtime nonce")
    need(set(row["source_hashes"]) == {"host.py", "decode.py", "init.sh", "build_guest.py", "QUALIFICATION.json"}, "closed source input set")
    for path, expected_sha in DEPENDENCIES.items():
        need(digest(path, 256 * 1024) == expected_sha, "accepted dependency changed")
    for name, sha in row["source_hashes"].items():
        need(digest(HERE / name, 128 * 1024) == sha, "runtime source changed")
    need(digest(row["archive"]["path"], 160 * 1024**2) == row["archive"]["sha256"] and Path(row["archive"]["path"]).stat().st_size == row["archive"]["bytes"], "runtime archive changed")
    need(digest(row["assembly_result"]["path"], 2 * 1024**2) == row["assembly_result"]["sha256"], "assembly receipt changed")
    receipt = json.loads(Path(row["assembly_result"]["path"]).read_bytes())
    need(receipt["nonce"] == row["nonce"] and receipt["purpose"] == row["purpose"] and receipt["archive_sha256"] == row["archive"]["sha256"] and receipt["ELF_or_VM_executed"] is False, "assembly receipt binding")
    qualification()
    return row, hashlib.sha256(raw).hexdigest()


def stage_and_run(host, engine, nonce, ids, deadline, runtime):
    proof = qualification()
    endpoint = host.strict_json(engine.command(["context", "inspect", "--format", "{{json .Endpoints.docker.Host}}", "desktop-linux"], deadline))
    need(endpoint == host.ENDPOINT, "Docker endpoint differs")
    image = host.strict_json(engine.command(["image", "inspect", IMAGE], deadline))
    need(len(image) == 1, "one qualified QEMU image")
    qualified_image(image[0], proof)
    target = "/s6-preparation/initramfs.cpio.gz"
    source = WORK / "hmix.cpio.gz"
    with Path(runtime["archive"]["path"]).open("rb") as stream, source.open("xb") as out:
        shutil.copyfileobj(stream, out)
    source.chmod(0o444)
    need(digest(source, 160 * 1024**2) == runtime["archive"]["sha256"], "staged archive changed")
    args = probe_profile.create_args(nonce, IMAGE)
    args.insert(args.index("--entrypoint=" + probe_profile.QEMU), f"--mount=type=bind,src={source},dst=/hmix.cpio.gz,readonly")
    args[args.index(target)] = "/hmix.cpio.gz"
    ident = engine.command(args, deadline, mutation=True).decode().strip()
    need(re.fullmatch("[0-9a-f]{64}", ident), "runtime container ID")
    ids.append(ident)
    meta = engine.inspect(ident, deadline)
    (mount,) = meta["Mounts"]
    need((mount["Type"], mount["Source"], mount["Destination"], mount["RW"], mount["Propagation"]) == ("bind", str(source), "/hmix.cpio.gz", False, "rprivate"), "own readonly input mount changed")
    checked = dict(meta, Mounts=[])
    checked["Config"] = dict(meta["Config"], Cmd=[target if item == "/hmix.cpio.gz" else item for item in meta["Config"]["Cmd"]])
    probe_profile.check_created(checked, ident, nonce, IMAGE)
    engine.command(["start", ident], deadline, mutation=True)
    exit_code = engine.command(["wait", ident], deadline).strip()
    state = engine.inspect(ident, deadline)["State"]
    console = engine.command(["logs", ident], deadline)
    need(len(console) <= 1024**2, "full console bound")
    with (WORK / "console.log").open("xb") as out:
        out.write(console)
    need(exit_code == b"0" and state["Status"] == "exited" and state["Running"] is False and state["ExitCode"] == 0 and state["OOMKilled"] is False, "guest stop/OOM/incomplete")
    result = verify_console(console)
    need(digest(source, 160 * 1024**2) == runtime["archive"]["sha256"], "runtime input changed")
    result.update(console_sha256=hashlib.sha256(console).hexdigest(), console_bytes=len(console), guest_normal_poweroff=True)
    return result


def main():
    global WORK
    runtime, runtime_sha = inputs()
    WORK = Path("/private/tmp") / (NAME + "-" + runtime["nonce"])
    origin = time.monotonic()
    os.umask(0o077)
    host = shared.load_host()
    need(hashlib.sha256(host.WRAPPER.read_bytes()).hexdigest() == shared.WRAPPER_SHA, "heavy-run wrapper differs")
    need(os.getpid() == os.getpgrp() and (os.getuid(), os.getgid()) == (501, 20), "unexpected process owner")
    while True:
        owner = dict(line.split("=", 1) for line in host.read_owned(host.LOCK / "owner", 8192).decode().splitlines()
                     if "=" in line)
        need(owner.get("name") == NAME and time.monotonic() < origin + 3, "incorrect heavy-lock")
        if owner.get("pgid") == str(os.getpgrp()):
            break
        time.sleep(.05)
    need(shutil.disk_usage(WORK.parent).free >= 15 * 1024**3, "insufficient free space")
    WORK.mkdir(mode=0o700)
    stopping = False

    def stop(_signal, _frame):
        nonlocal stopping
        stopping = True

    class BoundedEngine(host.Engine):
        cleaning = False

        def pump_until(self, predicate, deadline):
            super().pump_until(lambda: predicate() or (stopping and not self.cleaning), deadline)
            need(not stopping or self.cleaning, "work aborted")

    signal.signal(signal.SIGTERM, stop)
    signal.signal(signal.SIGINT, stop)
    engine = BoundedEngine()
    engine.root = WORK
    nonce, ids = runtime["nonce"], []
    result = {"status": "INCOMPLETE", "nonce": nonce, "purpose": runtime["purpose"], "runtime_sha256": runtime_sha, "metrics": "NOT_MEASURED", "images_created_or_removed": False}
    try:
        result.update(stage_and_run(host, engine, nonce, ids, origin + 180, runtime))
        _, after_runtime_sha = inputs()
        need(after_runtime_sha == runtime_sha, "runtime binding changed")
        need(not stopping and time.monotonic() < origin + 180, "work deadline")
        result["status"] = "PUBLISHED31_OFF_VS_PRIVATE_R_FUNCTIONAL_PASS"
    except Exception as error:
        result["failure_type"] = type(error).__name__
        result["failure"] = str(error)[:256]
    finally:
        engine.cleaning = True
        try:
            closed = host.cleanup(engine, nonce, ids, [], origin + 210)
        except Exception:
            closed = False
        result["closure"] = "KNOWN" if closed else "UNKNOWN"
        if not closed:
            result["status"] = "RECOVERY_REQUIRED"
        elif stopping or engine.output_failed:
            result["status"] = "INCOMPLETE"
        try:
            engine.put("commands.json", engine.commands)
            engine.put("result.json", result)
        finally:
            while not closed:
                time.sleep(30)
            engine.selector.close()
    return 0 if result["status"] == "PUBLISHED31_OFF_VS_PRIVATE_R_FUNCTIONAL_PASS" else 2


if __name__ == "__main__":
    sys.exit(main())
