"""Replay only this fixed functional test's complete guest transcript."""
import re
import base64
import hashlib

TEST = "TestOwnedFindNodePublished31GuestDelivery"
CASES = ("Off_control", "private_Responder_with_held_F1")
OLD_SHA = "06e26f9b30594d19fb7da9782921f3ef2e7d297da3441d521a8e2c6343d2fade"


def verify_console(raw):
    assert len(raw) <= 1024**2 and b"\0" not in raw
    text = raw.decode("utf-8")
    lines = text.splitlines()
    assert lines.count("HMIX_GUEST_READY x86_64 lo-only root0755 uid501 gid20") == 1
    assert [line for line in lines if line.startswith("HMIX_GUEST_END ")] == ["HMIX_GUEST_END 0"]
    assert not any(line.lstrip().startswith(("--- FAIL:", "--- SKIP:", "panic:", "fatal error:")) for line in lines)
    assert sum(line == "PASS" for line in lines) == 1
    runs = [line.removeprefix("=== RUN   ") for line in lines if line.startswith("=== RUN   ")]
    expected = [TEST, *(TEST + "/" + case for case in CASES)]
    assert runs == expected
    passes = []
    for line in lines:
        match = re.fullmatch(r"\s*--- PASS: ([^ ]+) \([0-9.]+s\)", line)
        if match:
            passes.append(match[1])
    assert len(passes) == 3 and set(passes) == set(expected)
    for case in CASES:
        ready = f"HMIX_OLD_READY case={case} sha256={OLD_SHA} protocol=31 f1=false cached_route=true keys=true"
        complete = f"HMIX_CASE_COMPLETE case={case} delivered=true seen=true seen_ack=true old_normal_exit=0 old_group_absent=true"
        assert text.count(ready) == text.count(complete) == 1
        assert text.index(ready) < text.index(complete)
    logs = {}
    total = 0
    for line in lines:
        if "HMIX_OLD_RAW " not in line:
            continue
        match = re.search(r"HMIX_OLD_RAW case=(Off_control|private_Responder_with_held_F1) name=([A-Za-z0-9_.-]+) sha256=([0-9a-f]{64}) bytes=([0-9]+) payload=([A-Za-z0-9+/=]*)$", line)
        assert match is not None
        case, name, sha, size, encoded = match.groups()
        assert name in {"stdout.log", "corsa.log", "stderr.log"} or re.fullmatch(r"crash-[A-Za-z0-9_.-]+[.]log", name)
        key = case + "/" + name
        assert key not in logs and len(logs) < 32
        body = base64.b64decode(encoded, validate=True)
        assert len(body) == int(size) <= 128 * 1024 and hashlib.sha256(body).hexdigest() == sha
        total += len(body)
        assert total <= 256 * 1024
        logs[key] = {"bytes": len(body), "sha256": sha}
    assert all(case + "/stdout.log" in logs for case in CASES)
    held = "HMIX_HELD_DELIVERY pending=1 decrypted=true signed_return=true original_members=true"
    assert text.count(held) == 1
    assert text.index("HMIX_OLD_READY case=" + CASES[1]) < text.index(held) < text.index("HMIX_CASE_COMPLETE case=" + CASES[1])
    assert text.index("HMIX_CASE_COMPLETE case=" + CASES[0]) < text.index("HMIX_OLD_READY case=" + CASES[1])
    return {"status": "PUBLISHED31_OFF_VS_PRIVATE_R_FUNCTIONAL_PASS", "outer": 1, "child": 2,
            "old_published_sha256": OLD_SHA, "dial_direction": "old_to_current", "DM_direction": "current_to_old",
            "held_FIND_NODE_delivery_decrypted": True, "same_original_F1_members": True, "signed_return": True,
            "receipt_lifecycle_after_FN_return": True, "old_normal_exit_each_case": 0, "full_old_log_members": logs,
            "scope": "FUNCTIONAL_ONLY_NOT_13B_512MB_K11_D1_G2_OR_RELEASE"}
