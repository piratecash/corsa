import copy,hashlib,json,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
import host as h

class RebindTests(unittest.TestCase):
 def test_original_guest_source_and_workload_are_unchanged(self):
  old=h.HERE.parent/'d1-hmix-published31-linux-guest-source-v1'
  for n in ('decode.py','init.sh','build_guest.py'):self.assertEqual((old/n).read_bytes(),(h.HERE/n).read_bytes())
  runtime=json.loads((h.HERE/'RUNTIME.PREPARED.json').read_bytes())
  self.assertEqual(runtime['nonce'],'3abb1637f9541f5751438c0501c9406e')
  self.assertEqual(runtime['archive']['sha256'],'fa517d63ab521537853a292be2e721fc0c3f3e64ea0f249b34832b2651423e00')
  self.assertNotEqual(runtime['status'],'READY_FOR_ONE_FUNCTIONAL_ATTEMPT')
 def test_exact_qualified_image_and_metadata_refusals(self):
  proof=h.qualification();image=copy.deepcopy(proof['image_immutable']);h.qualified_image(image,proof)
  for edit in (lambda r:r.update(Id='sha256:'+'0'*64),lambda r:r['Config'].update(Entrypoint=['/foreign']),lambda r:r['RootFS']['Layers'].append('sha256:'+'0'*64)):
   bad=copy.deepcopy(image);edit(bad)
   with self.assertRaises(ValueError):h.qualified_image(bad,proof)
 def test_failed_unknown_or_unpaired_qualification_cannot_authorize(self):
  original=json.loads((h.HERE/'QUALIFICATION.json').read_bytes())
  for edit in (lambda r:r.update(unknown=True),lambda r:r.update(owned_container_removed=False),lambda r:r.update(status='STOP'),lambda r:r.update(handoff_sha256='0'*64)):
   with tempfile.TemporaryDirectory(dir='/private/tmp') as directory:
    root=Path(directory);proof=copy.deepcopy(original)
    for key in ('result','ready_handoff','frozen_source','console'):
     raw=Path(proof[key]['path']).read_bytes()
     if key=='result':
      result=json.loads(raw);edit(result);raw=json.dumps(result).encode()
     target=root/key;target.write_bytes(raw);proof[key]={'path':str(target),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
    # Keep successful original handoff pairing for non-pairing mutations.
    if 'handoff_sha256' not in json.loads((root/'result').read_bytes()):raise AssertionError('fixture')
    raw=json.dumps(proof).encode();(root/'QUALIFICATION.json').write_bytes(raw)
    with patch.object(h,'HERE',root),patch.object(h,'QUALIFICATION_SHA',hashlib.sha256(raw).hexdigest()):
     with self.assertRaises(ValueError):h.qualification()
if __name__=='__main__':unittest.main()
