#!/bin/busybox sh
set -eu
bb=/usr/bin/busybox
finish() {
    printf 'HMIX_GUEST_END %s\n' "$1"
    "$bb" poweroff -f
    exit 1
}
"$bb" chmod 0755 / || finish root-mode
[ "$("$bb" stat -c '%u:%g:%a' /)" = '0:0:755' ] || finish root-mode-readback
"$bb" mount -t proc -o nosuid,nodev,noexec proc /proc || finish proc
[ "$("$bb" uname -m)" = x86_64 ] || finish arch
interfaces=$("$bb" awk 'NR > 2 { sub(/:.*/, ""); gsub(/[ \t]/, ""); print }' /proc/net/dev)
[ "$interfaces" = lo ] || finish interfaces
"$bb" ip link set dev lo up || finish loopback
[ "$("$bb" stat -c '%u:%g:%a' /work)" = '501:20:700' ] || finish work-owner
# The same cached glibc/loader closure that ran published06e26 in S6.
/lib64/ld-linux-x86-64.so.2 --version || finish loader
printf 'HMIX_GUEST_READY x86_64 lo-only root0755 uid501 gid20\n'
set +e
"$bb" timeout -s TERM -k 10 120 "$bb" su -s /bin/sh -c 'exec /usr/bin/busybox env -i PATH=/usr/bin:/bin HOME=/work TMPDIR=/work/tmp GOMAXPROCS=1 GOMEMLIMIT=512MiB /inputs/node.test -test.v -test.run=^TestOwnedFindNodePublished31GuestDelivery$ -test.timeout=90s -test.parallel=1' s6baseline
result=$?
set -e
finish "$result"
