import gzip
import hashlib
from pathlib import Path
import stat
import struct
import tempfile
import unittest

import build_guest as b
import decode as d


def console():
    lines = ["HMIX_GUEST_READY x86_64 lo-only root0755 uid501 gid20", "=== RUN   " + d.TEST]
    empty = hashlib.sha256(b"").hexdigest()
    for case in d.CASES:
        lines += ["=== RUN   " + d.TEST + "/" + case,
                  f"    a.go:1: HMIX_OLD_READY case={case} sha256={d.OLD_SHA} protocol=31 f1=false cached_route=true keys=true"]
        if case == d.CASES[1]:
            lines.append("    a.go:1: HMIX_HELD_DELIVERY pending=1 decrypted=true signed_return=true original_members=true")
        lines += [f"    a.go:1: HMIX_OLD_RAW case={case} name=stdout.log sha256={empty} bytes=0 payload=",
                  f"    a.go:1: HMIX_CASE_COMPLETE case={case} delivered=true seen=true seen_ack=true old_normal_exit=0 old_group_absent=true",
                  "--- PASS: " + d.TEST + "/" + case + " (0.01s)"]
    lines += ["--- PASS: " + d.TEST + " (0.02s)", "PASS", "HMIX_GUEST_END 0"]
    return ("\n".join(lines) + "\n").encode()


class HarnessTests(unittest.TestCase):
    def test_complete_replay_and_exact_negative_controls(self):
        raw = console()
        result = d.verify_console(raw)
        self.assertEqual((result["outer"], result["child"]), (1, 2))
        for name, changed in {
            "guest-failure": raw.replace(b"HMIX_GUEST_END 0", b"HMIX_GUEST_END 1"),
            "duplicate-end": raw + b"HMIX_GUEST_END 0\n",
            "missing-case": raw.replace(b"=== RUN   " + d.TEST.encode() + b"/Off_control\n", b""),
            "skip": raw.replace(b"--- PASS:", b"--- SKIP:", 1),
            "failed": raw.replace(b"--- PASS:", b"--- FAIL:", 1),
            "wrong-old": raw.replace(d.OLD_SHA.encode(), b"0" * 64),
            "false-held": raw.replace(b"pending=1 decrypted=true", b"pending=0 decrypted=true"),
            "bad-raw-hash": raw.replace(hashlib.sha256(b"").hexdigest().encode(), b"0" * 64, 1),
            "raw-size-lie": raw.replace(b"bytes=0 payload=", b"bytes=1 payload=", 1),
            "foreign-raw-name": raw.replace(b"name=stdout.log", b"name=identity.json", 1),
        }.items():
            with self.subTest(name=name), self.assertRaises((AssertionError, ValueError)):
                d.verify_console(changed)

    def test_actual_file_reads_do_not_false_fail_on_atime(self):
        with tempfile.TemporaryDirectory(dir="/private/tmp") as directory:
            path = Path(directory) / "input"
            path.write_bytes(b"public frozen input")
            expected = b.digest(path.read_bytes())
            self.assertEqual(b.exact(path, expected, 64), path.read_bytes())
            self.assertEqual(b.exact(path, expected, 64), path.read_bytes())
            link = Path(directory) / "link"
            link.symlink_to(path)
            with self.assertRaises(AssertionError):
                b.exact(link, expected, 64)
            with self.assertRaises(AssertionError):
                b.exact(path, "0" * 64, 64)
            with self.assertRaises(AssertionError):
                b.exact(path, expected, 2)

    def test_static_amd64_header_controls(self):
        raw = bytearray(120)
        raw[:7] = b"\x7fELF\x02\x01\x01"
        struct.pack_into("<HHIQQQIHHHHHH", raw, 16, 2, 62, 1, 0, 64, 0, 0, 64, 56, 1, 0, 0, 0)
        struct.pack_into("<IIQQQQQQ", raw, 64, 1, 5, 0, 0, 0, 120, 120, 4096)
        b.static_test(raw)
        for name, offset, fmt, value in (("wrong-machine", 18, "<H", 183), ("interpreter", 64, "<I", 3),
                                          ("dynamic", 64, "<I", 2), ("overrun", 96, "<Q", 121)):
            with self.subTest(name=name), self.assertRaises(AssertionError):
                changed = bytearray(raw)
                struct.pack_into(fmt, changed, offset, value)
                b.static_test(changed)

    def test_exact_tiny_cpio_readback_rejects_truncation(self):
        rows = [("work", stat.S_IFDIR | 0o700, b"", 501, 20, (0, 0)),
                ("dev/null", stat.S_IFCHR | 0o666, b"", 0, 0, (1, 3)),
                ("init", stat.S_IFREG | 0o755, b"source-only fixture", 0, 0, (0, 0))]
        with tempfile.TemporaryDirectory(dir="/private/tmp") as directory:
            path = Path(directory) / "tiny.gz"
            with gzip.open(path, "wb") as stream:
                for i, row in enumerate(rows, 1):
                    b.emit(stream, row, i)
                b.emit(stream, ("TRAILER!!!", 0, b"", 0, 0, (0, 0)), len(rows) + 1)
            b.verify(path, rows)
            with self.assertRaises(AssertionError):
                b.verify(path, [rows[0], (*rows[1][:5], (1, 9)), rows[2]])
            path.write_bytes(path.read_bytes()[:-8])
            with self.assertRaises((AssertionError, EOFError)):
                b.verify(path, rows)


if __name__ == "__main__":
    unittest.main()
