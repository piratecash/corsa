"""Data-only minimal guest from the exact cached S6 runtime; never executes ELF."""
from pathlib import Path
import gzip
import hashlib
import json
import re
import stat
import struct

HERE = Path(__file__).resolve().parent
BASE = HERE.parent.parent / "2026-11-13/s6-amd64-lo-only-guest-v2/restart/restart-verified.cpio.gz"
BASE_SHA = "9d4a8a309beebc371932a4bd5203d7ec99decdd941d927e87dea0e19497e4a06"
OLD_SHA = "06e26f9b30594d19fb7da9782921f3ef2e7d297da3441d521a8e2c6343d2fade"
TOTAL = 160 * 1024**2
NORMAL_FILE = 32 * 1024**2
TEST_FILE = 96 * 1024**2
CLOSURE = {
    "bin": (stat.S_IFLNK | 0o777, "51eb85985e2f36e92fb2e18d663412b7bb94839f546901884eda4936683d9481"),
    "lib": (stat.S_IFLNK | 0o777, "bb40df61b3e0947109adb2e4d4ec41261d2c50580463391f34d67b5f30712176"),
    "lib64": (stat.S_IFLNK | 0o777, "1a8dcebf89cf73748aa1a3c88dd1ecc2a040ffabb45a10d9231a642e1a89913b"),
    "usr/lib64/ld-linux-x86-64.so.2": (stat.S_IFLNK | 0o777, "1195439cc03527ea587ac03c5db33a8ed61d81a07be3061aad52ea03b5c7c5d4"),
    "usr/bin/busybox": (stat.S_IFREG | 0o755, "7ae95c260622412ceba6eb9f45d68f616cdc091a1d71d6c0a08b5875bb2c31dd"),
    "usr/lib/x86_64-linux-gnu/ld-linux-x86-64.so.2": (stat.S_IFREG | 0o755, "02bcda52c1a5dfc236f94d9e5255b4a0e26347d8a372a5223b650e31f291ce3c"),
    "usr/lib/x86_64-linux-gnu/libc.so.6": (stat.S_IFREG | 0o755, "6b4a45352fd0c540a9c7c718f35ce8c8e46a4e482f9d3885a910c32d1a0e1421"),
    "inputs/corsa-node": (stat.S_IFREG | 0o555, OLD_SHA),
}


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def exact(path, expected, limit):
    path = Path(path)
    before = path.lstat()
    assert stat.S_ISREG(before.st_mode) and before.st_nlink == 1 and 0 < before.st_size <= limit
    with path.open("rb") as stream:
        raw = stream.read(before.st_size + 1)
    after = path.lstat()
    fields = ("st_dev", "st_ino", "st_uid", "st_gid", "st_mode", "st_nlink", "st_size", "st_mtime_ns", "st_ctime_ns")
    assert tuple(getattr(before, f) for f in fields) == tuple(getattr(after, f) for f in fields)
    assert len(raw) == before.st_size and digest(raw) == expected
    return raw


def read(stream, size):
    raw = stream.read(size)
    assert len(raw) == size, "truncated cpio"
    return raw


def runtime_closure():
    # Whole original archive digest first; selected payload/header readback next.
    exact(BASE, BASE_SHA, NORMAL_FILE * 2)
    selected, names, count, total = {}, set(), 0, 0
    with gzip.open(BASE, "rb") as stream:
        while True:
            header = read(stream, 110)
            assert header[:6] == b"070701"
            values = [int(header[6 + 8 * i:14 + 8 * i], 16) for i in range(13)]
            mode, uid, gid, size, namesize = values[1], values[2], values[3], values[6], values[11]
            assert 1 < namesize <= 4096 and 0 <= size <= NORMAL_FILE
            name = read(stream, namesize)
            assert name.endswith(b"\0") and b"\0" not in name[:-1]
            name = name[:-1].decode("utf-8")
            assert read(stream, (-110 - namesize) % 4).strip(b"\0") == b""
            if name == "TRAILER!!!":
                tail = stream.read(513)
                assert size == 0 and len(tail) <= 512 and tail.strip(b"\0") == b"" and stream.read(1) == b""
                break
            assert name not in names
            names.add(name)
            count += 1
            total += size
            assert count <= 8192 and total <= TOTAL
            raw = read(stream, size)
            assert read(stream, (-size) % 4).strip(b"\0") == b""
            if name in CLOSURE:
                expected_mode, expected_sha = CLOSURE[name]
                assert (mode, uid, gid) == (expected_mode, 0, 0) and digest(raw) == expected_sha
                selected[name] = (mode, raw)
    assert selected.keys() == CLOSURE.keys()
    return selected


def static_test(raw):
    assert 64 <= len(raw) <= TEST_FILE and raw[:7] == b"\x7fELF\x02\x01\x01"
    kind, machine, version, _, offset, _, _, size, entsize, count, _, _, _ = struct.unpack_from("<HHIQQQIHHHHHH", raw, 16)
    assert kind in (2, 3) and machine == 62 and version == 1 and size == 64
    assert entsize == 56 and 0 < count <= 128 and 64 <= offset and offset + 56 * count <= len(raw)
    for i in range(count):
        segment, _, start, _, _, length, _, _ = struct.unpack_from("<IIQQQQQQ", raw, offset + 56 * i)
        assert segment not in (2, 3) and start <= len(raw) and length <= len(raw) - start


def header(name, ino, mode, size, uid=0, gid=0, device=(0, 0)):
    values = (ino, mode, uid, gid, 2 if stat.S_ISDIR(mode) else 1, 0, size, 0, 0, *device, len(name.encode("ascii")) + 1, 0)
    return ("070701" + "".join(f"{value:08x}" for value in values)).encode("ascii")


def emit(stream, row, ino):
    name, mode, raw, uid, gid, device = row
    encoded = name.encode("ascii") + b"\0"
    stream.write(header(name, ino, mode, len(raw), uid, gid, device))
    stream.write(encoded)
    stream.write(b"\0" * ((-110 - len(encoded)) % 4))
    stream.write(raw)
    stream.write(b"\0" * (-len(raw) % 4))


def verify(path, rows):
    with gzip.open(path, "rb") as stream:
        for ino, row in enumerate([*rows, ("TRAILER!!!", 0, b"", 0, 0, (0, 0))], 1):
            name, mode, raw, uid, gid, device = row
            assert read(stream, 110) == header(name, ino, mode, len(raw), uid, gid, device)
            encoded = name.encode("ascii") + b"\0"
            assert read(stream, len(encoded)) == encoded
            assert read(stream, (-110 - len(encoded)) % 4).strip(b"\0") == b""
            assert read(stream, len(raw)) == raw
            assert read(stream, -len(raw) % 4).strip(b"\0") == b""
        assert stream.read(1) == b""


def assemble(binding, output):
    assert binding["schema"] == 1 and binding["status"] == "ACTUAL_TEST_ELF_METADATA_ACCEPTED" and binding["purpose"] == "HMIX_PUBLISHED31_FUNCTIONAL"
    assert re.fullmatch("[0-9a-f]{32}", binding["nonce"])
    test = exact(binding["test"]["path"], binding["test"]["sha256"], TEST_FILE)
    assert len(test) == binding["test"]["bytes"]
    static_test(test)
    exact(binding["test_build_result"]["path"], binding["test_build_result"]["sha256"], 1 << 20)
    files = runtime_closure()
    files["init"] = (stat.S_IFREG | 0o755, exact(HERE / "init.sh", binding["init_sha256"], 65536))
    files["usr/bin/sh"] = (stat.S_IFLNK | 0o777, b"busybox")
    files["inputs/node.test"] = (stat.S_IFREG | 0o555, test)
    descriptor = {"schema": 1, "purpose": binding["purpose"], "nonce": binding["nonce"], "test_sha256": digest(test), "published_sha256": OLD_SHA}
    files["inputs/hmix-guest.json"] = (stat.S_IFREG | 0o444, (json.dumps(descriptor, sort_keys=True) + "\n").encode())
    files["etc/passwd"] = (stat.S_IFREG | 0o644, b"root:x:0:0:root:/:/bin/sh\ns6baseline:x:501:20:Baseline:/work:/bin/sh\n")
    files["etc/group"] = (stat.S_IFREG | 0o644, b"root:x:0:\ns6baseline:x:20:\n")
    assert sum(len(raw) for _, raw in files.values()) <= TOTAL
    assert all(len(raw) <= (TEST_FILE if name == "inputs/node.test" else NORMAL_FILE) for name, (_, raw) in files.items())
    directories = {"dev", "proc", "sys", "tmp", "work", "work/tmp", "etc", "inputs", "usr", "usr/bin", "usr/lib", "usr/lib64", "usr/lib/x86_64-linux-gnu"}
    rows = []
    for name in sorted(directories, key=lambda name: (name.count("/"), name)):
        mode = 0o1777 if name == "tmp" else 0o700 if name.startswith("work") else 0o755
        owner = (501, 20) if name.startswith("work") else (0, 0)
        rows.append((name, stat.S_IFDIR | mode, b"", *owner, (0, 0)))
    rows += [(name, mode, raw, 0, 0, (0, 0)) for name, (mode, raw) in sorted(files.items())]
    rows += [(name, stat.S_IFCHR | mode, b"", 0, 0, device) for name, mode, device in (("dev/console", 0o600, (5, 1)), ("dev/null", 0o666, (1, 3)), ("dev/urandom", 0o666, (1, 9)))]
    assert len({row[0] for row in rows}) == len(rows)
    with Path(output).open("xb") as stream:
        with gzip.GzipFile(filename="", mode="wb", fileobj=stream, mtime=0) as compressed:
            for ino, row in enumerate(rows, 1):
                emit(compressed, row, ino)
            emit(compressed, ("TRAILER!!!", 0, b"", 0, 0, (0, 0)), len(rows) + 1)
    verify(output, rows)
    return {"purpose": binding["purpose"], "nonce": binding["nonce"], "archive": str(output), "archive_sha256": digest(Path(output).read_bytes()), "archive_bytes": Path(output).stat().st_size,
            "members": {name: {"mode": oct(mode), "uid": uid, "gid": gid, "device": list(device), "bytes": len(raw), "sha256": digest(raw)} for name, mode, raw, uid, gid, device in rows}, "ELF_or_VM_executed": False}
