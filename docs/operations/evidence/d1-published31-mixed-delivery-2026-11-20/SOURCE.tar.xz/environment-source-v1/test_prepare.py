"""Bounded pure parser/custody controls; no network, APK, Go, Docker or VM."""
import hashlib
import io
from pathlib import Path
import tarfile
import tempfile
from unittest.mock import patch
import prepare
import stage
import host
import copy


def refused(call):
    try:
        call()
    except (ValueError, AssertionError, KeyError):
        return
    raise AssertionError('refusal missing')


def test_fixed_origin_redirect_refusal():
    refused(lambda: prepare.FixedOrigin().redirect_request(None, None, 302, '', {}, 'https://foreign.invalid'))


def test_index_parser_finite_package_identity():
    with tempfile.TemporaryDirectory() as d:
        path = Path(d)/'index.tar.gz'
        def make(raw):
            with tarfile.open(path, 'w:gz') as t:
                info = tarfile.TarInfo('APKINDEX'); info.size = len(raw); t.addfile(info, io.BytesIO(raw))
        make(b'P:qemu-system-x86_64\nV:1-r0\nA:aarch64\nC:Q1example\nS:123\n\n')
        assert prepare.parse_index(path)['qemu-system-x86_64', '1-r0']['A'] == 'aarch64'
        make(b'P:a\nP:b\nV:1-r0\n\n'); refused(lambda: prepare.parse_index(path))


def test_package_urls_exact_repository_and_index():
    row = {'P': 'qemu-system-x86_64', 'V': '1-r0', 'A': 'aarch64'}
    indexes = {'main': {}, 'community': {('qemu-system-x86_64','1-r0'): row}}
    repos = {'main': 'file:///own/main/aarch64', 'community': 'file:///own/community/aarch64'}
    for prefix in ('file:///own/community/aarch64', '/own/community/aarch64'):
        assert prepare.package_urls((prefix+'/qemu-system-x86_64-1-r0.apk\n').encode(), repos, indexes)[0][2] == row
    for raw in (b'https://foreign/qemu-system-x86_64-1-r0.apk\n', b'file:///own/community/aarch64/../escape.apk\n',
                b'file:///own/community/aarch64/unknown-1-r0.apk\n', b''):
        refused(lambda: prepare.package_urls(raw, repos, indexes))


def test_kernel_ar_exact_selected_payloads():
    payloads = {'boot/test-kernel': b'kernel', 'boot/test-config': b'config'}
    out = io.BytesIO()
    with tarfile.open(fileobj=out, mode='w:xz') as t:
        for name, raw in payloads.items():
            info = tarfile.TarInfo(name); info.size = len(raw); t.addfile(info, io.BytesIO(raw))
    data = out.getvalue()
    header = ('data.tar.xz/'.ljust(16)+'0'.ljust(12)+'0'.ljust(6)+'0'.ljust(6)+'100644'.ljust(8)+str(len(data)).ljust(10)+'`\n').encode()
    raw = b'!<arch>\n'+header+data+(b'\n' if len(data)%2 else b'')
    pins = {name: ('vmlinuz' if name.endswith('kernel') else 'kernel.config', hashlib.sha256(value).hexdigest())
            for name, value in payloads.items()}
    with patch.object(prepare, 'KERNEL_MEMBERS', pins):
        assert prepare.kernel_data(raw) == {'vmlinuz': b'kernel', 'kernel.config': b'config'}
        refused(lambda: prepare.kernel_data(raw[:-11]))
        wrong = dict(pins); wrong['boot/test-kernel'] = ('vmlinuz', '0'*64)
        with patch.object(prepare, 'KERNEL_MEMBERS', wrong):
            refused(lambda: prepare.kernel_data(raw))


def test_staging_custody_read_and_symlink_refusal():
    with tempfile.TemporaryDirectory() as d:
        p = Path(d)/'data'; p.write_bytes(b'public'); digest = hashlib.sha256(b'public').hexdigest()
        assert stage.exact(p, digest, 6) == stage.exact(p, digest, 6) == b'public'
        refused(lambda: stage.exact(p, '0'*64, 6)); refused(lambda: stage.exact(p, digest, 5))
        q = Path(d)/'link'; q.symlink_to(p); refused(lambda: stage.exact(q, digest, 6))


def test_fixed_release_and_kernel_selector():
    assert prepare.SELECTOR == 'qemu-system-x86_64'
    assert prepare.KERNEL_PATH == 'pool/updates/main/l/linux-signed-amd64/linux-image-6.12.117+deb13-amd64_6.12.117-1_amd64.deb'
    assert prepare.KERNEL_SHA == 'ca712d36790184f6ac125ce2b20ea4e2202ae6bb7817b7de268f1f0115ccda73'
    assert prepare.KEY_SHA == stage.KEY_SHA


def test_actual_profile_inspect_and_negative_controls():
    row = {'Id': 'a'*64, 'Image': host.BASE, 'Name': '/d1-hmix-environment-'+'b'*32,
           'Mounts': [], 'Config': {'Labels': {host.LABEL: 'b'*32}, 'User': '0:0',
               'Entrypoint': ['/usr/bin/python3'], 'Cmd': ['/tmp/hmix-input/prepare.py'], 'WorkingDir': '/',
               'Env': ['PATH=/usr/sbin:/usr/bin:/sbin:/bin', 'LC_ALL=C', 'HOME=/root']},
           'HostConfig': {'NanoCpus': 1000000000, 'Memory': host.GIB, 'MemorySwap': host.GIB,
               'PidsLimit': 128, 'NetworkMode': 'bridge', 'ReadonlyRootfs': False, 'Privileged': False,
               'CgroupnsMode': 'private', 'IpcMode': 'private', 'RestartPolicy': {'Name': 'no'},
               'CapDrop': ['ALL'], 'CapAdd': sorted(host.CAPS), 'SecurityOpt': ['no-new-privileges'],
               'LogConfig': {'Type': 'local', 'Config': {'max-size': '1m', 'max-file': '1'}}}}
    assert host.inspect_row(row, 'a'*64, 'b'*32) is row
    for group, key, value in [('HostConfig','MemorySwap',2*host.GIB), ('HostConfig','CapAdd',sorted(host.CAPS|{'SYS_ADMIN'})),
                              ('HostConfig','Binds',['/foreign:/foreign']), ('HostConfig','NetworkMode','host'),
                              ('HostConfig','Privileged',True), ('HostConfig','PidMode','host'),
                              ('Config','Cmd',['/foreign.py']), ('Config','Env',['HTTP_PROXY=http://foreign'])]:
        wrong = copy.deepcopy(row); wrong[group][key] = value
        refused(lambda: host.inspect_row(wrong, 'a'*64, 'b'*32))
    wrong = copy.deepcopy(row); wrong['Mounts'] = [{'Type': 'volume'}]
    refused(lambda: host.inspect_row(wrong, 'a'*64, 'b'*32))
    refused(lambda: host.inspect_row(row, 'c'*64, 'b'*32))
    refused(lambda: host.inspect_row(row, 'a'*64, 'd'*32))


if __name__ == '__main__':
    for name in sorted(globals()):
        if name.startswith('test_'):
            globals()[name]()
            print(name, 'PASS')
