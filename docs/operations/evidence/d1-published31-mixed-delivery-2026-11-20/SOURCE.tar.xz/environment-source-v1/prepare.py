"""Fixed official QEMU/kernel environment preparation; never starts a VM or Corsa."""
import hashlib
import io
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import tarfile
import time
import urllib.request

ROOT = Path('/s6-preparation')
INPUT = Path('/tmp/hmix-input')
KEY = 'alpine-devel@lists.alpinelinux.org-616ae350.rsa.pub'
KEY_SHA = 'd11f6b21c61b4274e182eb888883a8ba8acdbf820dcc7a6d82a7d9fc2fd2836d'
SELECTOR = 'qemu-system-x86_64'
KERNEL_PATH = 'pool/updates/main/l/linux-signed-amd64/linux-image-6.12.117+deb13-amd64_6.12.117-1_amd64.deb'
KERNEL_SHA = 'ca712d36790184f6ac125ce2b20ea4e2202ae6bb7817b7de268f1f0115ccda73'
KERNEL_MEMBERS = {
    'boot/vmlinuz-6.12.117+deb13-amd64': ('vmlinuz', '14159c607ad9762133db41e479dafecde1d6a5fe715a8d65d292a3262e4b6bed'),
    'boot/config-6.12.117+deb13-amd64': ('kernel.config', 'a3d4ca3e2a1b8cd86ed458b9fd8887e0420f58c05f32d4f32197edd82323c037'),
}
MIB = 1024**2
END = 0.0


def need(ok, reason):
    if not ok:
        raise ValueError(reason)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def save(path, value):
    with path.open('x', encoding='utf-8') as stream:
        json.dump(value, stream, sort_keys=True, indent=2)
        stream.write('\n')


class FixedOrigin(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, request, fp, code, message, headers, newurl):
        raise ValueError('redirect refused: fixed official origin only')


def fetch(url, path, limit, expected=None):
    need(time.monotonic() < END, 'preparation deadline')
    digest = hashlib.sha256()
    count = 0
    opener = urllib.request.build_opener(FixedOrigin())
    with opener.open(url, timeout=min(30, max(1, END-time.monotonic()))) as response, path.open('xb') as output:
        need(response.status == 200 and response.geturl() == url, 'fixed download response')
        while True:
            need(time.monotonic() < END, 'download deadline')
            block = response.read(65536)
            if not block:
                break
            count += len(block)
            need(count <= limit, 'download size')
            output.write(block)
            digest.update(block)
    need(count > 0 and (expected is None or digest.hexdigest() == expected), 'download checksum')
    return {'url': url, 'bytes': count, 'sha256': digest.hexdigest()}


def run(argv, label, timeout=120):
    remaining = END-time.monotonic()
    need(remaining > 0, 'command deadline')
    out = ROOT/'evidence'/f'{label}.stdout'
    err = ROOT/'evidence'/f'{label}.stderr'
    with out.open('xb') as stdout, err.open('xb') as stderr:
        result = subprocess.run(argv, stdin=subprocess.DEVNULL, stdout=stdout, stderr=stderr,
                                check=False, timeout=min(timeout, remaining), env={
                                    'PATH': '/usr/sbin:/usr/bin:/sbin:/bin', 'LC_ALL': 'C', 'HOME': '/root'})
    need(out.stat().st_size+err.stat().st_size <= MIB, 'command output bound')
    save(ROOT/'evidence'/f'{label}.json', {'argv': argv, 'exit': result.returncode,
         'stdout_sha256': sha(out.read_bytes()), 'stderr_sha256': sha(err.read_bytes())})
    need(result.returncode == 0, f'command failed: {label}')
    return out.read_bytes()


def phase_space(label):
    raw = run(['du', '-xsk', str(ROOT), '/usr', '/lib', '/etc', '/var/cache/apk'], 'space-'+label)
    rows = raw.decode('ascii').splitlines()
    need(len(rows) == 5 and sum(int(row.split()[0]) for row in rows) <= 4*1024**2,
         'four GiB phase bound')


def parse_index(path):
    with tarfile.open(path, 'r:gz') as archive:
        rows = archive.getmembers()
        need(len(rows) <= 4 and len({r.name for r in rows}) == len(rows), 'index members')
        matches = [r for r in rows if r.name == 'APKINDEX']
        need(len(matches) == 1 and matches[0].isfile() and 0 < matches[0].size <= 12*MIB, 'index payload')
        raw = archive.extractfile(matches[0]).read()
    result = {}
    for record in raw.decode('utf-8').split('\n\n'):
        fields = {}
        for line in record.splitlines():
            key, sep, value = line.partition(':')
            need(sep and key not in fields, 'index field')
            fields[key] = value
        if not fields:
            continue
        name, version = fields.get('P'), fields.get('V')
        need(name and version and (name, version) not in result, 'index package identity')
        result[name, version] = fields
    return result


def package_urls(raw, repositories, indexes):
    result = []
    seen = set()
    for value in raw.decode('ascii').splitlines():
        matches = [(branch, candidate) for branch, prefix in repositories.items()
                   for candidate in (prefix, prefix.removeprefix('file://'))
                   if value.startswith(candidate + '/')]
        need(len(matches) == 1, 'package repository')
        branch, prefix = matches[0]
        filename = value[len(prefix)+1:]
        need(re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9.+_-]*\.apk', filename) and filename not in seen,
             'package filename')
        candidates = [row for row in indexes[branch].values()
                      if row['P']+'-'+row['V']+'.apk' == filename]
        need(len(candidates) == 1 and candidates[0].get('A') in ('aarch64', 'noarch'), 'indexed package identity')
        row = candidates[0]
        seen.add(filename)
        result.append((branch, filename, row))
    need(0 < len(result) <= 128, 'closure count')
    return result


def kernel_data(raw):
    need(raw.startswith(b'!<arch>\n'), 'kernel deb ar magic')
    offset, compressed = 8, None
    while offset < len(raw):
        header = raw[offset:offset+60]
        need(len(header) == 60 and header[58:] == b'`\n', 'kernel ar header')
        size = int(header[48:58].decode('ascii').strip())
        name = header[:16].decode('ascii').strip().rstrip('/')
        offset += 60
        need(0 <= size <= len(raw)-offset, 'kernel ar size')
        if name.startswith('data.tar'):
            need(compressed is None and name in ('data.tar.xz', 'data.tar.gz', 'data.tar.zst'), 'kernel data member')
            compressed = raw[offset:offset+size]
        offset += size+(size%2)
    need(offset == len(raw) and compressed is not None, 'kernel ar completion')
    found, expanded = {}, 0
    with tarfile.open(fileobj=io.BytesIO(compressed), mode='r|*') as archive:
        for member in archive:
            expanded += member.size
            need(0 <= member.size <= 256*MIB and expanded <= 1024*MIB, 'kernel expanded bound')
            name = member.name.removeprefix('./')
            if name in KERNEL_MEMBERS:
                label, expected = KERNEL_MEMBERS[name]
                need(label not in found and member.isfile() and not member.issparse() and 0 < member.size <= 32*MIB,
                     'kernel selected member')
                payload = archive.extractfile(member).read()
                need(len(payload) == member.size and sha(payload) == expected, 'kernel member checksum')
                found[label] = payload
    need(set(found) == {'vmlinuz', 'kernel.config'}, 'kernel selected set')
    return found


def main():
    global END
    END = time.monotonic()+570
    os.umask(0o077)
    need(os.getuid() == 0 and os.uname().machine == 'aarch64', 'native preparation identity')
    ROOT.mkdir(mode=0o711)
    ROOT.chmod(0o711)
    (ROOT/'evidence').mkdir(mode=0o700)
    (ROOT/'extracted').mkdir(mode=0o711)
    (ROOT/'extracted').chmod(0o711)
    fs = os.statvfs('/')
    free = fs.f_bavail*fs.f_frsize
    need(free >= 5*1024**3, 'Docker backing filesystem reserve')
    save(ROOT/'evidence/docker-filesystem-before.json', {'f_bavail': fs.f_bavail,
         'f_frsize': fs.f_frsize, 'available_bytes': free, 'minimum_bytes': 5*1024**3,
         'scope': 'container root overlay backing filesystem, not a disk quota'})
    work = ROOT/'downloads'
    work.mkdir(mode=0o700)
    keys = work/'keys'
    keys.mkdir(mode=0o700)
    key = (INPUT/KEY).read_bytes()
    need(sha(key) == KEY_SHA and (Path('/etc/apk/keys')/KEY).read_bytes() == key, 'exact existing trust key')
    (keys/KEY).write_bytes(key)
    before = run(['apk', 'info', '-v'], '01-installed-before')
    phase_space('initial')
    downloads, prefixes, indexes = {}, {}, {}
    for branch in ('main', 'community'):
        directory = work/branch/'aarch64'
        directory.mkdir(parents=True, mode=0o700)
        downloads[branch] = fetch(f'https://dl-cdn.alpinelinux.org/alpine/v3.24/{branch}/aarch64/APKINDEX.tar.gz',
                                  directory/'APKINDEX.tar.gz', 4*MIB)
        prefixes[branch] = f'file://{directory}'
    repositories = work/'repositories'
    repositories.write_text(''.join('v2 '+prefix.rsplit('/', 1)[0]+'\n' for prefix in prefixes.values()))
    apk = ['apk', '--keys-dir', str(keys), '--repositories-file', str(repositories), '--no-network']
    # Authentication happens through apk's exact preexisting key BEFORE parsing selection.
    run([*apk, 'update'], '02-authenticate-indexes')
    for branch in prefixes:
        actual_index = (work/branch/'aarch64/APKINDEX.tar.gz').read_bytes()
        need(sha(actual_index) == downloads[branch]['sha256'], 'authenticated index changed')
        with (ROOT/'evidence'/f'APKINDEX-{branch}.tar.gz').open('xb') as output:
            output.write(actual_index)
        indexes[branch] = parse_index(work/branch/'aarch64/APKINDEX.tar.gz')
    with (ROOT/'evidence'/KEY).open('xb') as output:
        output.write(key)
    candidates = [row for rows in indexes.values() for row in rows.values() if row['P'] == SELECTOR]
    need(len(candidates) == 1 and candidates[0].get('A') == 'aarch64', 'fixed native QEMU selector')
    constraint = SELECTOR+'='+candidates[0]['V']
    urls = run([*apk, 'fetch', '--simulate', '-R', '--url', constraint], '03-resolve-closure')
    closure = []
    for branch, filename, record in package_urls(urls, prefixes, indexes):
        path = work/branch/'aarch64'/filename
        receipt = fetch(f'https://dl-cdn.alpinelinux.org/alpine/v3.24/{branch}/aarch64/{filename}', path, 128*MIB)
        need(path.stat().st_size == int(record['S']), 'indexed package size')
        closure.append(dict(receipt, package=record['P'], version=record['V'],
                            architecture=record['A'], signed_index_identity=record['C']))
        run([*apk, 'verify', str(path)], f'04-verify-{len(closure):03d}')
        need(sum(x['bytes'] for x in closure) <= 1024*MIB, 'package closure byte cap')
    phase_space('downloaded')
    run([*apk, 'add', '--no-progress', constraint], '05-install-closure', timeout=180)
    phase_space('installed')
    after = run(['apk', 'info', '-v'], '06-installed-after')
    old, new = set(before.decode().splitlines()), set(after.decode().splitlines())
    save(ROOT/'evidence/packages.json', {'selector': constraint, 'indexes': downloads, 'closure': closure,
         'installed_before': sorted(old), 'installed_after': sorted(new),
         'removed_or_upgraded_old_records': sorted(old-new), 'added_or_upgraded_new_records': sorted(new-old),
         'authentication_input_files': ['APKINDEX-main.tar.gz', 'APKINDEX-community.tar.gz', KEY],
         'trusted_key_sha256': KEY_SHA, 'index_and_packages_authenticated_by_apk': True})
    qemu = Path('/usr/bin/qemu-system-x86_64')
    need(qemu.is_file() and not qemu.is_symlink(), 'native QEMU executable')
    run([str(qemu), '--version'], '07-qemu-version')
    kernel = work/'kernel.deb'
    kr = fetch('https://security.debian.org/debian-security/'+KERNEL_PATH, kernel, 256*MIB, KERNEL_SHA)
    extracted = kernel_data(kernel.read_bytes())
    phase_space('kernel-downloaded')
    for name, payload in extracted.items():
        (ROOT/'extracted'/name).write_bytes(payload)
        (ROOT/'extracted'/name).chmod(0o644)
    # Exact cached old probe inputs; the newly built QEMU image is NOT yet qualified.
    run(['python3', str(INPUT/'build_initramfs.py'), '--init', str(INPUT/'init.sh'),
         '--busybox', str(INPUT/'busybox'), '--getconf', str(INPUT/'getconf'),
         '--loader', str(INPUT/'loader'), '--libc', str(INPUT/'libc'),
         '--output', str(ROOT/'initramfs.cpio.gz')], '08-probe-data-assembly')
    (ROOT/'initramfs.cpio.gz').chmod(0o644)
    save(ROOT/'evidence/RESULT.json', {'status': 'ENVIRONMENT_PREPARED_NOT_BOOTED', 'kernel_package': kr,
         'kernel': {name: {'bytes': len(payload), 'sha256': sha(payload)} for name, payload in extracted.items()},
         'qemu': {'path': str(qemu), 'bytes': qemu.stat().st_size, 'sha256': sha(qemu.read_bytes())},
         'probe_initramfs': {'bytes': (ROOT/'initramfs.cpio.gz').stat().st_size,
                            'sha256': sha((ROOT/'initramfs.cpio.gz').read_bytes())},
         'VM_Corsa_piratecashd_executed': False, 'fresh_strict_lo_glibc_qualification': 'REQUIRED'})
    shutil.rmtree(work)
    phase_space('final')
    print('HMIX_QEMU_ENVIRONMENT_PREPARED_NOT_BOOTED')


if __name__ == '__main__':
    main()
