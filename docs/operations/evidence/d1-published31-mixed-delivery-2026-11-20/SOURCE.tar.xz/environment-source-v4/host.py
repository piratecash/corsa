"""One Root-invoked owned QEMU environment preparation; no QEMU/guest/app run."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import shutil
import signal
import stat

HERE = Path(__file__).resolve().parent
COMMON = HERE.parent/'d1-o1a-capexec-seccomp-build-v1/common.py'
BASE = 'sha256:45ccc728acf675888bde399354b6c8338accfc591e35496f9413a3742f3ae313'
LABEL = 'corsa.hmix.environment_attempt'
CAPS = {'CHOWN', 'DAC_OVERRIDE', 'FOWNER', 'FSETID', 'SETGID', 'SETUID'}
MIB, GIB = 1024**2, 1024**3


def need(ok, reason):
    if not ok:
        raise ValueError(reason)


def digest(path):
    path = Path(path)
    before = path.lstat()
    need(not path.is_symlink() and path.is_file() and before.st_nlink == 1 and before.st_size <= 256*MIB,
         'public input metadata')
    value = hashlib.sha256(path.read_bytes()).hexdigest()
    after = path.lstat()
    keys = ('st_dev','st_ino','st_uid','st_gid','st_mode','st_nlink','st_size','st_mtime_ns','st_ctime_ns')
    need(all(getattr(before, k) == getattr(after, k) for k in keys), 'public input changed')
    return value


def source_check():
    frozen = json.loads((HERE/'FROZEN.json').read_bytes())
    for name, wanted in frozen['files'].items():
        need(digest(HERE/name) == wanted, 'frozen prep source changed: '+name)
    need(digest(COMMON) == frozen['common_sha256'], 'accepted common helper changed')
    return frozen


def inspect_row(row, cid, attempt):
    need(row['Id'] == cid and row['Image'] == BASE and
         row['Name'] == '/d1-hmix-environment-'+attempt, 'owned container identity')
    cfg, host = row['Config'], row['HostConfig']
    need(cfg['Labels'].get(LABEL) == attempt and cfg['User'] == '0:0' and
         cfg['Entrypoint'] == ['/usr/bin/python3'] and cfg['Cmd'] == ['/tmp/hmix-input/prepare.py'] and
         cfg['WorkingDir'] == '/', 'fixed preparation entry')
    need(len(cfg.get('Env') or []) == 3 and set(cfg['Env']) ==
         {'PATH=/usr/sbin:/usr/bin:/sbin:/bin', 'LC_ALL=C', 'HOME=/root'}, 'closed preparation environment')
    need((host['NanoCpus'], host['Memory'], host['MemorySwap'], host['PidsLimit']) ==
         (1_000_000_000, GIB, GIB, 128), 'preparation resource profile')
    need(host['NetworkMode'] == 'bridge' and host['ReadonlyRootfs'] is False and host['Privileged'] is False and
         host['CgroupnsMode'] == 'private' and host['IpcMode'] == 'private' and
         (host['RestartPolicy'] or {}).get('Name') == 'no', 'preparation isolation')
    need(host['CapDrop'] == ['ALL'] and {c.removeprefix('CAP_') for c in (host.get('CapAdd') or [])} == CAPS,
         'finite installation capabilities')
    need(host.get('SecurityOpt') in (['no-new-privileges'], ['no-new-privileges=true']), 'NNP')
    need(not row['Mounts'] and not cfg.get('Volumes') and not any(host.get(k) for k in (
         'Binds','Mounts','Tmpfs','VolumesFrom','Devices','DeviceRequests','DeviceCgroupRules',
         'PortBindings','PublishAllPorts','PidMode','UsernsMode','CgroupParent','ExtraHosts','Links')),
         'foreign mounts/namespaces/devices/ports')
    need(set(((row.get('NetworkSettings') or {}).get('Networks') or {})) <= {'bridge'}, 'foreign network attachment')
    need(host['LogConfig'] == {'Type': 'local', 'Config': {'max-size': '1m', 'max-file': '1', 'compress': 'false'}}, 'Docker log cap')
    return row


def retain_failure_evidence(run, work, cid, attempt, row):
    """Snapshot only this stopped container; no preparation success inference."""
    inspect_row(row, cid, attempt)
    state = row['State']
    need(not state['Running'] and state['Pid'] == 0 and state['Status'] in ('created','exited','dead'),
         'cannot capture a live/unknown container')
    snapshot = work/'STOPPED-CONTAINER.json'
    with snapshot.open('x') as output:
        json.dump(row, output, indent=2, sort_keys=True)
        output.write('\n')
    result = {'status': 'EVIDENCE_UNAVAILABLE', 'stopped_inspect': str(snapshot),
              'preparation_pass': False, 'secondary_error': None, 'members': {}}
    try:
        target = work/'failure-evidence'
        need(not target.exists() and not target.is_symlink(), 'failure capture target exists')
        run('failed-evidence-copy', 'container', 'cp', cid+':/s6-preparation/evidence', str(target), cleanup=True)
        need(target.is_dir() and not target.is_symlink(), 'failure evidence directory absent')
        total = 0
        for path in target.iterdir():
            metadata = path.lstat()
            need(stat.S_ISREG(metadata.st_mode) and metadata.st_nlink == 1 and
                 metadata.st_size <= 4*MIB, 'failure evidence entry metadata/size')
            total += metadata.st_size
            need(len(result['members']) < 512 and total <= 16*MIB, 'failure evidence capture bound')
            result['members'][path.name] = {'bytes': metadata.st_size, 'sha256': digest(path)}
        result.update(status='AVAILABLE_DIRECTORY_SNAPSHOT_MAY_BE_PARTIAL', bytes=total)
    except BaseException as exc:
        # Missing directory before script entry is a known unavailability; a
        # runner UNKNOWN remains set on the original Job and cannot be cleared.
        result['secondary_error'] = type(exc).__name__+': '+str(exc)
    with (work/'FAILURE-EVIDENCE.json').open('x') as output:
        json.dump(result, output, indent=2, sort_keys=True)
        output.write('\n')
    return result


def main():
    os.umask(0o077)
    if os.getpid() != os.getpgrp():
        os.setsid()
    frozen = source_check()
    spec = importlib.util.spec_from_file_location('hmix_accepted_common', COMMON)
    common = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(common)
    # This exact accepted helper owns process EOF/reap, heavy-lock custody and UNKNOWN HOLD.
    job = common.Job('hmix-qemu-environment', 600, 4*GIB)
    cid, created, removed, image, error = None, False, False, None, None
    commit_started, failed_image_removed = False, False
    artifact, initial_base, stage_receipt, prep = None, None, None, None
    failure_evidence = None
    env = {'PATH': '/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin', 'HOME': os.environ.get('HOME', '/nonexistent'), 'LC_ALL': 'C'}
    docker = '/usr/local/bin/docker'

    def run(name, *args, cleanup=False):
        return job.run(name, [docker, '--context', 'desktop-linux', *args], env=env, cleanup=cleanup)

    def inspect(cleanup=False):
        rows = json.loads(run('owned-inspect', 'container', 'inspect', cid, cleanup=cleanup))
        need(len(rows) == 1, 'exact owned inspect result')
        return inspect_row(rows[0], cid, job.attempt)

    def interrupt(_sig, _frame):
        # The accepted runner cannot complete its ordinary EOF path once the
        # Python call is interrupted. Preserve UNKNOWN/HOLD rather than lose
        # that original CLI group when a cleanup command starts.
        job.unknown = True
        job.stop_child()
        raise KeyboardInterrupt('Root preparation interrupted')

    signal.signal(signal.SIGINT, interrupt)
    signal.signal(signal.SIGTERM, interrupt)
    try:
        need(shutil.disk_usage('/private/tmp').free >= 15*GIB, 'host reserve <15GiB')
        endpoint = json.loads(run('endpoint', 'context', 'inspect', '--format', '{{json .Endpoints.docker.Host}}', 'desktop-linux'))
        need(endpoint == 'unix:///Users/hades/.docker/run/docker.sock', 'wrong Docker endpoint')
        info = json.loads(run('base-image', 'image', 'inspect', BASE))
        need(len(info) == 1, 'exact existing base image')
        initial_base = info[0]
        need(initial_base['Id'] == BASE and initial_base['Architecture'] == 'arm64' and
             initial_base['Os'] == 'linux' and not initial_base['Config'].get('Volumes'), 'existing owned base differs')
        need(0 < initial_base['Size'] < 4*GIB, 'base image size')
        stage_spec = importlib.util.spec_from_file_location('hmix_fixed_stage', HERE/'stage.py')
        module = importlib.util.module_from_spec(stage_spec)
        stage_spec.loader.exec_module(module)
        stage = job.work/'hmix-input'
        stage_receipt = module.stage(stage)
        (job.work/'STAGING.json').write_text(json.dumps(stage_receipt, indent=2, sort_keys=True)+'\n')
        caps = [item for name in sorted(CAPS) for item in ('--cap-add', name)]
        created = True
        value = run('create', 'container', 'create', '--pull', 'never', '--platform', 'linux/arm64',
                    '--name', 'd1-hmix-environment-'+job.attempt, '--label', LABEL+'='+job.attempt,
                    '--user', '0:0', '--workdir', '/', '--cpus', '1', '--memory', '1024m',
                    '--memory-swap', '1024m', '--pids-limit', '128', '--network', 'bridge',
                    '--cgroupns', 'private', '--ipc', 'private', '--restart', 'no', '--cap-drop', 'ALL', *caps,
                    '--security-opt', 'no-new-privileges', '--log-driver', 'local', '--log-opt', 'max-size=1m',
                    '--log-opt', 'max-file=1', '--log-opt', 'compress=false', '--env', 'PATH=/usr/sbin:/usr/bin:/sbin:/bin',
                    '--env', 'LC_ALL=C', '--env', 'HOME=/root', '--entrypoint', '/usr/bin/python3', BASE,
                    '/tmp/hmix-input/prepare.py').decode().strip()
        need(re.fullmatch('[0-9a-f]{64}', value), 'ambiguous container creation')
        cid = value
        state = inspect()['State']
        need(state['Status'] == 'created' and not state['Running'] and state['Pid'] == 0, 'unexpected initial state')
        run('stage-copy', 'container', 'cp', str(stage), cid+':/tmp/')
        run('prepare-no-VM', 'container', 'start', '--attach', cid)
        state = inspect()['State']
        need(state['Status'] == 'exited' and not state['Running'] and state['Pid'] == 0 and
             state['ExitCode'] == 0 and state['OOMKilled'] is False, 'preparation failed/OOM/unknown')
        size = json.loads(run('writable-size', 'inspect', '--size', '--format', '{{json .SizeRw}}', cid))
        need(type(size) is int and size > 0 and initial_base['Size']+2*size+MIB <= 4*GIB,
             'base plus own layers exceeds four GiB')
        run('evidence-copy', 'container', 'cp', cid+':/s6-preparation/evidence', str(job.work/'evidence'))
        prep = json.loads((job.work/'evidence/RESULT.json').read_bytes())
        need(prep['status'] == 'ENVIRONMENT_PREPARED_NOT_BOOTED' and prep['VM_Corsa_piratecashd_executed'] is False and
             prep['fresh_strict_lo_glibc_qualification'] == 'REQUIRED', 'preparation output scope')
        need(prep['kernel']['vmlinuz']['sha256'] == '14159c607ad9762133db41e479dafecde1d6a5fe715a8d65d292a3262e4b6bed' and
             prep['kernel_package']['sha256'] == 'ca712d36790184f6ac125ce2b20ea4e2202ae6bb7817b7de268f1f0115ccda73', 'fixed kernel output')
        run('input-readback', 'container', 'cp', cid+':/tmp/hmix-input', str(job.work/'input-readback'))
        readback = job.work/'input-readback'
        need(set(p.name for p in readback.iterdir()) == set(stage_receipt['files']), 'input readback set')
        for name, row in stage_receipt['files'].items():
            need(digest(readback/name) == row['sha256'] and digest(stage/name) == row['sha256'], 'staged input changed')
        commit_started = True
        candidate = run('commit-owned-child', 'container', 'commit', '--pause=false', '--change', 'ENTRYPOINT []',
                        '--change', 'CMD ["/bin/sh"]', cid).decode().strip()
        need(re.fullmatch('sha256:[0-9a-f]{64}', candidate) and candidate != BASE, 'ambiguous new image ID')
        image = candidate
        rows = json.loads(run('owned-image', 'image', 'inspect', image))
        need(len(rows) == 1, 'new image result count')
        row = rows[0]
        need(row['Id'] == image and row['Architecture'] == 'arm64' and row['Os'] == 'linux' and
             row['Config']['Labels'].get(LABEL) == job.attempt and not row['Config'].get('Entrypoint') and
             row['Config']['Cmd'] == ['/bin/sh'] and not row['Config'].get('Volumes'), 'new owned image metadata')
        need(row['RootFS']['Layers'][:-1] == initial_base['RootFS']['Layers'] and
             row['Size']+size+MIB <= 4*GIB, 'new image ancestry/space bound')
        final_base = json.loads(run('base-unchanged', 'image', 'inspect', BASE))[0]
        need(all(final_base[k] == initial_base[k] for k in ('Id','RootFS','Config','Size')), 'original base changed')
        source_check()
        artifact = {'image_id': image, 'parent_image_id': BASE, 'size_bytes': row['Size'], 'writable_bytes': size,
                    'owned_label': LABEL+'='+job.attempt, 'VM_or_Corsa_executed': False,
                    'fresh_strict_lo_glibc_probe': 'REQUIRED_BEFORE_HMIX'}
    except BaseException as exc:
        error = type(exc).__name__+': '+str(exc)
    if created and cid is None:
        job.unknown = True
        error = (error or '')+'; creation ambiguous: exact own label reconciliation required'
    if commit_started and image is None:
        job.unknown = True
        error = (error or '')+'; commit ambiguous: exact own image label reconciliation required'
    if cid:
        try:
            stopped = inspect(cleanup=True)
            state = stopped['State']
            if state['Running'] or state['Pid'] != 0:
                run('stop-owned', 'container', 'kill', '--signal', 'KILL', cid, cleanup=True)
                stopped = inspect(cleanup=True)
                state = stopped['State']
            need(not state['Running'] and state['Pid'] == 0 and state['Status'] in ('created','exited','dead'), 'owned stop unknown')
            if error is not None:
                failure_evidence = retain_failure_evidence(run, job.work, cid, job.attempt, stopped)
                need(not job.unknown, 'failure capture process/output completion unknown')
            run('remove-owned-container', 'container', 'rm', cid, cleanup=True)
            need(run('own-container-absent', 'container', 'ls', '-aq', '--no-trunc', '--filter',
                     'label='+LABEL+'='+job.attempt, cleanup=True).strip() == b'', 'owned container remains')
            removed = True
        except BaseException as exc:
            job.unknown = True
            error = (error or '')+'; cleanup: '+type(exc).__name__+': '+str(exc)
    if image and error is not None and removed and not job.unknown:
        try:
            rows = json.loads(run('failed-own-image-inspect', 'image', 'inspect', image, cleanup=True))
            need(len(rows) == 1 and rows[0]['Id'] == image and image != BASE and
                 rows[0]['Config']['Labels'].get(LABEL) == job.attempt and
                 rows[0]['RootFS']['Layers'][:-1] == initial_base['RootFS']['Layers'], 'failed image ownership')
            run('remove-failed-own-image', 'image', 'rm', image, cleanup=True)
            need(run('failed-own-image-absent', 'image', 'ls', '-aq', '--no-trunc', '--filter',
                     'label='+LABEL+'='+job.attempt, cleanup=True).strip() == b'', 'failed own image remains')
            failed_image_removed = True
        except BaseException as exc:
            job.unknown = True
            error += '; failed image cleanup: '+type(exc).__name__+': '+str(exc)
    result = job.finish({'status': 'OWNED_QEMU_ENVIRONMENT_PREPARED_NOT_BOOTED' if error is None else 'STOP',
                         'error': error, 'container_id': cid, 'owned_container_removed': removed,
                         'new_owned_image_id': image, 'artifact': artifact, 'preparation': prep,
                         'failed_own_image_removed': failed_image_removed,
                         'failure_evidence': failure_evidence,
                         'base_image_unchanged': artifact is not None, 'QEMU_VM_Corsa_piratecashd_executed': False})
    if result['error']:
        raise SystemExit(1)


if __name__ == '__main__':
    main()
