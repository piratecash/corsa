"""Root-owned DATA-only staging for the finite environment-preparation inputs."""
from pathlib import Path
import gzip
import hashlib
import json
import os
import stat

HERE = Path(__file__).resolve().parent
OLD = HERE.parent.parent/'2026-11-13/s6-amd64-lo-only-guest-v2'
ARCHIVE = OLD/'restart/restart-verified.cpio.gz'
ARCHIVE_SHA = '9d4a8a309beebc371932a4bd5203d7ec99decdd941d927e87dea0e19497e4a06'
KEY = 'alpine-devel@lists.alpinelinux.org-616ae350.rsa.pub'
KEY_PATH = HERE.parent/'d1-full512-perl-toolchain/snapshot'/KEY
KEY_SHA = 'd11f6b21c61b4274e182eb888883a8ba8acdbf820dcc7a6d82a7d9fc2fd2836d'
CACHED = {
    'usr/bin/busybox': ('busybox', '7ae95c260622412ceba6eb9f45d68f616cdc091a1d71d6c0a08b5875bb2c31dd'),
    'usr/bin/getconf': ('getconf', 'dc5dae16d20761904355b3ed0ccea13133c1d1545f88a0bc44cc6ce3ae038b91'),
    'usr/lib/x86_64-linux-gnu/ld-linux-x86-64.so.2': ('loader', '02bcda52c1a5dfc236f94d9e5255b4a0e26347d8a372a5223b650e31f291ce3c'),
    'usr/lib/x86_64-linux-gnu/libc.so.6': ('libc', '6b4a45352fd0c540a9c7c718f35ce8c8e46a4e482f9d3885a910c32d1a0e1421'),
}


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def exact(path, expected, limit):
    before = path.lstat()
    assert stat.S_ISREG(before.st_mode) and before.st_nlink == 1 and 0 < before.st_size <= limit
    raw = path.read_bytes()
    after = path.lstat()
    keys = ('st_dev', 'st_ino', 'st_uid', 'st_gid', 'st_mode', 'st_nlink', 'st_size', 'st_mtime_ns', 'st_ctime_ns')
    assert all(getattr(before, k) == getattr(after, k) for k in keys)
    assert len(raw) == before.st_size and sha(raw) == expected
    return raw


def cached_files():
    raw = exact(ARCHIVE, ARCHIVE_SHA, 64*1024**2)
    found, seen, expanded = {}, set(), 0
    with gzip.GzipFile(fileobj=__import__('io').BytesIO(raw)) as stream:
        while True:
            header = stream.read(110)
            assert len(header) == 110 and header[:6] == b'070701'
            values = [int(header[6+i*8:14+i*8], 16) for i in range(13)]
            mode, uid, gid, size, namesize = values[1], values[2], values[3], values[6], values[11]
            assert 1 < namesize <= 4096 and 0 <= size <= 32*1024**2
            encoded = stream.read(namesize)
            assert len(encoded) == namesize and encoded[-1:] == b'\0' and b'\0' not in encoded[:-1]
            name = encoded[:-1].decode('utf-8')
            assert stream.read((-110-namesize)%4).strip(b'\0') == b''
            if name == 'TRAILER!!!':
                tail = stream.read(513)
                assert size == 0 and len(tail) <= 512 and not tail.strip(b'\0') and stream.read(1) == b''
                break
            assert name not in seen
            seen.add(name)
            expanded += size
            assert len(seen) <= 8192 and expanded <= 160*1024**2
            payload = stream.read(size)
            assert len(payload) == size and stream.read((-size)%4).strip(b'\0') == b''
            if name in CACHED:
                label, expected = CACHED[name]
                assert stat.S_ISREG(mode) and (uid, gid) == (0, 0) and sha(payload) == expected
                found[label] = payload
    assert len(found) == 4
    return found


def stage(output):
    frozen = json.loads((HERE/'SOURCE.json').read_bytes())
    inputs = cached_files()
    inputs[KEY] = exact(KEY_PATH, KEY_SHA, 65536)
    for name, origin in (('init.sh', OLD/'init.sh'), ('build_initramfs.py', OLD/'build_initramfs.py'),
                         ('prepare.py', HERE/'prepare.py')):
        inputs[name] = exact(origin, frozen['files'][name]['sha256'], 65536)
    output = Path(output)
    output.mkdir(mode=0o700)
    receipts = {}
    for name, raw in inputs.items():
        with (output/name).open('xb') as stream:
            stream.write(raw)
        (output/name).chmod(0o444)
        row = (output/name).lstat()
        assert stat.S_ISREG(row.st_mode) and row.st_nlink == 1 and row.st_uid == os.getuid() and stat.S_IMODE(row.st_mode) == 0o444
        receipts[name] = {'bytes': len(raw), 'sha256': sha(raw), 'mode': '0444'}
    return {'status': 'FINITE_PREP_INPUT_DATA_READY_NOT_EXECUTED', 'output': str(output), 'files': receipts,
            'VM_Corsa_Docker_executed': False}
