"""One frozen offline strict lo/glibc QEMU qualification; no Corsa or image mutation."""
import argparse,copy,hashlib,importlib.util,json,os,re,shutil,signal,stat,struct
from pathlib import Path
import probe_profile as profile
from verify_console import verify,MAX_BYTES
HERE=Path(__file__).resolve().parent
COMMON=HERE.parent/'d1-o1a-capexec-seccomp-build-v1/common.py'
DOCKER='/usr/local/bin/docker'
IMAGE='sha256:45009926747bc2be5493d1d28f84f8a40b358f9bb600f5ff9c1724ff201913e1'
MIB=1024**2

def need(v,s):
 if not v:raise ValueError(s)
def digest(p,limit=128*MIB):
 p=Path(p);before=p.lstat();need(stat.S_ISREG(before.st_mode) and before.st_nlink==1 and 0<=before.st_size<=limit,'bounded regular input')
 with p.open('rb') as f:raw=f.read(before.st_size+1)
 need(len(raw)==before.st_size,'input length changed');after=p.lstat();fields=('st_dev','st_ino','st_uid','st_gid','st_mode','st_nlink','st_size','st_mtime_ns','st_ctime_ns');need(all(getattr(before,k)==getattr(after,k) for k in fields),'input identity changed');return hashlib.sha256(raw).hexdigest()
def source_check():
 f=json.loads((HERE/'FROZEN.json').read_bytes())
 for n,sha in f['source_files'].items():need(digest(HERE/n)==sha,'source changed')
 need(digest(COMMON)==f['common_sha256'],'common changed')
 for p,row in f['references'].items():need(digest(p)==row['sha256'],'fixed reference changed')
 return f

def image_check(row,f):
 need(all(row.get(k)==v for k,v in f['image_immutable'].items()),'exact corrected image metadata changed')
 need(row['Id']==IMAGE and row['Architecture']=='arm64' and row['Os']=='linux' and not row['Config'].get('Volumes'),'native owned image')

def owned(row,cid,attempt):
 need(row['Id']==cid and row['Image']==IMAGE and row['Name']=='/corsa-d1-sg32-'+attempt+'-service' and row['Config']['Labels'].get('corsa.sg32.owner')==attempt,'owned container identity')
 need(type(row['State']['Running']) is bool and type(row['State']['Pid']) is int and row['State']['Status'] in ('created','running','exited','dead'),'actual state shape')
 # The original profile checker includes created-state validation. Reuse all
 # configuration checks at later inspect points while checking REAL state below.
 check=copy.deepcopy(row);check['State']['Status']='created';check['State']['Running']=False
 profile.check_created(check,cid,attempt,IMAGE)
 return row

def main(approved):
 os.umask(0o077)
 if os.getpid()!=os.getpgrp():os.setsid()
 f=source_check();raw=(HERE/'HANDOFF.json').read_bytes();h=json.loads(raw);need(hashlib.sha256(raw).hexdigest()==approved and h['readiness']=={'CODE':True,'QA':True,'ROOT':True} and set(h)=={'profile','readiness','image_id','FROZEN_sha256'} and h['profile']=='s6-amd64-lo-only-probe' and h['image_id']==IMAGE and h['FROZEN_sha256']==digest(HERE/'FROZEN.json'),'exact ready handoff')
 spec=importlib.util.spec_from_file_location('accepted_job',COMMON);common=importlib.util.module_from_spec(spec);spec.loader.exec_module(common)
 job=common.Job('hmix-qemu-lo-probe',180,256*MIB);cid=None;created=False;removed=False;error=None;proof=None;before=None
 env={'PATH':'/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin','HOME':os.environ.get('HOME','/nonexistent'),'LC_ALL':'C'}
 def run(label,*args,cleanup=False):return job.run(label,[DOCKER,'--context','desktop-linux',*args],env=env,cleanup=cleanup)
 def inspect(cleanup=False):
  rows=json.loads(run('owned-inspect','container','inspect',cid,cleanup=cleanup));need(len(rows)==1,'one container');return owned(rows[0],cid,job.attempt)
 def interrupt(_sig,_frame):job.unknown=True;job.stop_child();raise KeyboardInterrupt('Root qualification interrupted')
 signal.signal(signal.SIGTERM,interrupt);signal.signal(signal.SIGINT,interrupt)
 try:
  need(shutil.disk_usage('/private/tmp').free>=15*1024**3,'free space <15GiB')
  endpoint=json.loads(run('endpoint','context','inspect','--format','{{json .Endpoints.docker.Host}}','desktop-linux'));need(endpoint=='unix:///Users/hades/.docker/run/docker.sock','Docker endpoint')
  rows=json.loads(run('image','image','inspect',IMAGE));need(len(rows)==1,'one image');before=rows[0];image_check(before,f)
  created=True;value=run('create',*profile.create_args(job.attempt,IMAGE)).decode().strip();need(re.fullmatch('[0-9a-f]{64}',value),'ambiguous create');cid=value
  initial=inspect();profile.check_created(initial,cid,job.attempt,IMAGE);need(initial['State']['Pid']==0,'not stopped before readback')
  for name,row in f['boot_files'].items():
   target=job.work/name;need(not target.exists(),'readback path exists');run('readback-'+name,'container','cp',cid+':'+row['image_path'],str(target));need(digest(target)==row['sha256'] and target.stat().st_size==row['bytes'],'critical boot image bytes changed')
   if name=='qemu-system-x86_64':
    data=target.read_bytes();need(data[:6]==b'\x7fELF\x02\x01' and struct.unpack_from('<H',data,18)[0]==183,'QEMU not native AArch64')
  run('start','container','start',cid)
  exit_code=run('wait','container','wait',cid).strip();state=inspect()['State'];need(exit_code==b'0' and state['Status']=='exited' and not state['Running'] and state['Pid']==0 and type(state['ExitCode']) is int and state['ExitCode']==0 and state['OOMKilled'] is False,'QEMU did not stop normally')
  console=run('console','container','logs',cid);need(len(console)<=MAX_BYTES,'console bound');proof=verify(console)
  final=json.loads(run('image-unchanged','image','inspect',IMAGE));need(len(final)==1,'one final image');image_check(final[0],f);source_check()
 except BaseException as exc:error=type(exc).__name__+': '+str(exc)
 if created and cid is None:job.unknown=True;error=(error or '')+'; create outcome UNKNOWN, own label reconciliation required'
 if cid:
  try:
   row=inspect(cleanup=True)
   if row['State']['Running']:run('kill-owned','container','kill',cid,cleanup=True);row=inspect(cleanup=True)
   need(not row['State']['Running'] and row['State']['Pid']==0 and row['State']['Status'] in ('created','exited','dead'),'container stop UNKNOWN')
   run('remove-owned','container','rm',cid,cleanup=True);remaining=run('owned-absent','container','ls','-a','--no-trunc','--filter','label=corsa.sg32.owner='+job.attempt,'--format','{{.ID}}',cleanup=True);need(not remaining.strip(),'owned container remains');removed=True
  except BaseException as exc:job.unknown=True;error=(error or '')+'; cleanup: '+type(exc).__name__+': '+str(exc)
 result=job.finish({'status':'AMD64_GLIBC_AND_LO_ONLY_VERIFIED' if error is None and removed and proof else 'STOP','error':error,'scope':'FRESH_OWN_IMAGE_ENVIRONMENT_ONLY_NOT_HMIX_OR_APP_RUNTIME','handoff_sha256':approved,'image_id':IMAGE,'image_created_or_deleted':False,'owned_container':cid,'owned_container_removed':removed,'guest':proof,'Corsa_piratecashd_or_old_runtime_executed':False,'console_complete':proof is not None,'work_seconds':180,'cleanup_seconds':30})
 if result['error']:raise SystemExit(1)
if __name__=='__main__':
 parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--execute',required=True);args=parser.parse_args();main(args.execute)
