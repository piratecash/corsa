"""Verify the serial markers from the S6 Linux amd64 preflight."""

import argparse
import json
from pathlib import Path
import re

MAX_BYTES = 1024**2
PREFIX = "S6-AMD64-"


def verify(raw):
    if not raw or len(raw) > MAX_BYTES or not raw.endswith(b"\n"):
        raise ValueError("missing, truncated or oversized console")
    lines = raw.decode("utf-8", errors="replace").splitlines()
    records = [(i, line) for i, line in enumerate(lines) if line.startswith(PREFIX)]
    if len(records) != 7:
        raise ValueError("wrong number of guest records")
    (_, arch), (_, libc), (_, boot), (boot_idx, boot_interfaces), (_, fresh), (fresh_idx, fresh_interfaces), (_, result) = records
    version = re.fullmatch(r"S6-AMD64-LIBC glibc ([0-9]+)\.([0-9]+)", libc)
    boot_ns = re.fullmatch(r"S6-AMD64-NETNS boot (net:\[[1-9][0-9]*\])", boot)
    fresh_ns = re.fullmatch(r"S6-AMD64-NETNS fresh (net:\[[1-9][0-9]*\])", fresh)
    if (arch != "S6-AMD64-ARCH x86_64" or version is None or tuple(map(int, version.groups())) < (2, 34)
            or boot_ns is None or fresh_ns is None or boot_ns[1] == fresh_ns[1]
            or boot_interfaces != "S6-AMD64-INTERFACES boot" or fresh_interfaces != "S6-AMD64-INTERFACES fresh"
            or lines[boot_idx + 1:records[4][0]] != ["lo"] or lines[fresh_idx + 1:records[6][0]] != ["lo"]
            or result != "S6-AMD64-RESULT PASS"):
        raise ValueError("guest did not prove x86_64, glibc and strict lo-only in both namespaces")
    return {"arch": "x86_64", "glibc": ".".join(version.groups()),
            "boot_netns": boot_ns[1], "fresh_netns": fresh_ns[1], "interfaces": ["lo"]}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("console", type=Path)
    args = parser.parse_args()
    try:
        with args.console.open("rb") as stream:
            result = verify(stream.read(MAX_BYTES + 1))
    except (OSError, ValueError) as exc:
        parser.exit(2, f"Guest evidence refused: {exc}\n")
    print(json.dumps(result, indent=2))
