"""Clean f258 + two test posts: seven source guards and compile-only amd64 ELF."""
from pathlib import Path, PurePosixPath
import hashlib
import json
import os
import re
import shutil
import struct
import sys
import tarfile
import time

HERE = Path(__file__).resolve().parent
REPO = HERE.parents[4]
SUBJECT = HERE.parent / "d1-hmix-published31-linux-guest-source-v1"
BASE = "f258093a44aa15dd7ce79f6e6a13df9c0aae363c"
GO = "/usr/local/go/bin/go"
sys.path.insert(0, str(HERE.parent / "d1-o1a-capexec-seccomp-build-v1"))
from common import Job, need, sha, directory_bytes


def check_inputs(frozen):
    for path, expected in frozen["dependencies"].items():
        need(sha(path) == expected, "accepted dependency changed")
    for name, expected in frozen["controller_files"].items():
        need(sha(HERE / name) == expected, "controller changed")
    for path, record in frozen["toolchain_files"].items():
        need(sha(path) == record["sha256"] and Path(path).stat().st_size == record["bytes"], "toolchain changed")
    need(sha(SUBJECT / "MANIFEST.json") == frozen["subject_manifest_sha256"], "subject changed")
    manifest = json.loads((SUBJECT / "MANIFEST.json").read_bytes())
    need(manifest["full_build_subject_commit"] == BASE and manifest["production_changes"] == 0, "closed subject")
    for row in manifest["files"].values():
        need(sha(SUBJECT / row["post"]) == row["after_sha256"], "post changed")
    return manifest


def snapshot(archive, destination, base_files, manifest):
    seen = set()
    total = 0
    before = {}
    with tarfile.open(archive, "r:") as stream:
        for item in stream:
            path = PurePosixPath(item.name)
            need(not path.is_absolute() and ".." not in path.parts and "\\" not in item.name, "archive path")
            need(not item.linkname and set(item.pax_headers) <= {"comment"} and
                 item.pax_headers.get("comment", BASE) == BASE, "archive metadata")
            if item.isdir():
                continue
            need(item.isfile() and item.name in base_files and item.name not in seen, "archive member")
            row = base_files[item.name]
            need(item.size == row["bytes"] and item.size <= 128 * 1024**2 and item.mode == int(row["mode"], 8) & 0o777, "archive file shape")
            total += item.size
            need(total <= 512 * 1024**2 and len(seen) < 8192, "snapshot bound")
            raw = stream.extractfile(item).read(item.size + 1)
            need(len(raw) == item.size and hashlib.sha1(b"blob " + str(len(raw)).encode() + b"\0" + raw).hexdigest() == row["blob_sha1"], "git blob changed")
            target = destination / item.name
            target.parent.mkdir(parents=True, exist_ok=True)
            with target.open("xb") as out:
                out.write(raw)
            target.chmod(0o555 if row["mode"] == "100755" else 0o444)
            before[item.name] = hashlib.sha256(raw).hexdigest()
            seen.add(item.name)
    need(seen == base_files.keys(), "missing git files")
    after = dict(before)
    for name, row in manifest["files"].items():
        need(before.get(name) == row["before_sha256"], "exact before image")
        target = destination / name
        target.parent.mkdir(parents=True, exist_ok=True)
        if target.exists():
            target.chmod(0o600)
        with target.open("wb") as out:
            out.write((SUBJECT / row["post"]).read_bytes())
        target.chmod(0o444)
        after[name] = row["after_sha256"]
    return before, after


def inventory(root):
    result = {}
    for folder, directories, files in os.walk(root, followlinks=False):
        for name in directories + files:
            need(not (Path(folder) / name).is_symlink(), "source link")
        for name in files:
            path = Path(folder) / name
            result[path.relative_to(root).as_posix()] = sha(path)
            need(len(result) <= 8192, "source count")
    return result


def events(raw, expected, required_child=None):
    rows = [json.loads(line) for line in raw.splitlines()]
    need(rows and not any(row.get("Action") in ("fail", "skip") for row in rows), "FAIL/SKIP")
    passed = [row["Test"] for row in rows if row.get("Action") == "pass" and row.get("Test")]
    outer = [name for name in passed if "/" not in name]
    need(len(outer) == len(set(outer)) and set(outer) == set(expected), "named test inventory")
    need(any(row.get("Action") == "pass" and not row.get("Test") for row in rows), "package PASS missing")
    if required_child:
        need(required_child in passed, "new negative caller control missing")
    return {"outer": outer, "child": sum("/" in name for name in passed)}


def static_amd64(path):
    raw = path.read_bytes()
    need(64 <= len(raw) <= 96 * 1024**2 and raw[:7] == b"\x7fELF\x02\x01\x01", "ELF shape")
    kind, machine, version, _, offset, _, _, size, entsize, count, _, _, _ = struct.unpack_from("<HHIQQQIHHHHHH", raw, 16)
    need(kind in (2, 3) and machine == 62 and version == 1 and size == 64 and entsize == 56 and 0 < count <= 128 and 64 <= offset and offset + count * 56 <= len(raw), "amd64 ELF header")
    for i in range(count):
        segment, _, start, _, _, length, _, _ = struct.unpack_from("<IIQQQQQQ", raw, offset + 56 * i)
        need(segment not in (2, 3) and start <= len(raw) and length <= len(raw) - start, "dynamic or invalid ELF")
    return {"path": str(path), "bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest(), "static_amd64": True, "executed": False}


def main():
    os.umask(0o077)
    if os.getpid() != os.getpgrp():
        os.setsid()
    frozen = json.loads((HERE / "FROZEN.json").read_bytes())
    job = Job("hmix-published31-goqa", 600, 6 * 1024**3)
    error, checks, artifact, expected = None, {}, None, None
    try:
        need(shutil.disk_usage("/private/tmp").free >= 10 * 1024**3, "free space <10GiB")
        manifest = check_inputs(frozen)
        base_files = json.loads((HERE / "BASE-FILES.json").read_bytes())
        archive = job.work / "source.tar"
        git_policy = '(version 1)(allow default)(deny network*)(deny file-write* (subpath ' + json.dumps(str(REPO)) + '))'
        job.run("git-clean-archive", ["/usr/bin/sandbox-exec", "-p", git_policy, "/usr/bin/git", "-c", "tar.umask=0022", "-C", str(REPO), "archive", "--format=tar", "--output=" + str(archive), BASE])
        source = job.work / "source"
        source.mkdir()
        before, expected = snapshot(archive, source, base_files, manifest)
        need(inventory(source) == expected, "fresh source snapshot")
        for name, data in (("SOURCE-BEFORE.json", before), ("SOURCE-EXPECTED.json", expected)):
            (job.work / name).write_text(json.dumps(data, indent=2, sort_keys=True) + "\n")
        for name in ("cache", "tmp", "artifacts"):
            (job.work / name).mkdir()
        policy = '(version 1)(allow default)(deny network*)(deny file-write* (subpath ' + json.dumps(str(REPO)) + '))(deny file-write* (subpath ' + json.dumps(str(source)) + '))'
        env = {"PATH": "/usr/local/go/bin:/usr/bin:/bin:/usr/sbin:/sbin", "GOROOT": "/usr/local/go", "HOME": str(job.work), "TMPDIR": str(job.work / "tmp"), "GO111MODULE": "on", "GOENV": "off", "GOWORK": "off", "GOVCS": "*:off", "GOTOOLCHAIN": "local", "GOPROXY": "off", "GOSUMDB": "off", "GOTELEMETRY": "off", "GOMAXPROCS": "2", "GOMEMLIMIT": "768MiB", "GOFLAGS": "-p=1", "GOCACHE": str(job.work / "cache"), "GOMODCACHE": str(REPO / ".gomodcache"), "GOOS": "darwin", "GOARCH": "arm64", "CGO_ENABLED": "0", "LC_ALL": "C"}

        def run(name, argv):
            return job.run(name, ["/usr/bin/sandbox-exec", "-p", policy, *argv], cwd=source, env=env)

        need(run("go-version", [GO, "version"]).decode().strip() == "go version go1.27.4 darwin/arm64", "Go version")
        run("modules-verify", [GO, "mod", "verify"])
        tests = json.loads((HERE / "TESTS.json").read_bytes())
        for name in ("findnode", "pilot"):
            group = tests[name]
            pattern = "^(" + "|".join(re.escape(value) for value in group["tests"]) + ")$"
            raw = run(name + "-guards", [GO, "test", "-mod=readonly", "-buildvcs=false", "-p=1", "-parallel=1", "-count=1", "-timeout=180s", "-json", "-run=" + pattern, group["package"]])
            checks[name] = events(raw, group["tests"], group.get("required_child"))
        env.update(GOOS="linux", GOARCH="amd64", GOAMD64="v1", CGO_ENABLED="0")
        target = job.work / "artifacts/node.test"
        run("compile-linux-amd64", [GO, "test", "-mod=readonly", "-buildvcs=false", "-p=1", "-c", "-tags=interop,d1_owned_guest_interop", "-trimpath", "-ldflags=-buildid=", "-o", str(target), "./internal/core/node"])
        artifact = static_amd64(target)
        metadata = run("build-info", [GO, "version", "-m", str(target)]).decode()
        need(": go1.27.4\n" in metadata and all("\tbuild\t" + value in metadata for value in ("CGO_ENABLED=0", "GOOS=linux", "GOARCH=amd64", "GOAMD64=v1")), "BuildInfo target")
        artifact["BuildInfo_verified"] = True
        after = inventory(source)
        need(after == expected, "source changed after commands")
        (job.work / "SOURCE-AFTER.json").write_text(json.dumps(after, indent=2, sort_keys=True) + "\n")
        check_inputs(frozen)
        directory_bytes(job.work, 6 * 1024**3)  # Only after every child settles.
        need(shutil.disk_usage("/private/tmp").free >= 10 * 1024**3, "reserve after job")
    except BaseException as exc:
        error = repr(exc)
    result = job.finish({"status": "HMIX_SOURCE_GUARDS_AND_AMD64_TEST_COMPILE_PASS" if error is None else "STOP", "error": error, "base_commit": BASE, "subject_manifest_sha256": frozen["subject_manifest_sha256"], "checks": checks, "artifact": artifact, "source_files": len(expected) if expected else None, "Service_Run_or_Linux_ELF_or_Docker_VM_executed": False, "scope": "SEVEN_GUARDS_AND_COMPILE_METADATA_ONLY_NOT_INTEROP_RUNTIME"})
    if result["error"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
