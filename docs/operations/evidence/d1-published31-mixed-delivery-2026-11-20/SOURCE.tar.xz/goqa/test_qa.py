from pathlib import Path
import hashlib
import io
import json
import tarfile
import tempfile
import unittest

import qa


class Controls(unittest.TestCase):
    def test_events_require_exact_tests_package_and_new_negative(self):
        rows = [{"Action": "pass", "Test": "A/negative"}, {"Action": "pass", "Test": "A"}, {"Action": "pass"}]
        raw = b"\n".join(json.dumps(row).encode() for row in rows)
        self.assertEqual(qa.events(raw, ["A"], "A/negative")["child"], 1)
        for changed in (rows[:-1], rows + [rows[1]], rows + [{"Action": "fail"}], rows + [{"Action": "skip"}]):
            with self.assertRaises(RuntimeError):
                qa.events(b"\n".join(json.dumps(row).encode() for row in changed), ["A"], "A/negative")
        with self.assertRaises(RuntimeError):
            qa.events(raw, ["A"], "A/missing")

    def test_git_snapshot_blob_and_escaping_controls(self):
        raw = b"package a\n"
        blob = hashlib.sha1(b"blob " + str(len(raw)).encode() + b"\0" + raw).hexdigest()
        expected = {"a.go": {"mode": "100644", "bytes": len(raw), "blob_sha1": blob}}
        with tempfile.TemporaryDirectory(dir="/private/tmp") as directory:
            root = Path(directory)
            path = root / "tiny.tar"
            with tarfile.open(path, "w", format=tarfile.PAX_FORMAT, pax_headers={"comment": qa.BASE}) as out:
                item = tarfile.TarInfo("a.go")
                item.mode, item.size = 0o644, len(raw)
                out.addfile(item, io.BytesIO(raw))
            dest = root / "source"
            dest.mkdir()
            before, after = qa.snapshot(path, dest, expected, {"files": {}})
            self.assertEqual(before, after)
            self.assertEqual(qa.inventory(dest), after)
            wrong = {"a.go": {**expected["a.go"], "blob_sha1": "0" * 40}}
            other = root / "other"
            other.mkdir()
            with self.assertRaises(RuntimeError):
                qa.snapshot(path, other, wrong, {"files": {}})
            with tarfile.open(path, "w") as out:
                item = tarfile.TarInfo("../escape")
                item.size = len(raw)
                out.addfile(item, io.BytesIO(raw))
            with self.assertRaises(RuntimeError):
                qa.snapshot(path, other, expected, {"files": {}})


if __name__ == "__main__":
    unittest.main()
