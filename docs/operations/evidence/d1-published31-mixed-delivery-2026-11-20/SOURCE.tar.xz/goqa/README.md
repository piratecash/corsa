# H-mix current source guards and compile-only test ELF

Root-owned execution only. No Go, service, binary, Docker or VM was run by preparation. Two meaningful pure controller functions PASS (complete JSON test outcomes/new negative required; Git blob/PAX snapshot and path-escape refusal).

Reuses accepted common Job/lock/EOF/cleanup/UNKNOWN behavior. One clean git archive of exactf258, full2726 fixed Git blob/mode/size records and exact two test posts; all resulting files hashed before/after. No ignored archive or unrelated untracked input, no root working-tree writes. Readonly sources and kernel network-deny for Git/Go. No service Run/network tests: five existing findnode global source guards plus two changed pilot source guards, including the new wrong-file caller control.

Then compile ONLY Linuxamd64/CGO0 Node test ELF with localGo1.27.4, tagsinterop,d1_owned_guest_interop; verify static ELF and BuildInfo. The Linux test ELF is NOT executed. Same accepted five toolchain files/dependencies pinned, no downloads.600s work+30s cleanup, softCPU2/GOMEMLIMIT768MiB/-p1;6GiB phase checks and10GiB reserve, RAW1MiB. No live cache/temp traversal: inventories occur only after child completion. Any failure/OOM/timeout/incomplete data stops without repeat/growth; UNKNOWN retains exact own lock.

HANDOFF is a concrete source controller for Root review, not proof of runtime readiness or published31 delivery. Actual build result/ELF/SHA will be needed before BINDING data assembly, then separate runtime source/data readiness. No broad release run/new historical selection or public activation.
