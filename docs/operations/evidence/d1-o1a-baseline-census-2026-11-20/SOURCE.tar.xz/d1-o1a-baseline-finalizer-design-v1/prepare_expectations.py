"""Data-only expectation preparation; never builds or executes the baseline."""
import copy
import difflib
import hashlib
import importlib.util
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[4]
DAY = HERE.parent
BASE = DAY.parent / '2026-11-17/d1-o1a-v2672-build'
GRAPH = DAY.parent / '2026-11-17/d1-o1a-v2672-baseline/LINUX-INPUTS.json'
HELPER = DAY.parent / '2026-11-18/d1-o1a-guest-source-inputs/prepare_sources.py'
POSTS = DAY / 'd1-o1a-member-setup-finalize-v1/posts'
COMMIT = '4fcc2f7245095fc43d2225f0f0065f4ce3b26113'
ARCHIVE_SHA = '7c24787328e87934d135471171b75ed4bf5a91ca558d4de8b4e06711842607ea'
REQUEST_SHA = '745eefbb111b761e76556cc51e02dd735d0baa88779a23237bc336f8aeef30a8'
GRAPH_SHA = 'ad24cd24480aa0e5d8e9881dc7ae9914c22fd3d5217a17cecb9a905e670117c9'
HELPER_SHA = 'ef03517ca302983e39235a56c09baaca3354e7e0bf8791bc9361f71cef43e9ee'
SCOPED = {
 'internal/testutil/loadstand/planned_network_backend_linux.go': ('6dff1b276cc01ba57961e98567b05f54779e566bcde024c1958dd98525a823bd', 'c1aafd3e09f02bc63d5890cb2d605e60337430f8b7f5125389714e657c2ac0ab', 'production_fixture'),
 'internal/testutil/loadstand/planned_network_namespace_linux.go': ('c8bb202a00e84162053ec824a30d189268f3db2cc89ddecbfc1c295f71fd2dc8', '697a1680ccaf6517ac25160330a7a7378a43a7aba7c9d5ddcd93a16f666c1f9f', 'production_fixture'),
 'internal/testutil/loadstand/linux_runtime_start_linux_test.go': ('68c27cd34949a850f0f2c06712774a67a58f69e337724a4f8f28644cb2a8708c', '1d83ba9f57d5386a5035e544320e8dccbfd0fdd0c5128d6ab3af3b52982f9e58', 'existing_authority_inventory_test_maintenance'),
}

def sha(raw):
 return hashlib.sha256(raw).hexdigest()

def apply_overlay(original, posts, pins=SCOPED):
 if set(posts) != set(pins):
  raise ValueError('exact scoped post set required')
 out = dict(original)
 for name, (before, after, _kind) in pins.items():
  if name not in original or sha(original[name]) != before or sha(posts[name]) != after:
   raise ValueError('before/after source differs: ' + name)
  if name.startswith('internal/core/') or not name.startswith('internal/testutil/loadstand/'):
   raise ValueError('overlay outside the closed stand')
  out[name] = posts[name]
 if len(out) != len(original) or {n for n in original if out[n] != original[n]} != set(pins):
  raise ValueError('source identity/count/delta differs')
 return out

def prepare():
 for path, expected in ((HELPER, HELPER_SHA), (BASE/'REQUEST.json', REQUEST_SHA), (GRAPH, GRAPH_SHA)):
  if sha(path.read_bytes()) != expected:
   raise ValueError('pinned input differs: ' + str(path))
 spec = importlib.util.spec_from_file_location('original_source_packer', HELPER)
 helper = importlib.util.module_from_spec(spec)
 spec.loader.exec_module(helper)
 original = helper.load_sources(BASE/'source.tar.gz', ARCHIVE_SHA, COMMIT)
 posts = {n:(POSTS/n).read_bytes() for n in SCOPED}
 result = apply_overlay(original, posts)
 before_groups = helper.manifests(original)
 groups = helper.manifests(result)
 if len(original) != 1345 or groups['measured'] != before_groups['measured']:
  raise ValueError('measured source changed')
 expected_old = {'measured':('b70de373d032b8fed471c6b93bba6d034d932b322495866d40766e7c746fcd9c',640), 'stand':('921f04b57c4f869bde11194a5770de2a2914e172302567b8e897e87581063840',705)}
 for group,(digest,count) in expected_old.items():
  if sha(before_groups[group]) != digest or sum(group in helper.groups(n) for n in result) != count:
   raise ValueError('canonical original group/count differs')
 for name,raw in posts.items():
  target = HERE/'posts'/name
  target.parent.mkdir(parents=True,exist_ok=True)
  target.write_bytes(raw)
 diff = ''.join(''.join(difflib.unified_diff(original[n].decode().splitlines(True),result[n].decode().splitlines(True),fromfile='4fcc/'+n,tofile='4fcc-plus-finalizer/'+n)) for n in sorted(SCOPED))
 (HERE/'SCOPED-THREE.diff').write_text(diff,encoding='utf-8')
 for group,raw in groups.items():
  (HERE/(group+'.expected.manifest')).write_bytes(raw)
 plan = {'scope':'SOURCE_ONLY_NEW_BASELINE_HARNESS_VARIANT_NOT_PUBLISHED_K11','base_commit':COMMIT,
  'base_full_export':{'path':str(BASE/'source.tar.gz'),'sha256':ARCHIVE_SHA,'immutable':True},
  'original_build_request_sha256':REQUEST_SHA,'selected_source_files':len(result),
  'measured_group_unchanged':True,'copy_new_current_regression_test':False,'current_core_or_SDK_source_imported':False,
  'existing_guard_test_post_included':True,'Go_API_validation':'NOT_RUN',
  'new_guest_source_archive_sha256':'NOT_PACKED_NOT_INVENTED','new_four_ELF_sha256':'NOT_BUILT_NOT_INVENTED',
  'allowed_overlay_files':{n:{'before_sha256':v[0],'after_sha256':v[1],'kind':v[2],'bytes':len(posts[n])} for n,v in SCOPED.items()},
  'prospective_groups':{g:{'files':sum(g in helper.groups(n) for n in result),'sha256':sha(raw),'stamp':sha(raw)[:16],'qualification':'CANONICAL_DATA_EXPECTATION_NOT_YET_GO_API_READBACK'} for g,raw in groups.items()},'resources_executed':False}
 graphs={}
 for key,old in json.loads(GRAPH.read_bytes()).items():
  new=copy.deepcopy(old)
  old_graph_sha=new.pop('graph_sha256')
  changed=[]
  for name,(before,after,_kind) in SCOPED.items():
   if name in new['tracked_files']:
    if new['tracked_files'][name] != before:
     raise ValueError('original selected graph source mismatch')
    new['tracked_files'][name]=after
    changed.append(name)
  graphs[key]={'expected_semantic_graph':new,'changed_selected_files':changed,'prior_relocated_graph_sha256':old_graph_sha,'next_actual_graph_sha256':'NOT_RUN'}
 for name,obj in (('SOURCE-PLAN.json',plan),('GRAPH-EXPECTATIONS.json',graphs)):
  (HERE/name).write_text(json.dumps(obj,indent=2,sort_keys=True)+'\n',encoding='utf-8')
 return plan

if __name__ == '__main__':
 result=prepare()
 print(json.dumps({'status':'SOURCE_DATA_CHECKED_NOT_BUILT','groups':result['prospective_groups'],'posts':len(SCOPED)},sort_keys=True))
