# O‑1a: исходный baseline с исправлением завершения сетевой настройки

Статус: SOURCE ONLY. Это новый вариант испытательного стенда от `4fcc2f7245095fc43d2225f0f0065f4ce3b26113`, а не опубликованный K11 и не результат O‑1a. Сборок и запусков этот пакет не выполняет. Готовность runtime остаётся ложной.

## Единственная область изменения

Исходный полный Git-export берётся из неизменяемого `2026-11-17/d1-o1a-v2672-build/source.tar.gz` с SHA `7c24787328e87934d135471171b75ed4bf5a91ca558d4de8b4e06711842607ea`. До изменения проверяются его commit, SHA и исходные хеши каждого разрешённого файла. В собственную свежую копию накладываются ровно три существующих файла:

1. `planned_network_backend_linux.go`: сохраняет исходный индекс member-side peer и вызывает отдельный setup-finalize после UP всех carrier, перед прежней readonly-проверкой.
2. `planned_network_namespace_linux.go`: отдельная закрытая setup-операция сверяет namespace, nonce/имя/исходный индекс, прежнюю строгую квалификацию всего dump и удаление/readback. Поздний readonly/postflight остаётся без мутаций.
3. `linux_runtime_start_linux_test.go`: существующая карта полномочий теста учитывает перенос закрытого запроса в `plannedRequest` и проверку занятого worker. Его before SHA также совпадает с оригинальным 4fcc. Это поддержка прежнего тестового контракта; новый тестовый файл не импортируется.

Первые два файла — единственное изменение исполняемого стенда. Третий не входит в выбранные графы четырёх продуктов, но входит в исходный stand snapshot. Новый `planned_network_finalize_linux_test.go`, текущий c8e subject, текущие core/SDK и unit ELF не используются. Все 1345 выбранных файлов сохраняются на тех же путях; measured 640 файлов остаются побайтно неизменны. Stand остаётся 705 файлов.

Проверенный канонический ожидаемый measured SHA: `b70de373d032b8fed471c6b93bba6d034d932b322495866d40766e7c746fcd9c` (stamp `b70de373d032b8fe`). Новый ожидаемый stand SHA: `52e346f971a30a1da05570e17b4f6133e913eaaf9ea14f433a03fc7575a77aec` (stamp `52e346f971a30a1d`). Это вычисление по данным; readback исходным Go API ещё не выполнен. Старый stand `921f04b57c4f869b` не присваивается изменённым данным.

## Почему четыре исходных продукта

Собираются ровно прежние цели, одинаковыми флагами, из одного baseline+overlay workspace:

| Продукт | Команда Go до общих флагов | Пакет | Модули / пакеты / выбранные файлы |
|---|---|---|---|
| node.test | `test -c` | `./internal/core/node` | 26 / 386 / 1212 |
| loadstand-full | `build` | `./internal/testutil/loadstand/fullnode` | 23 / 342 / 677 |
| loadstand-linuxhelper | `build` | `./internal/testutil/loadstand/linuxhelper` | 5 / 227 / 260 |
| loadstand-sdkedge | `build` | `./internal/testutil/loadstand/sdkedge` | 23 / 343 / 693 |

Именно Node test ELF содержит исходный `TestLoadStandLinuxRouteWireNative`. Текущий unit ELF пакета loadstand не является заменой. В каждом из четырёх исходных графов меняются только хеши двух production fixture файлов. Списки модулей/версии/sums, пакеты, полный набор выбранных файлов и generated test main неизменны. `GRAPH-EXPECTATIONS.json` хранит точные ожидаемые семантические графы. Путь-зависимый SHA сырого `go list` заново записывается как свидетельство; прежний контроллер уже исключал только это поле при семантическом сравнении. Другие расхождения запрещены.

## Минимальная последовательность подготовки

1. Перенести принятый `2026-11-17/d1-o1a-v2672-build/build.py` в новый пакет, заменить только входной subject/ожидаемые графы и собственные пути/claim. До и после overlay проверить полный экспорт и ровно три разрешённых изменения; не применять patch к текущему checkout. Сохранить `go.mod`/`go.sum`, toolchain и per-target module closures. Использовать актуальную принятую обработку OSError/EPERM как UNKNOWN с сохранением результата/lock, а не старое предположение об отсутствии группы.
2. Одним ограниченным job собрать все четыре прежних цели, до/после каждой проверить semantic `go list`, static ARM64 ELF/BuildInfo и исходные входы. Полученные размеры/SHA сейчас неизвестны и не подставляются в готовность.
3. Из того же baseline+3 файла сформировать новый guest source archive прежним USTAR/gzip алгоритмом: ровно 1345 исходников, два канонических manifests, прежние владельцы/права/время. Не выдавать изменённый tar за исходный Git archive с прежним PAX commit. Отдельная provenance-запись связывает base commit, три before/after SHA, новый archive SHA, measured и stand manifests. Base commit — происхождение; полный вариант идентифицируется также archive/overlay/ELF hashes.
4. Обновить только данные в private helper bindings: PID1 `SourceArchiveSHA` и четыре `FrozenArtifacts`, Boot template source rows/четыре ELF rows; capexec `frozen_inputs.h` с новым Node SHA. Потребуются PID1 и capexec сборки после этих фактических результатов, без изменения lifecycle, policy, четырёх capabilities или Go oracle. Exporter не содержит старого source archive/stand stamp и может быть переиспользован побайтно после проверки его unchanged binding contract: base commit + прежний профиль + свежий attempt. Новый archive остаётся обязательным во внешнем/boot binding; одного base commit недостаточно для уникальности subject.
5. Повторно использовать принятые assembler/runtime controllers с точечными фактическими pins нового source archive, helpers и четырёх ELF. Проверить все 1435 cpio members; разрешённые изменения — четыре ELF, source-три файла, stand manifest, два helper, свежий boot config/attempt (число может уточниться только из точного assembler inventory; не принимать wildcard). Kernel `9ffeb24f…`, nft closure, root0755, режимы0555, profiles, окна и oracle остаются прежними. PID1 inventory/source rows, source archive SHA, Go source stamps и journal replay должны согласовываться. Не запускать основной тест до принятого DATA readback.
6. После этого одна исходная periodic попытка. Reconnect — только после полного успеха periodic и известного завершения/очистки. Итог проверяет исходный oracle и полноценный журнал; FAIL/UNKNOWN сохраняются, повторов по тому же subject нет.

## Применимость уже выполненных проверок

Текущие 14 outer / 74 child теста подтверждают логику двух production изменений и существующего guard-контракта на их точных post bytes. Они не являются PASS четырёх baseline ELF или O‑1a. Короткая carrier-проба 3946… квалифицировала/удалила одну собственную ff00 route и не воспроизвела позднее появление в 0/25/100/250 мс. Она не доказывает единственную причину прежнего отказа и не опровергает её. Эта проба выполнялась без seccomp; исходный Go путь сохраняет принятый seccomp2. Новых правил публичной активации, UTC, 512МБ или combined-load этот вариант не добавляет.
