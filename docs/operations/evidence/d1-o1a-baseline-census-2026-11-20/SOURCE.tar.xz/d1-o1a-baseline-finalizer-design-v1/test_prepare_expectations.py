import unittest
import prepare_expectations as p

class OverlayRefusals(unittest.TestCase):
 def setUp(self):
  self.name='internal/testutil/loadstand/fixture_linux.go'
  self.old={self.name:b'old', 'internal/core/node/service.go':b'unchanged product'}
  self.pins={self.name:(p.sha(b'old'),p.sha(b'new'),'production_fixture')}
 def test_exact_existing_fixture_only_preserves_original_mapping(self):
  got=p.apply_overlay(self.old,{self.name:b'new'},self.pins)
  self.assertEqual(self.old[self.name],b'old')
  self.assertEqual(got['internal/core/node/service.go'],b'unchanged product')
  self.assertEqual(set(got),set(self.old))
 def test_new_regression_test_is_not_accepted_as_an_extra_post(self):
  with self.assertRaisesRegex(ValueError,'exact scoped'):
   p.apply_overlay(self.old,{self.name:b'new','internal/testutil/loadstand/new_test.go':b'new'},self.pins)
 def test_old_subject_cannot_be_substituted(self):
  wrong=dict(self.old);wrong[self.name]=b'current unrelated source'
  with self.assertRaisesRegex(ValueError,'before/after'):
   p.apply_overlay(wrong,{self.name:b'new'},self.pins)
 def test_unreviewed_post_bytes_are_rejected(self):
  with self.assertRaisesRegex(ValueError,'before/after'):
   p.apply_overlay(self.old,{self.name:b'new with more changes'},self.pins)
 def test_production_source_cannot_be_authorized_by_a_post_pin(self):
  name='internal/core/node/service.go'
  pins={name:(p.sha(self.old[name]),p.sha(b'new'),'production_fixture')}
  with self.assertRaisesRegex(ValueError,'outside'):
   p.apply_overlay(self.old,{name:b'new'},pins)
 def test_added_baseline_file_does_not_pass_existing_file_requirement(self):
  name='internal/testutil/loadstand/not_in_old.go'
  pins={name:(p.sha(b'old'),p.sha(b'new'),'test')}
  with self.assertRaisesRegex(ValueError,'before/after'):
   p.apply_overlay(self.old,{name:b'new'},pins)

if __name__=='__main__':unittest.main()
