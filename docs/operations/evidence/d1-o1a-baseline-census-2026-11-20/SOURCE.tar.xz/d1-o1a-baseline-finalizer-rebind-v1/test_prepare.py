import copy,json,unittest
from pathlib import Path
import prepare as p
class DeltaTests(unittest.TestCase):
 def fixture(self):
  old={n:{'bytes':1,'sha256':'old-'+n,'mode':'0o100755' if n=='init' or n.startswith('bin/') else '0o100644'} for n in p.EXPECTED_MEMBER_NAMES};old.update({'config/boot.json':{'bytes':10,'sha256':'oldboot','mode':'0o100644'},'usr/sbin/nft':{'bytes':1,'sha256':'fixed','mode':'0o100555'}});e={n:dict(v,sha256='new-'+n) for n,v in old.items() if n in p.EXPECTED_MEMBER_NAMES};new=copy.deepcopy(old);new.update(e);new['config/boot.json']['sha256']='newboot';return old,new,e
 def test_exact_nine_payloads_plus_boot_and_foreign_refusals(self):
  old,new,e=self.fixture();p.exact_member_delta(old,new,e)
  for key in ('usr/sbin/nft','bin/node.test','source/internal/testutil/loadstand/linux_runtime_start_linux_test.go'):
   bad=copy.deepcopy(new);bad[key]['sha256']='foreign'
   with self.assertRaises(ValueError):p.exact_member_delta(old,bad,e)
  bad=copy.deepcopy(new);bad['bin/capexec']['mode']='0o100777'
  with self.assertRaises(ValueError):p.exact_member_delta(old,bad,e)
  bad=copy.deepcopy(new);del bad['bin/node.test']
  with self.assertRaises(ValueError):p.exact_member_delta(old,bad,e)
  del old['bin/node.test']
  with self.assertRaisesRegex(ValueError,'required subject'):p.exact_member_delta(old,bad,e)
 def test_boot_exact_subject_nonce_and_unchanged_oracles(self):
  old,new,e=self.fixture();before={'attempt_id':'a'*32,'source_archive_sha256':'old','workload':'periodic','budget':600,'files':{'/'+n:{k:v[k] for k in ('bytes','sha256')} for n,v in old.items() if n not in ('init','config/boot.json')}};after=copy.deepcopy(before);after.update(attempt_id='b'*32,source_archive_sha256=p.NEW_SOURCE_SHA)
  for n,v in e.items():
   if n!='init':after['files']['/'+n]={k:v[k] for k in ('bytes','sha256')}
  p.exact_boot_delta(before,after,'b'*32,e)
  for key in ('budget','workload','source_archive_sha256'):
   bad=copy.deepcopy(after);bad[key]='foreign'
   with self.assertRaises(ValueError):p.exact_boot_delta(before,bad,'b'*32,e)
  for key in ('/init','/usr/sbin/nft','/source/foreign.go'):
   bad=copy.deepcopy(after);bad['files'][key]={}
   with self.assertRaises(ValueError):p.exact_boot_delta(before,bad,'b'*32,e)
 def test_runtime_source_bytes_only_exact_launch_literal_changes(self):
  f=json.loads((Path(__file__).parent/'FROZEN.PENDING.json').read_text());self.assertEqual(p.OLD.name,'d1-o1a-root-mode-runtime-periodic-v1')
  for n,w in f['old_runtime_sources'].items():self.assertEqual(p.file_hash(p.OLD/n,1024**2),w)
  raw=(p.OLD/'launch.py').read_bytes();old=b'f228fb0e86e351456bde5120fdea5c83c1539682e027017ad5e00ef90a88e838';self.assertEqual(raw.count(old),1);self.assertEqual(raw.replace(old,p.NEW_SOURCE_SHA.encode()).replace(p.NEW_SOURCE_SHA.encode(),old),raw)
if __name__=='__main__':unittest.main()
