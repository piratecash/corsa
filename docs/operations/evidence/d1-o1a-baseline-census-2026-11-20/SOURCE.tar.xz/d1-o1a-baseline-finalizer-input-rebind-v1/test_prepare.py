import copy,json,unittest
from pathlib import Path
import prepare as p

class RebindTests(unittest.TestCase):
 def test_four_header_pins_only_and_exact_match_refusal(self):
  raw=p.read(p.COLD/'frozen_inputs.h');got=p.header_rebind(raw)
  for name,macro in p.MACROS.items():
   self.assertIn(f'#define {macro} "{p.NEW[name]["sha256"]}"'.encode(),got)
   got=got.replace(p.NEW[name]['sha256'].encode(),p.OLD[name]['sha256'].encode())
  self.assertEqual(got,raw)
  with self.assertRaisesRegex(ValueError,'missing/ambiguous'):p.header_rebind(raw+raw)
 def test_frozen_four_artifact_rows_only(self):
  raw=p.read(p.GOOLD/'source/cmd/o1a-init/frozen.go');got=p.frozen_rebind(raw)
  for name in p.OLD:
   before=f'"/bin/{name}":{{Bytes:{p.OLD[name]["bytes"]},SHA256:"{p.OLD[name]["sha256"]}"}}'.encode()
   after=f'"/bin/{name}":{{Bytes:{p.NEW[name]["bytes"]},SHA256:"{p.NEW[name]["sha256"]}"}}'.encode()
   self.assertIn(after,got);got=got.replace(after,before)
  self.assertEqual(got,raw)
 def test_source_archive_constant_only_and_malformed_refusal(self):
  raw=p.read(p.GOOLD/'source/cmd/o1a-init/config.go');got=p.config_rebind(raw,'1'*64)
  self.assertEqual(got.replace(('const SourceArchiveSHA="'+'1'*64+'"').encode(),('const SourceArchiveSHA="'+p.OLD_ARCHIVE+'"').encode()),raw)
  for invalid in ('A'*64,'a'*63):
   with self.assertRaisesRegex(ValueError,'invalid'):p.config_rebind(raw,invalid)
 def template(self):
  rows={'/source/one.go':{'bytes':3,'sha256':p.sha(b'old')},'/bin/capexec':{'bytes':None,'sha256':None},'/bin/journal-export':{'bytes':None,'sha256':None},'/usr/sbin/nft':{'bytes':1,'sha256':'nft'}}
  rows.update({'/bin/'+name:copy.deepcopy(row) for name,row in p.OLD.items()})
  return {'config':{'source_archive_sha256':p.OLD_ARCHIVE,'source_commit':p.BASE_COMMIT,'files':rows,'attempt_id':None},'status':'TEMPLATE_NOT_RUNNABLE','requires':['fresh attempt']}
 def test_template_keeps_null_runtime_and_exact_paths(self):
  old=self.template();got=p.template_rebind(old,{'one.go':b'new'},'2'*64)
  self.assertEqual(got['config']['files']['/source/one.go'],{'bytes':3,'sha256':p.sha(b'new')})
  self.assertEqual(got['config']['files']['/usr/sbin/nft'],old['config']['files']['/usr/sbin/nft'])
  self.assertEqual(got['config']['files']['/bin/capexec'],{'bytes':None,'sha256':None})
  self.assertIsNone(got['config']['attempt_id']);self.assertEqual(old,self.template())
  with self.assertRaisesRegex(ValueError,'inventory'):p.template_rebind(old,{'extra.go':b'new'},'2'*64)
 def test_template_refuses_premature_helper_authority(self):
  old=self.template();old['config']['files']['/bin/capexec']={'bytes':1,'sha256':'invented'}
  with self.assertRaisesRegex(ValueError,'premature'):p.template_rebind(old,{'one.go':b'new'},'2'*64)
 def test_policy_and_original_program_unchanged_pins(self):
  self.assertEqual(p.file_sha(p.COLD/'guest_policy.h'),'699c0a05f15cdf93c620326a2bc1112b53932f06dc08bd6a343076b22416162c')
  self.assertEqual(p.file_sha(p.COLD/'capexec.c'),'e1b4134cccabe88d976b70ca07040fb6b01f208351fe22bc91836bda0fb195a3')
  self.assertEqual(p.file_sha(p.CAP_REFERENCE),'7703f4619287eade9482be86c22572abfda2dc0a1a9685a86437b38bbdafbbd3')

if __name__=='__main__':unittest.main()
