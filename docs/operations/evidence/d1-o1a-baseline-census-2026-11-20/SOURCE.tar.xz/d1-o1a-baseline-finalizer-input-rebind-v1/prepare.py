"""Root-invoked data-only archive and helper source rebinding. Never compile/run ELF."""
import argparse,copy,difflib,hashlib,importlib.util,json,os,shutil,stat,uuid,sys
sys.dont_write_bytecode=True
from pathlib import Path
HERE=Path(__file__).resolve().parent
DAY=HERE.parent
DESIGN=DAY/'d1-o1a-baseline-finalizer-design-v1'
ACTUAL=Path('/private/tmp/corsa-o1a-baseline-finalizer-build-c59004257e11496c84a1ba4a7f37f1e4')
RESULT_SHA='76120cafa089cdaf462c4348da21cc49540304de9af69a44d50ef4c3f9fe405c'
GOOLD=DAY/'d1-o1a-root-mode-fix-v1'
COLD=DAY/'d1-o1a-capexec-seccomp-source-v1'
CFROZEN=DAY/'d1-o1a-capexec-seccomp-build-v1/FROZEN.json'
CAP_REFERENCE=DAY/'d1-o1a-capexec-no-pie-v1/source/capexec.c'
PACKER=DAY.parent/'2026-11-18/d1-o1a-guest-source-inputs/prepare_sources.py'
BASE=DAY.parent/'2026-11-17/d1-o1a-v2672-build'
OLD_ARCHIVE='f228fb0e86e351456bde5120fdea5c83c1539682e027017ad5e00ef90a88e838'
BASE_COMMIT='4fcc2f7245095fc43d2225f0f0065f4ce3b26113'
OLD={
'node.test':{'sha256':'bf6a1a9ae8a4937935d9243ae70796ea0e4dbf90d5cb33964c16ef8a5561ef3e','bytes':68918834},
'loadstand-full':{'sha256':'cfe3d7ba3bde9e362b654e7084f063a2195e8a21c64bac7a536b43035b6d1826','bytes':30912288},
'loadstand-linuxhelper':{'sha256':'c4715d4936d60c5d9aded72eb8fdd02d3e70387eaecaf0241496fb44bcda67b9','bytes':10828086},
'loadstand-sdkedge':{'sha256':'d4a45e865c76d3f68fb0a2903056a5f4f348e212379ee50375c4cb098d5f891d','bytes':33514521}}
NEW={
'node.test':{'sha256':'4722dff4abb832f6d04038022f2a4c56ae06b771bbede8d911300ed61d3b90d1','bytes':68918916},
'loadstand-full':{'sha256':'c46b0812cbc3130e33f885afe14a9e35b7164357646504168189bd6b87b8f1d4','bytes':30912672},
'loadstand-linuxhelper':{'sha256':'7ad3b53bc5906c00e6b47d95af4e70ec4b8292ea677c7f9ebc8a88e7a64e764d','bytes':10827902},
'loadstand-sdkedge':{'sha256':'18f71d236bea79c20b3f3f7cfa171f64d0fe3a55dafff294961dc50e1d9324c3','bytes':33514497}}
MACROS={'node.test':'NODE_SHA','loadstand-full':'FULL_SHA','loadstand-linuxhelper':'HELPER_SHA','loadstand-sdkedge':'TARGET_SHA'}

def need(v,why):
 if not v:raise ValueError(why)
def sha(raw):return hashlib.sha256(raw).hexdigest()
def read(path,cap=2*1024**2):
 s=path.lstat();need(stat.S_ISREG(s.st_mode) and s.st_size<=cap,'bounded ordinary input required')
 with path.open('rb') as f:raw=f.read(s.st_size+1)
 need(len(raw)==s.st_size,'input length changed');return raw

def file_sha(path,cap=96*1024**2):
 s=path.lstat();need(stat.S_ISREG(s.st_mode) and s.st_size<=cap,'bounded ordinary input required')
 h=hashlib.sha256();remaining=s.st_size
 with path.open('rb') as f:
  while remaining:
   raw=f.read(min(remaining,1024**2));need(raw,'truncated input');h.update(raw);remaining-=len(raw)
  need(not f.read(1),'growing input')
 after=path.lstat();immutable=lambda x:(x.st_dev,x.st_ino,x.st_uid,x.st_gid,x.st_mode,x.st_nlink,x.st_size,x.st_mtime_ns,x.st_ctime_ns)
 need(immutable(s)==immutable(after),'input identity changed');return h.hexdigest()

def replace_one(raw,old,new):
 need(raw.count(old)==1,'literal missing/ambiguous')
 return raw.replace(old,new)

def header_rebind(raw):
 for name,macro in MACROS.items():
  raw=replace_one(raw,f'#define {macro} "{OLD[name]["sha256"]}"'.encode(),f'#define {macro} "{NEW[name]["sha256"]}"'.encode())
 return raw

def frozen_rebind(raw):
 for name in OLD:
  before=f'"/bin/{name}":{{Bytes:{OLD[name]["bytes"]},SHA256:"{OLD[name]["sha256"]}"}}'.encode()
  after=f'"/bin/{name}":{{Bytes:{NEW[name]["bytes"]},SHA256:"{NEW[name]["sha256"]}"}}'.encode()
  raw=replace_one(raw,before,after)
 return raw

def config_rebind(raw,archive_sha):
 need(len(archive_sha)==64 and all(c in '0123456789abcdef' for c in archive_sha),'archive SHA invalid')
 return replace_one(raw,('const SourceArchiveSHA="'+OLD_ARCHIVE+'"').encode(),('const SourceArchiveSHA="'+archive_sha+'"').encode())

def template_rebind(old,files,archive_sha):
 result=copy.deepcopy(old);c=result['config'];need(c['source_archive_sha256']==OLD_ARCHIVE and c['source_commit']==BASE_COMMIT and result['status']=='TEMPLATE_NOT_RUNNABLE','old template binding')
 c['source_archive_sha256']=archive_sha
 need({n[8:] for n in c['files'] if n.startswith('/source/')}==set(files),'source path inventory differs')
 for name,raw in files.items():c['files']['/source/'+name]={'bytes':len(raw),'sha256':sha(raw)}
 for name in NEW:
  need(c['files']['/bin/'+name]==OLD[name],'old template binary differs');c['files']['/bin/'+name]=NEW[name]
 need(c['files']['/bin/capexec']=={'bytes':None,'sha256':None} and c['files']['/bin/journal-export']=={'bytes':None,'sha256':None},'premature helper runtime binding')
 return result

def inputs():
 paths=[HERE/'prepare.py',HERE/'test_prepare.py',HERE/'README.ru.md',HERE/'source_api_main.go',PACKER,GOOLD/'FROZEN.json',CFROZEN,CAP_REFERENCE,BASE/'source.tar.gz',BASE/'REQUEST.json',DESIGN/'SOURCE-PLAN.json',DESIGN/'GRAPH-EXPECTATIONS.json',DESIGN/'prepare_expectations.py',DESIGN/'measured.expected.manifest',DESIGN/'stand.expected.manifest',ACTUAL/'result.json',ACTUAL/'source-before.json',ACTUAL/'source-after.json']
 plan=json.loads(read(DESIGN/'SOURCE-PLAN.json'));paths += [DESIGN/'posts'/n for n in plan['allowed_overlay_files']]
 for parent,frozen in ((GOOLD/'source',json.loads(read(GOOLD/'FROZEN.json'))),(COLD,json.loads(read(CFROZEN)))):
  paths += [parent/name for name in frozen['source_files']]
 paths += [ACTUAL/name for name in NEW]
 paths += [ACTUAL/'source/go.mod',ACTUAL/'source/go.sum',ACTUAL/'source/internal/core/node/loadstand_executor_functional_test.go']
 paths += sorted(p for p in (ACTUAL/'source/internal/testutil/runjournal').iterdir() if p.name.endswith('.go') and not p.name.endswith('_test.go'))
 return paths

def check(request):
 raw=read(request);x=json.loads(raw)
 need(x=={'scope':'DATA_ONLY_NEW_BASELINE_HARNESS_INPUTS_NOT_RUNTIME','files':{str(p):{'sha256':file_sha(p),'bytes':p.stat().st_size} for p in inputs()}},'input freeze differs')
 need(file_sha(ACTUAL/'result.json')==RESULT_SHA,'actual build result changed')
 r=json.loads(read(ACTUAL/'result.json'));need(r['status']=='BUILT_NOT_EXECUTED' and r['artifacts']==NEW and r['commit']==BASE_COMMIT,'actual build subject')
 for parent,frozen in ((GOOLD/'source',json.loads(read(GOOLD/'FROZEN.json'))),(COLD,json.loads(read(CFROZEN)))):
  for name,row in frozen['source_files'].items():need(file_sha(parent/name)==row['sha256'] and (parent/name).stat().st_size==row['bytes'],'old helper source differs')
 return sha(raw)

def prepare(approved):
 need(check(HERE/'INPUTS.json')==approved,'exact input SHA required')
 out=Path('/private/tmp')/('corsa-o1a-baseline-finalizer-inputs-'+uuid.uuid4().hex);out.mkdir(mode=0o700);print(json.dumps({'stage':'DATA_PREPARATION_STARTED','owned_output':str(out)}),flush=True)
 spec=importlib.util.spec_from_file_location('accepted_packer',PACKER);packer=importlib.util.module_from_spec(spec);spec.loader.exec_module(packer)
 original=packer.load_sources(BASE/'source.tar.gz','7c24787328e87934d135471171b75ed4bf5a91ca558d4de8b4e06711842607ea',BASE_COMMIT)
 plan=json.loads(read(DESIGN/'SOURCE-PLAN.json'));files=dict(original)
 for name,pin in plan['allowed_overlay_files'].items():
  post=read(DESIGN/'posts'/name);need(sha(files[name])==pin['before_sha256'] and sha(post)==pin['after_sha256'],'source delta changed');files[name]=post
 need(len(files)==1345 and set(files)==set(original),'selected source inventory differs')
 for group,raw in packer.manifests(files).items():need(raw==read(DESIGN/(group+'.expected.manifest')),'source group differs')
 built_after=json.loads(read(ACTUAL/'source-after.json'))
 need(all(built_after[n]==sha(raw) for n,raw in files.items()),'archive source differs from actual compilation subject')
 packed=packer.pack(out/'guest-sources.tar.gz',files)
 packed['scope']='BASELINE_4FCC_PLUS_THREE_EXISTING_STAND_POSTS_NOT_PUBLISHED_K11'
 packed['base_commit']=packed.pop('commit');packed['base_export_build_request_sha256']=packed.pop('build_request_sha256')
 packed['actual_four_ELF_result_sha256']=RESULT_SHA;packed['build_request_sha256']='64c23df1411d6e0900f7056a36d43e71d91c94f4368366cf838f104a4ed68cd4';packed['overlay']=plan['allowed_overlay_files'];packed['Go_source_API_readback']='NOT_RUN'
 archive_sha=packed['archive_sha256'];(out/'SOURCE-ARCHIVE.json').write_text(json.dumps(packed,indent=2,sort_keys=True)+'\n')
 tree=out/'source-tree';tree.mkdir(mode=0o700)
 for name,raw in files.items():
  target=tree/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw)
 manifestdir=out/'manifests';manifestdir.mkdir()
 for group,raw in packer.manifests(files).items():(manifestdir/(group+'.manifest')).write_bytes(raw)
 module=out/'source-api-module';module.mkdir(mode=0o700);api_records={}
 for source in [ACTUAL/'source/go.mod',ACTUAL/'source/go.sum',*sorted(p for p in (ACTUAL/'source/internal/testutil/runjournal').iterdir() if p.name.endswith('.go') and not p.name.endswith('_test.go'))]:
  rel=source.relative_to(ACTUAL/'source').as_posix();raw=read(source);need(built_after[rel]==sha(raw),'original Go API source differs')
  target=module/rel;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw);api_records[rel]={'sha256':sha(raw),'bytes':len(raw)}
 target=module/'cmd/source-api-readback/main.go';target.parent.mkdir(parents=True);target.write_bytes(read(HERE/'source_api_main.go'))
 manifests={};deltas={}
 for kind,oldroot,frozen in [('pid1-source',GOOLD/'source',json.loads(read(GOOLD/'FROZEN.json'))),('capexec-source',COLD,json.loads(read(CFROZEN)))]:
  dest=out/kind;dest.mkdir(mode=0o700);records={};changed=[];diff=[]
  for name,row in frozen['source_files'].items():
   raw=read(oldroot/name);new=raw
   if kind=='pid1-source':
    if name=='cmd/o1a-init/config.go':new=config_rebind(raw,archive_sha)
    elif name=='cmd/o1a-init/frozen.go':new=frozen_rebind(raw)
    elif name=='BOOT-CONFIG.TEMPLATE.json':new=(json.dumps(template_rebind(json.loads(raw),files,archive_sha),indent=2,sort_keys=True)+'\n').encode()
   elif name=='frozen_inputs.h':new=header_rebind(raw)
   elif name=='test_source_binding.py':
    new=replace_one(raw,b"        self.assertEqual((HERE/'frozen_inputs.h').read_bytes(),(HERE.parent/'d1-o1a-capexec-no-pie-v1/source/frozen_inputs.h').read_bytes())",('        self.assertEqual(hashlib.sha256((HERE/\'frozen_inputs.h\').read_bytes()).hexdigest(),'+repr(sha(header_rebind(read(COLD/'frozen_inputs.h'))))+')').encode())
   if kind=='capexec-source' and name=='test_source_binding.py':
    new=replace_one(new,b"old=(HERE.parent/'d1-o1a-capexec-no-pie-v1/source/capexec.c').read_text()",('old=Path('+repr(str(CAP_REFERENCE))+').read_text()').encode())
   target=dest/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(new)
   records[name]={'sha256':sha(new),'bytes':len(new)}
   if new!=raw:
    changed.append(name);diff.extend(difflib.unified_diff(raw.decode().splitlines(True),new.decode().splitlines(True),fromfile=kind+'/before/'+name,tofile=kind+'/after/'+name))
  expected={'BOOT-CONFIG.TEMPLATE.json','cmd/o1a-init/config.go','cmd/o1a-init/frozen.go'} if kind=='pid1-source' else {'frozen_inputs.h','test_source_binding.py'}
  need(set(changed)==expected,'unexpected helper source delta')
  (dest/'SHA256SUMS').write_text(''.join(v['sha256']+'  '+n+'\n' for n,v in sorted(records.items())))
  manifests[kind]={'source_files':records,'source_sums_sha256':file_sha(dest/'SHA256SUMS'),'source_path':str(dest)};deltas[kind]=changed
  (out/(kind+'.diff')).write_text(''.join(diff))
 need(check(HERE/'INPUTS.json')==approved,'inputs changed during preparation')
 result={'status':'SOURCE_ARCHIVE_AND_HELPER_BINDINGS_PREPARED_NOT_COMPILED_NOT_RUNTIME','input_sha256':approved,'output':str(out),'archive':{'path':str(out/'guest-sources.tar.gz'),'bytes':packed['archive_bytes'],'sha256':archive_sha},'source_groups':packed['source_groups'],'actual_four_ELF':NEW,'helper_sources':manifests,'helper_changed_files':deltas,'Go_source_API_readback':{'status':'NOT_RUN','cwd':str(module),'go_arguments':['run','-mod=readonly','-buildvcs=false','-p=1','./cmd/source-api-readback','--source-tree',str(tree),'--manifests',str(manifestdir)],'original_API_source_files':api_records,'private_command_sha256':file_sha(HERE/'source_api_main.go')},'exporter_reused_sha256':'36ed540a1dab92f28752a0fe80eef641ca4d4a04cb259ea5c0abe3ce8f79706f','policy_unchanged_sha256':'699c0a05f15cdf93c620326a2bc1112b53932f06dc08bd6a343076b22416162c','PID1_ELF':'NOT_BUILT','capexec_ELF':'NOT_BUILT','runtime_ready':False,'resource_execution':False}
 need(sum(p.stat().st_size for p in out.rglob('*') if p.is_file())<=64*1024**2,'output phase files exceeded64MiB')
 (out/'RESULT.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n');print(json.dumps({'result':str(out/'RESULT.json'),'status':result['status'],'archive_sha256':archive_sha,'groups':packed['source_groups']},sort_keys=True))

if __name__=='__main__':
 parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--execute');a=parser.parse_args()
 if a.execute:prepare(a.execute)
 else:print(check(HERE/'INPUTS.json'))
