import copy,json,tempfile,unittest
from pathlib import Path
import assemble as a
class AssemblyTests(unittest.TestCase):
 def test_actual_archive_and_exact_new_template(self):
  c=json.loads((a.INPUTS/'pid1-source/BOOT-CONFIG.TEMPLATE.json').read_text())['config']['files'];f,m=a.source_files(a.INPUTS/'guest-sources.tar.gz',c);self.assertEqual(len(f),1345)
  self.assertEqual(m['manifests/measured.manifest']['sha256'],'b70de373d032b8fed471c6b93bba6d034d932b322495866d40766e7c746fcd9c');self.assertEqual(m['manifests/stand.manifest']['sha256'],'52e346f971a30a1da05570e17b4f6133e913eaaf9ea14f433a03fc7575a77aec')
  c=copy.deepcopy(c);c['/source/internal/testutil/loadstand/planned_network_backend_linux.go']['sha256']='0'*64
  with self.assertRaises(AssertionError):a.source_files(a.INPUTS/'guest-sources.tar.gz',c)
 def test_audited_modes_and_cpio_readback(self):
  with tempfile.TemporaryDirectory(dir='/private/tmp') as d:
   r=a.pack(Path(d)/'tiny.gz',{'init':b'i','bin/loadstand-full':b'f','bin/loadstand-linuxhelper':b'h','bin/loadstand-sdkedge':b's','usr/sbin/nft':b'n','source/a.go':b'package a'})
   for n in ('bin/loadstand-full','bin/loadstand-linuxhelper','bin/loadstand-sdkedge','usr/sbin/nft'):self.assertEqual(r['members'][n]['mode'],'0o100555')
   self.assertEqual(r['members']['init']['mode'],'0o100755');self.assertEqual(r['members']['source/a.go']['mode'],'0o100644')
 def test_pending_helpers_refused(self):
  import pack_job
  with self.assertRaisesRegex(RuntimeError,'actual helper records'):pack_job.check(json.loads((Path(__file__).parent/'PACK-FROZEN.PENDING.json').read_text()))
