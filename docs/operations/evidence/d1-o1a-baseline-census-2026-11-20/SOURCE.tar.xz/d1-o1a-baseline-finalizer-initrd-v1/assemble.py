"""Data-only O1a initramfs assembly; no guest or ELF execution."""
from pathlib import Path, PurePosixPath
import copy
import gzip
import hashlib
import importlib.util
import io
import json
import re
import stat
import tarfile

HERE=Path(__file__).resolve().parent
DAY=HERE.parent
SOURCE_SHA='71569cb33f466e7d3a896bcdf6e4fd2463b333db3b45339ae70c0661b20763c9'
INPUTS=Path('/private/tmp/corsa-o1a-baseline-finalizer-inputs-cc481326e8504a94a20da6c792be66c4')
MAX_TOTAL=256*1024**2
MAX_FILE=96*1024**2

def sha(raw):return hashlib.sha256(raw).hexdigest()

def safe_name(name):
    return isinstance(name,str) and 0<len(name)<=1024 and name.isascii() and not any(c in name for c in '\\\r\n\x00') and not name.startswith('/') and all(p not in ('','.','..') for p in name.split('/'))

def exact(path,record):
    assert not path.is_symlink() and path.is_file(),'regular input required'
    before=path.stat()
    assert before.st_nlink==1 and 0<before.st_size<=MAX_FILE and before.st_size==record['bytes']
    with path.open('rb') as stream:raw=stream.read(before.st_size+1)
    after=path.stat()
    assert (before.st_dev,before.st_ino,before.st_size,before.st_mtime_ns,before.st_ctime_ns)==(after.st_dev,after.st_ino,after.st_size,after.st_mtime_ns,after.st_ctime_ns)
    assert len(raw)==record['bytes'] and sha(raw)==record['sha256'],'input content differs'
    return raw

def source_files(archive,expected):
    verified=exact(archive,{'bytes':4914874,'sha256':SOURCE_SHA})
    result={};seen=set();total=0;count=0;directories=0;metadata={}
    with tarfile.open(fileobj=io.BytesIO(verified),mode='r:gz') as tar:
        for member in tar:
            count+=1;assert count<=8192 and safe_name(member.name) and member.name not in seen
            seen.add(member.name)
            assert not member.pax_headers and not member.linkname and member.uid==0 and member.gid==0
            if member.isdir():
                directories+=1;assert directories<=4096
                continue
            assert member.isfile() and 0<member.size<=8*1024**2
            total+=member.size;assert total<=32*1024**2
            with tar.extractfile(member) as stream:raw=stream.read(member.size+1)
            assert len(raw)==member.size
            if member.name.startswith('source/'):
                key='/'+member.name
                assert member.name.endswith('.go') and key in expected
                assert {'bytes':len(raw),'sha256':sha(raw)}==expected[key]
                result[member.name]=raw
            else:
                assert member.name in ('manifests/measured.manifest','manifests/stand.manifest')
                metadata[member.name]={'bytes':len(raw),'sha256':sha(raw)}
    assert len(result)==1345 and {'/'+name for name in result}=={p for p in expected if p.startswith('/source/')}
    assert set(metadata)=={'manifests/measured.manifest','manifests/stand.manifest'}
    return result,metadata

def record(raw):return {'bytes':len(raw),'sha256':sha(raw)}

def helper_record(path):
    assert not path.is_symlink() and path.is_file()
    size=path.stat().st_size;assert 0<size<=16*1024**2
    with path.open('rb') as stream:raw=stream.read(size+1)
    assert len(raw)==size
    return record(raw)

def cpio_header(name,ino,mode,size):
    major,minor=(5,1) if name=='dev/console' else (0,0)
    fields=(ino,mode,0,0,2 if stat.S_ISDIR(mode) else 1,0,size,0,0,major,minor,len(name.encode('ascii'))+1,0)
    return ('070701'+''.join(f'{v:08x}' for v in fields)).encode('ascii')

def member(stream,name,ino,mode,raw):
    encoded=name.encode('ascii')+b'\0'
    stream.write(cpio_header(name,ino,mode,len(raw)));stream.write(encoded);stream.write(b'\0'*((-110-len(encoded))%4))
    stream.write(raw);stream.write(b'\0'*((-len(raw))%4))

def verify(output,rows):
    def read(stream,n):
        raw=stream.read(n);assert len(raw)==n,'truncated cpio';return raw
    with gzip.open(output,'rb') as stream:
        for ino,(name,mode,raw) in enumerate([*rows,('TRAILER!!!',0,b'')],1):
            assert read(stream,110)==cpio_header(name,ino,mode,len(raw))
            encoded=name.encode('ascii')+b'\0';assert read(stream,len(encoded))==encoded
            assert read(stream,(-110-len(encoded))%4).strip(b'\0')==b''
            assert sha(read(stream,len(raw)))==sha(raw)
            assert read(stream,(-len(raw))%4).strip(b'\0')==b''
        assert stream.read(1)==b'','trailing cpio data'

def pack(output,files):
    assert len(files)<=4096 and sum(len(raw) for raw in files.values())<=MAX_TOTAL
    assert all(safe_name(name) and 0<len(raw)<=MAX_FILE for name,raw in files.items())
    directories={'dev','proc','sys','tmp','profiles','config','usr/local/lib'}
    for name in files:
        directories.update(str(p) for p in PurePosixPath(name).parents if str(p)!='.')
    assert len(directories)<=4096 and not directories.intersection(files)
    rows=[(n,stat.S_IFDIR|0o755,b'') for n in sorted(directories,key=lambda n:(n.count('/'),n))]
    rows.append(('dev/console',stat.S_IFCHR|0o600,b''))
    for name,raw in sorted(files.items()):
        executable=name=='init' or name.startswith(('bin/','lib/','usr/lib/','usr/sbin/'))
        audited=name in {"bin/loadstand-full","bin/loadstand-linuxhelper","bin/loadstand-sdkedge","usr/sbin/nft"}
        rows.append((name,stat.S_IFREG|(0o555 if audited else 0o755 if executable else 0o644),raw))
    assert len({name for name,_,_ in rows})==len(rows)
    with output.open('xb') as out:
        with gzip.GzipFile(fileobj=out,mode='wb',filename='',mtime=0) as stream:
            for ino,(name,mode,raw) in enumerate(rows,1):member(stream,name,ino,mode,raw)
            member(stream,'TRAILER!!!',len(rows)+1,0,b'')
    assert output.stat().st_size<=128*1024**2
    verify(output,rows)
    return {'archive':record(output.read_bytes()),'members':{name:{'mode':oct(mode),'bytes':len(raw),'sha256':sha(raw)} for name,mode,raw in rows}}

def assemble(output,workload,attempt,init,capexec,exporter):
    assert workload in ('periodic','reconnect') and re.fullmatch('[a-f0-9]{32}',attempt)
    template=json.loads((INPUTS/'pid1-source/BOOT-CONFIG.TEMPLATE.json').read_bytes())
    config=copy.deepcopy(template['config']);config.update(workload=workload,attempt_id=attempt,production_probe='2.26.72.130:64646',fallback_probe='1.1.1.1:443',ipv6_probe='[2001:4860:4860::8888]:443')
    files,metadata=source_files(INPUTS/'guest-sources.tar.gz',config['files'])
    names={'node.test':'node.test','loadstand-full':'loadstand-full','loadstand-linuxhelper':'loadstand-linuxhelper','loadstand-sdkedge':'loadstand-sdkedge'}
    baseline=Path('/private/tmp/corsa-o1a-baseline-finalizer-build-c59004257e11496c84a1ba4a7f37f1e4')
    for name,local in names.items():files['bin/'+name]=exact(baseline/local,config['files']['/bin/'+name])
    closure=DAY/'d1-o1a-library-closure-result-v1/closure/rootfs'
    for name,wanted in config['files'].items():
        if name.startswith(('/lib/','/usr/lib/','/usr/local/lib/')) or name=='/usr/sbin/nft':files[name[1:]]=exact(closure/name[1:],wanted)
    for phase in ('periodic','reconnect'):
        key='config/'+phase+'.json';files[key]=exact(DAY.parent/'2026-11-17/d1-o1a-v2672-baseline'/(phase+'.json'),config['files']['/'+key])
    assert config['files']['/config/'+workload+'.json']['sha256']==sha(files['config/'+workload+'.json'])
    config['profile_sha256']=sha(files['config/'+workload+'.json'])
    spec=importlib.util.spec_from_file_location('static',DAY/'d1-full512-devnull-fix-v1/package_initrd.py');static=importlib.util.module_from_spec(spec);spec.loader.exec_module(static)
    for name,path in [('init',init),('bin/capexec',capexec),('bin/journal-export',exporter)]:
        raw=exact(path,helper_record(path));static.require_static_arm64(raw);files[name]=raw
        if name!='init':config['files']['/'+name]=record(raw)
    assert {'/'+name for name in files if name!='init'}==set(config['files'])
    assert all(record(files[name[1:]])==wanted for name,wanted in config['files'].items())
    boot=json.dumps(config,sort_keys=True,separators=(',',':')).encode('ascii')+b'\n';assert len(boot)<=1024**2
    files['config/boot.json']=boot
    result=pack(output,files)
    result.update(scope='INITRAMFS_DATA_READBACK_ONLY',workload=workload,attempt_id=attempt,config_sha256=sha(boot),boot_arguments=f'corsa.o1a=1 corsa.o1a_workload={workload} corsa.o1a_attempt={attempt} corsa.o1a_config_sha={sha(boot)}',source_archive_sha256=SOURCE_SHA,source_files=1345,source_manifests=metadata,elf_or_vm_executed=False)
    return result
