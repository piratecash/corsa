"""Independent retained-byte replay. Transport/Go PASS does not replace journal review."""
from pathlib import Path
import hashlib,json,sys
HERE=Path(__file__).resolve().parent
REFERENCE=HERE.parent/'d1-o1a-guest-preparation-v1'
sys.path.insert(0,str(REFERENCE))
import journal_capsule
from support import need
SECOND=10**9
SOURCE='4fcc2f7245095fc43d2225f0f0065f4ce3b26113'
PROFILE='d1-o1a-native-v1'
PROFILES={'periodic':'28e76a342c9b28b8a2e1495f181f2463b35c04d64a268c705b55d789edd7791d','reconnect':'36a65318713e5b4cb795749a4a5e12424cdfe905760f3a352b7ac602040621de'}

def decode(raw):return journal_capsule.decode_json(raw)
def digest(raw):return hashlib.sha256(raw).hexdigest()

def check_capture(row,raw,limit):
    need(type(row) is dict and set(row)=={'received','retained','eof','sha256'},'capture schema')
    need(type(raw) is bytes and len(raw)<=limit and row['eof'] is True,'RAW bound/EOF')
    need(all(type(row[k]) is int and row[k]==len(raw) for k in ('received','retained')) and row['sha256']==digest(raw),'RAW coverage/hash')

def check_lifecycle(expected,receipt,console,native,stderr):
    need(receipt['input_recheck'] is True and all(receipt.get(k)==v for k,v in expected.items()),'receipt input binding')
    need(receipt['controller_stop'] is False and receipt['outer_kill'] is False and receipt['stop_reason'] is None and receipt['worker_reaped'] is True and receipt['owned_group_absent'] is True and receipt['capture_complete'] is True,'host intervention/incomplete')
    need(type(receipt['worker_exit']) is int and receipt['worker_exit']==0,'worker not normal exit0')
    need(set(receipt['captures'])=={'console','native','stderr'},'three RAW required')
    for name,raw,limit in [('console',console,32*1024**2),('native',native,16384),('stderr',stderr,4096)]:check_capture(receipt['captures'][name],raw,limit)
    need(not stderr,'unexpected native stderr')
    need(native.endswith(b'\n'),'truncated native JSONL line')
    rows=[decode(line) for line in native.splitlines()]
    stages=('ready','start_ok','guest_stopped','stop_complete');evidence=({}, {}, {'guest_error':None},{'final_state':'stopped'})
    need(len(rows)==4,'native event count');previous=-1
    for seq,(row,event,extra) in enumerate(zip(rows,stages,evidence),1):
        need(set(row)=={'attempt_id','profile','workload','config_sha256','seq','event','elapsed_ns',*extra},'native event schema')
        need(row['profile']==PROFILE and all(row[k]==expected[k] for k in ('attempt_id','workload','config_sha256')),'native binding')
        need(type(row['seq']) is int and row['seq']==seq and row['event']==event and all(row[k]==v for k,v in extra.items()),'native stage/order/evidence')
        need(type(row['elapsed_ns']) is int and previous<row['elapsed_ns']<(680 if event=='stop_complete' else 660)*SECOND,'native time')
        previous=row['elapsed_ns']
    need(type(receipt['worker_reaped_ns']) is int and previous<=receipt['worker_reaped_ns']<698*SECOND,'reap fence')
    return rows

def guest_receipt(expected,console):
    prefix=b'O1A_INIT_RESULT_V1 '
    rows=[decode(line[len(prefix):]) for line in console.splitlines() if line.startswith(prefix)]
    need(len(rows)==1,'one final guest receipt required');row=rows[0]
    need(all(row[k]==expected[k] for k in ('attempt_id','workload','config_sha256')),'guest binding')
    need(row['source_commit']==SOURCE and row['profile_sha256']==PROFILES[expected['workload']] and row['input_files']==1363,'guest source/profile inputs')
    need(row['inputs_verified'] is True and row['initial_lo_checked'] is True and row['all_children_reaped'] is True and row['poweroff_attempt'] is True,'guest input/isolation/reap facts')
    need(type(row['guest_elapsed_ns']) is int and 0<row['guest_elapsed_ns']<650*SECOND,'guest time')
    return row

def successful_guest(row,console):
    need(row['state']=='TEST_EXIT_ZERO_CAPSULE_EXPORTED' and row['stage']=='completed' and row['export_started'] is True,'guest functional/export outcome')
    pids=set()
    for name in ('test','export'):
        child=row[name]
        need(set(child)=={'pid','exit','reaped','all_children_reaped','term_sent','kill_sent','log_complete','log_overflow','normal'},'child receipt schema')
        need(type(child['pid']) is int and child['pid']>1 and child['pid'] not in pids,'child PID');pids.add(child['pid'])
        need(type(child['exit']) is int and child['exit']==0 and all(child[k] is True for k in ('reaped','all_children_reaped','log_complete','normal')) and all(child[k] is False for k in ('term_sent','kill_sent','log_overflow')),'child normal/reap/drain')
    lines=console.splitlines()
    need(sum(line==b'=== RUN   TestLoadStandLinuxRouteWireNative' for line in lines)==1,'exact Go RUN')
    need(sum(line.startswith(b'--- PASS: TestLoadStandLinuxRouteWireNative (') for line in lines)==1,'exact Go PASS')
    need(sum(line==b'PASS' for line in lines)==1 and not any(line.lstrip().startswith((b'--- FAIL:',b'--- SKIP:',b'FAIL',b'panic:')) for line in lines),'Go FAIL/SKIP/panic')

def replay(expected,receipt,console,native,stderr):
    lifecycle=check_lifecycle(expected,receipt,console,native,stderr)
    guest=guest_receipt(expected,console);successful_guest(guest,console)
    binding={'workload':expected['workload'],'attempt_id':expected['attempt_id'],'profile_sha256':PROFILES[expected['workload']],'source_commit':SOURCE}
    files=journal_capsule.decode(console,binding)
    need(bool(files),'empty journal')
    return {'scope':'TRANSPORT_AND_ORIGINAL_GO_PASS_PENDING_JOURNAL_REVIEW','native':lifecycle,'guest':guest,'journal_files':{name:{'bytes':len(raw),'sha256':digest(raw)} for name,raw in files.items()}},files
