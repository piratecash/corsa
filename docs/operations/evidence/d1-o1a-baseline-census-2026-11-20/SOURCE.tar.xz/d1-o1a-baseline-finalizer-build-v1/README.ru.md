# Четыре исходных O‑1a продукта с ограниченным fixture overlay

SOURCE/CODE пакет, не выполненная сборка. Прежний build.py сохранён как основа; OLD-TO-NEW.diff перечисляет точечную адаптацию subject/overlay/графов/own claim и сохранение UNKNOWN процесса. Никаких новых build flags, целей или module closures.

`REQUEST.json` SHA-256 `64c23df1411d6e0900f7056a36d43e71d91c94f4368366cf838f104a4ed68cd4`. Readonly preflight (без spawn/lock):

```sh
python3 /Users/hades/Documents/repos/corsa/docs/_internal/d1-artifacts/2026-11-20/d1-o1a-baseline-finalizer-build-v1/build.py
```

После Root/Critic CODE и свободного heavy-lock Root запускает ровно один job:

```sh
python3 /Users/hades/Documents/repos/corsa/docs/_internal/d1-artifacts/2026-11-20/d1-o1a-baseline-finalizer-build-v1/build.py --execute 64c23df1411d6e0900f7056a36d43e71d91c94f4368366cf838f104a4ed68cd4
```

Команда не запускает ELF. Успех обязан дать четыре точных ELF +16 command receipts/RAW, strict semantic graph before/after, BuildInfo/ABI, полный before/after source manifest и неизменность источников. После STOP повтор не выполняется; UNKNOWN сохраняет result и живой own HOLD.

Ожидаемая основа: 4fcc2f7245095fc43d2225f0f0065f4ce3b26113 +2 production fixture posts +существующий authority guard-map test. Подробнее SOURCE-PLAN/GRAPH-EXPECTATIONS в ../d1-o1a-baseline-finalizer-design-v1. Новый regression test/current c8e subject/unit ELF не используются. Measured640 unchanged; stand705/new stamp52e346f971a30a1d. Это не опубликованный K11 и не O‑1a PASS.
