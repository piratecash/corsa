# О‑1а: capexec для четырёх исправленных baseline ELF

Сохраняются проверенные C body, историческая seccomp policy и compiler flags.
Меняются только четыре SHA-макроса frozen_inputs.h. Новый capexec не исполняется;
исполняется лишь прежний чистый dumper фабрики BPF, без установки фильтра.

Один job до 180 секунд плюс 30 секунд очистки, heavy-lock, минимум 10 GiB
свободно, собственные файлы до 64 MiB по фазовым проверкам и RAW до 1 MiB.
Один собственный контейнер из существующего закреплённого образа45ccc…:
1 CPU / 1024 MiB / 64 PID без swap; UID501:20, network none, read-only root,
CapDropALL/NNP, private namespaces, два bind mounts только свежих собственных
каталогов input RO/output RW, /tmp tmpfs128 MiB. Скачиваний и новых образов нет.

Проверяется полный inspect, static ET_EXEC ARM64, точные policy bytes, полный
RAW и остановка/удаление только собственного контейнера. Неоднозначный create,
неизвестное завершение или неполные данные удерживают lock для восстановления.
Ошибка/OOM/таймаут — STOP без повторов и роста лимитов. Общих host hard caps,
гарантии no-swap и жёсткой дисковой квоты нет; зависший I/O может превысить
программный срок. Corsad/piratecashd/VM не запускаются. Это не runtime PASS.
