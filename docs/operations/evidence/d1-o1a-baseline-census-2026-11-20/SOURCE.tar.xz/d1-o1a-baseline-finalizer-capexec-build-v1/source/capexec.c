#define _GNU_SOURCE
#include <errno.h>
#include <fcntl.h>
#include <inttypes.h>
#include <linux/capability.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/prctl.h>
#include <sys/resource.h>
#include <sys/stat.h>
#include <sys/syscall.h>
#include <sys/socket.h>
#include <unistd.h>
#include "frozen_inputs.h"
#include "guest_policy.h"

/* Static, single-threaded, fixed-entry wrapper. Never accepts shell/argv paths. */
#define ALLOWED ((UINT64_C(1)<<CAP_SETGID)|(UINT64_C(1)<<CAP_SETUID)|(UINT64_C(1)<<CAP_NET_ADMIN)|(UINT64_C(1)<<CAP_SYS_ADMIN))
struct status { uint64_t inh,prm,eff,bnd,amb; unsigned nnp,threads,seccomp,filters; };
static void fail(const char *stage) { fprintf(stderr,"O1A_CAPEXEC_FAIL stage=%s errno=%d\n",stage,errno); _exit(125); }
static void require(int ok,const char *stage) { if(!ok) {errno=EINVAL;fail(stage);} }
static struct status read_status(void) {
    FILE *f=fopen("/proc/self/status","re"); if(!f)fail("status-open");
    struct status s={0}; char line[512]; unsigned seen=0;
    while(fgets(line,sizeof(line),f)) {
        if(sscanf(line,"CapInh: %" SCNx64,&s.inh)==1)seen|=1;
        else if(sscanf(line,"CapPrm: %" SCNx64,&s.prm)==1)seen|=2;
        else if(sscanf(line,"CapEff: %" SCNx64,&s.eff)==1)seen|=4;
        else if(sscanf(line,"CapBnd: %" SCNx64,&s.bnd)==1)seen|=8;
        else if(sscanf(line,"CapAmb: %" SCNx64,&s.amb)==1)seen|=16;
        else if(sscanf(line,"NoNewPrivs: %u",&s.nnp)==1)seen|=32;
        else if(sscanf(line,"Threads: %u",&s.threads)==1)seen|=64;
        else if(sscanf(line,"Seccomp: %u",&s.seccomp)==1)seen|=128;
        else if(sscanf(line,"Seccomp_filters: %u",&s.filters)==1)seen|=256;
    }
    if(ferror(f)||fclose(f))fail("status-read-close");
    require(seen==511,"status-fields"); return s;
}
static void report(struct status s) {
    printf("O1A_CAPEXEC_STATUS uid=%lu euid=%lu gid=%lu egid=%lu threads=%u inh=%016" PRIx64 " prm=%016" PRIx64 " eff=%016" PRIx64 " bnd=%016" PRIx64 " amb=%016" PRIx64 " nnp=%u seccomp=%u filters=%u\n",(unsigned long)getuid(),(unsigned long)geteuid(),(unsigned long)getgid(),(unsigned long)getegid(),s.threads,s.inh,s.prm,s.eff,s.bnd,s.amb,s.nnp,s.seccomp,s.filters);
    if(fflush(stdout))fail("report-flush");
}
static int last_cap(void) {
    FILE *f=fopen("/proc/sys/kernel/cap_last_cap","re"); if(!f)fail("last-cap-open");
    unsigned value=0;char extra;int count=fscanf(f,"%u %c",&value,&extra);
    if (fclose(f)) {
        fail("last-cap-close");
    }
    require(count==1&&value<64,"last-cap-range");
    return (int)value;
}
static const char *copy_env(const char *name) {
    const char *value=getenv(name);require(value&&*value&&strlen(value)<=8192,"required-env");
    size_t n=strlen(name)+strlen(value)+2;char *row=malloc(n);if(!row)fail("env-memory");
    require(snprintf(row,n,"%s=%s",name,value)==(int)n-1,"env-format");return row;
}
static void restrict_caps(void) {
    struct rlimit core={0,0};if(setrlimit(RLIMIT_CORE,&core))fail("core-zero");
    if(prctl(PR_CAP_AMBIENT,PR_CAP_AMBIENT_CLEAR_ALL,0,0,0))fail("ambient-clear");
    /* Dropping SETPCAP from bounding does not remove its current effective bit. */
    int last=last_cap();for(int cap=0;cap<=last;cap++)if(!(ALLOWED&(UINT64_C(1)<<cap)))if(prctl(PR_CAPBSET_DROP,cap,0,0,0))fail("bounding-drop");
    struct __user_cap_header_struct header={_LINUX_CAPABILITY_VERSION_3,0};
    struct __user_cap_data_struct data[2]={{0}};
    data[0].effective=data[0].permitted=(uint32_t)ALLOWED;
    data[1].effective=data[1].permitted=(uint32_t)(ALLOWED>>32);
    if(syscall(SYS_capset,&header,data))fail("capset");
    if(prctl(PR_SET_NO_NEW_PRIVS,1,0,0,0))fail("no-new-privileges");
    struct status after=read_status();
    require(after.threads==1&&after.inh==0&&after.amb==0&&after.eff==ALLOWED&&after.prm==ALLOWED&&after.bnd==ALLOWED&&after.nnp==1,"final-capabilities");
    struct rlimit checked;if(getrlimit(RLIMIT_CORE,&checked))fail("core-readback");require(checked.rlim_cur==0&&checked.rlim_max==0,"core-readback-zero");
}
static void install_policy_and_controls(void) {
    struct status before=read_status();
    require(before.threads==1&&before.seccomp==0&&before.filters==0&&prctl(PR_GET_SECCOMP,0,0,0,0)==0,"prefilter-mode-zero");
    struct stat ns_before,ns_after;
    if(stat("/proc/thread-self/ns/net",&ns_before))fail("prefilter-netns");
    require(syscall(SYS_unshare,0)==0,"prefilter-unshare-zero");
    errno=0;long result=syscall(SYS_setns,-1,0);
    require(result==-1&&errno==EBADF,"prefilter-setns-ebadf");
    struct guest_policy policy=guest_policy();
    require(policy.count>0&&policy.count<=256,"policy-count");
    struct sock_fprog filter={policy.count,policy.code};
    if(prctl(PR_SET_SECCOMP,SECCOMP_MODE_FILTER,&filter))fail("install-original-policy");
    require(prctl(PR_GET_SECCOMP,0,0,0,0)==2,"postfilter-mode-two");
    errno=0;result=syscall(SYS_unshare,0);
    require(result==-1&&errno==EPERM,"postfilter-unshare-eperm");
    errno=0;result=syscall(SYS_setns,-1,0);
    require(result==-1&&errno==EPERM,"postfilter-setns-eperm");
    int fd=socket(AF_UNIX,SOCK_SEQPACKET|SOCK_CLOEXEC,0);
    if(fd<0)fail("postfilter-unix-socket");
    if(close(fd))fail("postfilter-unix-close");
    errno=0;result=fcntl(fd,F_GETFD);
    require(result==-1&&errno==EBADF,"postfilter-probe-fd-closed");
    if(stat("/proc/thread-self/ns/net",&ns_after))fail("postfilter-netns");
    require(ns_before.st_dev==ns_after.st_dev&&ns_before.st_ino==ns_after.st_ino,"controls-netns-unchanged");
    struct status after=read_status();
    require(after.threads==1&&after.seccomp==2&&after.filters==1&&after.nnp==1&&after.inh==0&&after.amb==0&&after.eff==ALLOWED&&after.prm==ALLOWED&&after.bnd==ALLOWED,"postfilter-status");
    struct rlimit checked;if(getrlimit(RLIMIT_CORE,&checked))fail("postfilter-core");
    require(checked.rlim_cur==0&&checked.rlim_max==0,"postfilter-core-zero");
    report(after);
    printf("O1A_POLICY_CONTROLS pre_mode=0 post_mode=2 filters=1 unshare_pre=0 unshare_post_errno=%d setns_pre_errno=%d setns_post_errno=%d unix_socket_closed=1 netns_unchanged=1\n",EPERM,EBADF,EPERM);
    if(fflush(stdout))fail("policy-controls-flush");
}
int main(int argc,char **argv) {
    struct status before=read_status();
    if(argc==2&&!strcmp(argv[1],"--probe")) {report(before);return 0;} /* Read-only. */
    int controls=argc==2&&!strcmp(argv[1],"--policy-controls");
    require(argc==2&&(controls||!strcmp(argv[1],"periodic")||!strcmp(argv[1],"reconnect")),"arguments");
    require(getuid()==0&&geteuid()==0&&before.threads==1,"single-root");
    require((before.eff&(UINT64_C(1)<<CAP_SETPCAP))&&((before.prm&ALLOWED)==ALLOWED)&&((before.bnd&ALLOWED)==ALLOWED),"initial-capabilities");
    if(controls) {restrict_caps();install_policy_and_controls();return 0;}
    require(!chdir("/source/internal/core/node"),"cwd");
    int executable=open("/bin/node.test",O_RDONLY|O_CLOEXEC|O_NOFOLLOW);if(executable<0)fail("entry-open");
    struct stat st;if(fstat(executable,&st))fail("entry-stat");
    unsigned char ident[20];require(S_ISREG(st.st_mode)&&st.st_nlink==1&&(st.st_mode&0111)&&!(st.st_mode&06000)&&pread(executable,ident,sizeof(ident),0)==sizeof(ident),"entry-regular");
    require(!memcmp(ident,"\177ELF\002\001\001",7)&&ident[18]==183&&ident[19]==0,"entry-aarch64");
    const char *keys[]={"LOADSTAND_LINUX_NATIVE","LOADSTAND_NATIVE_HELPER","LOADSTAND_NATIVE_HELPER_SHA","LOADSTAND_NATIVE_TARGET","LOADSTAND_NATIVE_TARGET_SHA","LOADSTAND_NATIVE_FULL","LOADSTAND_NATIVE_FULL_SHA","LOADSTAND_NATIVE_NFT","LOADSTAND_NATIVE_NFT_SHA","LOADSTAND_NATIVE_PRODUCTION_PROBE","LOADSTAND_NATIVE_FALLBACK_PROBE","LOADSTAND_NATIVE_IPV6_PROBE","LOADSTAND_NATIVE_ROUTE_WIRE_PROFILE"};
    char *environment[20]={"PATH=/usr/bin:/bin","LC_ALL=C","GOMAXPROCS=2","HOME=/nonexistent","TMPDIR=/tmp",NULL};
    require(getenv(keys[0])&&!strcmp(getenv(keys[0]),"1"),"native-enabled");
    const char *expected[]={"1","/bin/loadstand-linuxhelper",HELPER_SHA,"/bin/loadstand-sdkedge",TARGET_SHA,"/bin/loadstand-full",FULL_SHA,"/usr/sbin/nft",NFT_SHA};
    for(size_t i=0;i<sizeof(expected)/sizeof(expected[0]);i++)require(getenv(keys[i])&&!strcmp(getenv(keys[i]),expected[i]),"frozen-env");
    const char *profile=!strcmp(argv[1],"periodic")?profile_periodic:profile_reconnect;
    require(getenv(keys[12])&&!strcmp(getenv(keys[12]),profile),"frozen-profile");
    for(size_t i=0;i<sizeof(keys)/sizeof(keys[0]);i++)environment[5+i]=(char *)copy_env(keys[i]);
    restrict_caps();install_policy_and_controls();
    char *timeout=!strcmp(argv[1],"periodic")?"-test.timeout=570s":"-test.timeout=255s";
    char *arguments[]={"/bin/node.test","-test.run=^TestLoadStandLinuxRouteWireNative$","-test.count=1","-test.v",timeout,NULL};
    fexecve(executable,arguments,environment);fail("entry-exec");
}
