"""Small synthetic serialized reports; never Corsa activity or real wire proof."""
import json
from o1a_journal import journal,profile,rates
NS=10**9
TIME='2026-11-20T00:00:00Z'
ATTEMPT='a'*32

def endpoint(peer,direction,sid,begin,end,active,source):
 counts=lambda:{name:{'frames':0,'bytes':0,'sha256':''} for name in rates.CLASSES}
 tx,rx=counts(),counts();row={'conn_id':1 if sid=='1'*64 else 2,'peer':peer,'direction':direction,'session_id':sid,'session_interval':dict(zip(('begin_before_ns','begin_after_ns','end_before_ns','end_after_ns'),(begin,begin,end,end))),'complete':True,'sent':tx,'received':rx}
 if active:
  (tx if direction=='outbound' else rx)['full_v3']={'frames':1,'bytes':100,'sha256':'c'*64};row['sent_span' if direction=='outbound' else 'received_span']={'first_ns':begin+1,'last_ns':begin+2}
  proof={'destinations':10000,'identity_sha256':profile.seed_digest(),'epoch':1}
  if direction=='outbound':proof.update(passes=1,periodic_passes=int(source=='periodic'),triggered_passes=0,connect_passes=int(source=='connect'));row['full_send']=proof
  else:proof['snapshot_after_ns']=end+100*NS;row['full_receive']=proof
 return row

def report(workload,raw):
 p,params=profile.build_params(workload,raw,'f'*64,100*NS);begin,end=int(params['route_wire_begin_ns']),int(params['route_wire_end_ns']);life={'Ordinal':1,'StartedAt':TIME};ids={node:str(i+1)*40 for i,node in enumerate(profile.NODES)};traffic={'StartedAt':TIME,'ReadAt':'2026-11-20T00:10:00Z','BytesSent':1000,'BytesReceived':1000}
 b={'FunctionalLifecycleComplete':True,'FullSampleAvailable':True,'RoutesReady':True,'AcceptanceEligible':False,'OwnedAfterCleanup':None,'ExecutionID':'b'*32,'PlanVersion':'3','PlanDigest':profile.plan_digest(p),'ByteBalanceScope':'declared_functional_closed_fixture','ByteBalanceTerminal':'terminal_tail_unjudged','ByteBalanceChecks':[{'Status':'undefined','Reason':'awaiting_second_edge'},{'Status':'undefined','Reason':'partial_network_sweep'}],'Ended':{},'Samples':[],'Actions':[],'RouteWire':[]}
 for node in profile.NODES:b['Ended'][node]=[{'Incarnation':dict(life),'Finality':'exact-after-stop','Final':{'State':'available','Value':dict(traffic)}}]
 for at in range(0,p['Plan']['Duration']+1,15*NS):
  b['Actions'].append({'Kind':'sample','Scheduled':at,'Begin':at,'End':at+1})
  for i,node in enumerate(profile.NODES):
   sample={name:{'State':'available','Value':{}} for name in ('Runtime','LinuxProcess','Traffic','Sessions','Modes','Neighbours','RouteEntries','Resources','Bans')};sample.update(Identity=ids[node],Incarnation=dict(life),ReadAt=TIME,Datagram={'State':'explicitly-disabled','Value':None});sample['Traffic']['Value']=dict(traffic);sample['LinuxProcess']['Value']={'read_started_at':TIME,'read_completed_at':TIME,'provenance':{'uid':65532,'running_executable_sha256':'cfe3d7ba3bde9e362b654e7084f063a2195e8a21c64bac7a536b43035b6d1826','running_executable_verified':True,'kernel_start_time_available':True,'incarnation':{'pid':100+i,'kernel_start_ticks':10}}};b['Samples'].append({'Node':node,'At':at,'PreStop':False,'PreStopOf':'','Sample':sample})
 sessions=[('1'*64,begin,end,True)] if workload=='periodic' else [('1'*64,begin,int(params['route_wire_disconnect_at_ns'])+NS,False),('2'*64,int(params['route_wire_disconnect_at_ns'])+2*NS,end,True)]
 for node,peer,direction in [('full-000',ids['full-001'],'outbound'),('full-001',ids['full-000'],'inbound')]:b['RouteWire'].append({'Node':node,'Incarnation':dict(life),'Accounting':{'Bounds':{'begin_ns':begin,'end_ns':end},'Traffic':dict(traffic),'Endpoints':[endpoint(peer,direction,sid,left,right,active,p['RequiredFullSource']) for sid,left,right,active in sessions]}})
 totals={node:{direction:{name:0 for name in rates.CLASSES} for direction in ('sent','received')} for node in profile.NODES};durations=[];session_rates=[]
 for sid,left,right,active in sessions:
  duration=right-left;forward={name:100 if active and name=='full_v3' else 0 for name in rates.CLASSES};reverse={name:0 for name in rates.CLASSES};durations.append({'SessionID':sid,'Minimum':duration,'Maximum':duration});session_rates.append({'session_id':sid,'dialer':'full-000','listener':'full-001','dialer_to_listener':rates.per_class(forward,duration,duration),'listener_to_dialer':rates.per_class(reverse,duration,duration)})
  for name,count in forward.items():totals['full-000']['sent'][name]+=count;totals['full-001']['received'][name]+=count
 b['RouteWirePairs']=len(sessions);b['RouteWireDurations']=durations;b['RouteWireRates']={'window_ns':end-begin,'sessions':session_rates,'nodes':[{'node':node,'sent':rates.per_class(totals[node]['sent'],end-begin,end-begin),'received':rates.per_class(totals[node]['received'],end-begin,end-begin)} for node in profile.NODES]};return b,params

def encode(h,body):
 line=json.dumps(h,sort_keys=True,separators=(',',':')).encode();checksum=journal.sha(b'corsa/testutil/runjournal/record/v1\0runjournal-record/v1\n'+line+b'\n'+body);return b'runjournal-record/v1\n'+line+b'\nsha256='+checksum.encode()+b'\n'+body

def journal_files(workload,raw,mutate=None):
 body,params=report(workload,raw)
 if mutate:mutate(body,params)
 manifests={};files={}
 for name,path,data in [('measured','internal/core/fixture.go',b'package fixture\n'),('stand','internal/core/node/fixture_test.go',b'package node\n')]:
  manifest=('runjournal-sources/v1\nname '+name+'\n'+journal.sha(data)+'  '+path+'\n').encode();manifests[name]=manifest;prefix='sources/'+name+'-'+journal.sha(manifest)[:16]+'/';files[prefix+'MANIFEST.sha256']=manifest;files[prefix+path]=data
 payload=json.dumps(body,separators=(',',':')).encode();h={'config_id':'0'*16,'measurement':'loadstand-functional-lifecycle','label':'headless-sdk','params':[{'name':key,'value':value} for key,value in sorted(params.items())],'sources':[{'name':name,'stamp':journal.sha(raw)[:16]} for name,raw in sorted(manifests.items())],'outcome':'completed','detail':'','recorded_at':TIME,'body_bytes':len(payload),'run':'e'*16};identifier,_=journal.config_id(h);h['config_id']=identifier;stem='loadstand-functional-lifecycle-headless-sdk-'+identifier;files[stem+'.result']=encode(h,payload);files[stem+'.verified-'+h['run']]=encode(dict(h,outcome='verified',body_bytes=0),b'');return files,manifests
