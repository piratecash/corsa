"""Bounded, read-only equivalents of baseline runjournal record/source checks."""
import datetime,hashlib,json,re
from pathlib import PurePosixPath

MAX_FILE=8*1024**2
MAX_BODY=4*1024**2
MAX_TOTAL=64*1024**2
PINNED_MANIFESTS={'measured':'b70de373d032b8fed471c6b93bba6d034d932b322495866d40766e7c746fcd9c','stand':'52e346f971a30a1da05570e17b4f6133e913eaaf9ea14f433a03fc7575a77aec'}
HEX64=re.compile(r'^[0-9a-f]{64}$');HEX16=re.compile(r'^[0-9a-f]{16}$');HEX32=re.compile(r'^[0-9a-f]{32}$');HEX40=re.compile(r'^[0-9a-f]{40}$')
U64=2**64-1
class Refusal(ValueError):pass
def need(value,why):
 if not value:raise Refusal(why)
def sha(raw):return hashlib.sha256(raw).hexdigest()
def integer(value,minimum=0,maximum=U64):need(type(value) is int and minimum<=value<=maximum,'integer bound');return value
def digest(value,pattern=HEX64,nonzero=False):need(type(value) is str and pattern.fullmatch(value) and (not nonzero or any(c!='0' for c in value)),'digest encoding');return value
def unique(pairs):
 result={}
 for key,value in pairs:need(key not in result,'duplicate JSON key');result[key]=value
 return result
def decode(raw,limit=MAX_BODY):
 need(type(raw) is bytes and 0<len(raw)<=limit,'JSON byte bound')
 try:return json.loads(raw.decode('utf-8'),object_pairs_hook=unique,parse_constant=lambda v:need(False,'nonfinite JSON'))
 except (UnicodeError,ValueError,RecursionError) as e:raise Refusal('invalid bounded JSON') from e
def safe(name):
 need(type(name) is str and 0<len(name.encode('utf-8'))<=512 and name==PurePosixPath(name).as_posix() and not name.startswith('/') and not any(c in name for c in '\\\r\n\0'),'unsafe path')
 parts=name.split('/');need(len(parts)<=32 and all(p not in ('','.','..') for p in parts),'unsafe path components');return name
def inventory(files):
 need(type(files) is dict and 0<len(files)<=4096,'file count');total=0
 for name,raw in files.items():safe(name);need(type(raw) is bytes and len(raw)<=MAX_FILE,'file byte bound');total+=len(raw);need(total<=MAX_TOTAL,'total content bound')

def instant(value):
 need(type(value) is str,'time field')
 match=re.fullmatch(r'(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2}):(\d{2})(?:\.(\d{1,9}))?Z',value);need(match,'UTC RFC3339Nano encoding')
 parts=match.groups();year,month,day,hour,minute,second=map(int,parts[:6]);need(0<=hour<24 and 0<=minute<60 and 0<=second<60,'time range')
 try:days=datetime.date(year,month,day).toordinal()
 except ValueError as e:raise Refusal('invalid calendar time') from e
 return ((days*24+hour)*60+minute)*60*10**9+second*10**9+int((parts[6] or '').ljust(9,'0'))

def config_id(header):
 def field(tag,value):raw=value.encode('utf-8');return tag.encode()+str(len(raw)).encode()+b':'+raw+b'\n'
 params=header['params'];need(type(params) is list and len(params)<=128,'key params')
 values={}
 for row in params:need(type(row) is dict and set(row)=={'name','value'} and type(row['name']) is str and row['name'] and type(row['value']) is str and row['name'] not in values,'param duplicate/schema');values[row['name']]=row['value']
 canonical=field('m',header['measurement'])+field('l',header['label'])+field('n',str(len(values)))
 for key in sorted(values):canonical+=field('k',key)+field('v',values[key])
 return sha(b'corsa/testutil/runjournal/config/v1\0'+canonical)[:16],values

def record(raw):
 need(type(raw) is bytes and len(raw)<=MAX_FILE,'record bytes')
 parts=raw.split(b'\n',3);need(len(parts)==4 and parts[0]==b'runjournal-record/v1' and len(parts[1])<=65536,'record boundaries');_,line,checksum,body=parts
 need(len(body)<=MAX_BODY and checksum==b'sha256='+sha(b'corsa/testutil/runjournal/record/v1\0runjournal-record/v1\n'+line+b'\n'+body).encode(),'record checksum')
 h=decode(line,65536);need(type(h) is dict and set(h)=={'config_id','measurement','label','params','sources','outcome','detail','recorded_at','body_bytes','run'},'record header schema');need(h['measurement']=='loadstand-functional-lifecycle' and h['label']=='headless-sdk','journal family')
 need(type(h['detail']) is str and integer(h['body_bytes'],0,MAX_BODY)==len(body),'body count');digest(h['config_id'],HEX16);digest(h['run'],HEX16);instant(h['recorded_at'])
 identifier,params=config_id(h);need(identifier==h['config_id'],'derived config ID mismatch')
 need(h['outcome'] in ('completed','verified','failed','quarantined','released'),'unknown outcome')
 return h,params,body

def verify_sources(files,original_manifests):
 need(type(original_manifests) is dict and set(original_manifests)==set(PINNED_MANIFESTS),'original source manifests required');expected=set();stamps=[]
 for name,fullsha in sorted(PINNED_MANIFESTS.items()):
  raw=original_manifests[name];need(type(raw) is bytes and 0<len(raw)<=1024**2 and sha(raw)==fullsha,'original manifest full hash')
  stamp=fullsha[:16];prefix='sources/'+name+'-'+stamp+'/';path=prefix+'MANIFEST.sha256';need(files.get(path)==raw,'kept manifest bytes');expected.add(path)
  lines=raw.decode('utf-8').splitlines();need(len(lines)>=2 and raw.endswith(b'\n') and lines[:2]==['runjournal-sources/v1','name '+name],'source manifest format');previous=''
  for line in lines[2:]:
   value,sep,relative=line.partition('  ');need(sep and HEX64.fullmatch(value),'source manifest row');safe(relative);need(relative>previous,'source order/duplicate');previous=relative
   need((name=='measured' and relative.startswith('internal/core/') and relative.endswith('.go') and not relative.endswith('_test.go')) or (name=='stand' and relative.endswith('.go') and (relative.startswith(('internal/testutil/loadstand/','sdk/')) or relative.startswith('internal/core/node/') and relative.count('/')==3 and relative.endswith('_test.go'))),'source selector differs')
   target=prefix+relative;need(target in files and sha(files[target])==value,'kept source hash/missing');expected.add(target)
  stamps.append({'name':name,'stamp':stamp})
 return expected,stamps


def load_original_manifests(archive_raw):
 """Read the two manifests from the exact already-approved source archive bytes."""
 import io,tarfile
 need(type(archive_raw) is bytes and len(archive_raw)==4914874 and sha(archive_raw)=='71569cb33f466e7d3a896bcdf6e4fd2463b333db3b45339ae70c0661b20763c9','original source archive bytes/hash')
 result={};count=0;total=0
 with tarfile.open(fileobj=io.BytesIO(archive_raw),mode='r:gz') as archive:
  for member in archive:
   count+=1;need(count<=8192,'source archive count')
   if member.isdir():continue
   need(member.isfile() and 0<member.size<=8*1024**2,'source regular size');total+=member.size;need(total<=32*1024**2,'source archive content')
   if member.name.startswith('manifests/'):
    need(member.name in ('manifests/measured.manifest','manifests/stand.manifest'),'unknown original manifest');name=member.name.split('/')[1].split('.')[0];need(name not in result,'duplicate original manifest')
    raw=archive.extractfile(member).read(member.size+1);need(len(raw)==member.size and sha(raw)==PINNED_MANIFESTS[name],'original manifest bytes/hash');result[name]=raw
 need(set(result)==set(PINNED_MANIFESTS),'missing original manifests');return result
