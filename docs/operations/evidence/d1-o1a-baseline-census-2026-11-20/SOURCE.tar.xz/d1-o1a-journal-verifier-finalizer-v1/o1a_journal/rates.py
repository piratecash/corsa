"""Serialized reciprocal/window/projection/rate checks from baseline Go rules."""
from .journal import need,integer,digest,HEX40,U64,instant
from .profile import NODES,NS,seed_digest
CLASSES=('probe','ack','digest','summary','full_v3','delta_v3')

def incarnation(value):
 need(type(value) is dict and set(value)=={'Ordinal','StartedAt'} and integer(value['Ordinal'],1)==1,'original one-life incarnation');need(value['StartedAt']!='0001-01-01T00:00:00Z','zero started_at');instant(value['StartedAt']);return value

def observation(value):need(type(value) is dict and set(value)=={'State','Value'} and value['State']=='available' and value['Value'] is not None,'mandatory observation unavailable');return value['Value']
def traffic(value,life):
 need(type(value) is dict and set(value)=={'StartedAt','ReadAt','BytesSent','BytesReceived'},'traffic schema');need(instant(value['StartedAt'])==instant(life['StartedAt']) and instant(value['ReadAt'])>=instant(value['StartedAt']),'traffic lifetime');integer(value['BytesSent']);integer(value['BytesReceived']);return value

def lives(body,profile):
 ended=body.get('Ended');need(type(ended) is dict and set(ended)==set(NODES),'ended cohort');live={};final={};identities={};processes={}
 for node in NODES:
  rows=ended[node];need(type(rows) is list and len(rows)==1,'one final incarnation');row=rows[0];need(type(row) is dict and set(row)=={'Incarnation','Finality','Final'} and row['Finality']=='exact-after-stop','exact finality');life=incarnation(row['Incarnation']);live[node]=life;final[node]=traffic(observation(row['Final']),life)
 samples=body.get('Samples');need(type(samples) is list and 0<len(samples)<=192,'sample bound');regular={}
 for row in samples:
  need(type(row) is dict and row.get('Node') in live,'sample node');node=row['Node'];sample=row.get('Sample');need(type(sample) is dict and typed_equal(sample.get('Incarnation'),live[node]),'sample incarnation');identity=digest(sample.get('Identity'),HEX40,True)
  need(node not in identities or identities[node]==identity,'node identity changed');identities[node]=identity
  for key in ('Runtime','LinuxProcess','Traffic','Sessions','Modes','Neighbours','RouteEntries','Resources','Bans'):observation(sample.get(key))
  datagram=sample.get('Datagram');need(type(datagram) is dict and (datagram.get('State')=='explicitly-disabled' or datagram.get('State')=='available' and datagram.get('Value') is not None),'datagram reading')
  traffic(sample['Traffic']['Value'],live[node]);instant(sample['ReadAt'])
  linux=sample['LinuxProcess']['Value'];need(type(linux) is dict and instant(linux['read_completed_at'])>=instant(linux['read_started_at']),'Linux read bracket')
  provenance=linux.get('provenance');need(type(provenance) is dict and integer(provenance.get('uid'),0,2**32-1)==65532 and provenance.get('running_executable_sha256')=='cfe3d7ba3bde9e362b654e7084f063a2195e8a21c64bac7a536b43035b6d1826' and provenance.get('running_executable_verified') is True and provenance.get('kernel_start_time_available') is True,'serialized Linux executable provenance')
  proc=provenance['incarnation'];need(type(proc) is dict and set(proc)=={'pid','kernel_start_ticks'},'process identity');pid=integer(proc['pid'],1);ticks=integer(proc['kernel_start_ticks'],1);pair=(pid,ticks);need(node not in processes or processes[node]==pair,'process changed within live');processes[node]=pair
  at=integer(row['At'],0,profile['Plan']['Duration']);need(type(row.get('PreStop')) is bool and type(row.get('PreStopOf')) is str,'sample stop scope')
  if not row['PreStop'] and row['PreStopOf']=='':regular.setdefault(at,[]).append(node)
 need(set(identities)==set(NODES) and len(set(identities.values()))==2 and len(set(processes.values()))==2,'distinct original identities/process labels')
 expected=list(range(0,profile['Plan']['Duration']+1,15*NS));need(set(regular)==set(expected) and all(sorted(value)==list(NODES) for value in regular.values()),'complete periodic two-node sample schedule')
 actions=body.get('Actions');need(type(actions) is list and len(actions)==len(expected),'action schedule count')
 for action,at in zip(actions,expected):
  need(action.get('Kind')=='sample' and action.get('Scheduled')==at,'fixed quiet actions');begin=integer(action.get('Begin'),at,2**63-1);end=integer(action.get('End'),begin,2**63-1);need(end-at<=profile['Limits']['AllowedLateness'],'original dispatch lateness')
 return live,final,identities,processes

def counters(value,remaining):
 need(type(value) is dict and set(value)==set(CLASSES),'route classes');total=0
 for name,row in value.items():
  need(type(row) is dict and set(row)=={'frames','bytes','sha256'},'route count schema');frames=integer(row['frames']);count=integer(row['bytes']);total+=count;need(total<=remaining,'plaintext counts exceed transport total')
  if frames==0:need(count==0 and row['sha256']=='','nonempty zero frame counter')
  else:need(count>=frames and (count-1)//(128*1024)+1<=frames,'complete frame byte bound');digest(row['sha256'])
 return total

def interval(value,begin,end):
 need(type(value) is dict and set(value)=={'begin_before_ns','begin_after_ns','end_before_ns','end_after_ns'},'interval fields');a,b,c,d=[integer(value[key],0,2**63-1) for key in ('begin_before_ns','begin_after_ns','end_before_ns','end_after_ns')];need(begin<=a<=b<c<=d<=end,'registered interval within window');return a,b,c,d

def full_proof(row,direction,bounds,source):
 field='full_send' if direction=='sent' else 'full_receive';need(field not in row or type(row[field]) is dict,'null/invalid full proof');proof=row.get(field);frames=row[direction]['full_v3']['frames'];need((proof is not None)==(frames>0),'full proof coverage')
 if proof is None:return None
 expected={'destinations','identity_sha256','epoch','passes','periodic_passes','triggered_passes','connect_passes'} if direction=='sent' else {'destinations','identity_sha256','epoch','snapshot_after_ns'}
 need(type(proof) is dict and set(proof)==expected,'full projection schema');integer(proof['destinations'],1,10000);digest(proof['identity_sha256']);integer(proof['epoch'],1)
 if direction=='sent':
  passes=integer(proof['passes'],1,frames);counts=[integer(proof[key],0,passes) for key in ('periodic_passes','triggered_passes','connect_passes')];need(sum(counts)==passes and proof[source+'_passes']==passes,'full passes selected source')
 else:integer(proof['snapshot_after_ns'],bounds[1]+1,2**63-1)
 return proof

def span(row,direction,begin,end):
 field=direction+'_span';has=any(value['frames'] for value in row[direction].values());need((field in row)==has,'frame span coverage')
 if not has:return
 value=row[field];need(type(value) is dict and set(value)=={'first_ns','last_ns'},'span schema');first=integer(value['first_ns'],begin+1,end-1);integer(value['last_ns'],first,end-1)

def per_class(values,minimum,maximum):
 need(0<minimum<=maximum,'rate lifetime');result={}
 for name in CLASSES:
  count=integer(values[name]);lower=count*NS//maximum;upper=(count*NS+minimum-1)//minimum;need(lower<=U64 and upper<=U64,'rate overflow');result[name]={'bytes':count,'min_bytes_per_second':lower,'max_bytes_per_second':upper}
 return result

def verify_rates(body,profile,params,live,final,identities):
 begin=int(params['route_wire_begin_ns']);end=int(params['route_wire_end_ns']);source=profile['RequiredFullSource'];reports=body.get('RouteWire');need(type(reports) is list and len(reports)==2,'two final route reports');seen=set();pairs={}
 for report in reports:
  need(type(report) is dict and set(report)=={'Node','Incarnation','Accounting'},'route report schema');node=report['Node'];need(node in live and node not in seen and typed_equal(report['Incarnation'],live[node]),'route report live/cohort');seen.add(node);account=report['Accounting'];need(type(account) is dict and set(account)=={'Traffic','Bounds','Endpoints'} and typed_equal(account['Bounds'],{'begin_ns':begin,'end_ns':end}) and typed_equal(account['Traffic'],final[node]),'final accounting traffic/window')
  rows=account['Endpoints'];need(type(rows) is list and 1<=len(rows)<=4,'endpoint bound');connids=set();remain={'sent':final[node]['BytesSent'],'received':final[node]['BytesReceived']};receipt_rows=0
  for row in rows:
   keys={'session_interval','conn_id','peer','direction','session_id','complete','sent','received'};need(type(row) is dict and keys<=set(row)<=keys|{'sent_span','received_span','full_send','full_receive'},'endpoint schema');cid=integer(row['conn_id'],1);need(cid not in connids,'duplicate conn ID');connids.add(cid);sid=digest(row['session_id'],nonzero=True);peer=digest(row['peer'],HEX40,True);need(peer==identities[NODES[1] if node==NODES[0] else NODES[0]] and row['complete'] is True and row['direction'] in ('inbound','outbound'),'reciprocal peer/complete/direction')
   bounds=interval(row['session_interval'],begin,end)
   for direction in ('sent','received'):
    remain[direction]-=counters(row[direction],remain[direction]);span(row,direction,bounds[1],bounds[2]);proof=full_proof(row,direction,(begin,end),source)
    if direction=='received' and proof:receipt_rows+=proof['destinations'];need(receipt_rows<=10000,'full receipt route budget')
   pair=pairs.setdefault(sid,{})
   need(row['direction'] not in pair,'duplicate directional TLS session');pair[row['direction']]={'node':node,'row':row,'interval':bounds}
 need(len(pairs)==(1 if source=='periodic' else 2) and integer(body.get('RouteWirePairs'),1,2)==len(pairs),'pair count')
 totals={node:{direction:{name:0 for name in CLASSES} for direction in ('sent','received')} for node in NODES};sessions=[];durations=[];full_matched=False;observed=False
 for sid,pair in sorted(pairs.items()):
  need(set(pair)=={'inbound','outbound'},'missing reciprocal endpoint');out=pair['outbound'];inc=pair['inbound'];a,b=out['row'],inc['row'];need(out['node']==NODES[0] and inc['node']==NODES[1],'fixed initiator')
  need(a['sent']==b['received'] and b['sent']==a['received'],'reciprocal frame counts/digests')
  for sender,receiver,proofnode in ((a,b,out['node']),(b,a,inc['node'])):
   send=sender.get('full_send');receipt=receiver.get('full_receive');need((send is None)==(receipt is None),'reciprocal full coverage')
   if send:
    need(all(send[key]==receipt[key] for key in ('destinations','epoch','identity_sha256')),'reciprocal full projection');full_matched=full_matched or (proofnode==NODES[0] and send['destinations']==10000 and send['identity_sha256']==seed_digest())
  x,y=out['interval'],inc['interval'];minimum=min(x[2],y[2])-max(x[1],y[1]);maximum=min(x[3],y[3])-max(x[0],y[0]);need(0<minimum<=maximum,'proven common lifetime');start=max(x[1],y[1]);stop=min(x[2],y[2])
  for row in (a,b):span(row,'sent',start,stop);span(row,'received',start,stop)
  if source=='periodic':need(x[1]==y[1]==begin and x[2]==y[2]==end,'periodic stable boundary coverage')
  directions=[]
  for row,sender,receiver in ((a,out['node'],inc['node']),(b,inc['node'],out['node'])):
   values={name:row['sent'][name]['bytes'] for name in CLASSES};directions.append(per_class(values,minimum,maximum));observed=observed or any(value['frames'] for value in row['sent'].values())
   for name,count in values.items():totals[sender]['sent'][name]=integer(totals[sender]['sent'][name]+count);totals[receiver]['received'][name]=integer(totals[receiver]['received'][name]+count)
  sessions.append({'session_id':sid,'dialer':out['node'],'listener':inc['node'],'dialer_to_listener':directions[0],'listener_to_dialer':directions[1]});durations.append({'SessionID':sid,'Minimum':minimum,'Maximum':maximum})
 if source=='connect':
  old=[pair for pair in pairs.values() if pair['outbound']['interval'][1]==pair['inbound']['interval'][1]==begin];need(len(old)==1,'one opening session');old=old[0];replacement=next(pair for pair in pairs.values() if pair is not old);ox,oy=old['outbound']['interval'],old['inbound']['interval'];nx,ny=replacement['outbound']['interval'],replacement['inbound']['interval'];disconnect=int(params['route_wire_disconnect_at_ns'])
  need(begin<disconnect<min(ox[2],oy[2]) and max(ox[3],oy[3])<min(nx[0],ny[0]) and nx[2]==ny[2]==end,'ordered two-ended retirement/replacement');need(old['outbound']['row'].get('full_send') is None and old['inbound']['row'].get('full_send') is None,'full pass on old TLS session')
 need(full_matched and observed,'required seeded complete full projection/frames missing')
 rates={'window_ns':end-begin,'sessions':sessions,'nodes':[{'node':node,'sent':per_class(totals[node]['sent'],end-begin,end-begin),'received':per_class(totals[node]['received'],end-begin,end-begin)} for node in NODES]}
 need(typed_equal(body.get('RouteWireDurations'),durations) and typed_equal(body.get('RouteWireRates'),rates),'stored rates or duration differ from exact reduction')
 return {'pairs':len(pairs),'window_ns':end-begin,'rates':rates,'serialized_processes_only':True}


def typed_equal(actual,expected):
 if type(actual) is not type(expected):return False
 if type(expected) is dict:return set(actual)==set(expected) and all(typed_equal(actual[key],value) for key,value in expected.items())
 if type(expected) is list:return len(actual)==len(expected) and all(typed_equal(a,b) for a,b in zip(actual,expected))
 return actual==expected
