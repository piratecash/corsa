"""Direct fixed quiet-plan/key transcription; no scheduler/network execution."""
import hashlib,json,struct
from .journal import need,digest,HEX64,integer,sha
PROFILE_SHA={'periodic':'28e76a342c9b28b8a2e1495f181f2463b35c04d64a268c705b55d789edd7791d','reconnect':'36a65318713e5b4cb795749a4a5e12424cdfe905760f3a352b7ac602040621de'}
NODES=('full-000','full-001')
NS=10**9

def duration(value):
 need(type(value) is int and value>=0 and value%NS==0,'fixed profile duration')
 seconds=value//NS
 if seconds<60:return str(seconds)+'s'
 return str(seconds//60)+'m'+str(seconds%60)+'s'
def seed_digest():return hashlib.sha256(b''.join(b'corsa-o1a-seed!!'+struct.pack('>I',i) for i in range(1,10001))).hexdigest()
def plan_params(profile):
 p=profile['Plan'];return [('plan_version','3'),('seed','13'),('full_nodes','2'),('hubs','2'),('edge_nodes','0'),('edge_uplinks','1'),('contacts','0'),('duration',duration(p['Duration'])),('settle','0s'),('sample_interval','15s'),('churn','quiet'),('dm_mean_interval','off'),('traffic_resolution','100ms'),('gossip_interval','off'),('gossip_topic','global')]
def plan_digest(profile):
 rows=[]
 def field(tag,value):value=str(value);rows.append(tag+str(len(value.encode()))+':'+value+'\n')
 params=plan_params(profile);field('params',len(params))
 for key,value in params:field('k',key);field('v',value)
 field('duration',profile['Plan']['Duration']);field('nodes',2)
 for node,peer in ((NODES[0],NODES[1]),(NODES[1],NODES[0])):
  field('id',node);field('role','full');field('hub','true');field('dials',1);field('i',peer);field('contacts',0)
 field('events',0);samples=list(range(15*NS,profile['Plan']['Duration']+1,15*NS));field('samples',len(samples))
 for at in samples:field('s',at)
 return sha(b'corsa/node/loadstand/plan/v1\0'+''.join(rows).encode())
def build_params(workload,raw,nonce,origin):
 need(workload in PROFILE_SHA and sha(raw)==PROFILE_SHA[workload],'exact frozen profile SHA');p=json.loads(raw)
 nonce=digest(nonce,HEX64,True);origin=integer(origin,1,2**63-1-p['Plan']['Duration'])
 result=dict(plan_params(p));result.update(executor_version='3',plan_digest=plan_digest(p),profile='functional-loopback',acceptance_eligible='false',action_budget='8s',readiness_budget='30s',route_ready_budget='35s',cleanup_budget='20s',receipt_drain='8s',allowed_lateness='8s',max_actions='128',max_samples='96',max_trace_bytes='4194304',route_wire_pair_policy='tls_session_queue_intervals_v1',route_wire_rate_policy='session_registered_overlap_node_full_window_v1',route_wire_window=nonce,route_wire_begin_ns=str(origin+p['Begin']),route_wire_end_ns=str(origin+p['End']),route_wire_schedule_origin_ns=str(origin),route_wire_begin_offset_ns=str(p['Begin']),route_wire_end_offset_ns=str(p['End']),route_wire_full_receipt_route_budget='10000',route_wire_full_receipt_policy='complete_sender_passes_with_source_and_reciprocal_receipt_v2',route_wire_required_full_routes='10000',route_wire_required_full_source=p['RequiredFullSource'],route_wire_initiator=NODES[0],route_wire_seed_sender=NODES[0],route_wire_seed_identity_sha256=seed_digest(),route_wire_member_0=NODES[0]+'/4',route_wire_member_1=NODES[1]+'/4')
 result['route_wire_session_policy']='single_stable_session_v1' if workload=='periodic' else 'two_sessions_ordered_replacement_v1'
 if workload=='reconnect':result['route_wire_disconnect_at_ns']=str(origin+p['DisconnectAt'])
 return p,result
def expected_params(workload,raw,observed):
 origin=observed.get('route_wire_schedule_origin_ns');need(type(origin) is str and origin.isdigit() and str(int(origin))==origin,'origin decimal')
 p,result=build_params(workload,raw,observed.get('route_wire_window'),int(origin));need(observed==result,'full expected key mismatch');return p,result
