"""Serialized O1a journal consistency only; does not create runtime custody."""
from .journal import need,inventory,record,verify_sources,decode,sha,digest,HEX16,HEX32,Refusal
from .profile import expected_params,NODES,plan_digest
from .rates import lives,verify_rates

UNKNOWN=[
 {'field':'original_launch_owned_FD_census_seal','reason':'not serialized in HeadlessRouteWireAccounting; verified by original Go readCommittedHeadlessRouteWireReport','source':'internal/testutil/loadstand/linux_route_wire_linux.go:186; headless_route_wire_report.go:122'},
 {'field':'live_RuntimeProcess_or_CompletedStartBinding_custody','reason':'RuntimeProcess is json:"-"; public tuples are labels, not resurrected process handles','source':'internal/testutil/loadstand/member.go:58; final_binding.go:68'},
 {'field':'original_frame_bytes_and_full_projection_payload','reason':'saved report contains counts/digests/projections, not raw ordered wire frame bytes; raw digest/projection proof checked by unchanged Go oracle','source':'internal/testutil/loadstand/headless_route_wire_report.go:36; internal/core/node/loadstand_executor_route_wire_pairs_test.go:39'},
]

def _verify(files,workload,profile_raw,original_manifests,attempt_id):
 """Input is reference-capsule decoded dict[path,bytes], never paths on disk.

 Caller must separately match attempt_id to native/guest/capsule handoff; this
 function cannot infer host attempt provenance from runjournal alone.
 """
 digest(attempt_id,HEX32);inventory(files)
 source_files,stamps=verify_sources(files,original_manifests)
 top=[name for name in files if '/' not in name]
 need(not any(name.startswith('.pending-') or '.attempt-' in name or name.endswith(('.quarantined','.released')) for name in top),'failed/quarantined/pending fresh run is not success')
 results=[name for name in top if name.endswith('.result')];need(len(results)==1,'exactly one completed result required')
 result_name=results[0];header,params,rawbody=record(files[result_name]);need(header['outcome']=='completed' and header['detail']=='' and header['sources']==stamps,'completed outcome/source stamps')
 profile,expected=expected_params(workload,profile_raw,params);stem='loadstand-functional-lifecycle-headless-sdk-'+header['config_id'];need(result_name==stem+'.result','result stem mismatch');mark_name=stem+'.verified-'+header['run'];need(mark_name in files,'missing own-run verified mark')
 mark,mparams,empty=record(files[mark_name]);need(mark['outcome']=='verified' and mark['detail']=='' and not empty and mark['run']==header['run'] and mark['sources']==stamps and mark['config_id']==header['config_id'] and mparams==params,'verified mark/key/source/run mismatch')
 need(set(files)==source_files|{result_name,mark_name},'stranger/unlisted journal file')
 body=decode(rawbody);need(type(body) is dict,'report object')
 for key in ('FunctionalLifecycleComplete','FullSampleAvailable','RoutesReady'):need(body.get(key) is True,'original report incomplete: '+key)
 need(body.get('AcceptanceEligible') is False and 'OwnedAfterCleanup' in body and body['OwnedAfterCleanup'] in (None,[]),'overstated acceptance/owned after cleanup')
 digest(body.get('ExecutionID'),HEX32);need(body.get('PlanVersion')=='3' and body.get('PlanDigest')==plan_digest(profile),'exact fixed plan digest/version')
 need(body.get('ByteBalanceScope')=='declared_functional_closed_fixture' and body.get('ByteBalanceTerminal')=='terminal_tail_unjudged','byte balance scope changed')
 checks=body.get('ByteBalanceChecks');need(type(checks) is list and len(checks)<=192,'byte checks bound')
 for row in checks:
  need(type(row) is dict and row.get('Status') in ('judged_no_defect','undefined'),'byte balance source invalid/defect')
  if row['Status']=='undefined':need(row.get('Reason') in ('awaiting_second_edge','empty_network_edge','overlapping_network_edges','zero_volume','allowance_blind','partial_network_sweep'),'unknown undefined qualification')
 live,final,identities,processes=lives(body,profile)
 reduction=verify_rates(body,profile,expected,live,final,identities)
 return {'status':'SERIALIZED_JOURNAL_CONSISTENT_ORIGINAL_GO_RUNTIME_REQUIRED','scope':'DATA_CONSISTENCY_ONLY_NOT_O1A_OR_RELEASE_PASS','attempt_id_supplied_by_caller':attempt_id,'workload':workload,'config_id':header['config_id'],'sweep_run':header['run'],'route_window_nonce':params['route_wire_window'],'execution_id':body['ExecutionID'],'ledger':{'expected':1,'completed':1,'failed':0,'missing':0,'quarantined':0,'pending':0,'strangers':0},'source_stamps':stamps,'source_files_verified':len(source_files)-2,'original_record_sha256':sha(files[result_name]),'profile_sha256':sha(profile_raw),'serialized_process_labels':{node:list(processes[node]) for node in NODES},'reduction':reduction,'unknown_not_invented':UNKNOWN,'external_requirements':['exact original baseline Go test RUN/PASS no FAIL/SKIP/panic','same-attempt native/guest/input/capsule provenance','VM stopped and worker reaped/full RAW independent safety evidence'],'new_gates_added':{'external_UTC':False,'standalone512MB':False,'allByteBalanceChecksJudged':False,'G2_or_release':False}}


def verify(files,workload,profile_raw,original_manifests,attempt_id):
 try:return _verify(files,workload,profile_raw,original_manifests,attempt_id)
 except Refusal:raise
 except (KeyError,TypeError,ValueError,IndexError,OverflowError,RecursionError,AttributeError) as error:
  raise Refusal('malformed serialized report: '+type(error).__name__) from error
