import json
from pathlib import Path
import unittest
from unittest import mock
import fixtures
from o1a_journal import journal,profile,rates
from o1a_journal import verify as check_journal
class Tests(unittest.TestCase):
 def setUp(self):self.profiles={name:(Path(__file__).resolve().parent.parent/'d1-o1a-guest-preparation-v1'/(name+'.json')).read_bytes() for name in ('periodic','reconnect')}
 def check(self,workload='periodic',mutate=None,files_edit=None):
  files,manifests=fixtures.journal_files(workload,self.profiles[workload],mutate)
  if files_edit:files_edit(files)
  with mock.patch.object(journal,'PINNED_MANIFESTS',{key:journal.sha(raw) for key,raw in manifests.items()}):return check_journal(files,workload,self.profiles[workload],manifests,fixtures.ATTEMPT)
 def test_complete_periodic_and_reconnect_data(self):
  for name,window,pairs in [('periodic',240*10**9,1),('reconnect',55*10**9,2)]:
   with self.subTest(workload=name):r=self.check(name);self.assertEqual((r['reduction']['window_ns'],r['reduction']['pairs']),(window,pairs));self.assertTrue(r['unknown_not_invented']);self.assertFalse(r['new_gates_added']['external_UTC'])
 def test_missing_mark_quarantine_pending_or_stranger(self):
  edits=[lambda f:f.pop(next(n for n in f if '.verified-' in n)),lambda f:f.update({'.pending-left':b'x'}),lambda f:f.update({'stranger':b'x'}),lambda f:f.update({'any.quarantined':b'x'})]
  for edit in edits:
   with self.subTest(edit=edit),self.assertRaises(journal.Refusal):self.check(files_edit=edit)
 def test_checksum_source_copy_and_wrong_window_nonce(self):
  for edit in [lambda f:f.__setitem__(next(n for n in f if n.endswith('.result')),b'bad'),lambda f:f.__setitem__(next(n for n in f if n.endswith('fixture.go')),b'edited')]:
   with self.assertRaises(journal.Refusal):self.check(files_edit=edit)
  with self.assertRaises(journal.Refusal):self.check(mutate=lambda b,p:p.update(route_wire_window='0'*64))
 def test_rechecksummed_semantic_mutations_fail(self):
  edits=[lambda b,p:b.update(FunctionalLifecycleComplete=False),lambda b,p:b.update(AcceptanceEligible=True),lambda b,p:p.update(route_wire_required_full_routes='9999'),lambda b,p:b['RouteWireRates'].__setitem__('window_ns',1),lambda b,p:b['RouteWireRates']['nodes'][0]['sent']['full_v3'].__setitem__('bytes',101),lambda b,p:b['RouteWire'][0]['Accounting']['Endpoints'][0].__setitem__('peer','3'*40),lambda b,p:b['RouteWire'][0]['Accounting']['Endpoints'][0]['full_send'].__setitem__('periodic_passes',0),lambda b,p:b['Samples'][0]['Sample']['Traffic'].__setitem__('State','unavailable'),lambda b,p:b['RouteWireRates']['nodes'][0]['sent']['full_v3'].__setitem__('bytes',100.0),lambda b,p:b.__setitem__('RouteWirePairs',True)]
  for edit in edits:
   with self.subTest(edit=edit),self.assertRaises(journal.Refusal):self.check(mutate=edit)
 def test_reconnect_replacement_overlap_refused(self):
  def edit(b,p):b['RouteWire'][0]['Accounting']['Endpoints'][1]['session_interval']['begin_before_ns']=int(p['route_wire_begin_ns'])
  with self.assertRaises(journal.Refusal):self.check('reconnect',edit)
 def test_json_integer_and_file_bounds(self):
  self.addCleanup(mock.patch.stopall);mock.patch.object(journal,'MAX_FILE',4).start()
  for action in [lambda:journal.decode(b'{"a":1,"a":2}'),lambda:journal.integer(True),lambda:journal.safe('../escape'),lambda:journal.inventory({'one':b'x'*5})]:
   with self.assertRaises(journal.Refusal):action()
 def test_outward_rounding_and_overflow(self):
  values={name:0 for name in rates.CLASSES};values['probe']=1;self.assertEqual(rates.per_class(values,2*10**9,3*10**9)['probe'],{'bytes':1,'min_bytes_per_second':0,'max_bytes_per_second':1});values['probe']=journal.U64
  with self.assertRaises(journal.Refusal):rates.per_class(values,1,10**9)
 def test_production_api_keeps_original_source_pins(self):
  files,manifests=fixtures.journal_files('periodic',self.profiles['periodic'])
  with self.assertRaises(journal.Refusal):check_journal(files,'periodic',self.profiles['periodic'],manifests,fixtures.ATTEMPT)
if __name__=='__main__':unittest.main()
