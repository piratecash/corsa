"""ROOT-invoked offline helper QA and Linux-arm64 compile; never run resulting ELF."""
import json,os,shutil,sys
from pathlib import Path
from common import Job,need,sha,directory_bytes,static_arm64
HERE=Path(__file__).resolve().parent
SOURCE=HERE/'source'
GO='/usr/local/go/bin/go'
EXPECTED={'corsa.local/o1aguesthelpers/cmd/o1a-init':{'TestBootConfigExactSourceAndBinding','TestBootFlagsStrict','TestDuplicateJSONAndProbeRefusal','TestOriginalBudgetsRemainNested','TestDeviceModesRecoverInheritedUmask','TestDeviceModesRejectWrongTypeAndPermissions','TestDeviceModesPropagateSetAndReadFailures','TestRootModeRepairsStickyDefault','TestRootModeRejectsWrongMetadata','TestRootModePropagatesSetAndReadFailures'}}
def check_inputs(frozen):
 need(sha(frozen['data_preparation_result']['path'])==frozen['data_preparation_result']['sha256'],'data preparation changed')
 for rel,row in frozen['readback_files'].items():
  p=Path(frozen['readback_input_root'])/rel
  need(sha(p)==row['sha256'] and p.stat().st_size==row['bytes'],'source readback input changed: '+rel)
 need(sha(SOURCE/'SHA256SUMS')==frozen['source_sums_sha256'],'source manifest changed')
 for rel,row in frozen['source_files'].items():need(sha(SOURCE/rel)==row['sha256'] and (SOURCE/rel).stat().st_size==row['bytes'],'source changed: '+rel)
 for path,row in frozen['toolchain_files'].items():need(sha(path)==row['sha256'],'toolchain changed: '+path)
 need(sha(frozen['python_reference']['path'])==frozen['python_reference']['sha256'],'Python reference changed')
def go_passes(raw):
 events=[json.loads(line) for line in raw.splitlines()]
 need(not any(row.get('Action') in ('fail','skip') for row in events),'Go FAIL/SKIP')
 actual={}
 for row in events:
  if row.get('Action')=='pass' and row.get('Test') and '/' not in row['Test']:actual.setdefault(row['Package'],set()).add(row['Test'])
 need(actual==EXPECTED,'missing or unexpected Go cases')
def readback_passes(raw):
 value=json.loads(raw)
 need(value=={'status':'ORIGINAL_GO_SOURCE_API_MATCH','service_or_ELF_execution':False,'groups':{'measured':{'files':640,'sha256':'b70de373d032b8fed471c6b93bba6d034d932b322495866d40766e7c746fcd9c','stamp':'b70de373d032b8fe','manifest_bytes_equal':True,'verify_tree':'PASS'},'stand':{'files':705,'sha256':'52e346f971a30a1da05570e17b4f6133e913eaaf9ea14f433a03fc7575a77aec','stamp':'52e346f971a30a1d','manifest_bytes_equal':True,'verify_tree':'PASS'}}},'original Go source API readback incomplete')
 return value
def main():
 os.umask(0o077)
 if os.getpid()!=os.getpgrp():os.setsid()
 frozen=json.loads((HERE/'FROZEN.json').read_text());job=Job('baseline-finalizer-pid1',600,2*1024**3);error=None;artifacts={};readback=None
 try:
  need(shutil.disk_usage('/private/tmp').free>=10*1024**3,'host free space <10GiB')
  check_inputs(frozen)
  source=job.work/'source';source.mkdir()
  for rel,row in frozen['source_files'].items():
   target=source/rel;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(SOURCE/rel,target);need(sha(target)==row['sha256'],'snapshot copy mismatch');target.chmod(0o444)
  reference=job.work/'d1-o1a-guest-preparation-v1';reference.mkdir();shutil.copyfile(frozen['python_reference']['path'],reference/'journal_capsule.py')
  api=job.work/'source-api-inputs';api.mkdir()
  for rel,row in frozen['readback_files'].items():
   target=api/rel;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(Path(frozen['readback_input_root'])/rel,target);need(sha(target)==row['sha256'],'readback snapshot differs');target.chmod(0o444)
  for folder in ('cache','modcache','tmp','artifacts'):(job.work/folder).mkdir()
  env={'PATH':'/usr/local/go/bin:/usr/bin:/bin:/usr/sbin:/sbin','GOROOT':'/usr/local/go','HOME':str(job.work),'TMPDIR':str(job.work/'tmp'),'GOENV':'off','GOWORK':'off','GOVCS':'*:off','GOTOOLCHAIN':'local','GOPROXY':'off','GOSUMDB':'off','GOTELEMETRY':'off','GOPRIVATE':'','GONOSUMDB':'','GONOPROXY':'','GOINSECURE':'','GOMAXPROCS':'2','GOMEMLIMIT':'768MiB','GOFLAGS':'-p=1','GOCACHE':str(job.work/'cache'),'GOMODCACHE':str(job.work/'modcache'),'GOOS':'darwin','GOARCH':'arm64','CGO_ENABLED':'0','GOARM64':'v8.0','LC_ALL':'C','PYTHONDONTWRITEBYTECODE':'1'}
  policy='(version 1)(allow default)(deny network*)(deny file-write* (subpath '+json.dumps(str(source))+'))(deny file-write* (subpath '+json.dumps(str(api))+'))'
  def run(name,args,extra=None,cwd=None):return job.run(name,['/usr/bin/sandbox-exec','-p',policy,*args],cwd=cwd or source,env=dict(env,**(extra or {})))
  need(run('go-version',[GO,'version']).decode().strip()=='go version go1.27.4 darwin/arm64','unexpected Go version')
  readback=readback_passes(run('original-go-source-api',[GO,'run','-mod=readonly','-buildvcs=false','-p=1','./cmd/source-api-readback','--source-tree',str(api/'source-tree'),'--manifests',str(api/'manifests')],cwd=api/'source-api-module'))
  raw=run('pure-go-qa',[GO,'test','-mod=readonly','-buildvcs=false','-p=1','-count=1','-timeout=120s','-json','./cmd/o1a-init']);go_passes(raw)
  linux={'GOOS':'linux','GOARCH':'arm64','CGO_ENABLED':'0'}
  for name,target in [('o1a-init','./cmd/o1a-init')]:
   output=job.work/'artifacts'/name
   run(name+'-build',[GO,'build','-mod=readonly','-buildvcs=false','-p=1','-trimpath','-ldflags=-buildid=','-o',str(output),target],linux)
   row=static_arm64(output)
   metadata=run(name+'-metadata',[GO,'version','-m',str(output)]).decode()
   for token in ('go1.27.4','CGO_ENABLED=0','GOOS=linux','GOARCH=arm64'):need(token in metadata,'incomplete BuildInfo')
   artifacts[name]=dict(row,path=str(output),source_sums_sha256=frozen['source_sums_sha256'])
  check_inputs(frozen)
  for rel,row in frozen['source_files'].items():need(sha(source/rel)==row['sha256'],'readonly source changed')
  for rel,row in frozen['readback_files'].items():need(sha(api/rel)==row['sha256'],'readonly source readback snapshot changed')
  directory_bytes(job.work,2*1024**3)
 except BaseException as exc:error=str(exc)
 result=job.finish({'status':'PID1_BASELINE_FINALIZER_BINDINGS_QA_ELF_BUILT' if error is None else 'FAILED','error':error,'artifacts':artifacts,'original_go_source_API':readback,'host_pure_tests_expected':10,'exporter_reused_sha256':'36ed540a1dab92f28752a0fe80eef641ca4d4a04cb259ea5c0abe3ce8f79706f','exporter_go_source_unchanged':True,'linux_inventory_test':'NOT_RUN','c_capexec_build':'SEPARATE_NOT_RUN','linux_artifacts_executed':False,'source_sums_sha256':frozen['source_sums_sha256']})
 if result['error']:raise SystemExit(1)
if __name__=='__main__':main()
