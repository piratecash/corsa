package main

var FrozenProfiles=map[string]string{
"periodic":"{\n  \"Plan\": {\n    \"Seed\": 13,\n    \"FullNodes\": 2,\n    \"Hubs\": 2,\n    \"EdgeUplinks\": 1,\n    \"Duration\": 390000000000,\n    \"SampleInterval\": 15000000000,\n    \"Churn\": {\"Profile\": \"quiet\"}\n  },\n  \"Limits\": {\n    \"RouteReady\": 35000000000,\n    \"Readiness\": 30000000000,\n    \"Action\": 8000000000,\n    \"Cleanup\": 20000000000,\n    \"ReceiptDrain\": 8000000000,\n    \"AllowedLateness\": 8000000000,\n    \"MaxActions\": 128,\n    \"MaxSamples\": 96,\n    \"MaxTraceBytes\": 4194304\n  },\n  \"Timeout\": 540000000000,\n  \"StartupLead\": 90000000000,\n  \"Begin\": 120000000000,\n  \"End\": 360000000000,\n  \"MaxEndpoints\": 4,\n  \"FullReceiptRouteBudget\": 10000,\n  \"RequiredFullRoutes\": 10000,\n  \"SeedFullRoutes\": true,\n  \"RequiredFullSource\": \"periodic\",\n  \"SingleInitiator\": true,\n  \"JournalDir\": \"/profiles/o1a-periodic-journal\"\n}\n",
"reconnect":"{\n  \"Plan\": {\n    \"Seed\": 13,\n    \"FullNodes\": 2,\n    \"Hubs\": 2,\n    \"EdgeUplinks\": 1,\n    \"Duration\": 75000000000,\n    \"SampleInterval\": 15000000000,\n    \"Churn\": {\"Profile\": \"quiet\"}\n  },\n  \"Limits\": {\n    \"RouteReady\": 35000000000,\n    \"Readiness\": 30000000000,\n    \"Action\": 8000000000,\n    \"Cleanup\": 20000000000,\n    \"ReceiptDrain\": 8000000000,\n    \"AllowedLateness\": 8000000000,\n    \"MaxActions\": 128,\n    \"MaxSamples\": 96,\n    \"MaxTraceBytes\": 4194304\n  },\n  \"Timeout\": 225000000000,\n  \"StartupLead\": 90000000000,\n  \"Begin\": 5000000000,\n  \"End\": 60000000000,\n  \"MaxEndpoints\": 4,\n  \"FullReceiptRouteBudget\": 10000,\n  \"RequiredFullRoutes\": 10000,\n  \"SeedFullRoutes\": true,\n  \"RequiredFullSource\": \"connect\",\n  \"SingleInitiator\": true,\n  \"RequireReconnect\": true,\n  \"DisconnectAt\": 15000000000,\n  \"JournalDir\": \"/profiles/o1a-reconnect-journal\"\n}\n",
}
var FrozenArtifacts=map[string]Artifact{
"/bin/node.test":{Bytes:68918916,SHA256:"4722dff4abb832f6d04038022f2a4c56ae06b771bbede8d911300ed61d3b90d1"},
"/bin/loadstand-full":{Bytes:30912672,SHA256:"c46b0812cbc3130e33f885afe14a9e35b7164357646504168189bd6b87b8f1d4"},
"/bin/loadstand-sdkedge":{Bytes:33514497,SHA256:"18f71d236bea79c20b3f3f7cfa171f64d0fe3a55dafff294961dc50e1d9324c3"},
"/bin/loadstand-linuxhelper":{Bytes:10827902,SHA256:"7ad3b53bc5906c00e6b47d95af4e70ec4b8292ea677c7f9ebc8a88e7a64e764d"},
"/usr/sbin/nft":{Bytes:67544,SHA256:"db01c7e0de5d39a0ca4947f7bc413af3bd004f61511fba9be659d0f1793dc55b"},
"/config/periodic.json":{Bytes:798,SHA256:"28e76a342c9b28b8a2e1495f181f2463b35c04d64a268c705b55d789edd7791d"},
"/config/reconnect.json":{Bytes:853,SHA256:"36a65318713e5b4cb795749a4a5e12424cdfe905760f3a352b7ac602040621de"},
}
