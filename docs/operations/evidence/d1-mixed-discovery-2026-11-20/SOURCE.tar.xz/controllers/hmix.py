import os,sys,json,hashlib,subprocess,shutil
from pathlib import Path
R=Path('/Users/hades/Documents/repos/corsa');INPUT=Path('/private/tmp/corsa-d1-o1a-full-receipt-clean-findnode-guards-0216a464d806404aa07a2d8cc5acb633');S=INPUT/'source';B='a6a9fdc90d02134f5995df412a304f9e49201aa5'
sys.path.insert(0,str(R/'docs/_internal/d1-artifacts/2026-11-20/d1-o1a-capexec-seccomp-build-v1'))
from common import Job,need,sha
names={'TestOwnedFindNodeMixedV2KeepsPeerExchange','TestOwnedFindNodeMixedV2KeepsEncryptedDirectMessages','TestOwnedBareV2PilotRefusalsDoNotAdmit','TestOwnedAnswerThreeNodeOriginalRequestRelayAndSignedReturn'}
manifest=json.loads((INPUT/'GO-SOURCE-AFTER.json').read_text());need(len(manifest)==2103 and subprocess.check_output(['git','rev-parse','HEAD'],cwd=R).decode().strip()==B,'source identity')
def check():
 for n,h in manifest.items():need(sha(R/n)==sha(S/n)==h,'Go source drift '+n)
check();os.umask(0o077)
if os.getpid()!=os.getpgrp():os.setsid()
j=Job('hmix-existing-four-goqa',600,2*1024**3);error=None;counts=None
try:
 need(shutil.disk_usage('/private/tmp').free>=10*1024**3,'host free')
 for n in ('cache','tmp'):(j.work/n).mkdir()
 (j.work/'GO-SOURCE.json').write_text(json.dumps(manifest,sort_keys=True,indent=2)+'\n')
 env=os.environ.copy();env.update(GOCACHE=str(j.work/'cache'),GOMODCACHE=str(R/'.gomodcache'),TMPDIR=str(j.work/'tmp'),GOPROXY='off',GOSUMDB='off',GOTOOLCHAIN='local',GOTELEMETRY='off',GOMAXPROCS='2',GOMEMLIMIT='768MiB',GOFLAGS='-p=1',GOOS='darwin',GOARCH='arm64',CGO_ENABLED='0',GOENV='off',GOWORK='off')
 policy='(version 1)(allow default)(deny network*)(allow network-inbound (local ip "localhost:*"))(allow network-outbound (remote ip "localhost:*"))(deny file-write* (subpath '+json.dumps(str(S))+'))(deny file-write* (subpath '+json.dumps(str(R))+'))'
 raw=j.run('four-real-node-tests',['/usr/bin/sandbox-exec','-p',policy,'/usr/local/go/bin/go','test','-mod=readonly','-p=1','-parallel=1','-count=1','-timeout=180s','-json','-run=^('+'|'.join(sorted(names))+')$','./internal/core/node'],cwd=S,env=env)
 es=[json.loads(x) for x in raw.splitlines()];need(not any(x.get('Action') in ('fail','skip') for x in es),'GoFAIL/SKIP');p=[x['Test'] for x in es if x.get('Action')=='pass' and x.get('Test')];need({x for x in p if '/' not in x}==names,'testinventory');counts={'outer':len(names),'child':sum('/' in x for x in p)};check()
except BaseException as e:error=str(e)
j.finish({'status':'HMIX_EXISTING_FOUR_PASS' if error is None else 'FAILED','error':error,'base_code_commit':B,'source_snapshot':'21b146 tracked files +gofmt test; exactall2103Go/modsum equalcurrenta6','source_manifest_sha256':sha(INPUT/'GO-SOURCE-AFTER.json'),'tests':counts,'scope':'REAL_LOCALHOST_TLS_CURRENT_F1_NONF1_DELIVERY_AND_RESOLVER_ONLY','published_old31_binary_delivery':'NOT_RUN','real_presence_prober_while_FIND_NODE_pending':'NOT_COVERED','standalone_corsad_VM_piratecashd_executed':False})
if error:raise SystemExit(1)
