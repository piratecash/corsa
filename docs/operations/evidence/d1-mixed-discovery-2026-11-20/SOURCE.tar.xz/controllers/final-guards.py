import os,sys,json,shutil
from pathlib import Path
R=Path('/Users/hades/Documents/repos/corsa');I=Path('/private/tmp/corsa-d1-o1a-t7-producer-readiness-goqa-4f2cc32456334c1b93c99742414f27ba');S=I/'source'
sys.path.insert(0,str(R/'docs/_internal/d1-artifacts/2026-11-20/d1-o1a-capexec-seccomp-build-v1'))
from common import Job,need,sha
m=json.loads((I/'SOURCE-MANIFEST.json').read_text());go={n:h for n,h in m.items() if n.endswith('.go') or n in ('go.mod','go.sum')};need(len(go)==2104,'scope')
for n,h in go.items():need(sha(S/n)==sha(R/n)==h,'currentGo!=passedT7 '+n)
if os.getpid()!=os.getpgrp():os.setsid()
os.umask(0o077);j=Job('t7-final-findnode-guards',600,2*1024**3);error=None;tests=None
try:
 need(shutil.disk_usage('/private/tmp').free>=10*1024**3,'hostfree')
 for n in ('cache','tmp'):(j.work/n).mkdir()
 (j.work/'GO-SOURCE.json').write_text(json.dumps(go,sort_keys=True,indent=2)+'\n')
 old=json.loads(Path('/private/tmp/corsa-d1-native-responder-goqa-bbc0b7455f5a4a269692df9953b0c93f/result.json').read_text());step=next(x for x in old['steps'] if x.get('phase')=='findnode-guards');pattern=next(x for x in step['argv'] if x.startswith('-run='));expected=set(step['tests']['passed'])
 env=os.environ.copy();env.update(GOCACHE=str(j.work/'cache'),GOMODCACHE=str(R/'.gomodcache'),TMPDIR=str(j.work/'tmp'),GOPROXY='off',GOSUMDB='off',GOTOOLCHAIN='local',GOTELEMETRY='off',GOMAXPROCS='2',GOMEMLIMIT='768MiB',GOFLAGS='-p=1',GOOS='darwin',GOARCH='arm64',CGO_ENABLED='0',GOENV='off',GOWORK='off')
 policy='(version 1)(allow default)(deny network*)(deny file-write* (subpath '+json.dumps(str(S))+'))(deny file-write* (subpath '+json.dumps(str(R))+'))'
 raw=j.run('five-source-guards',['/usr/bin/sandbox-exec','-p',policy,'/usr/local/go/bin/go','test','-mod=readonly','-p=1','-count=1','-timeout=90s','-json',pattern,'./internal/core/findnode'],cwd=S,env=env);es=[json.loads(x) for x in raw.splitlines()];need(not any(x.get('Action') in ('fail','skip') for x in es),'GoFAILSKIP');p=[x['Test'] for x in es if x.get('Action')=='pass' and x.get('Test')];need({x for x in p if '/' not in x}==expected,'inventory');tests={'outer':5,'child':sum('/' in x for x in p)}
 for n,h in go.items():need(sha(S/n)==sha(R/n)==h,'sourceafterdrift')
except BaseException as e:error=str(e)
j.finish({'status':'T7_FINAL_SOURCE_GUARDS_PASS' if error is None else 'STOP','error':error,'tests':tests,'Go_source_count':len(go),'T7_manifest_sha256':'c3aea5015be9871c7578f620dc7ec48c88e6e16bc66748ec3a3ed080038016e8','scope':'FIVE_SOURCE_GUARDS_CURRENT_APPLIED_TESTS_NO_PROD_OR_VM','Go_test_only':True})
if error:raise SystemExit(1)
