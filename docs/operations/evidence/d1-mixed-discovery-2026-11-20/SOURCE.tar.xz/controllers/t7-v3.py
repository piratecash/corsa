import os,sys,json,hashlib,subprocess,shutil
from pathlib import Path
R=Path('/Users/hades/Documents/repos/corsa');P=R/'docs/_internal/d1-artifacts/2026-11-20/d1-o1a-t7-identity-presence-source-v3';I=Path('/private/tmp/corsa-d1-o1a-full-receipt-clean-findnode-guards-0216a464d806404aa07a2d8cc5acb633');B='a6a9fdc90d02134f5995df412a304f9e49201aa5'
sys.path.insert(0,str(R/'docs/_internal/d1-artifacts/2026-11-20/d1-o1a-capexec-seccomp-build-v1'))
from common import Job,need,sha
need(sha(P/'MANIFEST.json')=='c3aea5015be9871c7578f620dc7ec48c88e6e16bc66748ec3a3ed080038016e8','manifestdrift');m=json.loads((P/'MANIFEST.json').read_text());before=json.loads((I/'SOURCE-MANIFEST.json').read_text());gomap=json.loads((I/'GO-SOURCE-AFTER.json').read_text())
for n,h in gomap.items():need(sha(R/n)==sha(I/'source'/n)==h,'Go source drift')
for row in m['files']:
 need(sha(P/row['post'])==row['after_sha256'],'postdrift');n=row['path'];need((n not in before) if row['new_file'] else before[n]==row['before_sha256'],'beforeimage')
names={'TestOwnedFindNodeT7RealIdentityAndPresenceWhilePending','TestOwnedBareV2PilotClosedTestOnlyAdvertisement','TestOwnedBareV2PilotAdvertisementSourceControls'}
os.umask(0o077)
if os.getpid()!=os.getpgrp():os.setsid()
j=Job('t7-producer-readiness-goqa',600,2*1024**3);error=None;counts=None
try:
 need(shutil.disk_usage('/private/tmp').free>=10*1024**3,'hostfree')
 for n in ('source','cache','tmp'):(j.work/n).mkdir()
 src=j.work/'source';after=dict(before)
 for n,h in before.items():
  q=src/n;q.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(I/'source'/n,q);need(sha(q)==h,'copydrift');q.chmod(0o444)
 for row in m['files']:
  q=src/row['path'];q.parent.mkdir(parents=True,exist_ok=True)
  if q.exists():q.chmod(0o600)
  q.write_bytes((P/row['post']).read_bytes());q.chmod(0o444);after[row['path']]=row['after_sha256']
 (j.work/'SOURCE-MANIFEST.json').write_text(json.dumps(after,sort_keys=True,indent=2)+'\n')
 env=os.environ.copy();env.update(GOCACHE=str(j.work/'cache'),GOMODCACHE=str(R/'.gomodcache'),TMPDIR=str(j.work/'tmp'),GOPROXY='off',GOSUMDB='off',GOTOOLCHAIN='local',GOTELEMETRY='off',GOMAXPROCS='2',GOMEMLIMIT='768MiB',GOFLAGS='-p=1',GOOS='darwin',GOARCH='arm64',CGO_ENABLED='0',GOENV='off',GOWORK='off')
 policy='(version 1)(allow default)(deny network*)(allow network-inbound (local ip "localhost:*"))(allow network-outbound (remote ip "localhost:*"))(deny file-write* (subpath '+json.dumps(str(src))+'))(deny file-write* (subpath '+json.dumps(str(R))+'))'
 raw=j.run('functional-and-pilot-guards',['/usr/bin/sandbox-exec','-p',policy,'/usr/local/go/bin/go','test','-mod=readonly','-p=1','-parallel=1','-count=1','-timeout=180s','-json','-run=^('+'|'.join(sorted(names))+')$','./internal/core/node'],cwd=src,env=env)
 es=[json.loads(x) for x in raw.splitlines()];need(not any(x.get('Action') in ('fail','skip') for x in es),'GoFAIL/SKIP');passed=[x['Test'] for x in es if x.get('Action')=='pass' and x.get('Test')];need({x for x in passed if '/' not in x}==names,'testinventory');counts={'outer':len(names),'child':sum('/' in x for x in passed)}
 need({n:sha(src/n) for n in after}==after,'readonlysourcechanged')
 for n,h in gomap.items():need(sha(R/n)==h,'rootGodrift')
 for row in m['files']:need(sha(P/row['post'])==row['after_sha256'],'postafterdrift')
except BaseException as e:error=str(e)
j.finish({'status':'T7_REAL_IDENTITY_PRESENCE_FUNCTIONAL_PASS' if error is None else 'STOP','error':error,'manifest_sha256':sha(P/'MANIFEST.json'),'base_code_commit':B,'source_snapshot':'Exacta6Go2103+two test-onlyposts; trackedmetadatafrompriorclean21bcopy','tests':counts,'scope':'FUNCTIONAL_T7_NATURAL_PRODUCER_READINESS_ORIGINAL_REQUEST_BUDGETS','old_published31_binary_delivery':'NOT_RUN','D1_load_latency_metrics':'NOT_MEASURED','standalone_corsad_VM_piratecashd_executed':False})
if error:raise SystemExit(1)
