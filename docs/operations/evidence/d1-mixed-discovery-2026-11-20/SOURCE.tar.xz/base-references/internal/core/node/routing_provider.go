package node

import (
	"github.com/piratecash/corsa/internal/core/domain"
	"github.com/piratecash/corsa/internal/core/protocol"
	"github.com/piratecash/corsa/internal/core/routing"
)

// RoutingSnapshot returns the cached routing snapshot maintained by the
// hot-reads refresher (see routing_snapshot.go and hot_reads_refresh.go).
// Reads are lock-free: a single atomic.Pointer.Load with no acquisition
// of routing.Table.t.mu (neither RLock nor the publisher's Lock) on the
// RPC path.
//
// Two staleness bounds apply (see docs/routing.md "Snapshot freshness"):
//
//   - Structural changes (route accepted/withdrawn/replaced, direct peer
//     added/removed, flap burst arming hold-down, flap-state cleanup
//     after a writer touched the table) are reflected within
//     routingSnapshotMinInterval (2 s — the coalescing floor that throttles
//     the 500 ms refresher) plus the next refresh tick that crosses that
//     floor (~500 ms) plus the publisher's t.mu.Lock acquisition time
//     (SnapshotIncremental takes the exclusive lock to consume the snap
//     dirty-set and update the reuse cache) — on the order of 2–2.5 s.
//   - Time-derived state (`IsExpired`, `ttl_seconds` evaluated against
//     `snap.TakenAt`, `FlapEntry.InHoldDown` flipping from true to
//     false on hold-down expiry) lags up to TickTTL_interval (≈10 s)
//     plus the structural publish bound (routingSnapshotMinInterval
//     floor + a refresh tick, ~2–2.5 s), i.e. ≈12–12.5 s: the dirty-flag
//     publisher only republishes when a writer touches the table, but
//     TTL elapse and hold-down expiry are wall-clock events without a
//     writer until TickTTL rewrites the entry. Hold-down arming is a
//     writer event and is reflected within the structural bound (~2–2.5 s).
//
// Returned routing.Snapshot must NOT be mutated by callers — the underlying
// routes map is shared between every concurrent reader of the same
// publish generation. Mutating it would corrupt observers downstream;
// the next refresh produces a brand-new map under a new pointer rather
// than mutating in place.
//
// Callers that require a strictly fresh view — most commonly because
// they make decisions that depend on TTL freshness, such as
// file_integration.isPeerReachable — should call
// s.routingTable.Snapshot() or s.routingTable.Lookup() directly. Those
// paths take t.mu.RLock and pay the full deep-copy cost (Snapshot) or
// an O(K) per-destination scan (Lookup); they are not exposed over RPC.
//
// Implements rpc.RoutingProvider.
func (s *Service) RoutingSnapshot() routing.Snapshot {
	return s.loadRoutingSnapshot()
}

// PeerTransport resolves a peer identity to its current transport address
// and network group. Returns zero values if the peer is not currently
// connected. When a peer has multiple sessions, the lexicographically
// smallest connected address is returned for deterministic output.
//
// The health map (Connected flag) is the source of truth for live
// connectivity. peerIDs entries alone are not sufficient because normal
// disconnect paths do not clear them immediately.
//
// Locking: takes s.peerMu.RLock for the iteration of peerIDs / health.
// Unlike Service.RoutingSnapshot — which is fully lock-free via the
// cached atomic.Pointer — this method is still coupled to peer-domain
// writers. routeTableHandler calls it once per unique next-hop identity
// (cached inside the handler), so under a peer-domain writer storm
// fetchRouteTable can still observe stalls even though the routing
// snapshot itself is now lock-free. Migrating PeerTransport onto a
// cached peer-transport view is a follow-up task; see docs/routing.md
// "Snapshot freshness" for the explicit contract.
// Implements rpc.RoutingProvider.
func (s *Service) PeerTransport(peerIdentity domain.PeerIdentity) (address domain.PeerAddress, network domain.NetGroup) {
	s.peerMu.RLock()
	defer s.peerMu.RUnlock()

	var bestAddr domain.PeerAddress
	for addr, recorded := range s.peerIDs {
		if recorded.identity != peerIdentity {
			continue
		}
		resolved := s.resolveHealthAddress(addr)
		h := s.health[resolved]
		if h == nil || !h.Connected {
			continue
		}
		if bestAddr == "" || addr < bestAddr {
			bestAddr = addr
		}
	}
	if bestAddr == "" {
		return "", ""
	}
	return bestAddr, classifyAddress(bestAddr)
}

// reachableIDsFrame returns identities that have at least one live route in
// the routing table. Used by desktop clients in remote TCP mode where direct
// RoutingSnapshot() is not available.
//
// Reads from the cached routing snapshot — the same lock-free path that
// fetchRouteTable / fetchRouteSummary use. Two staleness bounds apply
// (see RoutingSnapshot doc): structural reachability changes (peer
// connect / withdraw) are visible within ~2–2.5 s (routingSnapshotMinInterval
// floor plus the next refresh tick plus the publisher's t.mu.Lock); TTL-derived
// expiry inside the cached projection is evaluated against snap.TakenAt and may
// lag up to TickTTL_interval + the structural publish bound (~2–2.5 s), i.e.
// ~12–12.5 s, for routes that age out without any other table mutation. Both
// bounds are acceptable for a
// UI reachability indicator: this frame feeds desktop polling, not
// message routing — operators see reachable=true for an aged-out route
// for at most one TickTTL cycle, never an action that depends on
// strict TTL freshness.
//
// The synthetic local self-route (RouteSourceLocal) is excluded because
// reachability is about remote peers, not the node itself.
func (s *Service) reachableIDsFrame() protocol.Frame {
	reachable := s.loadReachableIDsSnapshot()
	ids := make([]string, 0, len(reachable))
	for _, id := range reachable {
		ids = append(ids, id.String())
	}
	return protocol.Frame{
		Type:       "reachable_ids",
		Identities: ids,
	}
}

// OverloadStats returns the cumulative engagement counters for the
// announce-loop overload gate. Surfaced via fetchRouteSummary so
// operators can see whether backpressure is firing in production.
// Lock-free: the underlying counter is in-memory atomic on AnnounceLoop.
//
// Implements rpc.RoutingProvider.
func (s *Service) OverloadStats() routing.OverloadStats {
	if s.announceLoop == nil {
		return routing.OverloadStats{}
	}
	return routing.OverloadStats{
		EngagedCycles: s.announceLoop.OverloadCycleCount(),
	}
}

// DigestHeartbeatStats returns the cumulative route_sync digest-as-heartbeat
// counters. Surfaced via fetchRouteSummary so operators can see, without debug
// logging, whether periodic heartbeats are confirmed (suppressing full syncs)
// or diverging. Lock-free: all underlying counters are in-memory atomics.
//
// Implements rpc.RoutingProvider.
func (s *Service) DigestHeartbeatStats() routing.DigestHeartbeatStats {
	return routing.DigestHeartbeatStats{
		HeartbeatsSent:  s.digestStats.heartbeatsSent.Load(),
		SummaryMatch:    s.digestStats.summaryMatch.Load(),
		SummaryMismatch: s.digestStats.summaryMismatch.Load(),
		DigestsCompared: s.digestStats.digestsCompared.Load(),
		CompareMatch:    s.digestStats.compareMatch.Load(),
	}
}

// JournalCauseStats returns the per-cause change-journal append tally for
// steady-state churn attribution, surfaced via fetchRouteSummary. Delegates to
// routing.Table.JournalCauseStats (lock-free atomic reads). Returns nil when
// the routing table is not wired (legacy test fixtures) or journal-less.
//
// Implements rpc.RoutingProvider.
func (s *Service) JournalCauseStats() map[string]uint64 {
	if s.routingTable == nil {
		return nil
	}
	return s.routingTable.JournalCauseStats()
}

// HealthSnapshot returns the Phase 2 per-(Identity, Uplink)
// RouteHealthState snapshot for fetchRouteHealth RPC observability.
// Delegates to routing.Table.HealthSnapshot which takes t.mu.RLock
// and returns a deep-copied slice; safe to publish lock-free.
//
// Returns nil when the routing table is not wired (legacy test
// fixtures) or when no health entries are tracked yet.
//
// Implements rpc.RoutingProvider.
func (s *Service) HealthSnapshot() []routing.RouteHealthState {
	if s.routingTable == nil {
		return nil
	}
	return s.routingTable.HealthSnapshot()
}

// ReputationSnapshot returns the Phase 3 PR 12.7 per-(Identity,
// Uplink) reputation snapshot for fetchRouteReputation RPC
// observability. Delegates to routing.Table.ReputationSnapshot
// which takes t.mu.RLock and returns a deep-copied slice.
//
// Returns nil when the routing table is not wired (legacy test
// fixtures) or when no reputation entries are tracked yet so
// callers can compare cheaply.
//
// Implements rpc.RoutingProvider.
func (s *Service) ReputationSnapshot() []routing.RouteReputationState {
	if s.routingTable == nil {
		return nil
	}
	return s.routingTable.ReputationSnapshot()
}
