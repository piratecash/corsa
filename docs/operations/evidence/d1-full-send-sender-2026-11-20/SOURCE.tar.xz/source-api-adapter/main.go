// Private host-only source readback; never part of the 1348 disposable source paths.
package main

import (
    "bytes"
    "context"
    "crypto/sha256"
    "encoding/hex"
    "encoding/json"
    "flag"
    "fmt"
    "os"
    "path/filepath"
    "strings"
    "time"

    "github.com/piratecash/corsa/internal/testutil/runjournal"
)

func fail(err error) { fmt.Fprintln(os.Stderr, err); os.Exit(1) }

func main() {
    base := flag.String("source-tree", "", "exact archive-selected source tree")
    manifests := flag.String("manifests", "", "canonical expected manifests")
    flag.Parse()
    if *base == "" || *manifests == "" || flag.NArg() != 0 { fail(fmt.Errorf("exact source-tree/manifests required")) }
    ctx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
    defer cancel()
    testGo := func(p string) bool { return strings.HasSuffix(p, "_test.go") }
    specs := []runjournal.SourceSpec{
        {Name: "measured", Base: *base, Roots: []runjournal.SourceRoot{{Dir: "internal/core", Recursive: true, Filter: func(p string) bool { return filepath.Ext(p) == ".go" && !testGo(p) }}}},
        {Name: "stand", Base: *base, Roots: []runjournal.SourceRoot{{Dir: "internal/core/node", Recursive: false, Filter: testGo}, {Dir: "internal/testutil/loadstand", Recursive: true, Filter: func(p string) bool { return filepath.Ext(p) == ".go" }}, {Dir: "sdk", Recursive: true, Filter: func(p string) bool { return filepath.Ext(p) == ".go" }}}},
    }
    expected := map[string]struct { Count int; SHA string }{
        "measured": {640, "90f33126457b02a039ccde6751643770ff260d014c280442daa64df7f9cc92cf"},
        "stand": {708, "78d671b120e64887b7a7a7c827d3c114a4d03c0fa1f4aee861fbd3fa7ce3185e"},
    }
    rows := map[string]any{}
    for _, spec := range specs {
        snapshot, err := runjournal.TakeSnapshot(ctx, spec)
        if err != nil { fail(err) }
        manifest := snapshot.Manifest()
        wanted, err := os.ReadFile(filepath.Join(*manifests, string(spec.Name)+".expected.manifest"))
        if err != nil { fail(err) }
        sum := sha256.Sum256(manifest)
        digest := hex.EncodeToString(sum[:])
        want := expected[string(spec.Name)]
        stamp := snapshot.Stamp()
        if !bytes.Equal(manifest, wanted) || len(snapshot.Files()) != want.Count || digest != want.SHA || string(stamp.Name) != string(spec.Name) || string(stamp.Stamp) != want.SHA[:16] {
            fail(fmt.Errorf("canonical source readback differs: %s", spec.Name))
        }
        if err := snapshot.VerifyTree(ctx); err != nil { fail(err) }
        rows[string(spec.Name)] = map[string]any{"files": len(snapshot.Files()), "sha256": digest, "stamp": stamp.Stamp, "manifest_bytes_equal": true, "verify_tree": "PASS"}
    }
    if err := json.NewEncoder(os.Stdout).Encode(map[string]any{"status": "ORIGINAL_GO_SOURCE_API_MATCH", "groups": rows, "service_or_ELF_execution": false}); err != nil { fail(err) }
}
