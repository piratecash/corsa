package main

var FrozenProfiles=map[string]string{
"periodic":"{\n  \"Plan\": {\n    \"Seed\": 13,\n    \"FullNodes\": 2,\n    \"Hubs\": 2,\n    \"EdgeUplinks\": 1,\n    \"Duration\": 390000000000,\n    \"SampleInterval\": 15000000000,\n    \"Churn\": {\"Profile\": \"quiet\"}\n  },\n  \"Limits\": {\n    \"RouteReady\": 35000000000,\n    \"Readiness\": 30000000000,\n    \"Action\": 8000000000,\n    \"Cleanup\": 20000000000,\n    \"ReceiptDrain\": 8000000000,\n    \"AllowedLateness\": 8000000000,\n    \"MaxActions\": 128,\n    \"MaxSamples\": 96,\n    \"MaxTraceBytes\": 4194304\n  },\n  \"Timeout\": 540000000000,\n  \"StartupLead\": 90000000000,\n  \"Begin\": 120000000000,\n  \"End\": 360000000000,\n  \"MaxEndpoints\": 4,\n  \"FullReceiptRouteBudget\": 10000,\n  \"RequiredFullRoutes\": 10000,\n  \"SeedFullRoutes\": true,\n  \"RequiredFullSource\": \"periodic\",\n  \"SingleInitiator\": true,\n  \"JournalDir\": \"/profiles/o1a-periodic-journal\"\n}\n",
"reconnect":"{\n  \"Plan\": {\n    \"Seed\": 13,\n    \"FullNodes\": 2,\n    \"Hubs\": 2,\n    \"EdgeUplinks\": 1,\n    \"Duration\": 20000000000,\n    \"SampleInterval\": 5000000000,\n    \"Churn\": {\n      \"Profile\": \"quiet\"\n    }\n  },\n  \"Limits\": {\n    \"RouteReady\": 35000000000,\n    \"Readiness\": 30000000000,\n    \"Action\": 8000000000,\n    \"Cleanup\": 20000000000,\n    \"ReceiptDrain\": 8000000000,\n    \"AllowedLateness\": 8000000000,\n    \"MaxActions\": 128,\n    \"MaxSamples\": 96,\n    \"MaxTraceBytes\": 4194304\n  },\n  \"Timeout\": 90000000000,\n  \"StartupLead\": 10000000000,\n  \"Begin\": 2000000000,\n  \"End\": 15000000000,\n  \"MaxEndpoints\": 4,\n  \"FullReceiptRouteBudget\": 10000,\n  \"RequiredFullRoutes\": 10000,\n  \"SeedFullRoutes\": true,\n  \"RequiredFullSource\": \"connect\",\n  \"SingleInitiator\": true,\n  \"RequireReconnect\": true,\n  \"DisconnectAt\": 6000000000,\n  \"JournalDir\": \"/profiles/o1a-reconnect-journal\"\n}\n",
}
var FrozenArtifacts=map[string]Artifact{
"/bin/node.test":{Bytes:68933144,SHA256:"b40969a61fce7a273a0facfaa716ba56b3044494f0c12aee7750cd5e7e0003a7"},
"/bin/loadstand-full":{Bytes:30917141,SHA256:"a4df3383e76996afba981d1f85367c2c07619c3505cb0c25a1d2138de9802b05"},
"/bin/loadstand-sdkedge":{Bytes:33519347,SHA256:"d3ed59043381a08c60a98e883da38c43fd9525a07a32be07326686d77cb7ea16"},
"/bin/loadstand-linuxhelper":{Bytes:10832482,SHA256:"4a1bd9c2cefa7b44449399c225d745d0825495a0285cf5b0293046d4c10d2ce3"},
"/usr/sbin/nft":{Bytes:67544,SHA256:"db01c7e0de5d39a0ca4947f7bc413af3bd004f61511fba9be659d0f1793dc55b"},
"/config/periodic.json":{Bytes:798,SHA256:"28e76a342c9b28b8a2e1495f181f2463b35c04d64a268c705b55d789edd7791d"},
"/config/reconnect.json":{Bytes:862,SHA256:"f84856cfa6f3c3d39f4f5d69487c5d968106aeea77b16f8a3d7bf864266e7369"},
}
