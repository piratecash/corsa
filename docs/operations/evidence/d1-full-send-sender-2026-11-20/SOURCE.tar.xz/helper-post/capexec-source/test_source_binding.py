from pathlib import Path
import hashlib
import unittest

HERE=Path(__file__).resolve().parent

class Tests(unittest.TestCase):
    def test_exact_historical_policy_and_frozen_product_pins(self):
        self.assertEqual(hashlib.sha256((HERE/'guest_policy.h').read_bytes()).hexdigest(),'699c0a05f15cdf93c620326a2bc1112b53932f06dc08bd6a343076b22416162c')
        self.assertEqual(hashlib.sha256((HERE/'frozen_inputs.h').read_bytes()).hexdigest(),'e2ff195c9511988de9ed52e300112f9ababce6a8ebcdedfc86ce46177e8b89ab')
    def test_original_caps_and_selected_go_argv_preserved(self):
        source=(HERE/'capexec.c').read_text();old=Path('/Users/hades/Documents/repos/corsa/docs/_internal/d1-artifacts/2026-11-20/d1-o1a-capexec-no-pie-v1/source/capexec.c').read_text()
        for prefix in ('#define ALLOWED ','    const char *keys[]=','    const char *expected[]=','    char *timeout=','    char *arguments[]='):
            self.assertEqual([x for x in source.splitlines() if x.startswith(prefix)],[x for x in old.replace('"-test.timeout=255s"', '"-test.timeout=120s"').splitlines() if x.startswith(prefix)])
        self.assertEqual(source.count('prctl(PR_SET_SECCOMP,'),1)
        self.assertIn('restrict_caps();install_policy_and_controls();',source)
    def test_dump_has_factory_and_no_security_or_app_side_effect_calls(self):
        source=(HERE/'policy_dump.c').read_text();self.assertIn('struct guest_policy p=guest_policy();',source)
        for forbidden in ('prctl(','syscall(','execve(','fexecve(','socket(','system(','fork('):self.assertNotIn(forbidden,source)

if __name__=='__main__':unittest.main()
