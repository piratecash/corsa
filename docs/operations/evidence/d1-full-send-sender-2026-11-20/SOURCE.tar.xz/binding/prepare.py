"""Data-only binding of the new baseline harness archives on the same accepted kernel.

Does not compile, claim, start a worker or invoke pack_job. It deliberately
leaves generated runtime readiness CODE/ROOT false for final DATA review.
"""
from pathlib import Path
import hashlib
import gzip
import copy
import json
import os
import re
import stat
import sys

HERE=Path(__file__).resolve().parent
DAY=HERE.parent
OLD=DAY/'d1-o1a-observer-coherent-runtime-v1'
OLD_KERNEL='6b7aa1f9357bc94136c67888f4a9c09643c462bcd5bae31a643f7d62ca51ab41'
BUILD_HANDOFF='a6fd0312aef012e089028460d5a9d5f91b5a6e014dabb6e390942bf4183cb736'
DELTA={'CONFIG_FIB_RULES':{'before':'n','after':'y'},'CONFIG_IPV6_MULTIPLE_TABLES':{'before':'n','after':'y'}}

def need(ok,why):
    if not ok:raise ValueError(why)

def immutable(s):
    return (s.st_dev,s.st_ino,s.st_uid,s.st_gid,s.st_mode,s.st_nlink,s.st_size,s.st_mtime_ns,s.st_ctime_ns)

def file_hash(path,limit):
    path=Path(path);s=path.lstat();need(stat.S_ISREG(s.st_mode) and s.st_nlink==1 and 0<s.st_size<=limit,'bounded regular input')
    h=hashlib.sha256();remaining=s.st_size
    with os.fdopen(os.open(path,os.O_RDONLY|os.O_CLOEXEC|os.O_NOFOLLOW),'rb') as stream:
        need(immutable(os.fstat(stream.fileno()))==immutable(s),'input replaced at open')
        while remaining:
            data=stream.read(min(1024**2,remaining));need(data,'short input');h.update(data);remaining-=len(data)
        need(not stream.read(1),'growing input')
        need(immutable(os.fstat(stream.fileno()))==immutable(s),'opened input changed')
    need(immutable(path.lstat())==immutable(s),'changed input');return h.hexdigest()

def record(path,limit=2*1024**2):
    digest=file_hash(path,limit)
    with Path(path).open('rb') as stream:raw=stream.read(limit+1)
    need(len(raw)<=limit and hashlib.sha256(raw).hexdigest()==digest,'record changed');return json.loads(raw)

def qualified_kernel(result):
    need(result.get('error') is None and result.get('cleanup_confirmed') is True and result.get('volume_removed') is True,'kernel build did not close')
    need(result.get('handoff_sha256')==BUILD_HANDOFF and result.get('toolchain_image_id')=='sha256:45ccc728acf675888bde399354b6c8338accfc591e35496f9413a3742f3ae313' and result.get('linux_source_sha256')=='81764a545072d160748beff4d9de2e7d95aa9f16e8261110288f067a2cc61d71','exact reviewed build/source/toolchain')
    kernel=result.get('kernel');need(type(kernel) is dict,'kernel result')
    delta=kernel.get('o1a_config_delta');need(type(delta) is dict and delta.get('semantic_changes')==DELTA and delta.get('baseline_sha256')=='c235b7569999b2591b2a0d90ab48b7a1828317fcf4fc2e79596e6c928e279c44','exact environment correction')
    need('CONFIG_IPV6_MULTIPLE_TABLES' in kernel.get('required_builtin',[]),'new builtin requirement')
    digest=kernel.get('image_sha256');need(type(digest) is str and re.fullmatch('[0-9a-f]{64}',digest) and digest!=OLD_KERNEL,'new image pin')
    return kernel

# Exact same member set; private observer payloads only, no new paths.
NEW_SOURCE_PATHS=frozenset()
NEW_DIRECTORIES=frozenset()
EXPECTED_PAYLOAD_NAMES=frozenset(['bin/capexec', 'bin/loadstand-full', 'bin/loadstand-linuxhelper', 'bin/loadstand-sdkedge', 'bin/node.test', 'init', 'source/internal/core/node/loadstand_route_wire_full_receipt.go', 'source/internal/core/node/loadstand_route_wire_full_send.go', 'source/internal/testutil/loadstand/censusdiag/diagnostic.go'])
EXPECTED_MEMBER_NAMES=EXPECTED_PAYLOAD_NAMES
NEW_SOURCE_SHA='aaa268a9e05b73eb0494bde5baf06cf77b8ef7b223062dcda1de04b951f27686'
COMPONENT_PROFILE='f84856cfa6f3c3d39f4f5d69487c5d968106aeea77b16f8a3d7bf864266e7369'
PURPOSE='DISPOSABLE_OBSERVER_FIRST_FAILURE_DIAGNOSTIC'

def exact_member_delta(before,after,expected):
    need(set(expected)==EXPECTED_MEMBER_NAMES,'exact component subject members required')
    need(set(after)==set(before)|NEW_SOURCE_PATHS|NEW_DIRECTORIES,'component archive member set changed')
    need(not (NEW_SOURCE_PATHS|NEW_DIRECTORIES),'observer must not add paths')
    need(after.get('config/boot.json',{}).get('mode')==before['config/boot.json']['mode']=='0o100644','boot mode changed')
    for name in after:
        if name=='config/boot.json':continue
        if name in expected:
            need(after[name]==expected[name],'new subject member differs: '+name)
            if name in before:need(after[name]['mode']==before[name]['mode'],'existing member mode changed')
        else:need(before[name]==after[name],'unexpected member delta: '+name)


def boot_record(path,expected_sha):
    # Bounded streaming cpio read; only the <=1MiB boot record is retained.
    consumed=0;seen=set()
    with gzip.open(path,'rb') as stream:
        def read(n):
            nonlocal consumed
            need(0<=n<=1024**2,'cpio read bound');consumed+=n;need(consumed<=256*1024**2,'cpio total bound')
            raw=stream.read(n);need(len(raw)==n,'short cpio');return raw
        for unused in range(4096):
            h=read(110);need(h[:6]==b'070701','newc magic')
            try:fields=[int(h[i:i+8],16) for i in range(6,110,8)]
            except ValueError:raise ValueError('invalid newc header')
            size=fields[6];namesize=fields[11];need(1<namesize<=1024 and size<=96*1024**2,'newc member bounds')
            name=read(namesize);need(name.endswith(b'\0') and b'\0' not in name[:-1],'newc name');name=name[:-1].decode('ascii');need(name not in seen,'duplicate member');seen.add(name)
            need(read((-110-namesize)%4).strip(b'\0')==b'','name padding')
            if name=='config/boot.json':
                need(size<=1024**2 and fields[1]==0o100644,'boot record bound/mode');raw=read(size);need(hashlib.sha256(raw).hexdigest()==expected_sha,'boot record hash');return json.loads(raw)
            need(name!='TRAILER!!!','boot record missing')
            remaining=size
            while remaining:
                part=min(remaining,1024**2);read(part);remaining-=part
            need(read((-size)%4).strip(b'\0')==b'','data padding')
    raise ValueError('boot record member count')

def exact_boot_delta(before,after,attempt,expected):
    need(set(expected)==EXPECTED_MEMBER_NAMES,'exact component subject member pins required')
    need('/init' not in before.get('files',{}) and '/init' not in after.get('files',{}),'PID1 not a product input')
    need(after.get('attempt_id')==attempt and after.get('source_archive_sha256')==NEW_SOURCE_SHA and after.get('profile_sha256')==COMPONENT_PROFILE and after.get('workload')=='reconnect','fresh component boot/source/profile mismatch')
    restored=copy.deepcopy(after);restored['attempt_id']=before['attempt_id'];restored['source_archive_sha256']=before['source_archive_sha256'];restored['profile_sha256']=before['profile_sha256']
    for name,want in expected.items():
        if name=='init' or name in NEW_DIRECTORIES:continue
        key='/'+name;row={k:want[k] for k in ('bytes','sha256')}
        need(after.get('files',{}).get(key)==row,'new boot subject differs: '+name)
        if name in NEW_SOURCE_PATHS:
            need(key not in before['files'],'new source unexpectedly existed');del restored['files'][key]
        else:
            need(key in before['files'],'old boot input missing');restored['files'][key]=copy.deepcopy(before['files'][key])
    need(restored==before,'unexpected component boot configuration change')


def runtime_sources():
    out={name:(OLD/name).read_bytes() for name in ('launch.py','support.py','verify.py','ack.py')}
    raw=out['launch.py'];before=b'50358b0d7c95a0ea8b40395bae1fbabbcbd2ccd53e113e4d14e06d28819cee9d'
    need(raw.count(before)==1,'source archive literal missing/ambiguous')
    out['launch.py']=raw.replace(before,NEW_SOURCE_SHA.encode())
    return out


def main():
    need(len(sys.argv)==3,'kernel result and fresh pack result paths required')
    kernel_path,pack_path=map(Path,sys.argv[1:]);kernel_result=record(kernel_path);kernel=qualified_kernel(kernel_result);pack=record(pack_path)
    need(kernel['image_sha256']=='9ffeb24f4131ec4c5177b83c4a74ed8af699553c00a6b0d7f0d0ff4e98970c73','same accepted kernel only')
    need(pack.get('status')=='OBSERVER_FIRST_FAILURE_INITRD_BYTE_VERIFIED' and pack.get('error') is None and pack.get('ELF_or_VM_executed') is False and pack.get('unknown') is False and pack.get('lock_retained') is False,'fresh data assembly failed')
    outputs=pack.get('outputs');need(type(outputs) is dict and set(outputs)=={'reconnect'},'one component reconnect transport')
    image=kernel_path.parent/'work'/'result'/'Image';need(file_hash(image,96*1024**2)==kernel['image_sha256'],'new image bytes changed')
    need(file_hash(image.with_name('config'),1024**2)==kernel['config_sha256'],'new config bytes changed')
    frozen=record(HERE/'FROZEN.json');need(frozen['status']=='ACTUAL_HELPERS_BOUND_NOT_RUNTIME','component references not bound');need(all(file_hash(path,2*1024**2)==row['sha256'] for path,row in frozen['reference_files'].items()),'component data/helper reference changed');need(all(file_hash(OLD/name,1024**2)==wanted for name,wanted in frozen['old_runtime_sources'].items()),'accepted old runtime source changed')
    need(file_hash(OLD/'HANDOFF.json',32768)==frozen['old_handoff_sha256'],'accepted old handoff changed')
    old_handoff=record(OLD/'HANDOFF.json');records={};attempts=set();planned={}
    for phase in ('reconnect',):
        row=outputs[phase];need(type(row['attempt_id']) is str and re.fullmatch('[0-9a-f]{32}',row['attempt_id']) and row['attempt_id'] not in attempts,'fresh distinct attempts');attempts.add(row['attempt_id'])
        receipt=record(Path(row['receipt']));need(receipt['scope']=='DISPOSABLE_OBSERVER_FIRST_FAILURE_DIAGNOSTIC_INITRAMFS_DATA_READBACK_ONLY' and receipt['elf_or_vm_executed'] is False and receipt['source_files']==1348 and receipt['source_archive_sha256']==NEW_SOURCE_SHA,'component diagnostic source subject')
        need(receipt['workload']==phase and receipt['attempt_id']==row['attempt_id'] and receipt['config_sha256']==row['config_sha256'],'assembly/attempt/config binding')
        need(file_hash(Path(row['receipt']),2*1024**2)==row['receipt_sha256'] and file_hash(Path(row['archive']),128*1024**2)==row['archive_sha256']==receipt['archive']['sha256'],'assembly bytes')
        baseline=frozen['baseline_assemblies'][phase];need(file_hash(baseline['path'],2*1024**2)==baseline['sha256'],'baseline assembly changed')
        old_receipt=record(baseline['path']);exact_member_delta(old_receipt['members'],receipt['members'],frozen['expected_members'])
        need(file_hash(baseline['archive'],128*1024**2)==baseline['archive_sha256'],'baseline archive changed')
        exact_boot_delta(boot_record(baseline['archive'],old_receipt['members']['config/boot.json']['sha256']),boot_record(row['archive'],receipt['members']['config/boot.json']['sha256']),row['attempt_id'],frozen['expected_members'])
        for name,wanted in frozen['original_members'].items():need(receipt['members'][name]==frozen['expected_members'].get(name,wanted),'bound ELF/helper/profile changed: '+name)
        for name in ('bin/loadstand-full','bin/loadstand-linuxhelper','bin/loadstand-sdkedge','usr/sbin/nft'):need(receipt['members'][name]['mode']=='0o100555','preserve audited0555')
        destination=DAY/'d1-o1a-full-send-leaf-runtime-v1';need(not destination.exists(),'runtime destination already exists')
        planned[phase]=(row,destination)
    for phase in ('reconnect',):
        row,destination=planned[phase]
        destination.mkdir(mode=0o700)
        for name,raw in runtime_sources().items():(destination/name).write_bytes(raw)
        files={name:file_hash(destination/name,1024**2) for name in ('launch.py','support.py','verify.py')}
        files['capture_worker.py']=old_handoff['files']['capture_worker.py'];files['journal_capsule.py']=old_handoff['files']['journal_capsule.py']
        handoff={'purpose':PURPOSE,'profile':'d1-o1a-native-v1','workload':phase,'attempt_id':row['attempt_id'],'config_sha256':row['config_sha256'],'files':files,'inputs':{'kernel':{'path':str(image),'sha256':kernel['image_sha256']},'initrd':{'path':row['archive'],'sha256':row['archive_sha256']},'launcher':old_handoff['inputs']['launcher']},'assembly':{'path':row['receipt'],'sha256':row['receipt_sha256']},'readiness':{'CODE':False,'QA':True,'ROOT':False}}
        (destination/'HANDOFF.json').write_text(json.dumps(handoff,sort_keys=True,indent=2)+'\n')
        records[phase]={'path':str(destination),'handoff_sha256':file_hash(destination/'HANDOFF.json',32768),'attempt_id':row['attempt_id'],'config_sha256':row['config_sha256']}
    (HERE/'REBIND-RESULT.json').write_text(json.dumps({'scope':'DISPOSABLE_OBSERVER_FIRST_FAILURE_DATA_BINDING_ONLY_NO_CLAIM_NO_VM','kernel_sha256':kernel['image_sha256'],'outputs':records},sort_keys=True,indent=2)+'\n')
    print(json.dumps(records,sort_keys=True))

if __name__=='__main__':main()
