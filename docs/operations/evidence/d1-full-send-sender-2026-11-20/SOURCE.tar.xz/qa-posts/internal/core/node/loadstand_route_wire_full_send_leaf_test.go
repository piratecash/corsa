package node

import (
	"crypto/sha256"
	"errors"
	"fmt"
	"strings"
	"testing"
	"time"

	"github.com/piratecash/corsa/internal/core/domain"
	"github.com/piratecash/corsa/internal/core/protocol"
	"github.com/piratecash/corsa/internal/testutil/loadstand/censusdiag"
)

type fullSendLeafSecret uint8

func (s fullSendLeafSecret) Error() string                  { return "DO_NOT_LEAK" }
func (s fullSendLeafSecret) RouteWireDiagnosticCode() uint8 { return uint8(s) }
func TestLoadStandFullSendLeafClosedTransportAndStickyReason(t *testing.T) {
	labels := []string{"start_sealed", "start_clock", "start_metadata", "entry", "duplicate", "frame_binding", "frame_claims", "projection_active", "projection_change", "projection_epoch", "finish_sealed", "finish_clock", "finish_begin_boundary", "finish_end_boundary", "finish_sender_false", "finish_no_frame", "finish_partial"}
	for i, label := range labels {
		t.Run(label, func(t *testing.T) {
			reason := routeWireFailureReason(17 + i)
			o := &LoadstandRouteWireObservation{}
			o.failAt(reason)
			o.failAt(routeWireFailureQueueWrite)
			err := o.failureLocked(routeWireFailureUnknown)
			if !o.incomplete || o.firstFailure != reason || !errors.Is(err, errRouteWireIncomplete) {
				t.Fatal("first scalar reason/error identity changed")
			}
			stage, ok := censusdiag.CensusDiagnosticFromObserver(err)
			if !ok || stage != censusdiag.CensusStage(81+i) || stage.Label() != "observer_full_send_"+label {
				t.Fatal("closed leaf mapping lost", stage)
			}
			message := censusdiag.CensusRPCMessage(stage)
			if len(message) > 96 {
				t.Fatal("existing RPC bound exceeded")
			}
			if got, ok := censusdiag.CensusDiagnosticFromRPCMessage(message); !ok || got != stage {
				t.Fatal("exact RPC mapping failed")
			}
			for _, bad := range []string{message + " ", " " + message, message + "DO_NOT_LEAK", strings.Repeat("x", 97)} {
				if _, ok := censusdiag.CensusDiagnosticFromRPCMessage(bad); ok {
					t.Fatal("noncanonical message accepted")
				}
			}
		})
	}
	for _, code := range []uint8{0, 34, 64, 255} {
		if _, ok := censusdiag.CensusDiagnosticFromObserver(fullSendLeafSecret(code)); ok {
			t.Fatal("unknown observer code escaped", code)
		}
	}
	for code := uint8(1); code <= 16; code++ {
		s, ok := censusdiag.CensusDiagnosticFromObserver(fullSendLeafSecret(code))
		if !ok || s != censusdiag.CensusStage(64+code) {
			t.Fatal("old family number changed", code)
		}
	}
	secret := errors.New("DO_NOT_LEAK")
	err := censusdiag.CensusFailure(81, secret)
	if !errors.Is(err, secret) || strings.Contains(err.Error(), secret.Error()) {
		t.Fatal("raw cause leaked/unwrapping lost")
	}
}
func TestLoadStandFullSendLeafStateClockShortCircuit(t *testing.T) {
	for _, finish := range []bool{false, true} {
		for _, tc := range []struct {
			name                 string
			sealed, clockFailure bool
		}{{"sealed-first", true, true}, {"clock-second", false, true}, {"clean", false, false}} {
			t.Run(fmt.Sprint(finish)+tc.name, func(t *testing.T) {
				calls := 0
				now := time.Duration(1)
				clockErr := errors.New("private clock")
				o := &LoadstandRouteWireObservation{window: &routeWireFrameWindow{begin: 10, windowEnd: 20, last: 1, clock: func() (time.Duration, error) {
					calls++
					if tc.clockFailure {
						return now, clockErr
					}
					return now, nil
				}}, fullBudget: 2, reportSealed: tc.sealed}
				var p *routeWireFullPass
				if !finish {
					p = o.startFullPass(7, buildSmallEntries(2), domain.RouteWireFullConnect)
				} else {
					now = 15
					o.fullPassesPending = 1
					p = &routeWireFullPass{observer: o, begin: 12, entries: buildSmallEntries(2), next: 2, send: &routeWireFullSend{}, source: domain.RouteWireFullConnect}
					p.finish(true)
				}
				wantCalls := 1
				if tc.sealed {
					wantCalls = 0
				}
				if calls != wantCalls || o.incomplete != (tc.sealed || tc.clockFailure) {
					t.Fatal("original OR result/advance count changed", calls, o.incomplete)
				}
				if tc.sealed {
					want := routeWireFailureFullSendStartSealed
					if finish {
						want = routeWireFailureFullSendFinishSealed
					}
					if o.firstFailure != want {
						t.Fatal("sealed-first order changed")
					}
				} else if tc.clockFailure {
					want := routeWireFailureFullSendStartClock
					if finish {
						want = routeWireFailureFullSendFinishClock
					}
					if o.firstFailure != want {
						t.Fatal("clock-second order changed")
					}
				}
				if !finish && p != nil {
					p.finish(true)
				}
			})
		}
	}
}
func TestLoadStandFullSendLeafFinishOriginalOREquivalence(t *testing.T) {
	for mask := 0; mask < 32; mask++ {
		t.Run(fmt.Sprint(mask), func(t *testing.T) {
			before, end, sender, noFrame, partial := mask&1 != 0, mask&2 != 0, mask&4 != 0, mask&8 != 0, mask&16 != 0
			first, last := time.Duration(12), time.Duration(15)
			if before {
				first = 9
			}
			if end {
				last = 21
			}
			calls := 0
			o := &LoadstandRouteWireObservation{window: &routeWireFrameWindow{begin: 10, windowEnd: 20, last: 1, clock: func() (time.Duration, error) { calls++; return last, nil }}, fullPassesPending: 1}
			full := &routeWireFullSend{}
			p := &routeWireFullPass{observer: o, begin: first, entries: buildSmallEntries(2), next: 2, send: full, source: domain.RouteWireFullConnect}
			if noFrame {
				p.send = nil
			}
			if partial {
				p.next = 1
			}
			oldOR := first <= 10 || last >= 20 || sender || noFrame || partial
			p.finish(!sender)
			if o.incomplete != oldOR || o.fullPassesPending != 0 || calls != 1 {
				t.Fatal("original finish predicate/advance/reap accounting changed")
			}
			want := routeWireFailureNone
			switch {
			case before:
				want = routeWireFailureFullSendFinishBegin
			case end:
				want = routeWireFailureFullSendFinishEnd
			case sender:
				want = routeWireFailureFullSendFinishSender
			case noFrame:
				want = routeWireFailureFullSendFinishNoFrame
			case partial:
				want = routeWireFailureFullSendFinishPartial
			}
			if o.firstFailure != want {
				t.Fatal("left-to-right first condition changed", o.firstFailure, want)
			}
		})
	}
}
func TestLoadStandFullSendLeafProjectionOriginalOREquivalence(t *testing.T) {
	for mask := 0; mask < 16; mask++ {
		t.Run(fmt.Sprint(mask), func(t *testing.T) {
			s, o, now, _, entries := fullSendMechanismFixture(t)
			_ = s
			*now = 12
			p := o.startFullPass(7, entries, domain.RouteWireFullConnect)
			if p == nil || p.entries == nil || o.incomplete {
				t.Fatal("valid setup pass unavailable")
			}
			full := &routeWireFullSend{projection: domain.RouteWireFullSend{Destinations: len(entries), IdentitySHA256: p.identitySHA, Epoch: 7}, offered: routeWireCounter{digest: sha256.New()}}
			active, count, identity, epoch := mask&1 != 0, mask&2 != 0, mask&4 != 0, mask&8 != 0
			full.active = active
			if count {
				full.projection.Destinations++
			}
			if identity {
				full.projection.IdentitySHA256 = "changed"
			}
			if epoch {
				full.projection.Epoch++
			}
			o.connections[1].fullSend = full
			frame, err := buildRouteAnnounceV3Frame(protocol.RouteAnnounceV3KindFull, 7, entries[:1])
			if err != nil {
				t.Fatal(err)
			}
			frameClockCalls := 0
			o.window.clock = func() (time.Duration, error) { frameClockCalls++; return *now, nil }
			p.frame(1, frame.RawLine)
			if frameClockCalls != 0 {
				t.Fatal("frame added an observation clock call")
			}
			oldOR := active || count || identity || epoch
			if o.incomplete != oldOR {
				t.Fatal("original projection OR result changed")
			}
			want := routeWireFailureNone
			switch {
			case active:
				want = routeWireFailureFullSendProjectionActive
			case count || identity:
				want = routeWireFailureFullSendProjectionChange
			case epoch:
				want = routeWireFailureFullSendProjectionEpoch
			}
			if o.firstFailure != want {
				t.Fatal("projection first-condition order changed", o.firstFailure, want)
			}
		})
	}
}
