# Private full-send leaf host QA

SOURCE ONLY, nojob bypreparer. Clone accepted observerGoQA-v2, same5commands/600+30/soft2/768MiB/-p1/localGo1.27.4/offline modules/ROsource/6GiBphase/free10GiB/RAW1MiB eachcommand and sameUNKNOWNhold.

Base is exactactualeb04 private2450 map eacba. Apply ONLY3leafprodposts -> artifact2450; then5QA-only -> QA2455. No currentproductCore/Role mixed, no LinuxELF/app/Service.Run/VM/image. Artifactselected1348/Core64090f331/stand70878d671 prospective differs; actualoriginalGoAPI notrunhere and must be fresh beforelater4ELF. QAselected1353 includes extra5testfiles, cannot be artifactmanifest.

43outer tests: prior36 plus4newNodeleaf+2originalSendmechanism+1parentcodec. Expected children Node126/Parent119/Server29. Node networkdenied; only original typedRPC httptest groups retain existing localHTTP allowance, no externalnetwork/download. Testnames explicit; FAIL/SKIP/partial/piperawerror STOP. No global protectedCore sourceguards ondisposableinstrumented body. Other15families and legacy RPC are covered along with17labels, ORorder/clockcounts/strictReady/null/type/holes. This is diagnostic-only QA, noNativecause/metric/baseline/512admission.
