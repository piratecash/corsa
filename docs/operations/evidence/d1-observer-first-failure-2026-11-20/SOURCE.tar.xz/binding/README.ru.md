# Изолированная диагностика первого отказа observer

Data-only binder; не запускает сборку, VM, приложения и не получает heavy-lock. Входы: тот же принятый результат kernel и новый PACK-RESULT.json. Команда: python3 prepare.py <kernel-result.json> <PACK-RESULT.json>. Выход: новый d1-o1a-observer-first-failure-runtime-v1 с CODE/ROOT=false; запуск выполняет Root после DATA.

Сравнение с фактическим component0a66: ровно тот же набор членов/каталогов; допустимы изменения 11 исходников private observer, четырёх ELF, PID1, capexec и boot. Итого 17 payload + boot; exporter7ef3/profilef848/nft/все остальные исходники и режимы неизменны. Boot допускает только свежий attempt, новый SHA архива и соответствующие 16 input rows (PID1 отсутствует в files). Две QA-only fixture в ELF/архив не входят.

Host purpose DISPOSABLE_OBSERVER_FIRST_FAILURE_DIAGNOSTIC. Изменённый Core640 не baseline/K11/metric/512 acceptance. Предыдущий component FAIL/full_receipt и периодический FAIL сохраняются; наличие категории не доказывает прежнюю причину. Сохранены исходные success predicates, четыре Native lifecycle events, RAW/capsule, проверка полного reap, conditional three-role stopped ACK. Runtime support/ack и критичные verify bodies byte-exact; launch меняет только purpose/source pin, verify только итоговую метку scope. Гость/профиль/windows/caps/codec/таймеры не меняются.
