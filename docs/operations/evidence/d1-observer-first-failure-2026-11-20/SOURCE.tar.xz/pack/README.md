# Disposable observer first-failure diagnostic: data-only pack source

Frozen source only. No assembly job, ELF or VM was executed here. Three existing pure assembly tests and direct read-only `pack_job.check(PACK-FROZEN)` pass.

Reuse: exact accepted `d1-o1a-census-component-initrd-v1` framing, bounds, mode rules, full readback, accepted common Job, dependency pins and reconnect-only flow. The reviewed delta changes only actual prepared source archive/path/size, actual four-app build path, actual helper/template/result pins, and explicit disposable-diagnostic status/scope labels. The actual input result retains1348 sources, measured640/stand708; these are the old diagnostic lineage, not current H-mix/HEAD source.

`pack_job.py` would produce one `outputs.reconnect` row with attempt_id/config_sha256/archive/archive_sha256/archive_bytes/receipt/receipt_sha256, exactly as before. Successful status is `OBSERVER_FIRST_FAILURE_INITRD_BYTE_VERIFIED`; assembly scope is `DISPOSABLE_OBSERVER_FIRST_FAILURE_DIAGNOSTIC_INITRAMFS_DATA_READBACK_ONLY`. The arch runtime binder owns subsequent readiness. This is not O1a metric success or admission.

Actual PID1d8ce94… and capexecfe2e58… are bound from their successful result paths; exporter7ef3b4… is reused byte-identically. App paths are the actual3e7567 build, source archiveb1d2ec…4921364B. No new cpio member paths/directories: expected1439. Against component0a66, only11 existing source payloads, four apps, init, capexec and boot change (18members); exporter/profilef848/nft/library closure/kernel9ffe/worker7b75/audited0555 and all original workload oracles remain unchanged. Main raw decoder/ACK/lifecycle are outside this source package and must remain with the accepted binder.

Root may run the one bounded data-only600+30 assembly only after independent CODE review. Inputs are checked before/after; network denied, no applications; no repeat/growth on failure, UNKNOWN holds the exact own lock. Original frozen component/source/results remain intact.
