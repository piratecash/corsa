"""Pure saved-source provenance and finite-code audit. Never compile/execute Go."""
from pathlib import Path
import hashlib,importlib.util,json,re
HERE=Path(__file__).resolve().parent;D=HERE.parent
ROOT=Path('/private/tmp/corsa-o1a-census-diagnostic-elf-build-1ad46baec0ab43c5b702dad5e8c7ead3/source')
def sha(raw):return hashlib.sha256(raw).hexdigest()
def need(v,s):
 if not v:raise ValueError(s)
source_manifest=json.loads((ROOT.parent/'source-after.json').read_bytes());need(sha((ROOT.parent/'source-after.json').read_bytes())=='1a4d80bf5a8861e032bb344b2ca5e9d4b6a2e67f24b40731e915c5c976b1e5a3','exact original artifact source')
files={p.relative_to(HERE/'posts').as_posix():p.read_bytes() for p in (HERE/'posts').rglob('*.go')};need(len(files)==11,'exact post inventory')
for n in files:need(sha((ROOT/n).read_bytes())==source_manifest[n],'post preimage changed')
allpost=b'\n'.join(files.values());need(len(re.findall(rb'\.incomplete\s*=\s*true',allpost))==1,'incomplete assignment escaped central helper')
full=files['internal/core/node/loadstand_route_wire_full_receipt.go'].decode();locked=full[full.index('func (o *LoadstandRouteWireObservation) failLocked'):full.index('func (o *LoadstandRouteWireObservation) failAt')];need('.mu.' not in locked and locked.count('o.firstFailure = reason')==1 and locked.index('if !o.incomplete')<locked.index('o.firstFailure = reason')<locked.index('o.incomplete = true'),'sticky mutation/lock boundary')
need(len(re.findall(rb'firstFailure\s+routeWireFailureReason',allpost))==1,'one observer scalar only')
old=(ROOT/'internal/core/node/loadstand_route_wire_full_receipt.go').read_text();need(old.count('o.window.advance()')==full.count('o.window.advance()')==2 and old.count('table = snapshot()')==full.count('table = snapshot()')==1,'capture clock/snapshot call counts')
early=full[full.index('func (o *LoadstandRouteWireObservation) captureFullReceipts'):full.index('at := o.window.last')];need('failLocked' not in early and 'firstFailure =' not in early,'transient capture newly poisoned')
leaf=files['internal/testutil/loadstand/censusdiag/diagnostic.go'].decode();labels=re.findall(r'case (\d+):\n\s*return "([^"]+)"',leaf);need({int(n) for n,s in labels}==set(range(65,81)),'exact16 label whitelist')
need(max(len('fixture registry witness unavailable: census_stage='+label) for _,label in labels)<=96,'old RPC message bound')
need('s.Valid() && raw == CensusRPCMessage(s)' in leaf and 'case 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16:' in leaf,'observer code allowlist/hole filter')
# Use the accepted original source selection/canonical byte algorithm as data.
packer=D.parent/'2026-11-18/d1-o1a-guest-source-inputs/prepare_sources.py';spec=importlib.util.spec_from_file_location('canonical_source',packer);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
base={n:(ROOT/n).read_bytes() for n in source_manifest if m.groups(n)};need(len(base)==1348,'original selected source count');subject=dict(base);subject.update(files)
qa={p.relative_to(HERE/'qa-posts').as_posix():p.read_bytes() for p in (HERE/'qa-posts').rglob('*.go')};need(len(qa)==2 and all(n not in subject for n in qa),'separate two QA-only paths');qsubject=dict(subject);qsubject.update(qa)
groups={}
for name,content in [('actual_before',base),('disposable_artifact_subject',subject),('QA_only_subject',qsubject)]:
 groups[name]={'selected_files':len(content),'groups':{g:{'files':len(raw.splitlines())-2,'sha256':sha(raw)} for g,raw in m.manifests(content).items()}}
need(groups['disposable_artifact_subject']['groups']['measured']['files']==640 and groups['disposable_artifact_subject']['groups']['stand']['files']==708,'runtime subject count')
need(groups['disposable_artifact_subject']['groups']['measured']['sha256']!=groups['actual_before']['groups']['measured']['sha256'],'instrumented Core hash must change')
(HERE/'SOURCE-GROUPS.json').write_text(json.dumps(groups,indent=2,sort_keys=True)+'\n')
result={'status':'PURE_SOURCE_CHECKS_PASS','post_files':len(files),'QA_only_files':len(qa),'original_setter_inventory_sites':43,'families':16,'Core_changed_NOT_baseline':True,'Go_QA':'NOT_RUN','compiler_VM_app':'NOT_RUN','checks':['exact11 preimages','oneboolmutationhelper/onebytefield/stickylockboundary','samecaptureclockandsnapshotcounts/transientnonpoison','finite16labels/old96Bbound/holesfilter','exactsourcegroupcounts/runtimevsQAseparate']};(HERE/'PURE-QA.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n');print(json.dumps(result))
