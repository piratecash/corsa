package node

import (
	"bufio"
	"crypto/sha256"
	"encoding/hex"
	"errors"
	"strconv"
	"strings"
	"testing"
	"time"

	"github.com/piratecash/corsa/internal/core/domain"
	"github.com/piratecash/corsa/internal/core/routing"
	"github.com/piratecash/corsa/internal/testutil/loadstand/censusdiag"
)

func firstFailureFixture(t *testing.T, budget int) (*LoadstandRouteWireObservation, *time.Duration) {
	t.Helper()
	now := time.Duration(1)
	window, err := newRouteWireFrameWindow(10, 20, func() (time.Duration, error) { return now, nil })
	if err != nil {
		t.Fatal(err)
	}
	o := &LoadstandRouteWireObservation{window: window, maximum: 1, fullBudget: budget, connections: make(map[domain.ConnID]*routeWireConnection)}
	o.begin(1)
	o.bind(1, idPeerB, domain.PeerDirectionInbound, [32]byte{1})
	return o, &now
}
func firstFailureCode(t *testing.T, err error, want routeWireFailureReason) {
	t.Helper()
	if !errors.Is(err, errRouteWireIncomplete) {
		t.Fatalf("sentinel lost: %v", err)
	}
	var readout interface{ RouteWireDiagnosticCode() uint8 }
	if !errors.As(err, &readout) || readout.RouteWireDiagnosticCode() != uint8(want) {
		t.Fatalf("closed diagnostic=%v want=%d", err, want)
	}
}

func TestLoadStandRouteWireFirstFailureStickyIdleRead(t *testing.T) {
	o, now := firstFailureFixture(t, 0)
	reader := bufio.NewReader(strings.NewReader(""))
	// Empty reader waits across opening; no byte/partial frame predates it.
	// The original conservative LOWER bound still spans the opening.
	tracker := o.trackPlaintextReader(reader, routeWireReadFunc(func(p []byte) (int, error) { *now = 14; return copy(p, "{\"type\":\"route_probe\"}\n"), nil }))
	*now = 9
	tracker.beginFrame(reader)
	line, err := readFrameLine(reader, 4096)
	first, has := tracker.endFrame()
	if err != nil || !has || first != 9 {
		t.Fatal("idle-read fixture")
	}
	o.observe(1, routeWireRead, line, true, first)
	if !o.incomplete || o.firstFailure != routeWireFailureWindowCrossing {
		t.Fatal("original crossing refusal or first family lost")
	}
	o.failAt(routeWireFailureReceiveGlobalBudget)
	*now = 21
	calls := 0
	err = o.captureFullReceipts(func() routing.Snapshot { calls++; return routing.Snapshot{} })
	firstFailureCode(t, err, routeWireFailureWindowCrossing)
	if calls != 0 {
		t.Fatal("incomplete observer read routing table")
	}
	other, _ := firstFailureFixture(t, 0)
	other.failAt(routeWireFailureQueueWrite)
	if other.firstFailure != routeWireFailureQueueWrite || o.firstFailure != routeWireFailureWindowCrossing {
		t.Fatal("reason shared/overwritten")
	}
}

func TestLoadStandRouteWireFirstFailureCaptureAndReceive(t *testing.T) {
	t.Run("transient_guards_do_not_poison", func(t *testing.T) {
		o, now := firstFailureFixture(t, 1)
		calls := 0
		snapshot := func() routing.Snapshot { calls++; return routing.Snapshot{} }
		*now = 15
		firstFailureCode(t, o.captureFullReceipts(snapshot), routeWireFailureCaptureWindow)
		if o.incomplete || o.firstFailure != 0 || calls != 0 {
			t.Fatal("early window refusal newly poisoned observer")
		}
		*now = 21
		o.fullPassesPending = 1
		firstFailureCode(t, o.captureFullReceipts(snapshot), routeWireFailureCapturePending)
		if o.incomplete || o.firstFailure != 0 || calls != 0 {
			t.Fatal("pending refusal newly poisoned observer")
		}
		o.fullPassesPending = 0
		if err := o.captureFullReceipts(snapshot); err != nil || !o.fullTaken || o.firstFailure != 0 || calls != 0 {
			t.Fatal("old later success changed", err)
		}
	})
	frame := func(id string, epoch, seq uint64) string {
		return "{\"type\":\"route_announce_v3\",\"kind\":\"full\",\"epoch\":" + strconv.FormatUint(epoch, 10) + ",\"entries\":[{\"identity\":\"" + id + "\",\"hops\":2,\"seq_no\":" + strconv.FormatUint(seq, 10) + "}]}\n"
	}
	const a = "aa00000000000000000000000000000000000001"
	const b = "aa00000000000000000000000000000000000002"
	for _, tc := range []struct {
		name, line string
		want       routeWireFailureReason
	}{{"global_budget", frame(b, 1, 1), routeWireFailureReceiveGlobalBudget}, {"changed_epoch", frame(a, 2, 1), routeWireFailureReceiveMetadataStability}, {"changed_claim", frame(a, 1, 2), routeWireFailureReceiveMetadataStability}} {
		t.Run(tc.name, func(t *testing.T) {
			o, now := firstFailureFixture(t, 1)
			*now = 15
			o.observe(1, routeWireRead, frame(a, 1, 1), true, 11)
			o.observe(1, routeWireRead, tc.line, true, 12)
			if !o.incomplete || o.firstFailure != tc.want || o.fullRows != 1 {
				t.Fatal("receive refusal/family changed")
			}
		})
	}
	for _, good := range []bool{false, true} {
		name := "missing_peer"
		if good {
			name = "valid_one_snapshot_digest"
		}
		t.Run(name, func(t *testing.T) {
			o, now := firstFailureFixture(t, 1)
			*now = 15
			o.observe(1, routeWireRead, frame(a, 1, 1), true, 11)
			*now = 21
			at := time.Date(2026, 11, 20, 0, 0, 0, 0, time.UTC)
			id := domain.PeerIdentityFromWire(a)
			table := routing.Snapshot{TakenAt: at, Routes: make(map[domain.PeerIdentity][]routing.RouteEntry)}
			if good {
				table.Routes[id] = []routing.RouteEntry{{Identity: id, NextHop: idPeerB, Hops: 3, SeqNo: 1, Source: routing.RouteSourceAnnouncement, ExpiresAt: at.Add(time.Hour)}}
			}
			calls := 0
			err := o.captureFullReceipts(func() routing.Snapshot { calls++; return table })
			if calls != 1 {
				t.Fatal("snapshot count changed")
			}
			if !good {
				firstFailureCode(t, err, routeWireFailureReceiptSnapshotMissingPeer)
				if !o.incomplete || o.firstFailure != routeWireFailureReceiptSnapshotMissingPeer {
					t.Fatal("claim reason not recorded at original mutation")
				}
				return
			}
			sum := sha256.Sum256(id[:])
			r := o.connections[1].fullReceive.receipt
			if err != nil || o.incomplete || o.firstFailure != 0 || !o.fullTaken || r == nil || r.IdentitySHA256 != hex.EncodeToString(sum[:]) || r.SnapshotAfterNS != 21 {
				t.Fatal("positive receipt changed", err)
			}
		})
	}
}

type fakeFirstFailureSecret struct{ code uint8 }

func (e fakeFirstFailureSecret) Error() string                  { return "secret-key=NEVER_EXPORT_THIS" }
func (e fakeFirstFailureSecret) RouteWireDiagnosticCode() uint8 { return e.code }
func TestLoadStandRouteWireFirstFailureClosedTransport(t *testing.T) {
	for code := uint8(1); code <= 16; code++ {
		stage, ok := censusdiag.CensusDiagnosticFromObserver(routeWireFailureError{routeWireFailureReason(code)})
		if !ok || stage != censusdiag.CensusStage(64+code) || !stage.Valid() {
			t.Fatal("known family lost", code)
		}
		wrapped := censusdiag.CensusFailure(stage, errors.New("secret-key=NEVER_EXPORT_THIS"))
		if strings.Contains(wrapped.Error(), "NEVER_EXPORT") || strings.Contains(censusdiag.CensusRPCMessage(stage), "NEVER_EXPORT") {
			t.Fatal("raw cause leaked")
		}
		got, ok := censusdiag.CensusDiagnosticFromRPCMessage(censusdiag.CensusRPCMessage(stage))
		if !ok || got != stage {
			t.Fatal("finite family transport lost")
		}
	}
	for _, code := range []uint8{0, 17, 64, 81, 255} {
		if _, ok := censusdiag.CensusDiagnosticFromObserver(fakeFirstFailureSecret{code}); ok {
			t.Fatal("unknown observer code accepted")
		}
	}
	for _, stage := range []censusdiag.CensusStage{0, 27, 64, 81, 255} {
		if stage.Valid() {
			t.Fatal("unknown stage accepted")
		}
	}
	if _, ok := censusdiag.CensusDiagnosticFromRPCMessage("fixture registry witness unavailable"); ok {
		t.Fatal("generic server text mapped through stage hole")
	}
}
