"""One offline Linux fixture-test compile from signed base plus exact private posts."""
from pathlib import Path
import hashlib,importlib.util,json,os,shutil,subprocess,tarfile
from common import Job,need,sha,static_arm64,directory_bytes
HERE=Path(__file__).resolve().parent
REPO=Path('/Users/hades/Documents/repos/corsa')
GO='/usr/local/go/bin/go'
COMMON=HERE.parent/'d1-churn512-runtime-inert-v7/canonical/sg32_common.py'
COMMON_SHA='2fa268e62081939cd4632b8a8deb59b2fe7d29e859b53769d59f552305a1ef33'
BASE='e4b51cc3f6004ff7e17a418f8d0058bd51109d4b'

def inventory(root):
 out={}
 for folder,dirs,files in os.walk(root,followlinks=False):
  for n in dirs+files:need(not (Path(folder)/n).is_symlink(),'source symlink')
  for n in files:
   p=Path(folder)/n;out[str(p.relative_to(root))]={'bytes':p.stat().st_size,'sha256':sha(p)}
 return out

def apply_posts(source,posts):
 for name,row in posts.items():
  need(name.startswith('internal/testutil/loadstand/') and '..' not in Path(name).parts,'fixture-only post path')
  p=source/name;need((sha(p) if p.exists() else None)==row['before_sha256'],'base post mismatch')
  q=Path(row['path']);need(sha(q)==row['after_sha256'],'private post changed');p.parent.mkdir(parents=True,exist_ok=True)
  if p.exists():p.chmod(0o600) # Only this fresh job's verified archive copy.
  shutil.copyfile(q,p);need(sha(p)==row['after_sha256'],'copied post mismatch');p.chmod(0o444)

def main():
 os.umask(0o077)
 if os.getpid()!=os.getpgrp():os.setsid()
 frozen=json.loads((HERE/'BUILD-INPUTS.json').read_text())
 need(frozen['base_commit']==BASE,'signed base changed')
 need(sha(__file__)==frozen['controller_sha256'] and sha(HERE/'common.py')==frozen['common_sha256'],'controller freeze changed')
 need(sha(COMMON)==COMMON_SHA,'accepted static ELF guard changed')
 for name,digest in frozen['toolchain_files'].items():need(sha(name)==digest,'local toolchain changed')
 spec=importlib.util.spec_from_file_location('fixture_static_guard',COMMON);elf=importlib.util.module_from_spec(spec);spec.loader.exec_module(elf)
 job=Job('namespace-coherent-snapshot-test-build',600,6*1024**3);error=None;artifact=None;initial=None
 try:
  need(shutil.disk_usage('/private/tmp').free>=10*1024**3,'host free space')
  need(subprocess.check_output(['/usr/bin/git','rev-parse','HEAD'],cwd=REPO).decode().strip()==BASE,'HEAD changed')
  job.run('archive',['/usr/bin/git','archive','--format=tar','--output='+str(job.work/'base.tar'),BASE],cwd=REPO)
  source=job.work/'source';source.mkdir();need((job.work/'base.tar').stat().st_size<=256*1024**2,'base archive bound')
  with tarfile.open(job.work/'base.tar','r:') as t:
   for m in t:
    parts=Path(m.name).parts;need(parts and not Path(m.name).is_absolute() and '..' not in parts,'archive path')
    p=source/m.name
    if m.isdir():p.mkdir(parents=True,exist_ok=True)
    else:
     need(m.isfile(),'source link/special entry');p.parent.mkdir(parents=True,exist_ok=True)
     with t.extractfile(m) as inp,p.open('xb') as out:shutil.copyfileobj(inp,out)
     p.chmod(0o444)
  apply_posts(source,frozen['posts'])
  initial=inventory(source);(job.work/'SOURCE-MANIFEST.json').write_text(json.dumps(initial,indent=2,sort_keys=True)+'\n')
  shutil.copyfile(HERE/'BUILD-INPUTS.json',job.work/'BUILD-INPUTS.json')
  for n in ('tmp','cache','artifacts'):(job.work/n).mkdir()
  env={'PATH':'/usr/local/go/bin:/usr/bin:/bin','GOROOT':'/usr/local/go','GOENV':'off','GOWORK':'off','GOVCS':'*:off','GOTOOLCHAIN':'local','GOPROXY':'off','GOSUMDB':'off','GOTELEMETRY':'off','GOFLAGS':'-p=1','GOMAXPROCS':'2','GOMEMLIMIT':'768MiB','CGO_ENABLED':'0','GOOS':'linux','GOARCH':'arm64','GOARM64':'v8.0','GOCACHE':str(job.work/'cache'),'GOMODCACHE':str(REPO/'.gomodcache'),'HOME':str(job.work),'TMPDIR':str(job.work/'tmp'),'LC_ALL':'C'}
  policy='(version 1)(allow default)(deny network*)(deny file-write* (subpath '+json.dumps(str(source))+'))'
  def run(name,args):return job.run(name,['/usr/bin/sandbox-exec','-p',policy,*args],cwd=source,env=env)
  need(run('go-version',[GO,'version']).decode().strip()=='go version go1.27.4 darwin/arm64','local Go mismatch')
  run('modules',[GO,'mod','verify'])
  output=job.work/'artifacts/loadstand.test'
  run('compile',[GO,'test','-mod=readonly','-buildvcs=false','-p=1','-trimpath','-c','-o',str(output),'./internal/testutil/loadstand'])
  need(output.stat().st_size<=128*1024**2,'test ELF bound');elf.static_elf(output.read_bytes())
  metadata=run('metadata',[GO,'version','-m',str(output)]).decode();need(all(x in metadata for x in ('go1.27.4','GOOS=linux','GOARCH=arm64','CGO_ENABLED=0','-trimpath=true')),'BuildInfo flags')
  sums={tuple(x.split()[:2]):x.split()[2] for x in (source/'go.sum').read_text().splitlines() if len(x.split())==3};deps=[]
  for line in metadata.splitlines():
   if line.startswith('\tdep\t'):
    x=line.split();need(len(x)==4 and sums.get((x[1],x[2]))==x[3],'exact dependency binding');deps.append(x[1:])
  need(deps and len(deps)==len({x[0] for x in deps}),'dependency inventory')
  need(inventory(source)==initial,'source changed during build')
  for name,row in frozen['posts'].items():need(sha(row['path'])==row['after_sha256'],'private post changed during build')
  for name,digest in frozen['toolchain_files'].items():need(sha(name)==digest,'local toolchain changed during build')
  artifact={'path':str(output),'sha256':sha(output),'bytes':output.stat().st_size,'static_linux_arm64':True,'executed':False,'dependencies':deps}
  directory_bytes(job.work,6*1024**3)
 except BaseException as e:error=str(e)
 result=job.finish({'status':'FIXTURE_LINUX_TEST_ELF_BUILT' if error is None else 'FAILED','error':error,'artifact':artifact,'source_files':len(initial or {}),'base_commit':BASE,'test_ELF_executed':False,'input_manifest_sha256':sha(HERE/'BUILD-INPUTS.json')})
 if error:raise SystemExit(1)
if __name__=='__main__':main()
