# Initial setup route snapshot

SOURCE ONLY: three fixture production files plus one Linux-only unit fixture. No tracked-tree edits, compilation, VM or app execution. Root owns bounded Linux pure QA before applying.

The initial configure step observes AF_INET, then strict complete AF_INET6 qualification/deletion/readback, and passes THAT ACTUAL IPv6 snapshot to the unchanged namespace prefix oracle. With zero candidates return original complete rows; with deletions return the last actual exactremaining readback, never a synthetic expected slice. A second independent IPv6 dump no longer sits between cleanup and this initial oracle. Existing general routes() still reads AF_INET then AF_INET6 for readonly/postflight.

All original whole-dump, ownership, delete identity, readback, deadline, address, namespace and claim guards remain. Wrapper reconcile retains all other callers/error semantics. Post-carrier finalize and subsequent fresh readonly/postflight remain mandatory before fixture claim/apps. No retry/sleep/new permissive prefix/table/owner/cap/profile. A snapshot does not imply future quiescence; later fresh readonly evidence may still correctly refuse a late route.

New deterministic tests: actual earlier zero-candidate or post-delete snapshot followed by a different NEXT dump; original strict readonly still rejects it. Foreign OIF/table/ownership/duplicate/readback errors refuse; IPv4 default/missingconnected remain rejected; causal errors.Is and deadline closure preserved; distinct later finalizer remains operational. Existing multicast/finalizer tests should also run. These are unit proofs of boundary semantics, not proof of the first physical kernel event in failed9b75, and not O1a PASS.
