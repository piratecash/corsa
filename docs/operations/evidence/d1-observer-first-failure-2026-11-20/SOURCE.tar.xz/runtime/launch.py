"""One frozen offline O1a VM attempt; always retain exact lock for DATA review."""
from pathlib import Path
import hashlib
import json
import os
import re
import shutil
import signal
import stat
import sys
from support import need,read_record,file_digest,exclusive_json,hash_bytes,validate_kernel,start_lock,lock_identity,sync_directory,LOCK,LIMITS,PROFILE

HERE=Path(__file__).resolve().parent
CAPTURE=HERE.parent/'d1-o1a-host-capture-v1'
sys.path.insert(0,str(CAPTURE))
from capture_worker import collect,clock_ns,Deadlines,Binding
WORKER='7b75f39616b5a77a2127510ecc1c65184f77f0b10e5fc16f3f80abc24449713c'
KERNEL='9ffeb24f4131ec4c5177b83c4a74ed8af699553c00a6b0d7f0d0ff4e98970c73'
FILES={'launch.py':HERE/'launch.py','support.py':HERE/'support.py','capture_worker.py':CAPTURE/'capture_worker.py','verify.py':HERE/'verify.py','journal_capsule.py':HERE.parent/'d1-o1a-guest-preparation-v1/journal_capsule.py'}

def decode(raw):
    def pairs(values):
        out={}
        for key,value in values:
            need(key not in out,'duplicate JSON key');out[key]=value
        return out
    return json.loads(raw,object_pairs_hook=pairs)

def validate(handoff):
    need(type(handoff) is dict and set(handoff)=={'profile','workload','attempt_id','config_sha256','files','inputs','assembly','readiness','purpose'},'handoff fields')
    need(handoff['profile']==PROFILE and handoff['workload']=='reconnect' and handoff['purpose']=='DISPOSABLE_OBSERVER_FIRST_FAILURE_DIAGNOSTIC','profile/workload')
    need(re.fullmatch('[0-9a-f]{32}',handoff['attempt_id']) and re.fullmatch('[0-9a-f]{64}',handoff['config_sha256']),'attempt/config binding')
    need(handoff['readiness']=={'CODE':True,'QA':True,'ROOT':True},'runtime not ready')
    need(set(handoff['files'])==set(FILES),'source list')
    for name,path in FILES.items():need(file_digest(path,1024**2)[0]==handoff['files'][name],'changed runtime source')
    need(set(handoff['inputs'])==set(LIMITS),'input list')
    for row in [*handoff['inputs'].values(),handoff['assembly']]:
        need(type(row) is dict and set(row)=={'path','sha256'} and type(row['path']) is str and re.fullmatch('[0-9a-f]{64}',row['sha256']),'input schema')
    need(handoff['inputs']['kernel']['sha256']==KERNEL and handoff['inputs']['launcher']['sha256']==WORKER,'wrong kernel/worker')
    assembly_raw=read_record(Path(handoff['assembly']['path']),2*1024**2)
    need(hash_bytes(assembly_raw)==handoff['assembly']['sha256'],'assembly receipt changed')
    assembly=decode(assembly_raw)
    need(assembly['scope']=='DISPOSABLE_OBSERVER_FIRST_FAILURE_DIAGNOSTIC_INITRAMFS_DATA_READBACK_ONLY' and assembly['elf_or_vm_executed'] is False and assembly['source_files']==1348 and assembly['source_archive_sha256']=='b1d2ec4ad6034fa4d688fd2b9b4e412b6301dc239217f091195fd3dfaefff79c','assembly scope')
    for key in ('workload','attempt_id','config_sha256'):need(assembly[key]==handoff[key],'assembly binding')
    need(assembly['archive']['sha256']==handoff['inputs']['initrd']['sha256'],'wrong initrd')
    return assembly

def main():
    origin=clock_ns();os.umask(0o077)
    if os.getpid()!=os.getpgrp():os.setsid()
    interrupted=False
    def stop(_signal,_frame):
        nonlocal interrupted
        interrupted=True
    signal.signal(signal.SIGINT,stop);signal.signal(signal.SIGTERM,stop)
    def check():need(not interrupted and clock_ns()-origin<Deadlines().work,'work interrupted/expired')
    raw=read_record(HERE/'HANDOFF.json',32768);handoff=decode(raw);assembly=validate(handoff)
    bound={}
    for name,row in handoff['inputs'].items():
        path=Path(row['path']);digest,size=file_digest(path,LIMITS[name],check=check);need(digest==row['sha256'],'input hash');bound[name]=(path,digest,size)
    validate_kernel(bound['kernel'][0])
    need(shutil.disk_usage(LOCK.parent).free>=10*1024**3+sum(row[2] for row in bound.values())+33*1024**2,'free reserve')
    attempt=handoff['attempt_id'];claim=HERE/'claims'/attempt
    need(not os.path.lexists(claim),'attempt already claimed');check()
    work=LOCK.parent/('corsa-d1-o1a-native-'+attempt);custody=start_lock(attempt,hash_bytes(raw));created=False
    try:
        need(read_record(HERE/'HANDOFF.json',32768)==raw,'handoff changed')
        claim.parent.mkdir(mode=0o700,exist_ok=True)
        info=claim.parent.lstat();need(info.st_uid==os.getuid() and stat.S_ISDIR(info.st_mode) and stat.S_IMODE(info.st_mode)==0o700,'unsafe claim directory')
        exclusive_json(claim,{'attempt_id':attempt,'handoff_sha256':hash_bytes(raw),'work':str(work)})
        sync_directory(claim.parent);work.mkdir(mode=0o700);created=True
        exclusive_json(work/'lock-binding.json',{'directory_stamp':list(custody[0]),'owner_stamp':list(custody[1]),'owner_sha256':hash_bytes(custody[2])})
        copies={}
        for name,(path,digest,size) in bound.items():
            p=work/name
            with p.open('xb') as out:
                got,_=file_digest(path,LIMITS[name],out,check);out.flush();os.fsync(out.fileno())
            need(got==digest,'copy hash');p.chmod(0o500 if name=='launcher' else 0o400)
            need(file_digest(p,LIMITS[name],check=check)[0]==digest,'copy readback');copies[name]=p
        expected={'purpose':'DISPOSABLE_OBSERVER_FIRST_FAILURE_DIAGNOSTIC','profile':PROFILE,'attempt_id':attempt,'workload':handoff['workload'],'config_sha256':handoff['config_sha256'],'handoff_sha256':hash_bytes(raw),**{name+'_sha256':row[1] for name,row in bound.items()}}
        exclusive_json(work/'expected.json',expected)
        need(custody==lock_identity(),'lock changed');check()
        result=collect([str(copies['launcher']),'--worker',attempt,str(origin),str(copies['kernel']),str(copies['initrd'])],attempt,origin,work,Binding(attempt,handoff['workload'],handoff['config_sha256']),interrupted=lambda:interrupted)
        exclusive_json(work/'controller-result.json',result)
        recheck=custody==lock_identity() and read_record(HERE/'HANDOFF.json',32768)==raw and validate(handoff)==assembly and all(file_digest(path,LIMITS[name])[0]==digest==file_digest(copies[name],LIMITS[name])[0] for name,(path,digest,_) in bound.items())
        exclusive_json(work/'receipt.json',dict(expected,input_recheck=recheck,**result))
        need(recheck and result['capture_complete'] and not interrupted,'incomplete input/worker/group/RAW')
        print(json.dumps({'scope':'CAPTURE_COMPLETE_PENDING_DATA_REVIEW','work':str(work),'heavy_lock_retained':True,'worker_exit':result['worker_exit']}),flush=True)
    except BaseException as exc:
        if created:exclusive_json(work/'refusal.json',{'error':str(exc),'heavy_lock_retained':True})
        raise

if __name__=='__main__':main()
