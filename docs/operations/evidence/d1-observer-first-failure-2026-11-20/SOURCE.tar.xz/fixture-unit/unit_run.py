"""ROOT-invoked offline static C compilation in one owned pinned-image container."""
import json,os,re,shutil
from pathlib import Path
from common import Job,need,sha,static_arm64
HERE=Path(__file__).resolve().parent
SOURCE=Path('/private/tmp/corsa-d1-o1a-namespace-coherent-snapshot-test-build-a8cc7165e43f4030ac1b4ee72602ff11/source')
IMAGE='sha256:45ccc728acf675888bde399354b6c8338accfc591e35496f9413a3742f3ae313'
ARGS=['-test.v', '-test.count=1', '-test.timeout=60s', '-test.run=^(TestPlannedNamespaceSetupFinalizerLateCarrierRoute|TestPlannedNamespaceSetupFinalizerRejectsForeignBinding|TestPlannedNamespaceSetupFinalizerStrictDumpAndReadback|TestPlannedNamespaceReadonlyRouteOracleStillRejectsMulticast|TestPlannedNamespaceSetupFinalizeSequenceSource|TestPlannedMulticastExactOwnedBatch|TestPlannedMulticastWholeDumpRefusesBeforeDelete|TestPlannedMulticastOwnershipRevalidated|TestPlannedMulticastFailuresPreserveErrorAndStop|TestPlannedMulticastReadbackIsExactRemainder|TestPlannedMulticastCacheCountersAreNotAuthority|TestPlannedMulticastRequestHasOnlyExactSelector|TestLinuxRuntimeClosedAuthorityInventory|TestLinuxRuntimeClosedAuthorityNegativeReferences|TestPlannedNamespaceInitialRouteSnapshotInterleaving|TestPlannedNamespaceInitialRouteSnapshotStrictRefusals|TestPlannedNamespaceInitialRouteSnapshotErrorsRemainClosed)$']
TMPFS='rw,noexec,nosuid,nodev,size=134217728,mode=1777'
def actual_source(value,wanted):
 need(value in (wanted,'/host_mnt'+wanted),'foreign bind source')
 return wanted
def inspect_row(row,cid,attempt,work):
 need(row['Id']==cid and row['Image']==IMAGE and row['Config']['Labels']['corsa.o1a.fixture_unit_test_attempt']==attempt,'owned container identity changed')
 host=row['HostConfig'];config=row['Config']
 need(host['NetworkMode']=='none' and host['ReadonlyRootfs'] is True and host['Privileged'] is False and host['Memory']==host['MemorySwap']==512000000 and host['NanoCpus']==1000000000 and host['PidsLimit']==64,'container limits changed')
 need(host['CapDrop']==['ALL'] and not host['CapAdd'] and config['User']=='501:20' and config['Entrypoint']==['/input/loadstand.test'] and config['Cmd']==ARGS and config['WorkingDir']=='/input/internal/testutil/loadstand','container execution policy changed')
 need((host.get('RestartPolicy') or {}).get('Name')=='no','automatic restart forbidden')
 need(host.get('PidMode','')=='' and host.get('CgroupnsMode')=='private' and host.get('IpcMode')=='private','foreign process/cgroup/IPC namespace')
 need(not host.get('Binds') and not host.get('Devices') and not host.get('DeviceRequests') and not host.get('PortBindings') and not host.get('PublishAllPorts'),'foreign binds/devices/ports')
 need(set(((row.get('NetworkSettings') or {}).get('Networks') or {}))<={'none'},'external attachment')
 mounts=row['Mounts'];binds={m['Destination']:m for m in mounts if m['Type']=='bind'}
 need(set(binds)=={'/input','/output'} and len([m for m in mounts if m['Type']=='bind'])==2,'unexpected bind mounts')
 for target,readonly in (('/input',True),('/output',False)):
  m=binds[target];actual_source(m['Source'],str(work/target[1:]));need(m['RW'] is (not readonly),'bind writable policy changed')
 extras=[m for m in mounts if m['Type']!='bind']
 need(not extras or (len(extras)==1 and extras[0]['Type']=='tmpfs' and extras[0]['Destination']=='/tmp' and extras[0]['RW'] is True),'unexpected actual mount')
 declarations=host.get('Mounts') or [];need(len(declarations)==2 and {m.get('Target') for m in declarations}=={'/input','/output'},'unexpected declared mounts')
 for m in declarations:
  need(m['Type']=='bind' and m['Target'] in ('/input','/output'),'foreign declared mount');actual_source(m['Source'],str(work/m['Target'][1:]));need(m.get('ReadOnly',False) is (m['Target']=='/input'),'declared bind permissions')
 need(set(host.get('Tmpfs',{}))=={'/tmp'} and set(host['Tmpfs']['/tmp'].split(','))==set(TMPFS.split(',')),'tmpfs changed')
 need(host.get('SecurityOpt') in (['no-new-privileges'],['no-new-privileges=true']),'NNP missing or foreign security option')
 return row
def strict_init(path):
 row=static_arm64(path)
 with Path(path).open('rb') as stream:header=stream.read(20)
 need(len(header)==20 and header[16:18]==b'\x02\x00','diagnostic init must be static ET_EXEC')
 row['elf_type']=2
 return row
def qualify_tests(raw,expected):
 need(type(raw) is bytes and len(raw)<=1024**2,'test RAW bound')
 rows=raw.decode('utf-8').splitlines();need(not any(x.lstrip().startswith(('--- FAIL:','--- SKIP:','FAIL','panic:')) for x in rows),'test FAIL/SKIP/panic')
 passed=[x.split()[2] for x in rows if x.startswith('--- PASS: ')]
 ran=[x.split()[2] for x in rows if x.startswith('=== RUN   ') and '/' not in x.split()[2]]
 need(len(passed)==len(set(passed))==len(ran)==17 and set(passed)==set(ran)==set(expected) and rows.count('PASS')==1,'missing/extra/duplicate test outcomes')
 return {'outer_pass':len(passed),'child_pass':sum(x.lstrip().startswith('--- PASS: ') and not x.startswith('--- PASS: ') for x in rows)}

def main():
 os.umask(0o077)
 if os.getpid()!=os.getpgrp():os.setsid()
 frozen=json.loads((HERE/'FROZEN.json').read_text());job=Job('namespace-coherent-snapshot-unit',180,256*1024**2);cid=None;removed=False;error=None;artifact=None;create_attempted=False
 docker=shutil.which('docker');need(docker,'Docker CLI unavailable')
 env={'PATH':'/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin','HOME':os.environ.get('HOME','/nonexistent'),'LC_ALL':'C'}
 def run(name,*args,cleanup=False):return job.run(name,[docker,*args],env=env,cleanup=cleanup)
 def inspect(cleanup=False):
  row=json.loads(run('owned-inspect','container','inspect',cid,cleanup=cleanup))[0]
  return inspect_row(row,cid,job.attempt,job.work)
 try:
  need(shutil.disk_usage('/private/tmp').free>=10*1024**3+sum(row['bytes'] for row in frozen['source_files'].values())+2*1024**2,'host free space <10GiB plus preparation')
  for name,wanted in frozen['controller_files'].items():need(sha(HERE/name)==wanted,'controller freeze changed')
  need(sha(Path(frozen['build_result']['path']))==frozen['build_result']['sha256'],'compiled result changed')
  source=job.work/'input';output=job.work/'output';source.mkdir();output.mkdir()
  for name,wanted in frozen['source_files'].items():
   need(not Path(name).is_absolute() and '..' not in Path(name).parts,'input path');q=Path(wanted['path']);need(sha(q)==wanted['sha256'],'test input changed');target=source/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(q,target);need(sha(target)==wanted['sha256'],'copied input changed');target.chmod(0o555 if name=='loadstand.test' else 0o444)
  row=json.loads(run('image','image','inspect',IMAGE))[0];need(row['Id']==IMAGE and row['Os']=='linux' and row['Architecture']=='arm64','pinned image mismatch')
  args=ARGS
  create_attempted=True
  candidate_id=run('create','create','--pull','never','--name','d1-o1a-fixture-unit-test-'+job.attempt,'--label','corsa.o1a.fixture_unit_test_attempt='+job.attempt,'--network','none','--cgroupns','private','--ipc','private','--restart','no','--read-only','--user','501:20','--cpus','1','--memory','512000000','--memory-swap','512000000','--pids-limit','64','--cap-drop','ALL','--security-opt','no-new-privileges','--tmpfs','/tmp:'+TMPFS,'--mount','type=bind,src='+str(source)+',dst=/input,readonly','--mount','type=bind,src='+str(output)+',dst=/output','--workdir','/input/internal/testutil/loadstand','--env','PATH=/usr/bin:/bin','--env','LC_ALL=C','--env','HOME=/tmp','--env','TMPDIR=/tmp','--env','GOMAXPROCS=2','--entrypoint','/input/loadstand.test',IMAGE,*args).decode().strip();need(re.fullmatch('[0-9a-f]{64}',candidate_id),'invalid owned container ID');cid=candidate_id
  before=inspect();need(before['State']['Status']=='created' and before['State']['Pid']==0,'container unexpectedly started')
  run('unit-tests','start','--attach',cid)
  after=inspect();state=after['State'];need(state['Status']=='exited' and not state['Running'] and state['Pid']==0 and state['ExitCode']==0 and state['OOMKilled'] is False,'test failed/OOM/unknown')
  artifact=dict(strict_init(source/'loadstand.test'),executed=True,path=str(source/'loadstand.test'),image_id=IMAGE,source_sums_sha256=frozen['source_sums_sha256']);qualify_tests((job.work/'04-unit-tests.stdout').read_bytes(),frozen['tests'])
  for name,wanted in frozen['source_files'].items():need(sha(source/name)==wanted['sha256'] and sha(wanted['path'])==wanted['sha256'],'readonly test input changed')
 except BaseException as exc:error=str(exc)
 if create_attempted and cid is None:
  job.unknown=True;error=(error or '')+'; create result ambiguous: exact attempt label/name reconciliation required before operator recovery'
 if cid:
  try:
   row=inspect(cleanup=True)
   if row['State']['Running'] or row['State']['Pid']!=0:
    run('kill-owned','kill','--signal','KILL',cid,cleanup=True);row=inspect(cleanup=True)
   need(not row['State']['Running'] and row['State']['Pid']==0,'owned container stop unknown')
   run('remove-owned','rm',cid,cleanup=True)
   need(run('owned-absent','ps','-a','--no-trunc','--filter','label=corsa.o1a.fixture_unit_test_attempt='+job.attempt,'--format','{{.ID}}',cleanup=True).strip()==b'','owned container remains')
   removed=True
  except BaseException as exc:job.unknown=True;error=(error or '')+'; cleanup: '+str(exc)
 result=job.finish({'status':'SEVENTEEN_FIXTURE_TESTS_PASSED' if error is None else 'FAILED','error':error,'artifact':artifact,'container_id':cid,'container_name':'d1-o1a-fixture-unit-test-'+job.attempt,'create_attempted':create_attempted,'owned_label':'corsa.o1a.fixture_unit_test_attempt='+job.attempt,'owned_container_removed':removed,'tests_execution_attempted':any(row['phase']=='unit-tests' for row in job.steps),'tests_passed':error is None,'expected_outer_tests':17,'apps_executed':False,'image_created_or_deleted':False,'source_sums_sha256':frozen['source_sums_sha256']})
 if result['error']:raise SystemExit(1)
if __name__=='__main__':main()
