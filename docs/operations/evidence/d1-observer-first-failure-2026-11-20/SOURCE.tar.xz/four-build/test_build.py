import copy,json,unittest
from pathlib import Path
import build
class Tests(unittest.TestCase):
 def test_exact_artifact_map_excludes_both_QA_only_files(self):
  a=build.artifact_map();m=json.loads((build.QA/'MANIFEST.json').read_bytes());self.assertEqual(len(a),2450);self.assertFalse(set(a)&set(m['QA_only_files']))
  for n,p in m['files'].items():self.assertEqual(a[n],p['after_sha256'])
 def test_all_four_graphs_change_only_reviewed_file_hashes(self):
  old=json.loads((build.HERE.parent/'d1-o1a-census-diagnostic-elf-build-v1/GRAPH-EXPECTATIONS.json').read_bytes());new=json.loads((build.HERE/'GRAPH-EXPECTATIONS.json').read_bytes());m=json.loads((build.QA/'MANIFEST.json').read_bytes())
  for key in old:
   a=old[key]['expected_semantic_graph'];z=new[key]['expected_semantic_graph'];self.assertEqual({k:v for k,v in a.items() if k!='tracked_files'},{k:v for k,v in z.items() if k!='tracked_files'});self.assertEqual(set(a['tracked_files']),set(z['tracked_files']))
   changed={n for n in a['tracked_files'] if a['tracked_files'][n]!=z['tracked_files'][n]};self.assertEqual(changed,set(m['files'])&set(a['tracked_files']))
   for n in changed:self.assertEqual(a['tracked_files'][n],m['files'][n]['before_sha256']);self.assertEqual(z['tracked_files'][n],m['files'][n]['after_sha256'])
 def test_original_API_implementation_and_private_parameter_only_adapter(self):
  base=Path('/private/tmp/corsa-o1a-baseline-finalizer-inputs-cc481326e8504a94a20da6c792be66c4/source-api-module')
  for p in (base/'internal/testutil/runjournal').glob('*.go'):self.assertEqual(p.read_bytes(),(build.API_MODULE/p.relative_to(base)).read_bytes())
  for n in ('go.mod','go.sum'):self.assertEqual((base/n).read_bytes(),(build.API_MODULE/n).read_bytes())
  expected=(base/'cmd/source-api-readback/main.go').read_text().replace('1345 baseline','1348 disposable').replace('b70de373d032b8fed471c6b93bba6d034d932b322495866d40766e7c746fcd9c','9fb7bba6dd77a128a634f0d6d26e67485b07f1178b9361166a754e0fb7d1268e').replace('"stand": {705, "52e346f971a30a1da05570e17b4f6133e913eaaf9ea14f433a03fc7575a77aec"}','"stand": {708, "982764418fc1cf30f59ff1b9bb71399763a91295bfd0c30b941e48f6cf1813b2"}').replace('string(spec.Name)+".manifest"','string(spec.Name)+".expected.manifest"')
  self.assertEqual(expected,(build.API_MODULE/'cmd/source-api-readback/main.go').read_text())
 def test_original_flags_targets_static_metadata_and_total_budget(self):
  self.assertEqual(build.OPTIONS,['-mod=readonly','-trimpath','-buildvcs=false']);self.assertEqual(build.TARGET,{'GOOS':'linux','GOARCH':'arm64','GOARM64':'v8.0','CGO_ENABLED':'0'});self.assertEqual(len(build.STAGES),4)
  text=(build.HERE/'build.py').read_text();self.assertIn('absolute_end = origin + 600',text);self.assertNotIn('origin + 1200',text);self.assertIn('phase_end + 30',text);self.assertIn("overrides={'GOOS':'darwin','GOARCH':'arm64'}",text)
  x={'package_count':1,'graph_sha256':'path-dependent'};self.assertTrue(build.graph_matches({'package_count':1,'graph_sha256':'other'},x));self.assertFalse(build.graph_matches({'package_count':2},x))
if __name__=='__main__':unittest.main()
