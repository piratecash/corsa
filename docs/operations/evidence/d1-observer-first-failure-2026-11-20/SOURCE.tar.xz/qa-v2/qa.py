"""Bounded clean-source private observer Go QA; no app/Linux ELF build or run."""
from pathlib import Path
import json,os,re,shutil,time
from common import Job,need,sha,directory_bytes
HERE=Path(__file__).resolve().parent;REPO=HERE.parents[4]
SUBJECT=HERE.parent/'d1-o1a-observer-first-failure-source-v2'
BASE_ROOT=Path('/private/tmp/corsa-o1a-census-diagnostic-elf-build-1ad46baec0ab43c5b702dad5e8c7ead3/source')
BASE_MANIFEST=BASE_ROOT.parent/'source-after.json'
GO='/usr/local/go/bin/go'
def inventory(root):
 out={}
 for p in root.rglob('*'):
  need(not p.is_symlink(),'source symlink')
  if p.is_file():need(len(out)<4096,'source count bound');out[p.relative_to(root).as_posix()]=sha(p)
 return out
def expected_maps(base,m):
 artifact=dict(base)
 for n,r in m['files'].items():need(artifact[n]==r['before_sha256'],'post preimage');artifact[n]=r['after_sha256']
 qa=dict(artifact)
 for n,r in m['QA_only_files'].items():need(n not in qa and r['before_sha256'] is None,'QA path in artifact');qa[n]=r['after_sha256']
 need(len(base)==len(artifact)==2450 and len(qa)==2452,'exact separate snapshot counts')
 return artifact,qa
def apply_posts(src,m):
 for kind,key in [('posts','files'),('qa-posts','QA_only_files')]:
  for n,r in m[key].items():
   p=src/n;p.parent.mkdir(parents=True,exist_ok=True)
   if p.exists():p.chmod(0o600)
   p.write_bytes((SUBJECT/kind/n).read_bytes());need(sha(p)==r['after_sha256'],'overlay copy');p.chmod(0o444)
def check_inputs(f):
 need(sha(BASE_MANIFEST)==f['base_manifest_sha256'],'base manifest changed')
 need(sha(SUBJECT/'MANIFEST.json')==f['subject_manifest_sha256'],'subject changed')
 for n,r in f['controller_files'].items():need(sha(HERE/n)==r['sha256'],'controller changed')
 for n,r in f['toolchain_files'].items():need(sha(n)==r['sha256'],'toolchain changed')
 m=json.loads((SUBJECT/'MANIFEST.json').read_bytes());base=json.loads(BASE_MANIFEST.read_bytes())
 for kind,key in [('posts','files'),('qa-posts','QA_only_files')]:
  for n,r in m[key].items():need(sha(SUBJECT/kind/n)==r['after_sha256'],'post changed')
 for n,digest in base.items():need(sha(BASE_ROOT/n)==digest,'actual base file changed')
 return base,m
def policy(source,loopback):
 raw='(version 1)(allow default)(deny network*)'
 if loopback:raw+='(allow network-inbound (local ip "localhost:*"))(allow network-outbound (remote ip "localhost:*"))'
 return raw+'(deny file-write* (subpath '+json.dumps(str(REPO))+'))(deny file-write* (subpath '+json.dumps(str(source))+'))'
def check_events(raw,expected,children=None):
 rows=[json.loads(x) for x in raw.splitlines()];need(rows and not any(r.get('Action') in ('fail','skip') for r in rows),'FAIL/SKIP')
 passed=[r['Test'] for r in rows if r.get('Action')=='pass' and r.get('Test') and '/' not in r['Test']]
 need(len(passed)==len(set(passed)) and set(passed)==set(expected),'missing/extra tests');need(any(r.get('Action')=='pass' and not r.get('Test') for r in rows),'package PASS')
 count=sum(r.get('Action')=='pass' and '/' in r.get('Test','') for r in rows)
 if children is not None:need(count==children,'legacy child count changed')
 return {'passed':passed,'child_passes':count}
def main():
 os.umask(0o077)
 if os.getpid()!=os.getpgrp():os.setsid()
 f=json.loads((HERE/'FROZEN.json').read_bytes());tests=json.loads((HERE/'TESTS.json').read_bytes());job=Job('observer-first-failure-goqa',600,6*1024**3);error=None;results={};artifact=None;qa=None
 try:
  need(shutil.disk_usage('/private/tmp').free>=10*1024**3,'free space <10GiB');base,m=check_inputs(f);artifact,qa=expected_maps(base,m)
  src=job.work/'source';src.mkdir();(job.work/'tmp').mkdir()
  for n,digest in base.items():
   need(time.monotonic()<job.deadline,'copy deadline');p=src/n;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(BASE_ROOT/n,p);need(sha(p)==digest,'snapshot copy');p.chmod(0o444)
  apply_posts(src,m)
  need(inventory(src)==qa,'QA source != artifact + two QA files')
  for n,rows in [('ARTIFACT-SOURCE-MANIFEST.json',artifact),('QA-SOURCE-MANIFEST.json',qa)]: (job.work/n).write_text(json.dumps(rows,indent=2,sort_keys=True)+'\n')
  env={'PATH':'/usr/local/go/bin:/usr/bin:/bin:/usr/sbin:/sbin','GOROOT':'/usr/local/go','HOME':str(job.work),'TMPDIR':str(job.work/'tmp'),'GO111MODULE':'on','GOENV':'off','GOWORK':'off','GOVCS':'*:off','GOTOOLCHAIN':'local','GOPROXY':'off','GOSUMDB':'off','GOTELEMETRY':'off','GOMAXPROCS':'2','GOMEMLIMIT':'768MiB','GOFLAGS':'-p=1','GOCACHE':str(job.work/'cache'),'GOMODCACHE':str(REPO/'.gomodcache'),'GOOS':'darwin','GOARCH':'arm64','GOARM64':'v8.0','CGO_ENABLED':'0','LC_ALL':'C'}
  def run(n,args,loopback=False):return job.run(n,['/usr/bin/sandbox-exec','-p',policy(src,loopback),*args],cwd=src,env=env)
  need(run('version',[GO,'version']).decode().strip()=='go version go1.27.4 darwin/arm64','Go version');run('module-verify',[GO,'mod','verify'])
  for n in ('node-observer','census-parent-and-original','census-server'):
   g=tests[n]
   args=[GO,'test','-mod=readonly','-buildvcs=false','-p=1','-parallel=1','-count=1','-timeout=180s','-json','-run=^('+'|'.join(re.escape(x) for x in g['tests'])+')$',g['package']]
   results[n]=check_events(run(n,args,g['loopback']),g['tests'],g.get('expected_child_passes'))
  need(inventory(src)==qa,'readonly source changed');check_inputs(f);directory_bytes(job.work,6*1024**3)
 except BaseException as exc:error=repr(exc)
 result=job.finish({'status':'DISPOSABLE_OBSERVER_PURE_GO_QA_PASS' if error is None else 'STOP','error':error,'scope':'HOST_TESTS_ONLY_CHANGED_CORE_NOT_BASELINE_NOT_METRIC_NO512','base_actual_source_manifest_sha256':f['base_manifest_sha256'],'subject_manifest_sha256':f['subject_manifest_sha256'],'artifact_source_manifest_sha256':sha(job.work/'ARTIFACT-SOURCE-MANIFEST.json') if (job.work/'ARTIFACT-SOURCE-MANIFEST.json').exists() else None,'QA_source_manifest_sha256':sha(job.work/'QA-SOURCE-MANIFEST.json') if (job.work/'QA-SOURCE-MANIFEST.json').exists() else None,'tests':results,'artifact_snapshot_files':len(artifact) if artifact else None,'QA_snapshot_files':len(qa) if qa else None,'Linux_or_app_ELF':'NOT_BUILT_NOT_EXECUTED','original_Go_source_API':'NOT_RUN_CHANGED_CORE_REQUIRES_FRESH_READBACK_LATER','work_seconds':600,'cleanup_seconds':30})
 if result['error']:raise SystemExit(1)
if __name__=='__main__':main()
