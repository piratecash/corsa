package censusdiag

import "errors"

// Closed fixture diagnostics only. A label never authorizes a census or changes
// its success/failure; it contains no error text, address, identity or secret.
type CensusStage uint8

const (
	CensusStageNone CensusStage = iota
	CensusStageFullRegistry
	CensusStageFullReceipt
	CensusStageWitnessClockBefore
	CensusStageWitnessRows
	CensusStageWitnessCommit
	CensusStageWitnessClockAfter
	CensusStageWitnessEncode
	CensusStageProcessBinding
	CensusStageProcessEndedBefore
	CensusStageProcessRPC
	CensusStageProcessEndedAfter
	CensusStageProcessContext
	CensusStageProcessDecode
	CensusStageHelperBinding
	CensusStageHelperClockBefore
	CensusStageHelperClockAfter
	CensusStageHelperClockMismatch
	CensusStageHelperCommitConflict
	CensusStageParentBinding
	CensusStageParentRunning
	CensusStageParentClockBefore
	CensusStageParentClockAfter
	CensusStageParentState
	CensusStageParentWrite
	CensusStageParentRead
	CensusStageParentDecode
)

func (s CensusStage) Valid() bool {
	if s > CensusStageNone && s <= CensusStageParentDecode {
		return true
	}
	switch s {
	case 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80:
		return true
	}
	return false
}

func (s CensusStage) Label() string {
	switch s {
	case CensusStageFullRegistry:
		return "full_registry"
	case CensusStageFullReceipt:
		return "full_receipt"
	case CensusStageWitnessClockBefore:
		return "witness_clock_before"
	case CensusStageWitnessRows:
		return "witness_rows"
	case CensusStageWitnessCommit:
		return "witness_commit"
	case CensusStageWitnessClockAfter:
		return "witness_clock_after"
	case CensusStageWitnessEncode:
		return "witness_encode"
	case CensusStageProcessBinding:
		return "process_binding"
	case CensusStageProcessEndedBefore:
		return "process_ended_before"
	case CensusStageProcessRPC:
		return "process_rpc"
	case CensusStageProcessEndedAfter:
		return "process_ended_after"
	case CensusStageProcessContext:
		return "process_context"
	case CensusStageProcessDecode:
		return "process_decode"
	case CensusStageHelperBinding:
		return "helper_binding"
	case CensusStageHelperClockBefore:
		return "helper_clock_before"
	case CensusStageHelperClockAfter:
		return "helper_clock_after"
	case CensusStageHelperClockMismatch:
		return "helper_clock_mismatch"
	case CensusStageHelperCommitConflict:
		return "helper_commit_conflict"
	case CensusStageParentBinding:
		return "parent_binding"
	case CensusStageParentRunning:
		return "parent_running"
	case CensusStageParentClockBefore:
		return "parent_clock_before"
	case CensusStageParentClockAfter:
		return "parent_clock_after"
	case CensusStageParentState:
		return "parent_state"
	case CensusStageParentWrite:
		return "parent_write"
	case CensusStageParentRead:
		return "parent_read"
	case CensusStageParentDecode:
		return "parent_decode"
	case 65:
		return "observer_unknown"
	case 66:
		return "observer_read_origin"
	case 67:
		return "observer_frame_shape"
	case 68:
		return "observer_window_crossing"
	case 69:
		return "observer_clock"
	case 70:
		return "observer_connection_admission"
	case 71:
		return "observer_queue_write"
	case 72:
		return "observer_full_send"
	case 73:
		return "observer_receive_metadata_stability"
	case 74:
		return "observer_receive_global_budget"
	case 75:
		return "observer_receive_connection_limit"
	case 76:
		return "observer_receipt_snapshot_missing_peer"
	case 77:
		return "observer_receipt_field_mismatch"
	case 78:
		return "observer_receipt_withdrawn_expired"
	case 79:
		return "observer_capture_window"
	case 80:
		return "observer_capture_pending"
	default:
		return "unknown"
	}
}

type censusFailure struct {
	stage CensusStage
	cause error
}

func (e *censusFailure) Error() string {
	if e == nil || !e.stage.Valid() {
		return "fixture census unavailable"
	}
	return "fixture census unavailable: stage=" + e.stage.Label()
}
func (e *censusFailure) Unwrap() error {
	if e == nil {
		return nil
	}
	return e.cause
}

// Unwrap retains errors.Is locally. Formatting never includes cause.Error().
func CensusFailure(stage CensusStage, cause error) error {
	return &censusFailure{stage: stage, cause: cause}
}

func CensusDiagnostic(err error) (CensusStage, bool) {
	var e *censusFailure
	if errors.As(err, &e) && e != nil && e.stage.Valid() {
		return e.stage, true
	}
	return CensusStageNone, false
}

func CensusRPCMessage(stage CensusStage) string {
	if !stage.Valid() {
		return "fixture registry witness unavailable"
	}
	return "fixture registry witness unavailable: census_stage=" + stage.Label()
}

// Only the exact fixed server error-message is mapped. The caller separately
// verifies the authenticated launch-bound client, HTTP503, command and schema.
func CensusDiagnosticFromRPCMessage(raw string) (CensusStage, bool) {
	if len(raw) > 96 {
		return CensusStageNone, false
	}
	for s := CensusStageFullRegistry; s <= 80; s++ {
		if s.Valid() && raw == CensusRPCMessage(s) {
			return s, true
		}
	}
	return CensusStageNone, false
}

// Private disposable observer build only. No named Service/product API.
// A raw error cause or unknown structural code never becomes a label.
func CensusDiagnosticFromObserver(err error) (CensusStage, bool) {
	var readout interface{ RouteWireDiagnosticCode() uint8 }
	if !errors.As(err, &readout) || readout == nil {
		return CensusStageNone, false
	}
	code := readout.RouteWireDiagnosticCode()
	switch code {
	case 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16:
		return CensusStage(64 + code), true
	}
	return CensusStageNone, false
}
