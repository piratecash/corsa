package node

import (
	"bytes"
	"crypto/sha256"
	"encoding/hex"
	"maps"
	"slices"

	"github.com/piratecash/corsa/internal/core/domain"
	"github.com/piratecash/corsa/internal/core/protocol"
	"github.com/piratecash/corsa/internal/core/routing"
)

type routeWireFullClaim struct {
	hops uint8
	seq  uint64
}

type routeWireFullReceive struct {
	epoch   uint64
	claims  map[domain.PeerIdentity]routeWireFullClaim
	receipt *domain.RouteWireFullReceipt
}

// Called under the observer lock for full frames wholly inside the window.
// Repeated stable entries contribute once to the window's set.
func (o *LoadstandRouteWireObservation) recordFullReceive(conn *routeWireConnection, line string) (bool, routeWireFailureReason) {
	frame, err := protocol.UnmarshalRouteAnnounceV3Frame([]byte(line))
	if err != nil || frame.Kind != protocol.RouteAnnounceV3KindFull || frame.Epoch == 0 ||
		len(frame.Entries) == 0 || len(frame.Entries) > maxRoutesPerAnnounceFrame {
		return false, routeWireFailureReceiveMetadataStability
	}
	full := conn.fullReceive
	if full == nil {
		full = &routeWireFullReceive{epoch: frame.Epoch, claims: make(map[domain.PeerIdentity]routeWireFullClaim)}
		conn.fullReceive = full
	}
	if full.epoch != frame.Epoch {
		return false, routeWireFailureReceiveMetadataStability
	}
	for _, entry := range frame.Entries {
		id := domain.PeerIdentityFromWire(entry.Identity)
		if id.IsZero() || id == conn.peer || entry.Hops < 1 || entry.Hops >= routing.HopsInfinity-1 {
			return false, routeWireFailureReceiveMetadataStability
		}
		claim := routeWireFullClaim{hops: entry.Hops, seq: entry.SeqNo}
		if prior, found := full.claims[id]; found {
			if prior != claim {
				return false, routeWireFailureReceiveMetadataStability
			}
			continue
		}
		if o.fullRows >= o.fullBudget {
			return false, routeWireFailureReceiveGlobalBudget
		}
		if len(full.claims) >= domain.RouteWireFullMaxDestinations {
			return false, routeWireFailureReceiveConnectionLimit
		}
		full.claims[id] = claim
		o.fullRows++
	}
	return true, 0
}

// CaptureLoadstandRouteWireFullReceipts reads the table before stopping the
// original session owners, on the fixture's census path.
func (s *Service) CaptureLoadstandRouteWireFullReceipts() error {
	o := s.routeWireObserver()
	if o == nil {
		return routeWireFailureError{routeWireFailureConnectionAdmission}
	}
	if o.fullBudget == 0 {
		return routeWireFailureError{routeWireFailureConnectionAdmission}
	}
	if s.routingTable == nil {
		return routeWireFailureError{routeWireFailureConnectionAdmission}
	}
	return o.captureFullReceipts(s.routingTable.Snapshot)
}

func (o *LoadstandRouteWireObservation) captureFullReceipts(snapshot func() routing.Snapshot) error {
	o.mu.Lock()
	// Preserve original short-circuit order. These early refusals never poison
	// the original bool or persist a reason: a later valid capture may succeed.
	if o.reportSealed {
		err := o.failureLocked(routeWireFailureConnectionAdmission)
		o.mu.Unlock()
		return err
	}
	if o.incomplete {
		err := o.failureLocked(routeWireFailureUnknown)
		o.mu.Unlock()
		return err
	}
	if o.window.advance() != nil {
		err := o.failureLocked(routeWireFailureClock)
		o.mu.Unlock()
		return err
	}
	if o.window.last <= o.window.windowEnd {
		err := o.failureLocked(routeWireFailureCaptureWindow)
		o.mu.Unlock()
		return err
	}
	if o.fullPassesPending != 0 {
		err := o.failureLocked(routeWireFailureCapturePending)
		o.mu.Unlock()
		return err
	}
	at := o.window.last
	hasClaims := o.fullRows != 0
	taken := o.fullTaken
	o.mu.Unlock()
	if taken {
		return nil
	}
	var table routing.Snapshot
	if hasClaims {
		table = snapshot()
	}
	o.mu.Lock()
	defer o.mu.Unlock()
	if o.reportSealed {
		return o.failureLocked(routeWireFailureConnectionAdmission)
	}
	if o.incomplete {
		return o.failureLocked(routeWireFailureUnknown)
	}
	if o.window.advance() != nil {
		return o.failureLocked(routeWireFailureClock)
	}
	if o.fullTaken {
		return nil
	}
	for _, conn := range o.connections {
		full := conn.fullReceive
		if full == nil {
			continue
		}
		digest, reason := full.claimDigest(conn.peer, table)
		if reason != 0 {
			o.failLocked(reason)
			return o.failureLocked(reason)
		}
		full.receipt = &domain.RouteWireFullReceipt{Destinations: len(full.claims), IdentitySHA256: digest, Epoch: full.epoch, SnapshotAfterNS: at}
		full.claims = nil
	}
	o.fullTaken = true
	return nil
}

func (f *routeWireFullReceive) claimDigest(sender domain.PeerIdentity, table routing.Snapshot) (string, routeWireFailureReason) {
	if sender.IsZero() {
		return "", routeWireFailureReceiptSnapshotMissingPeer
	}
	if len(f.claims) == 0 {
		return "", routeWireFailureReceiptSnapshotMissingPeer
	}
	if table.TakenAt.IsZero() {
		return "", routeWireFailureReceiptSnapshotMissingPeer
	}
	ids := slices.SortedFunc(maps.Keys(f.claims), func(a, b domain.PeerIdentity) int { return bytes.Compare(a[:], b[:]) })
	hash := sha256.New()
	for _, id := range ids {
		want := f.claims[id]
		found := false
		for _, row := range table.Routes[id] {
			if row.NextHop != sender {
				continue
			}
			if found {
				return "", routeWireFailureReceiptFieldMismatch
			}
			if row.Identity != id {
				return "", routeWireFailureReceiptFieldMismatch
			}
			if row.Source != routing.RouteSourceAnnouncement {
				return "", routeWireFailureReceiptFieldMismatch
			}
			if row.Hops != int(want.hops)+1 {
				return "", routeWireFailureReceiptFieldMismatch
			}
			if row.SeqNo != want.seq {
				return "", routeWireFailureReceiptFieldMismatch
			}
			if row.IsWithdrawn() {
				return "", routeWireFailureReceiptWithdrawnExpired
			}
			if row.ExpiresAt.IsZero() {
				return "", routeWireFailureReceiptWithdrawnExpired
			}
			if row.IsExpired(table.TakenAt) {
				return "", routeWireFailureReceiptWithdrawnExpired
			}
			found = true
		}
		if !found {
			return "", routeWireFailureReceiptSnapshotMissingPeer
		}
		_, _ = hash.Write(id[:])
	}
	return hex.EncodeToString(hash.Sum(nil)), 0
}

// DISPOSABLE diagnostic-only state/error helpers. Never included in a
// published/metric/512MB artifact. One scalar per observer, never per session.
type routeWireFailureReason uint8

const (
	routeWireFailureNone routeWireFailureReason = iota
	routeWireFailureUnknown
	routeWireFailureReadOrigin
	routeWireFailureFrameShape
	routeWireFailureWindowCrossing
	routeWireFailureClock
	routeWireFailureConnectionAdmission
	routeWireFailureQueueWrite
	routeWireFailureFullSend
	routeWireFailureReceiveMetadataStability
	routeWireFailureReceiveGlobalBudget
	routeWireFailureReceiveConnectionLimit
	routeWireFailureReceiptSnapshotMissingPeer
	routeWireFailureReceiptFieldMismatch
	routeWireFailureReceiptWithdrawnExpired
	routeWireFailureCaptureWindow
	routeWireFailureCapturePending
)

func (r routeWireFailureReason) valid() bool { return r > 0 && r <= routeWireFailureCapturePending }

type routeWireFailureError struct{ reason routeWireFailureReason }

func (e routeWireFailureError) Error() string                  { return "route-wire fixture observation unavailable" }
func (e routeWireFailureError) Unwrap() error                  { return errRouteWireIncomplete }
func (e routeWireFailureError) RouteWireDiagnosticCode() uint8 { return uint8(e.reason) }

// All callers retain the original observer lock boundary.
func (o *LoadstandRouteWireObservation) failLocked(reason routeWireFailureReason) {
	if !o.incomplete {
		if !reason.valid() {
			reason = routeWireFailureUnknown
		}
		o.firstFailure = reason
	}
	o.incomplete = true
}
func (o *LoadstandRouteWireObservation) failAt(reason routeWireFailureReason) {
	if o == nil {
		return
	}
	o.mu.Lock()
	o.failLocked(reason)
	o.mu.Unlock()
}
func (o *LoadstandRouteWireObservation) failureLocked(fallback routeWireFailureReason) error {
	reason := fallback
	if o.incomplete {
		if o.firstFailure.valid() {
			reason = o.firstFailure
		} else {
			reason = routeWireFailureUnknown
		}
	}
	if !reason.valid() {
		reason = routeWireFailureUnknown
	}
	return routeWireFailureError{reason}
}
