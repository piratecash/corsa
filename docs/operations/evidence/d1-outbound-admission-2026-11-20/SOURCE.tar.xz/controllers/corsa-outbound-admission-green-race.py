import os,sys,json,hashlib,subprocess,shutil
from pathlib import Path
R=Path('/Users/hades/Documents/repos/corsa');P=R/'docs/_internal/d1-artifacts/2026-11-20/d1-o1a-outbound-admission-fix-v1';sys.path.insert(0,str(R/'docs/_internal/d1-artifacts/2026-11-20/d1-o1a-capexec-seccomp-build-v1'))
from common import Job,need,sha
M=json.loads((P/'MANIFEST.json').read_bytes());need(subprocess.check_output(['git','rev-parse','HEAD'],cwd=R).decode().strip()==M['base_commit'],'HEAD drift')
for n,row in M['files'].items():need((not(R/n).exists() if row['before_sha256'] is None else sha(R/n)==row['before_sha256']) and sha(P/'posts'/n)==row['after_sha256'],'overlay source drift')
expected={'TestLoadStandRouteWireFullSendMatchesOriginalWriter','TestLoadStandRouteWireFullPassRefusesConnectionOrBoundaryChange','TestLoadStandRouteWireFullSendPreWindowCrossingMechanism','TestLoadStandRouteWireFullSendProjectionReuseMechanism','TestLoadStandRouteWireSenderRefusalMechanisms','TestLoadStandRouteWireZeroOfferThenActualCompletePass','TestLoadStandRouteWireZeroOfferKeepsFailureGuards','TestLoadStandRouteWirePairsRequireReciprocalReports','TestLoadStandRouteWireOutboundRefusalThenActualPass','TestLoadStandRouteWireOutboundPartialAdmissionStaysInvalid','TestLoadStandRouteWireWriterBeforeFullIntentProof'};pattern='^('+'|'.join(sorted(expected))+')$';files=sorted(set(subprocess.check_output(['git','ls-files','--','*.go','go.mod','go.sum'],cwd=R).decode().splitlines()+['internal/core/node/find_node_published31_guest_linux_test.go']));before={n:sha(R/n) for n in files};os.umask(0o077)
if os.getpid()!=os.getpgrp():os.setsid()
j=Job('outbound-admission-green-race',600,2*1024**3);error=None;counts=None
try:
 need(shutil.disk_usage('/private/tmp').free>=10*1024**3,'host free')
 for n in ('cache','tmp'):(j.work/n).mkdir()
 (j.work/'SOURCE-BEFORE.json').write_text(json.dumps(before,sort_keys=True,indent=2)+'\n');overlay=j.work/'overlay.json';overlay.write_text(json.dumps({'Replace':{str(R/n):str(P/'posts'/n) for n in M['files']}})+'\n')
 env=os.environ.copy();env.update(GOCACHE=str(j.work/'cache'),GOMODCACHE=str(R/'.gomodcache'),TMPDIR=str(j.work/'tmp'),GOPROXY='off',GOSUMDB='off',GOTOOLCHAIN='local',GOTELEMETRY='off',GOMAXPROCS='2',GOMEMLIMIT='768MiB',GOFLAGS='-p=1',GOOS='darwin',GOARCH='arm64',CGO_ENABLED='0',GOENV='off',GOWORK='off');policy='(version 1)(allow default)(deny network*)(deny file-write* (subpath '+json.dumps(str(R))+'))';
 previous=Path('/private/tmp/corsa-d1-o1a-outbound-admission-unit-2de968d3c4c5429f82895d71ef9a31ec/RESULT.json');need(sha(previous)=='96ac3d6a9aaee3ebba60af4ccef2778d59d7e6294688fa54fc8bc77718da95c0','previous failure changed');redresult=json.loads(previous.read_bytes());need(redresult['error']=='unexpected RED tests or compile error' and not redresult['unknown'] and not redresult['lock_retained'],'prior stop changed')
 redrows=[json.loads(x) for x in Path(redresult['steps'][0]['stdout']).read_bytes().splitlines()];redfails={x['Test'] for x in redrows if x.get('Action')=='fail' and x.get('Test')};wantred={'TestLoadStandRouteWireOutboundRefusalThenActualPass','TestLoadStandRouteWireOutboundPartialAdmissionStaysInvalid'}|{'TestLoadStandRouteWireOutboundRefusalThenActualPass/'+n for n in ('disconnected','full-queue','closed-queue')};need(redfails==wantred,'localized original RED changed');need(json.loads((previous.parent/'SOURCE-BEFORE.json').read_bytes())==before,'Root source changed since RED')
 env['GOCACHE']=str(previous.parent/'cache')
 args=['/usr/local/go/bin/go','test','-mod=readonly','-p=1','-count=1','-timeout=90s','-json','./internal/core/node','-run']
 counts={}
 for mode in ('ordinary','race'):
  extra=['-race'] if mode=='race' else []
  cfg=dict(env,CGO_ENABLED='1' if mode=='race' else '0')
  raw=j.run(mode,['/usr/bin/sandbox-exec','-p',policy,*args[:2],'-overlay='+str(overlay),*extra,*args[2:],pattern],cwd=R,env=cfg)
  events=[json.loads(x) for x in raw.splitlines()];need(not any(x.get('Action') in ('fail','skip') for x in events),'Go FAIL/SKIP');passed=[x['Test'] for x in events if x.get('Action')=='pass' and x.get('Test')];need({n for n in passed if '/' not in n}==expected,'test inventory');counts[mode]={'outer':len(expected),'child':sum('/' in n for n in passed)}
 after={n:sha(R/n) for n in files};need(after==before,'source changed');(j.work/'SOURCE-AFTER.json').write_text(json.dumps(after,sort_keys=True,indent=2)+'\n')
 for n,row in M['files'].items():need(sha(P/'posts'/n)==row['after_sha256'],'post changed')
except BaseException as e:error=str(e)
j.finish({'status':'OUTBOUND_ADMISSION_RED_GREEN_RACE_PASS' if error is None else 'FAILED','error':error,'tests':counts,'original_RED_result_sha256':sha(previous),'reused_own_cache':str(previous.parent/'cache'),'base':M['base_commit'],'manifest_sha256':sha(P/'MANIFEST.json'),'scope':'PROVEN_OUTBOUND_PRE_ADMISSION_ONLY_NOT_NATIVE_CAUSE_PROOF','app_or_Linux_ELF_executed':False,'Root_source_changed':False})
if error:raise SystemExit(1)
