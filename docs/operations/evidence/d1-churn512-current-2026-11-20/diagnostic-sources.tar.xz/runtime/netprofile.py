"""Finite SG512-only inert-default network contract. Inert on import."""
import hashlib
import ipaddress
import json
import os
from pathlib import Path
import re
import socket
import struct
import time

CONTRACT="SG512_INERT_DEFAULT_TUNNELS-v2"
PROFILE_SHA="b96b63e1ec5ce0a73e71320bf7e37bc458c0ca4407d40b2b81182ee5eb4981f0"
DUMPS=(("links",18,16,0,16),("addresses_v4",22,20,2,8),("addresses_v6",22,20,10,8),
       ("routes_v4",26,24,2,12),("routes_v6",26,24,10,12),("rules_v4",34,32,2,12),("rules_v6",34,32,10,12))


def require(value,reason):
    if not value:raise ValueError("sg512-network:"+reason)


def canonical(value):return json.dumps(value,sort_keys=True,separators=(",",":" )).encode()
def digest(value):return hashlib.sha256(canonical(value)).hexdigest()


def profile():
    path=Path(__file__).resolve().with_name("network-profile.json")
    fd=os.open(path,os.O_RDONLY|os.O_CLOEXEC|os.O_NOFOLLOW)
    try:raw=os.read(fd,65537)
    finally:os.close(fd)
    require(len(raw)<=65536 and hashlib.sha256(raw).hexdigest()==PROFILE_SHA,"profile-sha")
    value=json.loads(raw)
    require(value["contract"]==CONTRACT and value["source_count"]==768,"profile-contract")
    return value


def attrs(raw):
    result={}
    while raw:
        require(len(raw)>=4,"short-attribute")
        size,key=struct.unpack_from("<HH",raw);aligned=(size+3)&~3
        require(4<=size<=aligned<=len(raw) and key not in result,"attribute-size-or-duplicate")
        require(not any(raw[size:aligned]),"attribute-padding")
        result[key]=raw[4:size];raw=raw[aligned:]
        require(len(result)<=128,"attribute-count")
    return result


def encode_attrs(values):
    result=b""
    for key,value in values.items():
        size=4+len(value);result+=struct.pack("<HH",size,key)+value+b"\0"*((-size)%4)
    return result


def row_attrs(row):
    require(type(row["attrs"]) is list and len(row["attrs"])<=128,"row-attributes")
    values={}
    for item in row["attrs"]:
        key=item["type"];require(type(key) is int and 0<=key<=65535 and key not in values,"row-attribute-key")
        require(type(item["hex"]) is str and len(item["hex"])<=131072,"row-attribute-bound")
        values[key]=bytes.fromhex(item["hex"])
    return values


def attribute_rules(values,rules):
    require({str(k) for k in values}==set(rules),"unknown-or-missing-structural-attribute")
    for key,raw in values.items():
        rule=rules[str(key)]
        if "hex" in rule:require(raw.hex()==rule["hex"],"structural-attribute-value")
        elif "children" in rule:attribute_rules(attrs(raw),rule["children"])
        elif rule.get("format")=="local-unicast-mac16":
            require(rule["size"]==16 and len(raw)==16 and raw[0]&3==2 and raw[6:]==b"\0"*10,"permanent-address-local-unicast-shape")
        else:
            width={"u32":4,"u64":8}.get(rule.get("format"),0)
            require(width and rule["size"]>0 and rule["size"]%width==0 and len(raw)==rule["size"],"counter-cache-format")


def decode_datagram(raw,seq,port,expected_type,header_size):
    rows=[]
    while raw:
        require(len(raw)>=16,"short-netlink-header")
        size,kind,flags,got_seq,got_port=struct.unpack_from("<IHHII",raw);aligned=(size+3)&~3
        require(16<=size<=aligned<=len(raw) and got_seq==seq and got_port==port,"netlink-length-sequence-port")
        require(flags==2,"netlink-multipart-flags-interrupted-filtered")
        require(not any(raw[size:aligned]),"netlink-padding")
        body=raw[16:size]
        if kind==3:
            require(body==b"\0"*4 and aligned==len(raw),"netlink-terminal-error-or-tail")
            return rows,True
        require(kind==expected_type and len(body)>=header_size,"netlink-error-or-unexpected-message")
        values=attrs(body[header_size:])
        row={"type":kind,"header_hex":body[:header_size].hex(),"attrs":[{"type":k,"hex":v.hex()} for k,v in values.items()]}
        if kind==16:
            family,pad,hardware,index,link_flags,change=struct.unpack("<BBHiII",body[:16])
            name=values.get(3,b"");require(1<len(name)<=16 and name[-1:]==b"\0" and b"\0" not in name[:-1],"interface-name")
            row.update(name=name[:-1].decode("ascii"),index=index,flags=link_flags,hardware_type=hardware)
            if 18 in values:
                info=attrs(values[18]);require(1 in info,"link-kind")
                row["kind"]=info[1].rstrip(b"\0").decode("ascii")
        rows.append(row);raw=raw[aligned:]
    return rows,False


def dump(sock,request_type,result_type,family,header_size,seq,deadline,received):
    port=sock.getsockname()[0];require(port>0,"netlink-local-port")
    header=bytes([family])+b"\0"*(header_size-1)
    sock.settimeout(max(.001,deadline-time.monotonic()))
    sock.sendto(struct.pack("<IHHII",16+len(header),request_type,0x301,seq,port)+header,(0,0))
    rows=[]
    while True:
        require(time.monotonic()<deadline,"network-dump-deadline")
        sock.settimeout(max(.001,deadline-time.monotonic()))
        raw,ancillary,flags,peer=sock.recvmsg(65536)
        require(peer==(0,0) and not ancillary and flags==0 and raw,"kernel-peer-truncation-ancillary")
        received[0]+=len(raw);require(received[0]<=4*1024**2,"all-dumps-byte-bound")
        part,done=decode_datagram(raw,seq,port,result_type,header_size);rows+=part
        require(len(rows)<=2048,"dump-row-bound")
        if done:
            sock.setblocking(False)
            try:
                sock.recvmsg(65536)
            except BlockingIOError:pass
            else:raise ValueError("sg512-network:datagram-after-terminal")
            return rows


def read_field(path):
    fd=os.open(path,os.O_RDONLY|os.O_CLOEXEC|os.O_NOFOLLOW)
    try:raw=os.read(fd,257)
    finally:os.close(fd)
    require(len(raw)<=256 and raw.endswith(b"\n"),"sysfs-field-bound")
    return raw.decode("ascii").strip()


def collect():
    before=os.readlink("/proc/self/ns/net");require(re.fullmatch(r"net:\[[1-9][0-9]*\]",before),"netns-format")
    deadline=time.monotonic()+2;received=[0];result={"netns":before,"rtnetlink":{},"sysfs":{}}
    with socket.socket(socket.AF_NETLINK,socket.SOCK_RAW|socket.SOCK_CLOEXEC,socket.NETLINK_ROUTE) as sock:
        sock.bind((0,0))
        for seq,(name,request,reply,family,size) in enumerate(DUMPS,1001):
            result["rtnetlink"][name]=dump(sock,request,reply,family,size,seq,deadline,received)
    links=result["rtnetlink"]["links"]
    require(len(links)==10 and {x["name"] for x in links}==set(profile()["links"]),"finite-interface-set")
    for link in links:
        fields={}
        for key in ("addr_assign_type","address","carrier","flags","ifindex","iflink","mtu","operstate","type"):
            try:fields[key]=read_field("/sys/class/net/"+link["name"]+"/"+key)
            except OSError as error:fields[key]={"errno":error.errno}
        result["sysfs"][link["name"]]=fields
    require(before==os.readlink("/proc/self/ns/net") and time.monotonic()<deadline,"netns-change-or-deadline")
    result["received_bytes"]=received[0]
    return result


def norm_address(row,lo):
    require(row["type"]==20,"address-type")
    header=bytes.fromhex(row["header_hex"]);require(len(header)==8,"address-header")
    family,prefix,flags,scope,index=struct.unpack("<BBBBI",header)
    require(index==lo and family in (2,10) and flags==128 and scope==254,"address-on-nonlo-or-flags")
    values=row_attrs(row)
    if 6 in values:
        require(len(values[6])==16 and values[6][:8]==b"\xff"*8,"address-cache-lifetimes-format")
        values[6]=b"@permanent-cache16"
    return [header[:4].hex(),{str(k):v.hex() for k,v in values.items()}]


def norm_route(row,lo):
    require(row["type"]==24,"route-type")
    header=bytes.fromhex(row["header_hex"]);require(len(header)==12,"route-header")
    values=row_attrs(row)
    require(4 in values and values[4]==struct.pack("<I",lo),"route-nonlo-output")
    values[4]=b"@lo"
    if 12 in values:require(len(values[12])==32,"route-cache-format");values[12]=b"@cache32"
    return [header.hex(),{str(k):v.hex() for k,v in values.items()}]


def norm_rule(row):
    require(row["type"]==32 and len(bytes.fromhex(row["header_hex"]))==12,"rule-header")
    return [row["header_hex"],{str(k):v.hex() for k,v in row_attrs(row).items()}]


def same_set(actual,expected,reason):
    a=[canonical(x) for x in actual];b=[canonical(x) for x in expected]
    require(len(set(a))==len(a) and sorted(a)==sorted(b),reason)


def validate(inventory,aliases,baseline=None):
    model=profile();require(aliases in (0,768),"alias-mode")
    netns=inventory["netns"];require(re.fullmatch(r"net:\[[1-9][0-9]*\]",netns),"netns")
    data=inventory["rtnetlink"];require(set(data)=={x[0] for x in DUMPS},"seven-dumps-required")
    require(len(data["links"])==10,"finite-link-count")
    indices={};used=set();permanent={}
    for row in data["links"]:
        require(row["type"]==16,"link-type")
        header=bytes.fromhex(row["header_hex"]);require(len(header)==16,"link-header")
        family,pad,hardware,index,flags,change=struct.unpack("<BBHiII",header)
        values=row_attrs(row);name=values.get(3,b"")
        require(1<len(name)<=16 and name.endswith(b"\0") and b"\0" not in name[:-1],"interface-name")
        name=name[:-1].decode("ascii");require(name in model["links"] and name not in indices and index>0 and index not in used,"unknown-duplicate-link")
        expected=model["links"][name]
        require((family,pad,change)==(0,0,0) and hardware==expected["hardware_type"] and flags==expected["flags"],"hardware-or-interface-flags")
        require(row["name"]==name and row["index"]==index and row["flags"]==flags and row["hardware_type"]==hardware,"decoded-link-conflict")
        attribute_rules(values,expected["attrs"])
        if expected["attrs"].get("54",{}).get("format")=="local-unicast-mac16":permanent[name]=values[54].hex()
        fields=inventory["sysfs"][name]
        for key,want in expected["sysfs"].items():
            if key=="tun_flags":continue # Not needed: exact RTM kind/INFO_DATA proves tunnel configuration.
            require(fields.get(key)==want,"sysfs-structural-field")
        require(fields["ifindex"]==str(index) and fields["iflink"]==str(index if name=="lo" else 0),"sysfs-index-link")
        used.add(index);indices[name]=index
    require(set(indices)==set(model["links"]) and set(inventory["sysfs"])==set(indices),"sysfs-interface-inventory")
    lo=indices["lo"]
    expected_v4=[norm_address(x,1) for x in model["base_addresses_v4"]]
    expected_routes=[norm_route(x,1) for x in model["base_routes_v4"]]
    for slot in range(aliases):
        address=bytes([10,77,slot//254,slot%254+1]).hex()
        expected_v4.append(["022080fe",{"1":address,"2":address,"3":"6c6f00","8":"80000000","6":b"@permanent-cache16".hex()}])
        expected_routes.append(["02200000ff02fe0200000000",{"15":"ff000000","1":address,"7":address,"4":b"@lo".hex()}])
    same_set([norm_address(x,lo) for x in data["addresses_v4"]],expected_v4,"v4-address-set")
    same_set([norm_address(x,lo) for x in data["addresses_v6"]],[norm_address(x,1) for x in model["base_addresses_v6"]],"v6-address-set")
    same_set([norm_route(x,lo) for x in data["routes_v4"]],expected_routes,"v4-route-set")
    same_set([norm_route(x,lo) for x in data["routes_v6"]],[norm_route(x,1) for x in model["base_routes_v6"]],"v6-route-set")
    for family in ("rules_v4","rules_v6"):same_set([norm_rule(x) for x in data[family]],[norm_rule(x) for x in model[family]],"policy-rules-set")
    stable={"contract":CONTRACT,"profile_sha256":PROFILE_SHA,"netns":netns,"indices":indices,"permanent_addresses":permanent}
    result={**stable,"link_identity_sha256":digest(stable),"aliases":aliases,
            "addresses_v4":len(data["addresses_v4"]),"routes_v4":len(data["routes_v4"]),
            "rules_v4":len(data["rules_v4"]),"rules_v6":len(data["rules_v6"])}
    if baseline is not None:require(all(result[k]==baseline[k] for k in stable) and result["link_identity_sha256"]==baseline["link_identity_sha256"],"network-incarnation-changed")
    return result


def snapshot(aliases,baseline=None):return validate(collect(),aliases,baseline)
