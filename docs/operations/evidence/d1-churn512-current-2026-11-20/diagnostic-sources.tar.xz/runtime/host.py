"""One closed churn512 attempt. Reuses canonical bounded Docker transport only."""
import argparse
import base64
import hashlib
import json
import os
from pathlib import Path
import re
import secrets
import stat
import sys
import time

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE/"canonical"))
import sg32_host as old
from sg32_common import need,strict_json,encode,read_owned,digest,static_elf,hex_value
from verify_churn import PHASES,validate_driver,validate_service
import netprofile

PROFILE="D1_CHURN512-INERT-TUNNELS-v2"
IMAGE="sha256:45ccc728acf675888bde399354b6c8338accfc591e35496f9413a3742f3ae313"
INPUTS={"corsad","c2driver","topology","worker.py","netprofile.py","network-profile.json","sg32_common.py","sg32_service.py","clockprobe.py"}
CODE={"host.py","verify_churn.py","canonical/sg32_host.py","canonical/sg32_common.py"}
CGFILES={"memory.max","memory.swap.max","memory.peak","memory.current","memory.events","cpu.max","cpu.stat","pids.max","pids.current","pids.events","cgroup.procs"}
BOOTSTRAP="import sys;sys.path.insert(0,'/inputs');import worker;sys.exit(worker.main())"
old.OUTPUT_LIMITS.update(service=36*1024**2,driver=4*1024**2)
old.ROLE_LIMITS["topology"]=(250000000,134217728,32)


def custody_stamp(info):
    # Reading owner/listing the lock legitimately changes atime. Content,
    # identity, authority and metadata changes must still prevent release.
    return (info.st_dev,info.st_ino,info.st_uid,info.st_gid,info.st_mode,
            info.st_size,info.st_mtime_ns,info.st_ctime_ns)


def lock_custody(path):
    return custody_stamp(path.lstat()),custody_stamp((path/"owner").lstat())


def network_view(view,aliases,before=None):
    need(type(view) is dict and view.get("contract")==netprofile.CONTRACT and
         view.get("profile_sha256")==netprofile.PROFILE_SHA and view.get("aliases")==aliases and
         view.get("addresses_v4")==1+aliases and view.get("routes_v4")==3+aliases and
         view.get("rules_v4")==3 and view.get("rules_v6")==2,"network-contract-counts")
    stable={k:view[k] for k in ("contract","profile_sha256","netns","indices","permanent_addresses")}
    need(view.get("link_identity_sha256")==netprofile.digest(stable) and
         re.fullmatch(r"net:\[[1-9][0-9]*\]",view["netns"]),"network-fingerprint")
    need(set(view["indices"])==set(netprofile.profile()["links"]) and
         all(type(x) is int and x>0 for x in view["indices"].values()) and len(set(view["indices"].values()))==10 and
         set(view["permanent_addresses"])=={"ip6_vti0","ip6tnl0","ip6gre0"},"network-identities")
    for value in view["permanent_addresses"].values():
        need(type(value) is str and re.fullmatch("[0-9a-f]{32}",value),"network-permanent-format")
        raw=bytes.fromhex(value);need(raw[0]&3==2 and raw[6:]==b"\0"*10,"network-permanent-shape")
    if before is not None:
        need(all(view[k]==before[k] for k in stable) and view["link_identity_sha256"]==before["link_identity_sha256"],"network-incarnation-change")
    return view


def argv(role,nonce,volumes,service_id=None,cli_sha=None,relay=None,netns=None):
    need(role in ("preparer","service","driver","topology"),"role")
    if role=="topology":
        need(hex_value(service_id,64) and re.fullmatch(r"net:\[[1-9][0-9]*\]",netns or ""),"topology-binding")
        return ["create","--pull=never","--name","corsa-d1-sg32-"+nonce+"-topology",
                "--label","corsa.sg32.owner="+nonce,"--label","corsa.sg32.role=topology",
                "--restart=no","--read-only","--cgroupns=private","--cpus=0.25","--memory=134217728",
                "--memory-swap=134217728","--pids-limit=32","--cap-drop=ALL","--cap-add=NET_ADMIN",
                "--security-opt=no-new-privileges","--user=0:0","--network=container:"+service_id,
                "--mount","type=volume,source="+volumes["inputs"]+",target=/inputs,readonly,volume-nocopy",
                "--env=D1_CHURN512_EXPECTED_NETNS="+netns,"--entrypoint=/inputs/topology",IMAGE]
    args=old.create_argv(role,nonce,volumes,service_id,cli_sha)
    args=[x for x in args if x!="--env=CORSA_C2B32_RUN=1"]
    at=next(i for i,value in enumerate(args) if value.startswith("--entrypoint="))
    tail=["preparer" if role=="preparer" else "keeper" if role=="service" else "driver",nonce]
    if role=="service":tail.append(cli_sha)
    if role=="driver":
        need(hex_value(relay,40),"driver-relay")
        tail.append(relay)
        args[at:at]=["--tmpfs=/tmp:rw,size=16777216,mode=0700,uid=501,gid=20","--ulimit=nofile=4096:4096"]
        at+=2
    return args[:at]+["--entrypoint=/usr/bin/python3",IMAGE,"-I","-S","-B","-c",BOOTSTRAP,*tail]


def verify_created(meta,role,nonce,volumes,service_id=None,cli_sha=None,relay=None,netns=None):
    config,host,state=meta["Config"],meta["HostConfig"],meta["State"]
    cpu,memory,pids=old.ROLE_LIMITS[role]
    need(meta["Image"]==IMAGE and meta["Name"]=="/corsa-d1-sg32-"+nonce+"-"+role and
         config.get("Labels",{}).get("corsa.sg32.owner")==nonce and config["Labels"].get("corsa.sg32.role")==role,"actual-owner-or-image")
    need(config.get("User")==("0:0" if role in ("preparer","topology") else "501:20") and
         host.get("Privileged") is False and host.get("ReadonlyRootfs") is True and host.get("CapDrop")==["ALL"] and
         host.get("RestartPolicy",{}).get("Name")=="no" and host.get("SecurityOpt")==["no-new-privileges"],"actual-isolation")
    allowed=["CHOWN"] if role=="preparer" else ["NET_ADMIN"] if role=="topology" else []
    cap=[x.removeprefix("CAP_") for x in (host.get("CapAdd") or [])]
    need(cap==allowed,"actual-capabilities")
    need(all(type(host.get(k)) is int and host[k]==v for k,v in {"NanoCpus":cpu,"Memory":memory,"MemorySwap":memory,"PidsLimit":pids}.items()),"actual-budget")
    need(host.get("NetworkMode")==("container:"+service_id if role in ("driver","topology") else "none") and
         host.get("PidMode","")=="" and host.get("CgroupnsMode")=="private" and not host.get("Binds") and
         not host.get("PortBindings") and not host.get("Devices") and not host.get("DeviceRequests") and
         state.get("Running") is False,"actual-namespaces-or-state")
    expected={"/inputs":(volumes["inputs"],role=="preparer")}
    if role!="topology":expected["/run/c1"]=(volumes["secret"],role=="preparer")
    if role in ("preparer","service"):expected["/work"]=(volumes["state"],True)
    mounts=meta["Mounts"]
    regular=[x for x in mounts if x.get("Type")=="volume"]
    need(len(regular)==len(expected),"actual-volume-count")
    for item in regular:
        destination=item["Destination"]
        need(destination in expected and type(item.get("RW")) is bool and
             (item.get("Name"),item["RW"])==expected.pop(destination),"actual-volume")
    need(not expected,"actual-volume-missing")
    extras=[x for x in mounts if x.get("Type")!="volume"]
    if role!="driver":need(not extras and not host.get("Tmpfs"),"actual-tmpfs")
    else:
        declared=host.get("Tmpfs")=={"/tmp":"rw,size=16777216,mode=0700,uid=501,gid=20"}
        materialized=len(extras)==1 and extras[0].get("Type")=="tmpfs" and extras[0].get("Destination")=="/tmp" and extras[0].get("RW") is True
        pending=not extras and state.get("Status")=="created" and state.get("Pid")==0
        need(declared and (materialized or pending),"actual-tmpfs")
    if role=="topology":
        need(config.get("Entrypoint")==["/inputs/topology"] and config.get("Cmd") in (None,[]) and
             (config.get("Env") or []).count("D1_CHURN512_EXPECTED_NETNS="+netns)==1,"actual-topology-command")
    else:
        tail=["preparer" if role=="preparer" else "keeper" if role=="service" else "driver",nonce]
        if role=="service":tail.append(cli_sha)
        if role=="driver":tail.append(relay)
        need(config.get("Entrypoint")==["/usr/bin/python3"] and config.get("Cmd")==["-I","-S","-B","-c",BOOTSTRAP,*tail],"actual-command")
        if role=="driver":need(host.get("Ulimits")==[{"Name":"nofile","Hard":4096,"Soft":4096}],"actual-driver-nofile")


def terminal(meta):
    state=meta["State"]
    need(state.get("Running") is False and state.get("Status")=="exited" and type(state.get("ExitCode")) is int and
         state["ExitCode"]==0 and state.get("OOMKilled") is False and state.get("Pid")==0,"normal-container-terminal")


def running(meta):
    state=meta["State"]
    need(state.get("Running") is True and state.get("Status")=="running" and state.get("OOMKilled") is False and
         type(state.get("Pid")) is int and state["Pid"]>0,"running-container-state")


def tmpfs_proof(value):
    need(type(value) is dict and set(value)=={"netns","path","uid","gid","mode","fstype","mount_id","device","mountinfo_sha256","capacity_bytes","frsize","blocks","identity"},"driver-tmpfs-proof-fields")
    need(re.fullmatch(r"net:\[[1-9][0-9]*\]",value["netns"]) and value["path"]=="/tmp" and value["uid"]==501 and value["gid"]==20 and value["mode"]==0o700 and value["fstype"]=="tmpfs" and
         type(value["mount_id"]) is int and value["mount_id"]>0 and re.fullmatch(r"[0-9]+:[0-9]+",value["device"]) and
         hex_value(value["mountinfo_sha256"],64) and type(value["frsize"]) is int and 0<value["frsize"]<=65536 and
         type(value["blocks"]) is int and value["blocks"]>0 and value["capacity_bytes"]==value["blocks"]*value["frsize"]<=16777216 and
         type(value["identity"]) is list and len(value["identity"])==2 and all(type(x) is int and x>0 for x in value["identity"]),"driver-tmpfs-proof")
    return value


def driver_measurement(output,nonce,network_before=None):
    packets=[]
    for line in output.splitlines():
        if not line.startswith("{"):continue
        value=strict_json(line)
        if value.get("kind")=="DRIVER_FINAL":packets.append(value)
    ready=[]
    for line in output.splitlines():
        if line.startswith("{"):
            row=strict_json(line.encode())
            if row.get("kind")=="DRIVER_TMPFS_READY":ready.append(row)
    need(len(ready)==1 and ready[0].get("nonce")==nonce,"driver-tmpfs-ready-record")
    need(len(packets)==1 and packets[0].get("nonce")==nonce and packets[0].get("test_exit")==0,"driver-final-record")
    need(tmpfs_proof(ready[0]["tmpfs"])==tmpfs_proof(packets[0]["tmpfs"]),"driver-tmpfs-identity-changed")
    rows=[strict_json(line.encode()) for line in output.splitlines() if line.startswith("{")]
    need(rows.index(ready[0])<rows.index(packets[0]) and output.splitlines()[0].startswith("{") and strict_json(output.splitlines()[0].encode())==ready[0],"driver-tmpfs-order")
    if network_before is not None:need(ready[0]["tmpfs"]["netns"]==network_before["netns"],"driver-tmpfs-netns")
    network_view(packets[0]["network"],768,network_before)
    values=packets[0]["facts"]["values"]
    need(values["memory.max"]==268435456 and values["memory.swap.max"]==0 and values["pids.max"]==32 and
         values["cpu.max"]=="100000 100000" and values["cgroup.procs"]==[1] and
         0<values["memory.peak"]<=268435456 and all(values["memory.events"].get(k)==0 for k in ("max","oom","oom_kill")) and
         values["pids.events"].get("max")==0,"driver-group-measurement")
    return {"driver_peak_bytes":values["memory.peak"],"driver_inclusive_cpu_usec":values["cpu.stat"]["usage_usec"],"driver_exit_tail":"UNKNOWN"}


def read_handoff(path,expected_sha):
    raw=read_owned(path,65536);need(digest(raw)==expected_sha,"handoff-sha")
    cfg=strict_json(raw)
    need(cfg.get("profile")==PROFILE and cfg.get("inputs_ready") is True and cfg.get("one_attempt") is True and
         cfg.get("reviewer_accepted") is True and cfg.get("tester_accepted") is True and cfg.get("image")==IMAGE and
         set(cfg.get("files",{}))==INPUTS,"inert-handoff")
    for name,entry in cfg["files"].items():
        body=read_owned(entry["path"],128*1024**2)
        need(len(body)==entry["bytes"] and digest(body)==entry["sha256"],"handoff-input")
        if name in ("corsad","c2driver","topology"):static_elf(body)
        else:
            local=HERE/name if name in ("worker.py","netprofile.py","network-profile.json") else HERE/"canonical"/name
            need(digest(read_owned(local,131072))==entry["sha256"],"local-worker-source-binding")
    for name,sha in cfg["code"].items():
        need(name in CODE and digest(read_owned(HERE/name,131072))==sha,"host-code-sha")
    need(set(cfg["code"])==CODE,"host-code-set")
    return raw,cfg


def service_logs(service):
    out,err=bytearray(),bytearray()
    for row in service.records():
        if row.get("kind")!="LOG":continue
        raw=base64.b64decode(row["raw_base64"],validate=True)
        need(len(raw)==row["bytes"]<=16384 and digest(raw)==row["sha256"],"node-log-frame")
        (out if row["stream"]=="out" else err).extend(raw)
    return out.decode("utf-8"),err.decode("utf-8")


def verify_measurement(records,nonce,cli_sha):
    allowed={"SECRET_ATTACHED","NETWORK_POST","NETWORK_CONTINUED","INITIAL","SAMPLER_READY","NODE_BOUND","READY","STOPPING_ACK","NODE_REAP","SAMPLER_FINAL","FINAL","STATE_CHECK","SAMPLE","LOG"}
    need(all(type(x) is dict and x.get("nonce")==nonce and x.get("kind") in allowed for x in records),"service-records")
    selected={}
    for kind in ("SECRET_ATTACHED","NETWORK_POST","NETWORK_CONTINUED","INITIAL","SAMPLER_READY","NODE_BOUND","READY","STOPPING_ACK","NODE_REAP","SAMPLER_FINAL","FINAL"):
        found=[(i,x) for i,x in enumerate(records) if x.get("kind")==kind]
        need(len(found)==1,"missing-or-duplicate-"+kind);selected[kind]=found[0]
    need([v[0] for v in selected.values()]==sorted(v[0] for v in selected.values()),"service-order")
    final=selected["FINAL"][1];bound=selected["NODE_BOUND"][1]
    network_before=network_view(selected["SECRET_ATTACHED"][1]["network"],0)
    need(network_before["netns"]==selected["SECRET_ATTACHED"][1]["netns"],"attached-network-ns")
    network_view(selected["NETWORK_POST"][1]["network"],768,network_before)
    network_view(selected["NETWORK_CONTINUED"][1]["network"],768,network_before)
    for kind in ("SAMPLER_READY","SAMPLER_FINAL","FINAL"):network_view(selected[kind][1]["network"],768,network_before)
    sampler_pid=selected["SAMPLER_READY"][1]["pid"]
    need(type(sampler_pid) is int and sampler_pid>1 and sampler_pid!=bound["node"]["pid"],"sampler-pid")
    need(bound["exe_sha256"]==cli_sha and bound["node"]["ppid"]==1 and selected["READY"][1]["node"]==bound["node"] and
         selected["STOPPING_ACK"][1]["node"]==bound["node"]==selected["NODE_REAP"][1]["node"]==selected["SAMPLER_FINAL"][1]["node_reaped"],"owned-node-binding")
    need(final["node_exit"]==final["sampler_exit"]==0 and final["keeper_exit_tail"]==final["shared_page_attribution"]=="UNKNOWN" and
         final["checked_phases"]==[x[0] for x in PHASES] and final["facts"]["values"]["cgroup.procs"]==[1],"final-reap-scope")
    checks=[x for x in records if x.get("kind")=="STATE_CHECK"]
    for check in checks:network_view(check["network"],768,network_before)
    need([x["phase"] for x in checks]==[x[0] for x in PHASES] and all(type(x["bytes"]) is int and 0<=x["bytes"]<=64*1024**2 for x in checks+[final]),"state-checks")
    facts=[x["facts"] for x in records if "facts" in x]
    need(facts and all(x["files"]==facts[0]["files"] and x["netns"]==selected["SECRET_ATTACHED"][1]["netns"] for x in facts),"group-or-netns-incarnation")
    previous_peak=previous_cpu=0
    for fact in facts:
        values=fact["values"]
        need(set(fact["files"])==CGFILES and set(values)==CGFILES and
             all(type(fact[k]) is int and fact[k]>=0 for k in ("before_ns","after_ns")),"complete-cgroup-facts")
        need(values["memory.max"]==512000000 and values["memory.swap.max"]==0 and values["pids.max"]==64 and values["cpu.max"]=="100000 100000" and
             previous_peak<=values["memory.peak"]<=512000000 and previous_cpu<=values["cpu.stat"]["usage_usec"] and
             all(values["memory.events"].get(k)==0 for k in ("max","oom","oom_kill")) and values["pids.events"].get("max")==0,"resource-values")
        previous_peak,previous_cpu=values["memory.peak"],values["cpu.stat"]["usage_usec"]
    need(selected["INITIAL"][1]["facts"]["values"]["cgroup.procs"]==[1] and
         selected["SAMPLER_READY"][1]["facts"]["values"]["cgroup.procs"]==sorted([1,sampler_pid]) and
         selected["SAMPLER_FINAL"][1]["facts"]["values"]["cgroup.procs"]==sorted([1,sampler_pid]),"owned-group-edge-members")
    samples=[x for x in records if x.get("kind")=="SAMPLE"]
    need(samples,"missing-live-samples")
    need([x["ordinal"] for x in samples]==list(range(len(samples))) and selected["SAMPLER_FINAL"][1]["ordinal"]==len(samples),"sample-ordinal-gap")
    for i,row in enumerate(records):
        if row.get("kind")!="SAMPLE":continue
        members=set(row["facts"]["values"]["cgroup.procs"])
        known={1,sampler_pid,bound["node"]["pid"]}
        need(members==known if i<selected["STOPPING_ACK"][0] else {1,sampler_pid}<=members<=known,"foreign-or-missing-live-member")
    timeline=[selected["SAMPLER_READY"][1]["facts"]]+[x["facts"] for x in samples]+[selected["SAMPLER_FINAL"][1]["facts"]]
    need(all(0<=a["before_ns"]<=a["after_ns"]<=b["before_ns"]<=b["after_ns"] and b["after_ns"]-a["after_ns"]<=2*10**9 for a,b in zip(timeline,timeline[1:])),"sample-coverage-gap")
    return {"service_peak_bytes":final["facts"]["values"]["memory.peak"],"inclusive_group_cpu_usec":final["facts"]["values"]["cpu.stat"]["usage_usec"],"keeper_exit_tail":"UNKNOWN","shared_page_attribution":"UNKNOWN"}


def run(path,sha):
    origin=time.monotonic();work,end=origin+180,origin+210
    raw,cfg=read_handoff(path,sha)
    need(os.getpid()==os.getpgrp() and (os.getuid(),os.getgid())==(501,20),"own-controller-group")
    need(os.statvfs(HERE).f_bavail*os.statvfs(HERE).f_frsize>=10*1024**3+sum(x["bytes"] for x in cfg["files"].values()),"free-space")
    parent=Path(cfg["run_parent"])
    need(parent.is_absolute() and parent.resolve(strict=True)==parent and parent.is_dir() and
         parent.stat().st_uid==501 and stat.S_IMODE(parent.stat().st_mode)==0o700,"run-parent-custody")
    need(not os.path.lexists(Path(path).with_name("ONE-ATTEMPT-CLAIM.json")),"attempt-already-claimed")
    nonce=secrets.token_hex(16);names=old.volume_names(nonce);ids=[];volumes=[]
    owner=f"name=d1-churn512\npid={os.getpid()}\npgid={os.getpgrp()}\nattempt_id={nonce}\n".encode()
    old.LOCK.mkdir(mode=0o700);(old.LOCK/"owner").write_bytes(owner);custody=lock_custody(old.LOCK)
    engine=old.Engine();engine.root=parent/("churn512-"+nonce);engine.root.mkdir(mode=0o700)
    claim=Path(path).with_name("ONE-ATTEMPT-CLAIM.json")
    try:
        fd=os.open(claim,os.O_CREAT|os.O_EXCL|os.O_WRONLY|os.O_NOFOLLOW,0o600);os.write(fd,encode({"nonce":nonce,"handoff_sha256":sha},4096));os.fsync(fd);os.close(fd)
    except BaseException:
        # No Docker mutation occurred. Keep own lock for explicit provenance review.
        raise
    result={"status":"INCOMPLETE","nonce":nonce,"source_commit":cfg["source_commit"],"handoff_sha256":sha,"scope":"diagnostic-corsad-churn512","measurement_qualified":False,
            "preparation_costs":{"secret_preparer":"UNKNOWN","topology_helper":"UNKNOWN"},"process_rss":"UNKNOWN"}
    service=driver=None
    def create(role,service_id=None,relay=None,netns=None):
        ident=engine.command(argv(role,nonce,names,service_id,cfg["files"]["corsad"]["sha256"],relay,netns),work,mutation=True).decode().strip()
        need(hex_value(ident,64),"created-container-id");ids.append(ident)
        verify_created(engine.inspect(ident,work),role,nonce,names,service_id,cfg["files"]["corsad"]["sha256"],relay,netns)
        return ident
    try:
        image=strict_json(engine.command(["image","inspect","--format","{{json .}}",IMAGE],work))
        need(image["Id"]==IMAGE and image["Os"]=="linux" and image["Architecture"]=="arm64" and image["Config"].get("Volumes") in (None,{}),"image-platform")
        for role,name in names.items():
            need(not engine.command(["volume","ls","--filter","name="+name,"--format","{{.Name}}"],work).strip(),"fresh-volume")
            volumes.append(name)
            args=["volume","create","--driver=local","--label","corsa.sg32.owner="+nonce,"--label","corsa.sg32.role="+role]
            if role=="secret":args += ["--opt","type=tmpfs","--opt","device=tmpfs","--opt","o=size=1048576,mode=0700"]
            engine.command(args+[name],work,mutation=True)
            meta=strict_json(engine.command(["volume","inspect","--format","{{json .}}",name],work))
            options={"type":"tmpfs","device":"tmpfs","o":"size=1048576,mode=0700"} if role=="secret" else {}
            need(meta["Name"]==name and meta["Driver"]=="local" and (meta.get("Options") or {})==options and meta["Labels"].get("corsa.sg32.owner")==nonce and meta["Labels"].get("corsa.sg32.role")==role,"actual-volume")
        prep_id=create("preparer")
        manifest={"nonce":nonce,"files":{name:{"sha256":row["sha256"],"bytes":row["bytes"]} for name,row in cfg["files"].items()}}
        engine.put("inputs-manifest.json",manifest)
        for name,row in cfg["files"].items():
            need(digest(read_owned(row["path"],128*1024**2))==row["sha256"],"input-before-upload")
            engine.command(["cp",row["path"],prep_id+":/inputs/"+name],work,mutation=True)
            need(digest(read_owned(row["path"],128*1024**2))==row["sha256"],"input-after-upload")
        engine.command(["cp",str(engine.root/"inputs-manifest.json"),prep_id+":/inputs/manifest.json"],work,mutation=True)
        prep_limit=min(work,origin+20)
        prep=old.Child(engine,["start","-a","-i",prep_id],"control",True);prep.send(encode(manifest,8192))
        engine.pump_until(lambda:old.handoff_packet(prep,"PREPARED",nonce) is not None or prep.done(),prep_limit)
        need(prep.records(True)==[{"kind":"PREPARED","nonce":nonce,"files":manifest["files"],"credential":{"mode":384,"uid":501,"gid":20,"nlink":1},"state_children":["data","home","tmp"]}] and prep.p.poll() is None and not prep.err,"prepared-receipt")
        service_id=create("service");service=old.Child(engine,["start","-a","-i",service_id],"service",True)
        engine.pump_until(lambda:old.handoff_packet(service,"SECRET_ATTACHED",nonce) is not None or service.done() or prep.done(),prep_limit)
        attached=old.handoff_packet(service,"SECRET_ATTACHED",nonce)
        need(type(attached) is dict and attached.keys()=={"kind","nonce","netns","network"} and re.fullmatch(r"net:\[[1-9][0-9]*\]",attached["netns"]) and service.records(True)==[attached] and not service.err and service.p.poll() is None and prep.p.poll() is None,"secret-attached")
        network_before=network_view(attached["network"],0)
        need(network_before["netns"]==attached["netns"],"waiting-network-ns")
        prep.send(encode({"kind":"RELEASE","nonce":nonce},4096));prep.finish_input()
        engine.pump_until(prep.done,prep_limit);need(prep.p.returncode==0 and not prep.err,"preparer-cli-normal")
        terminal(engine.inspect(prep_id,prep_limit));engine.command(["rm",prep_id],prep_limit,mutation=True)
        need(not engine.command(["ps","-aq","--no-trunc","--filter","id="+prep_id],prep_limit).strip(),"preparer-absent")
        running(engine.inspect(service_id,work))
        topo_limit=min(work,origin+45,time.monotonic()+20)
        topology_id=create("topology",service_id,netns=attached["netns"])
        topology=old.Child(engine,["start","-a",topology_id],"control")
        engine.pump_until(topology.done,topo_limit)
        raw_topology=bytes(topology.out)
        need(topology.p.returncode==0 and not topology.err and raw_topology.startswith(b"D1_CHURN512_TOPOLOGY_READY ") and raw_topology.count(b"\n")==1 and raw_topology.endswith(b"\n"),"topology-execution")
        proof=strict_json(raw_topology.split(b" ",1)[1])
        need(proof=={"contract":netprofile.CONTRACT,"profile_sha256":netprofile.PROFILE_SHA,"sources":768,"netns":attached["netns"],
             "indices":network_before["indices"],"permanent_addresses":network_before["permanent_addresses"]},"topology-identity-readback")
        terminal(engine.inspect(topology_id,topo_limit));engine.command(["rm",topology_id],topo_limit,mutation=True)
        need(not engine.command(["ps","-aq","--no-trunc","--filter","id="+topology_id],topo_limit).strip(),"topology-absent")
        need(service.records(True)==[attached] and service.p.poll() is None and not service.err,"service-stayed-waiting")
        running(engine.inspect(service_id,work))
        service.send(encode({"kind":"NETWORK_CHECK","nonce":nonce,"netns":attached["netns"]},4096))
        engine.pump_until(lambda:old.find_record(service,"NETWORK_POST",nonce) is not None or service.done(),min(work,origin+45))
        network_post=old.find_record(service,"NETWORK_POST",nonce)
        need(network_post is not None and service.p.poll() is None and not service.err,"post-helper-network-ack")
        network_view(network_post["network"],768,network_before)
        service.send(encode({"kind":"CONTINUE","nonce":nonce,"netns":attached["netns"],"network_identity":network_before["link_identity_sha256"]},4096))
        engine.pump_until(lambda:old.find_record(service,"READY",nonce) is not None or service.done(),min(work,origin+45))
        ready=old.find_record(service,"READY",nonce);need(ready is not None and hex_value(ready.get("identity"),40) and service.p.poll() is None,"service-ready")
        need(work-time.monotonic()>=135,"remaining-driver-and-reap-budget")
        driver_id=create("driver",service_id,relay=ready["identity"]);driver=old.Child(engine,["start","-a",driver_id],"driver")
        driver_deadline=min(work-15,origin+165)
        for phase,_,_ in PHASES:
            marker=re.compile(rb"\bD1_CHURN512_PHASE "+phase.encode()+rb" (\[.*\])\n")
            engine.pump_until(lambda:marker.search(bytes(driver.out)) is not None or driver.done() or service.done(),driver_deadline)
            need(marker.search(bytes(driver.out)) is not None and service.p.poll() is None,"driver-phase")
            service.send(encode({"kind":"CHECK","nonce":nonce,"phase":phase},4096))
            engine.pump_until(lambda:any(x.get("kind")=="STATE_CHECK" and x.get("phase")==phase for x in service.records()) or service.done(),driver_deadline)
            need(service.p.poll() is None,"state-check-service-exit")
        engine.pump_until(lambda:driver.done() or service.done(),driver_deadline)
        need(driver.done() and driver.p.returncode==0 and service.p.poll() is None and not driver.err,"driver-exit")
        output=bytes(driver.out).decode();groups,answers=validate_driver(output)
        need(re.search(r"^--- PASS: TestD1Churn512ExternalProcess \(",output,re.M) and re.search(r"^PASS$",output,re.M) and "SKIP" not in output and "FAIL" not in output,"driver-go-pass")
        result["useful_work"]={"distinct_identities":len(groups["initial"]|groups["replacement"]),"signed_answers":{name:len(rows) for name,rows in answers.items()}}
        result["driver_measurement"]=driver_measurement(output,nonce,network_before)
        logs,stderr=service_logs(service);result["membership"]=validate_service(logs,groups)
        intake=re.findall(r"^D1_CHURN512_INTAKE (\{.*\})$",logs,re.M);need(intake,"intake-missing")
        counters=strict_json(intake[-1]);need(all(counters[k]==896 for k in ("Offered","Committed","Taken","Answered")) and all(counters[k]==0 for k in ("Refused","Replaced","Violations")) and counters["Saturated"] is False,"intake-final")
        service.send(encode({"kind":"STOP","nonce":nonce},4096));service.finish_input()
        engine.pump_until(service.done,work);need(service.p.returncode==0 and not service.err,"service-normal-exit")
        result["measurement"]=verify_measurement(service.records(True),nonce,cfg["files"]["corsad"]["sha256"])
        terminal(engine.inspect(service_id,work));terminal(engine.inspect(driver_id,work))
        result.update(status="SCOPED_SUCCESS",measurement_qualified=True)
    except BaseException as error:
        result["error"]={"type":type(error).__name__,"reason":str(error)[:160]}
    finally:
        result["streams"]={role:{"eof":child.done(),"exit":child.p.poll(),"raw_prefix":"child-"+str(child.number),
            "stdout_retained":len(child.out),"stderr_retained":len(child.err),
            "stdout_sha256":digest(bytes(child.out)),"stderr_sha256":digest(bytes(child.err))} for role,child in (("service",service),("driver",driver)) if child is not None}
        closed=old.cleanup(engine,nonce,ids,volumes,end)
        result["physical_closure"]="KNOWN" if closed else "UNKNOWN"
        if not closed:result.update(status="RECOVERY_REQUIRED",measurement_qualified=False)
        if engine.output_failed:result.update(status="INCOMPLETE" if closed else "RECOVERY_REQUIRED",measurement_qualified=False)
        engine.put("commands.json",engine.commands);engine.put("result.json",result)
        if closed and custody==lock_custody(old.LOCK) and (old.LOCK/"owner").read_bytes()==owner and list(old.LOCK.iterdir())==[old.LOCK/"owner"]:
            (old.LOCK/"owner").unlink();old.LOCK.rmdir()
        else:
            print(json.dumps({"status":"RECOVERY_REQUIRED","run":str(engine.root)}),flush=True)
            while True:time.sleep(3600)
    print(json.dumps({"status":result["status"],"run":str(engine.root)}),flush=True)
    return 0 if result["measurement_qualified"] else 2


if __name__=="__main__":
    parser=argparse.ArgumentParser();parser.add_argument("handoff");mode=parser.add_mutually_exclusive_group(required=True)
    mode.add_argument("--run",metavar="SHA256");mode.add_argument("--check",metavar="SHA256")
    options=parser.parse_args()
    if options.check:
        read_handoff(options.handoff,options.check);print(options.check)
    else:raise SystemExit(run(options.handoff,options.run))
