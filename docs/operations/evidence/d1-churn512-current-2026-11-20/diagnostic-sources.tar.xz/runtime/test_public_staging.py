"""Small filesystem fixtures only; no subprocess/Docker/ELF execution."""
import copy
import hashlib
import os
from pathlib import Path
import stat
from tempfile import TemporaryDirectory
import unittest
from unittest.mock import patch

import stage_public_inputs as stage


class PublicStagingTests(unittest.TestCase):
    def fixture(self,root):
        root=Path(root);root.chmod(0o700);source=root/"source";source.mkdir(mode=0o700)
        files={}
        for name in stage.NAMES:
            path=source/name;raw=("public-fixture-"+name).encode();path.write_bytes(raw);path.chmod(0o700)
            files[name]={"path":str(path),"sha256":hashlib.sha256(raw).hexdigest(),"bytes":len(raw)}
        return files

    def test_public_copies_exact_and_original_modes_preserved(self):
        with TemporaryDirectory() as root:
            files=self.fixture(root);before={name:stage.stamp(Path(row["path"]).lstat()) for name,row in files.items()}
            proof=stage.stage_inputs(files,Path(root)/"public-inputs")
            self.assertEqual(set(proof),set(stage.NAMES))
            for name,row in files.items():
                copy=Path(proof[name]["path"]);self.assertEqual(copy.read_bytes(),Path(row["path"]).read_bytes())
                self.assertEqual(stat.S_IMODE(copy.stat().st_mode),0o444);self.assertEqual(copy.stat().st_uid,501)
                self.assertEqual(copy.stat().st_nlink,1);self.assertNotEqual(copy.stat().st_ino,Path(row["path"]).stat().st_ino)
                self.assertEqual(stage.stamp(Path(row["path"]).lstat()),before[name])
            self.assertEqual(stat.S_IMODE((Path(root)/"public-inputs").stat().st_mode),0o700)

    def test_unknown_secret_missing_and_oversize_refused_before_stage(self):
        for mode in ("secret","missing","oversize","bool"):
            with self.subTest(mode=mode),TemporaryDirectory() as root:
                files=self.fixture(root)
                if mode=="secret":files["auth.json"]=dict(files["worker.py"])
                elif mode=="missing":del files["topology"]
                elif mode=="oversize":files["topology"]["bytes"]=stage.LIMITS["topology"]+1
                else:files["topology"]["bytes"]=True
                with self.assertRaises(ValueError):stage.stage_inputs(files,Path(root)/"public-inputs")
                self.assertFalse((Path(root)/"public-inputs").exists())

    def test_symlink_hardlink_digest_and_writable_source_refused(self):
        for mode in ("symlink","hardlink","digest","writable"):
            with self.subTest(mode=mode),TemporaryDirectory() as root:
                files=self.fixture(root);path=Path(files["corsad"]["path"])
                if mode=="symlink":saved=path.with_name("saved");path.rename(saved);path.symlink_to(saved)
                elif mode=="hardlink":os.link(path,path.with_name("linked"))
                elif mode=="digest":files["corsad"]["sha256"]="0"*64
                else:path.chmod(0o722)
                with self.assertRaises((ValueError,OSError)):stage.stage_inputs(files,Path(root)/"public-inputs")

    def test_existing_stage_directory_or_symlink_is_never_reused(self):
        for symlink in (False,True):
            with self.subTest(symlink=symlink),TemporaryDirectory() as root:
                files=self.fixture(root);destination=Path(root)/"public-inputs"
                if symlink:destination.symlink_to(Path(root)/"source",target_is_directory=True)
                else:destination.mkdir()
                with self.assertRaises(FileExistsError):stage.stage_inputs(files,destination)

    def test_no_new_output_can_replace_preexisting_entry(self):
        with TemporaryDirectory() as root:
            files=self.fixture(root);original=stage.read_source;destination=Path(root)/"public-inputs"
            def inject(path,row,limit):
                raw,identity=original(path,row,limit)
                if path==files["corsad"]["path"]:(destination/"corsad").write_bytes(b"existing")
                return raw,identity
            with patch.object(stage,"read_source",side_effect=inject),self.assertRaises(FileExistsError):stage.stage_inputs(files,destination)
            self.assertEqual((destination/"corsad").read_bytes(),b"existing")


if __name__=="__main__":unittest.main()
