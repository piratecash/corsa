"""Root invocation only: same frozen host entry, own process group and import path."""
import os,runpy,sys
from pathlib import Path
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
if os.getpid()!=os.getpgrp():os.setsid()
sys.argv=[str(HERE/"host.py"),*sys.argv[1:]]
runpy.run_path(str(HERE/"host.py"),run_name="__main__")
