import json
import re

PHASES = [("initial", 512, 256), ("survivors", 256, 128), ("replacement", 512, 512), ("closed", 0, 0)]


def require(condition, message):
    if not condition:
        raise ValueError(message)


def validate_driver(output):
    groups, answers, next_id = {}, {}, 41
    phase = None
    for line in output.splitlines():
        marker = re.search(r"\bD1_CHURN512_PHASE (\w+) (\[.*\])$", line)
        result = re.search(r"\bD1_CHURN512_ANSWER (\d+) ([0-9a-f]{40}) ([0-9a-f]{40})$", line)
        if marker:
            phase, values = marker[1], json.loads(marker[2])
            require(phase not in groups and len(groups) < len(PHASES), "duplicate or excess driver phase")
            name, size, _ = PHASES[len(groups)]
            require(name == phase and len(values) == size and len(set(values)) == size, "wrong driver population")
            require(all(re.fullmatch(r"[0-9a-f]{40}", x) for x in values), "invalid driver identity")
            groups[phase] = set(values)
            answers[phase] = []
        if result:
            require(phase is not None and int(result[1]) == next_id, "missing or extra lookup ID")
            source, target = result[2], result[3]
            require(source != target and {source, target} <= groups[phase], "lookup outside its live population")
            answers[phase].append((source, target))
            next_id += 1
    require(list(groups) == [name for name, _, _ in PHASES], "missing phase")
    require(all(len(answers[name]) == count for name, _, count in PHASES), "incomplete verified answers")
    require(groups["initial"] & groups["replacement"] == groups["survivors"], "wrong retained identities")
    new = groups["replacement"] - groups["survivors"]
    for name, slots in (("initial", groups["initial"]), ("survivors", groups["survivors"])):
        endpoints = [peer for edge in answers[name] for peer in edge]
        require(len(set(endpoints)) == len(endpoints) and set(endpoints) == slots,
                f"{name}: every peer must appear in exactly one useful lookup")
    sources, targets = (set(side) for side in zip(*answers["replacement"]))
    require(len(new) == 256 and sources == targets == groups["replacement"],
            "replacement peers must all send and receive verified lookups")
    history={target for phase in answers.values() for _,target in phase}
    require(history==groups["replacement"] and len(history)==512, "target history must stay within 512 identities")
    return groups, answers


def validate_service(output, groups):
    matched, used_connections = {}, set()
    next_phase = 0
    for line in output.splitlines():
        if not line.startswith("D1_CHURN512_MEMBERS ") or next_phase == len(PHASES):
            continue
        snapshot = json.loads(line.removeprefix("D1_CHURN512_MEMBERS "))
        name, size, _ = PHASES[next_phase]
        if not (snapshot["MembershipComplete"] and snapshot["ActiveCount"] == snapshot["F1Count"] == size
                and snapshot["RegistryVisits"] == size):
            continue
        require(type(snapshot["Rows"]) is list and len(snapshot["Rows"]) == 512,
                "incomplete fixed membership rows")
        rows = snapshot["Rows"][:size]
        require(all(row.get("PublishedF1") is True for row in rows) and
                all(row == {"Identity": "", "ConnID": 0, "PublishedF1": False}
                    for row in snapshot["Rows"][size:]),
                "unaccounted membership rows outside complete roster")
        active = {row["Identity"]: row["ConnID"] for row in rows if row["PublishedF1"]}
        if set(active) != groups[name]:
            continue
        require(len(set(active.values())) == size and all(type(x) is int and x > 0 for x in active.values()),
                "invalid original connection witness")
        survivors = groups["survivors"]
        if name in ("survivors", "replacement"):
            require(all(matched["initial"][peer] == active[peer] for peer in survivors), "survivor ConnID changed")
        if name == "replacement":
            require(all(active[peer] not in used_connections for peer in groups[name] - survivors),
                    "replacement reused an original ConnID")
        matched[name] = active
        used_connections.update(active.values())
        next_phase += 1
    require(next_phase == len(PHASES), f"missing service membership witness for {PHASES[next_phase][0] if next_phase < len(PHASES) else 'none'}")
    return matched
