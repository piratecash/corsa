"""Canonical nine-input preparer integration; pure fixtures, no resources."""
import json
from pathlib import Path
import sys
import unittest
from unittest.mock import patch

sys.path.insert(0,str(Path(__file__).resolve().parent/"canonical"))
import sg32_service as service
import worker
from sg32_common import Fault, static_elf

NAMES=("corsad","c2driver","topology","worker.py","netprofile.py","network-profile.json",
       "sg32_common.py","sg32_service.py","clockprobe.py")
NONCE="a"*32


def actual_manifest():
    handoff=json.loads((Path(__file__).resolve().parent/"HANDOFF.PREPARED-NOT-ADMITTED.json").read_text())
    return {"nonce":NONCE,"files":{name:{"sha256":row["sha256"],"bytes":row["bytes"]}
                                    for name,row in handoff["files"].items()}}


class CanonicalPreparerManifestTests(unittest.TestCase):
    def test_actual_nine_entry_manifest_and_large_helper_accepted(self):
        value=actual_manifest()
        self.assertEqual(tuple(service.INPUTS),NAMES)
        self.assertEqual(tuple(worker.INPUTS),NAMES)
        self.assertEqual(set(service.INPUT_LIMITS),set(NAMES))
        self.assertEqual(value["files"]["topology"]["bytes"],4824804)
        self.assertIs(service.manifest(value,NONCE),value)

    def test_unknown_missing_and_manifest_shape_refused(self):
        for mode in ("unknown","missing","extra-entry-field","wrong-nonce","boolean-size"):
            value=actual_manifest()
            if mode=="unknown":value["files"]["unknown.py"]=value["files"].pop("worker.py")
            elif mode=="missing":del value["files"]["topology"]
            elif mode=="extra-entry-field":value["files"]["topology"]["kind"]="ELF"
            elif mode=="wrong-nonce":value["nonce"]="b"*32
            else:value["files"]["topology"]["bytes"]=True
            with self.subTest(mode=mode),self.assertRaises(Fault):service.manifest(value,NONCE)

    def test_exact_per_input_limits_and_oversize_refused(self):
        for name in NAMES:
            limit=256*1024*1024 if name in ("corsad","c2driver") else 16*1024*1024 if name=="topology" else 65536
            self.assertEqual(service.INPUT_LIMITS[name],limit)
            value=actual_manifest();value["files"][name]["bytes"]=limit
            self.assertIs(service.manifest(value,NONCE),value)
            for size in (0,-1,limit+1):
                value=actual_manifest();value["files"][name]["bytes"]=size
                with self.subTest(name=name,size=size),self.assertRaises(Fault):service.manifest(value,NONCE)

    def test_all_nine_fixed_paths_call_original_operation(self):
        expected={"/inputs":"inputs","/run/c1":"secret-dir","/work":"work",
                  "/inputs/manifest.json":"manifest","/run/c1/auth.json":"auth",
                  **{"/inputs/"+name:name for name in NAMES},
                  **{"/work/"+name:name for name in ("data","home","tmp")},None:None}
        self.assertEqual(service.PREPARER_PATHS,expected)
        for name in NAMES:
            calls=[]
            with patch.object(service.os,"lstat",side_effect=FileNotFoundError(2,"fixture")):
                result=service.preparer_call("open","/inputs/"+name,lambda:calls.append(name) or name)
            self.assertEqual(result,name);self.assertEqual(calls,[name])
        calls=[]
        with self.assertRaises(Fault):service.preparer_call("open","/inputs/unknown.py",lambda:calls.append(1))
        self.assertEqual(calls,[])

    def test_text_cannot_pass_existing_host_elf_guard(self):
        for name in ("corsad","c2driver","topology"):
            with self.subTest(name=name),self.assertRaises(Fault):static_elf(b"text is not an ELF"*8)


if __name__=="__main__":unittest.main()
