"""Pure failure controls; no subprocess, Docker, VM or applications."""
import copy
import json
import os
from pathlib import Path
from tempfile import TemporaryDirectory
from types import SimpleNamespace
import time
import unittest

import host
from sg32_common import Fault

NONCE="a"*32
SERVICE="b"*64
CLI="c"*64
RELAY="d"*40
NETNS="net:[4026533000]"


class CustodyTests(unittest.TestCase):
    def test_reading_owner_does_not_change_custody(self):
        with TemporaryDirectory() as directory:
            lock=Path(directory)/"lock";lock.mkdir(mode=0o700)
            owner=lock/"owner";owner.write_bytes(b"own-controller\n")
            # Make a normal access-time update eligible before capturing custody.
            info=owner.stat();os.utime(owner,ns=(info.st_mtime_ns-2*86400*10**9,info.st_mtime_ns))
            before=host.lock_custody(lock)
            self.assertEqual(owner.read_bytes(),b"own-controller\n");list(lock.iterdir())
            self.assertEqual(before,host.lock_custody(lock))

    def test_only_atime_is_excluded(self):
        fields={"st_dev":1,"st_ino":2,"st_uid":501,"st_gid":20,"st_mode":0o100600,
                "st_size":12,"st_mtime_ns":100,"st_ctime_ns":101,"st_atime_ns":102}
        before=host.custody_stamp(SimpleNamespace(**fields))
        changed=dict(fields,st_atime_ns=999)
        self.assertEqual(before,host.custody_stamp(SimpleNamespace(**changed)))
        for name in fields.keys()-{"st_atime_ns"}:
            changed=dict(fields);changed[name]+=1
            with self.subTest(field=name):self.assertNotEqual(before,host.custody_stamp(SimpleNamespace(**changed)))

    def test_replaced_owner_inode_or_symlink_refuses(self):
        with TemporaryDirectory() as directory:
            lock=Path(directory)/"lock";lock.mkdir();owner=lock/"owner";owner.write_bytes(b"same")
            before=host.lock_custody(lock);replacement=lock/"replacement";replacement.write_bytes(b"same");replacement.replace(owner)
            self.assertNotEqual(before,host.lock_custody(lock))
            before=host.lock_custody(lock);owner.rename(lock/"saved");owner.symlink_to("saved")
            self.assertNotEqual(before,host.lock_custody(lock))


def metadata(role):
    cpu,memory,pids=host.old.ROLE_LIMITS[role]
    source=host.old.volume_names(NONCE)
    config={"User":"0:0" if role in ("preparer","topology") else "501:20",
            "Labels":{"corsa.sg32.owner":NONCE,"corsa.sg32.role":role}}
    h={"NanoCpus":cpu,"Memory":memory,"MemorySwap":memory,"PidsLimit":pids,"Privileged":False,
       "ReadonlyRootfs":True,"CapDrop":["ALL"],"CapAdd":["CHOWN"] if role=="preparer" else ["NET_ADMIN"] if role=="topology" else [],
       "SecurityOpt":["no-new-privileges"],"RestartPolicy":{"Name":"no"},"NetworkMode":"container:"+SERVICE if role in ("driver","topology") else "none",
       "CgroupnsMode":"private","PidMode":"","Binds":None,"PortBindings":{},"Devices":[],"DeviceRequests":None}
    mounts=[{"Type":"volume","Destination":"/inputs","Name":source["inputs"],"RW":role=="preparer"}]
    if role!="topology":mounts.append({"Type":"volume","Destination":"/run/c1","Name":source["secret"],"RW":role=="preparer"})
    if role in ("preparer","service"):mounts.append({"Type":"volume","Destination":"/work","Name":source["state"],"RW":True})
    if role=="topology":config.update(Entrypoint=["/inputs/topology"],Cmd=None,Env=["D1_CHURN512_EXPECTED_NETNS="+NETNS])
    else:
        tail=["preparer" if role=="preparer" else "keeper" if role=="service" else "driver",NONCE]
        if role=="service":tail.append(CLI)
        if role=="driver":tail.append(RELAY)
        config.update(Entrypoint=["/usr/bin/python3"],Cmd=["-I","-S","-B","-c",host.BOOTSTRAP,*tail])
    if role=="driver":
        h["Tmpfs"]={"/tmp":"rw,size=16777216,mode=0700,uid=501,gid=20"}
        h["Ulimits"]=[{"Name":"nofile","Hard":4096,"Soft":4096}]
        mounts.append({"Type":"tmpfs","Destination":"/tmp","RW":True})
    return {"Image":host.IMAGE,"Name":"/corsa-d1-sg32-"+NONCE+"-"+role,"Config":config,"HostConfig":h,"Mounts":mounts,"State":{"Running":False}}


def facts(index,members,memory=512000000,pids=64):
    return {"before_ns":index*100000000,"after_ns":index*100000000+1,"files":{name:[1,i+2] for i,name in enumerate(sorted(host.CGFILES))},"netns":NETNS,
            "values":{"memory.max":memory,"memory.swap.max":0,"pids.max":pids,"cpu.max":"100000 100000",
                      "memory.current":90000,"pids.current":len(members),"memory.peak":100000+index,"cpu.stat":{"usage_usec":index},"memory.events":{"max":0,"oom":0,"oom_kill":0},
                      "pids.events":{"max":0},"cgroup.procs":members}}


def network_views():
    raw=json.loads(Path(__file__).with_name("inventory.fixture.json").read_text())
    raw["netns"]=NETNS
    before=host.netprofile.validate(raw,0)
    after=copy.deepcopy(before);after.update(aliases=768,addresses_v4=769,routes_v4=771)
    return before,after


def record(rows,kind):return next(x for x in rows if x["kind"]==kind)


def service_records():
    before,after=network_views()
    node={"pid":3,"ppid":1,"start_ticks":123}
    return [
        {"kind":"SECRET_ATTACHED","nonce":NONCE,"netns":NETNS,"network":before},
        {"kind":"NETWORK_POST","nonce":NONCE,"network":after},
        {"kind":"NETWORK_CONTINUED","nonce":NONCE,"network":after},
        {"kind":"INITIAL","nonce":NONCE,"facts":facts(1,[1])},
        {"kind":"SAMPLER_READY","nonce":NONCE,"pid":2,"network":after,"facts":facts(2,[1,2])},
        {"kind":"NODE_BOUND","nonce":NONCE,"node":node,"exe_sha256":CLI},
        {"kind":"READY","nonce":NONCE,"node":node},
        {"kind":"SAMPLE","nonce":NONCE,"ordinal":0,"facts":facts(3,[1,2,3])},
        *[{"kind":"STATE_CHECK","nonce":NONCE,"phase":phase,"bytes":123,"network":after} for phase,_,_ in host.PHASES],
        {"kind":"STOPPING_ACK","nonce":NONCE,"node":node},
        {"kind":"NODE_REAP","nonce":NONCE,"node":node,"exit":0},
        {"kind":"SAMPLER_FINAL","nonce":NONCE,"node_reaped":node,"ordinal":1,"network":after,"facts":facts(4,[1,2])},
        {"kind":"FINAL","nonce":NONCE,"network":after,"facts":facts(5,[1]),"node_exit":0,"sampler_exit":0,"bytes":123,
         "checked_phases":[phase for phase,_,_ in host.PHASES],"keeper_exit_tail":"UNKNOWN","shared_page_attribution":"UNKNOWN"},
    ]


class MetadataTests(unittest.TestCase):
    def verify(self,value,role):
        host.verify_created(value,role,NONCE,host.old.volume_names(NONCE),SERVICE,CLI,RELAY,NETNS)

    def test_all_four_exact_roles(self):
        for role in ("preparer","service","driver","topology"):
            with self.subTest(role=role):self.verify(metadata(role),role)

    def test_topology_changes_refuse(self):
        for key,value in [("CapAdd",["NET_ADMIN","CHOWN"]),("NetworkMode","host"),("MemorySwap",268435456),
                          ("Privileged",True),("PidsLimit",64),("ReadonlyRootfs",False),("Binds",["/tmp:/host"])]:
            with self.subTest(field=key):
                item=metadata("topology");item["HostConfig"][key]=value
                with self.assertRaises(Fault):self.verify(item,"topology")

    def test_secret_preparer_cannot_gain_net_admin(self):
        item=metadata("preparer");item["HostConfig"]["CapAdd"]=["CHOWN","NET_ADMIN"]
        with self.assertRaises(Fault):self.verify(item,"preparer")

    def test_driver_budget_mount_owner_command_refuse(self):
        for change in (lambda m:m["Config"]["Labels"].update({"corsa.sg32.owner":"e"*32}),
                       lambda m:m["Config"].update(Cmd=["/bin/sh"]),
                       lambda m:m["HostConfig"].update(Memory=512000000),
                       lambda m:m["Mounts"].append({"Type":"bind","Destination":"/host","RW":True}),
                       lambda m:m["HostConfig"].update(Ulimits=[])):
            value=metadata("driver");change(value)
            with self.assertRaises(Fault):self.verify(value,"driver")

    def test_topology_argv_has_no_secret_mount_or_extra_capability(self):
        values=host.argv("topology",NONCE,host.old.volume_names(NONCE),SERVICE,CLI,RELAY,NETNS)
        self.assertEqual([x for x in values if x.startswith("--cap-add=")],["--cap-add=NET_ADMIN"])
        self.assertEqual(sum(x=="--mount" for x in values),1)
        self.assertFalse(any("/run/c1" in x or "target=/work" in x for x in values))

    def test_oom_or_unreaped_terminal_refuses(self):
        for value in ({"Running":False,"Status":"exited","ExitCode":0,"OOMKilled":True,"Pid":0},
                      {"Running":False,"Status":"exited","ExitCode":0,"OOMKilled":False,"Pid":123}):
            with self.assertRaises(Fault):host.terminal({"State":value})

    def test_waiting_service_must_still_run_before_continue(self):
        host.running({"State":{"Running":True,"Status":"running","OOMKilled":False,"Pid":123}})
        for value in ({"Running":False,"Status":"exited","OOMKilled":False,"Pid":0},
                      {"Running":True,"Status":"running","OOMKilled":True,"Pid":123}):
            with self.assertRaises(Fault):host.running({"State":value})

    def test_foreign_cleanup_owner_is_never_removed(self):
        class FakeEngine:
            uncertain=False
            def __init__(self):self.removals=[]
            def command(self,args,deadline,mutation=False):
                if args[0]=="ps":return (SERVICE+"\n").encode()
                if args[0]=="rm":self.removals.append(args)
                return b""
            def inspect(self,ident,deadline):
                item=metadata("topology");item["Config"]["Labels"]["corsa.sg32.owner"]="e"*32;return item
            def close_children(self,deadline):return True
        engine=FakeEngine()
        self.assertFalse(host.old.cleanup(engine,NONCE,[SERVICE],[],time.monotonic()+1))
        self.assertEqual(engine.removals,[])

    def test_unknown_docker_mutation_requires_recovery_even_if_queries_empty(self):
        class FakeEngine:
            uncertain=True
            def command(self,*args,**kwargs):return b""
            def close_children(self,deadline):return True
        self.assertFalse(host.old.cleanup(FakeEngine(),NONCE,[],[],time.monotonic()+1))


class MeasurementTests(unittest.TestCase):
    def test_network_identity_change_after_helper_refuses(self):
        rows=service_records();post=copy.deepcopy(record(rows,"NETWORK_POST")["network"])
        mac=bytearray.fromhex(post["permanent_addresses"]["ip6gre0"]);mac[0]^=4
        post["permanent_addresses"]["ip6gre0"]=mac.hex()
        stable={k:post[k] for k in ("contract","profile_sha256","netns","indices","permanent_addresses")}
        post["link_identity_sha256"]=host.netprofile.digest(stable)
        record(rows,"NETWORK_POST")["network"]=post
        with self.assertRaises(Fault):host.verify_measurement(rows,NONCE,CLI)

    def test_post_ack_must_precede_continue_and_apps(self):
        rows=service_records();rows[1],rows[2]=rows[2],rows[1]
        with self.assertRaises(Fault):host.verify_measurement(rows,NONCE,CLI)

    def test_unrecognized_network_control_refuses(self):
        rows=service_records();rows.insert(1,{"kind":"NETWORK_UNQUALIFIED","nonce":NONCE})
        with self.assertRaises(Fault):host.verify_measurement(rows,NONCE,CLI)

    def test_complete_window_without_subtraction(self):
        result=host.verify_measurement(service_records(),NONCE,CLI)
        self.assertEqual(result["service_peak_bytes"],100005)
        self.assertEqual(result["keeper_exit_tail"],"UNKNOWN")

    def test_missing_final_reap_or_phase_refuses(self):
        for kind in ("NETWORK_POST","NETWORK_CONTINUED","FINAL","SAMPLER_FINAL","NODE_REAP","STOPPING_ACK","STATE_CHECK"):
            rows=service_records();rows.pop(next(i for i,x in enumerate(rows) if x["kind"]==kind))
            with self.subTest(kind=kind),self.assertRaises(Fault):host.verify_measurement(rows,NONCE,CLI)

    def test_foreign_process_or_namespace_refuses(self):
        for change in (lambda r:record(r,"SAMPLE")["facts"]["values"].update({"cgroup.procs":[1,2,3,99]}),
                       lambda r:record(r,"SAMPLE")["facts"].update(netns="net:[1]"),
                       lambda r:record(r,"NODE_BOUND").update(exe_sha256="f"*64)):
            rows=service_records();change(rows)
            with self.assertRaises(Fault):host.verify_measurement(rows,NONCE,CLI)

    def test_sample_gap_or_counter_rollback_refuses(self):
        for change in (lambda r:record(r,"SAMPLE")["facts"].update(before_ns=3000000000,after_ns=3000000001),
                       lambda r:r[-1]["facts"]["values"].update({"memory.peak":1}),
                       lambda r:r[-1]["facts"]["values"]["memory.events"].update(oom=1)):
            rows=service_records();change(rows)
            with self.assertRaises(Fault):host.verify_measurement(rows,NONCE,CLI)

    def test_final_peak_with_sampler_still_present_refuses(self):
        rows=service_records();rows[-1]["facts"]["values"]["cgroup.procs"]=[1,2]
        with self.assertRaises(Fault):host.verify_measurement(rows,NONCE,CLI)

    def test_driver_final_required_and_separate(self):
        tmpfs={"netns":NETNS,"path":"/tmp","uid":501,"gid":20,"mode":448,"fstype":"tmpfs","mount_id":100,"device":"0:12","mountinfo_sha256":"a"*64,"capacity_bytes":16777216,"frsize":4096,"blocks":4096,"identity":[12,11]}
        packet={"kind":"DRIVER_FINAL","tmpfs":tmpfs,"nonce":NONCE,"test_exit":0,"network":network_views()[1],"facts":facts(4,[1],268435456,32)}
        self.assertEqual(host.driver_measurement(json.dumps({"kind":"DRIVER_TMPFS_READY","nonce":NONCE,"tmpfs":tmpfs})+"\n"+json.dumps(packet),NONCE)["driver_peak_bytes"],100004)
        for output in ("",json.dumps(packet)+"\n"+json.dumps(packet)):
            with self.assertRaises(Fault):host.driver_measurement(output,NONCE)


if __name__=="__main__":unittest.main()
