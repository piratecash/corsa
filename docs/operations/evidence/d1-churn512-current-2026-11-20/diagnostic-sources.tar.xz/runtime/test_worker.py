"""Actual Group.snapshot with fake file/clock boundaries; never opens real FDs."""
from pathlib import Path
import sys
import unittest
from unittest.mock import patch

sys.path.insert(0,str(Path(__file__).resolve().parent/"canonical"))
import worker
from sg32_common import Fault


class GroupReadbackTests(unittest.TestCase):
    def snapshot(self,changes=None):
        data={"memory.max":b"512000000\n","memory.swap.max":b"0\n","memory.peak":b"12345678\n",
              "memory.current":b"12000000\n","memory.events":b"low 0\nhigh 0\nmax 0\noom 0\noom_kill 0\n",
              "cpu.max":b"100000 100000\n","cpu.stat":b"usage_usec 50\n","pids.max":b"64\n",
              "pids.current":b"3\n","pids.events":b"max 0\n","cgroup.procs":b"1\n2\n3\n"}
        data.update(changes or {})
        group=worker.Group.__new__(worker.Group);group.memory=512000000;group.pids=64
        group.fds={name:i for i,name in enumerate(worker.CGFILES)}
        group.ids={name:[1,fd+10] for name,fd in group.fds.items()}
        reverse={fd:name for name,fd in group.fds.items()}
        with patch.object(worker.Group,"identity",side_effect=lambda fd:[1,fd+10]),patch.object(worker.os,"lseek"), \
             patch.object(worker.os,"read",side_effect=lambda fd,count:data[reverse[fd]]), \
             patch.object(worker,"namespace",return_value="net:[123]"):
            return group.snapshot()

    def test_complete_kernel_facts(self):
        facts=self.snapshot()
        self.assertEqual(facts["values"]["memory.peak"],12345678)
        self.assertEqual(set(facts["files"]),set(worker.CGFILES))

    def test_budget_oom_and_pid_refusal_are_fatal(self):
        for name,value in [("memory.max",b"1024000000\n"),("memory.swap.max",b"512000000\n"),
                           ("pids.max",b"128\n"),("memory.events",b"max 0\noom 1\noom_kill 0\n"),
                           ("pids.events",b"max 1\n"),("cpu.max",b"max 100000\n")]:
            with self.subTest(name=name),self.assertRaises(Fault):self.snapshot({name:value})

    def test_malformed_duplicate_or_oversized_reads_refuse(self):
        for name,value in [("memory.events",b"max 0\noom 0\noom 0\noom_kill 0\n"),
                           ("cgroup.procs",b"1\n1\n"),("memory.current",b"UNKNOWN\n"),
                           ("cpu.stat",b"x"*8193)]:
            with self.subTest(name=name),self.assertRaises(Fault):self.snapshot({name:value})


if __name__=="__main__":unittest.main()
