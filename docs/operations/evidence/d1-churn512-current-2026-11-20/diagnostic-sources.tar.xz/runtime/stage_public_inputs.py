"""Copy only nine SHA-bound PUBLIC inputs; never stage credentials or execute apps."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import stat

HERE=Path(__file__).resolve().parent
SOURCE_HANDOFF=HERE/"HANDOFF.PUBLIC-SOURCES.json"
SOURCE_HANDOFF_SHA="adee8bd82a905388649ce03364d069667895a94e5b04e3a29c25a11855e49cd5"
NAMES=("corsad","c2driver","topology","worker.py","netprofile.py","network-profile.json",
       "sg32_common.py","sg32_service.py","clockprobe.py")
LIMITS={name:128*1024**2 if name in ("corsad","c2driver") else 16*1024**2 if name=="topology" else 65536 for name in NAMES}


def need(value,reason):
    if not value:raise ValueError(reason)


def digest(raw):return hashlib.sha256(raw).hexdigest()


def stamp(info):
    # A bounded read may change atime, never original content or authority metadata.
    return tuple(getattr(info,key) for key in ("st_dev","st_ino","st_uid","st_gid","st_mode","st_nlink","st_size","st_mtime_ns","st_ctime_ns"))


def file_shape(info,limit):
    need(stat.S_ISREG(info.st_mode) and info.st_uid==501 and info.st_nlink==1 and
         not info.st_mode&0o022 and 0<info.st_size<=limit,"public-input-custody")


def read_source(path,expected,limit):
    fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW|os.O_CLOEXEC)
    try:
        before=os.fstat(fd);file_shape(before,limit)
        data=bytearray()
        while len(data)<=limit:
            part=os.read(fd,min(1024*1024,limit+1-len(data)))
            if not part:break
            data.extend(part)
        need(stamp(before)==stamp(os.fstat(fd))==stamp(Path(path).lstat()),"public-input-changed")
        need(len(data)==before.st_size==expected["bytes"] and digest(data)==expected["sha256"],"public-input-digest")
        return bytes(data),stamp(before)
    finally:os.close(fd)


def stage_inputs(files,destination):
    """No subprocess/network. Failure preserves partial own stage for diagnosis."""
    need(type(files) is dict and set(files)==set(NAMES),"exact-public-input-inventory")
    for name,row in files.items():
        need(type(row) is dict and set(row)=={"path","sha256","bytes"} and
             type(row["bytes"]) is int and 0<row["bytes"]<=LIMITS[name] and
             type(row["sha256"]) is str and len(row["sha256"])==64 and
             all(x in "0123456789abcdef" for x in row["sha256"]),"public-input-entry")
    destination=Path(destination)
    parent=destination.parent.lstat()
    need(stat.S_ISDIR(parent.st_mode) and parent.st_uid==501 and stat.S_IMODE(parent.st_mode)==0o700,"stage-parent-custody")
    destination.mkdir(mode=0o700) # Existing paths, including symlinks, must refuse.
    stage_fd=os.open(destination,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW|os.O_CLOEXEC)
    try:
        before=os.fstat(stage_fd)
        need(before.st_uid==501 and stat.S_IMODE(before.st_mode)==0o700,"stage-directory-custody")
        proof={}
        for name in NAMES:
            row=files[name];raw,original_stamp=read_source(row["path"],row,LIMITS[name])
            fd=os.open(name,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW|os.O_CLOEXEC,0o600,dir_fd=stage_fd)
            try:
                position=0
                while position<len(raw):
                    written=os.write(fd,raw[position:position+1024*1024]);need(written>0,"stage-short-write");position+=written
                os.fchmod(fd,0o444);os.fsync(fd)
                info=os.fstat(fd);file_shape(info,LIMITS[name])
                need(stat.S_IMODE(info.st_mode)==0o444 and info.st_size==row["bytes"],"stage-public-mode-size")
            finally:os.close(fd)
            staged=destination/name
            readback,staged_stamp=read_source(staged,row,LIMITS[name])
            need(readback==raw and original_stamp==stamp(Path(row["path"]).lstat()),"stage-or-source-changed")
            proof[name]={"path":str(staged.resolve()),"sha256":digest(readback),"bytes":len(readback),
                         "uid":info.st_uid,"gid":info.st_gid,"mode":stat.S_IMODE(info.st_mode),"nlink":info.st_nlink,
                         "original_path":row["path"],"original_stamp":list(original_stamp),"staged_stamp":list(staged_stamp)}
        need(set(os.listdir(stage_fd))==set(NAMES) and os.fstat(stage_fd).st_ino==before.st_ino and
             os.fstat(stage_fd).st_dev==before.st_dev and stamp(destination.lstat())==stamp(os.fstat(stage_fd)),"stage-directory-changed")
        os.fsync(stage_fd)
        return proof
    finally:os.close(stage_fd)


def main():
    parser=argparse.ArgumentParser();parser.add_argument("--stage",action="store_true",required=True);parser.parse_args()
    raw=SOURCE_HANDOFF.read_bytes();need(digest(raw)==SOURCE_HANDOFF_SHA,"frozen-public-source-handoff")
    source=json.loads(raw);target=json.loads((HERE/"HANDOFF.PREPARED-NOT-ADMITTED.json").read_bytes())
    need(set(source["files"])==set(target["files"])==set(NAMES),"handoff-public-inventory")
    for name in NAMES:
        need(all(target["files"][name][key]==source["files"][name][key] for key in ("sha256","bytes")) and
             target["files"][name]["path"]==str(HERE/"public-inputs"/name),"staged-target-binding")
    need(all(target.get(key) is False for key in ("inputs_ready","reviewer_accepted","tester_accepted")),"not-final-admitted")
    proof=stage_inputs(source["files"],HERE/"public-inputs")
    receipt={"status":"PUBLIC_INPUTS_STAGED","source_handoff_sha256":SOURCE_HANDOFF_SHA,
             "code_sha256":digest(Path(__file__).read_bytes()),"files":proof,"secrets_staged":False}
    fd=os.open(HERE/"STAGING-RESULT.json",os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
    with os.fdopen(fd,"w") as stream:json.dump(receipt,stream,indent=2);stream.write("\n");stream.flush();os.fsync(stream.fileno())
    print(json.dumps({"status":receipt["status"],"files":len(proof),"secrets_staged":False}))


if __name__=="__main__":main()
