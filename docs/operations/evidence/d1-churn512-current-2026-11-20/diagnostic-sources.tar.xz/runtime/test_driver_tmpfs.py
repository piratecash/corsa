"""Actual CREATED inspect and bounded fake-/tmp worker guards; no runtime resources."""
import copy
import json
import os
from pathlib import Path
import stat
from types import SimpleNamespace
import unittest
from unittest.mock import patch

import host
import worker
from sg32_common import Fault
from test_host import metadata,NONCE,SERVICE,CLI,RELAY,NETNS


class CreatedTmpfsTests(unittest.TestCase):
    def test_actual_created_inspect_without_materialized_tmpfs(self):
        meta=json.loads((Path(__file__).parent/"driver-created.fixture.json").read_text())
        nonce=meta["Config"]["Labels"]["corsa.sg32.owner"];service=meta["HostConfig"]["NetworkMode"].split(":",1)[1]
        host.verify_created(meta,"driver",nonce,host.old.volume_names(nonce),service,relay=meta["Config"]["Cmd"][-1])

    def test_created_omission_requires_exact_state_declaration_and_no_extra(self):
        for mode in ("decl-missing","decl-size","status","pid","extra","wrong-path","rw"):
            meta=metadata("driver");meta["State"].update(Status="created",Pid=0);meta["Mounts"]=[x for x in meta["Mounts"] if x["Type"]!="tmpfs"]
            if mode=="decl-missing":del meta["HostConfig"]["Tmpfs"]
            elif mode=="decl-size":meta["HostConfig"]["Tmpfs"]["/tmp"]="rw,size=33554432,mode=0700,uid=501,gid=20"
            elif mode=="status":meta["State"]["Status"]="exited"
            elif mode=="pid":meta["State"]["Pid"]=1
            elif mode=="extra":meta["Mounts"].append({"Type":"bind","Destination":"/other","RW":True})
            elif mode=="wrong-path":meta["Mounts"].append({"Type":"tmpfs","Destination":"/other","RW":True})
            else:meta["Mounts"].append({"Type":"tmpfs","Destination":"/tmp","RW":False})
            with self.subTest(mode=mode),self.assertRaises(Fault):host.verify_created(meta,"driver",NONCE,host.old.volume_names(NONCE),SERVICE,relay=RELAY)


class DriverTmpfsProofTests(unittest.TestCase):
    def proof(self,mode=None):
        dev=os.makedev(0,12)
        info=SimpleNamespace(st_mode=stat.S_IFDIR|0o700,st_uid=501,st_gid=20,st_dev=dev,st_ino=123)
        named=copy.copy(info)
        space=SimpleNamespace(f_frsize=4096,f_blocks=4096,f_flag=0)
        raw=b"100 90 0:12 / /tmp rw,nosuid,nodev - tmpfs tmpfs rw,size=16384k,uid=501,gid=20\n"
        if mode=="uid":info.st_uid=0
        elif mode=="gid":info.st_gid=0
        elif mode=="mode":info.st_mode=stat.S_IFDIR|0o777
        elif mode=="symlink":info.st_mode=stat.S_IFLNK|0o700
        elif mode=="fstype":raw=raw.replace(b"- tmpfs tmpfs",b"- overlay overlay")
        elif mode=="device":raw=raw.replace(b"0:12",b"0:13")
        elif mode=="duplicate":raw=raw+raw
        elif mode=="missing":raw=raw.replace(b"/tmp",b"/var")
        elif mode=="readonly":space.f_flag=os.ST_RDONLY
        elif mode=="oversize":space.f_blocks+=1
        elif mode=="zero":space.f_blocks=0
        elif mode=="changed":named.st_ino+=1
        elif mode=="mount-readonly":raw=raw.replace(b"/tmp rw",b"/tmp ro")
        elif mode=="root":raw=raw.replace(b"0:12 / /tmp",b"0:12 /sub /tmp")
        elif mode=="malformed":raw=b"x"*4097
        with patch.object(worker.os,"open",return_value=9) as opened,patch.object(worker.os,"close"), \
             patch.object(worker.os,"fstat",return_value=info),patch.object(worker.os,"lstat",return_value=named), \
             patch.object(worker.os,"fstatvfs",return_value=space),patch.object(worker.old.clockprobe,"read_file",return_value=raw), \
             patch.object(worker,"namespace",return_value=NETNS):
            value=worker.driver_tmpfs()
            self.assertEqual(opened.call_args[0][0],"/tmp")
            self.assertTrue(opened.call_args[0][1]&os.O_NOFOLLOW)
            return value

    def test_runtime_tmpfs_fd_mount_device_capacity(self):
        value=self.proof();self.assertEqual(value["capacity_bytes"],16777216);self.assertEqual(host.tmpfs_proof(value),value)

    def test_runtime_wrong_mount_permissions_capacity_or_identity_refuse(self):
        for mode in ("uid","gid","mode","symlink","fstype","device","duplicate","missing","readonly","oversize","zero","changed","mount-readonly","root","malformed"):
            with self.subTest(mode=mode),self.assertRaises(Fault):self.proof(mode)

    def test_refused_tmpfs_prevents_go_popen(self):
        with patch.object(worker.os,"getuid",return_value=501),patch.object(worker.os,"getgid",return_value=20), \
             patch.object(worker.resource,"setrlimit"),patch.object(worker,"driver_tmpfs",side_effect=Fault("fixture")), \
             patch.object(worker.subprocess,"Popen") as popen:
            with self.assertRaises(Fault):worker.driver(NONCE,RELAY)
            popen.assert_not_called()

    def test_host_requires_unique_before_go_and_unchanged_proof(self):
        from test_host import facts,network_views
        value=self.proof();ready={"kind":"DRIVER_TMPFS_READY","nonce":NONCE,"tmpfs":value}
        final={"kind":"DRIVER_FINAL","nonce":NONCE,"tmpfs":value,"test_exit":0,"network":network_views()[1],"facts":facts(4,[1],268435456,32)}
        render=lambda rows:"\n".join(json.dumps(x) for x in rows)
        self.assertEqual(host.driver_measurement(render([ready,final]),NONCE)["driver_peak_bytes"],100004)
        for rows in ([final],[final,ready],[ready,ready,final]):
            with self.subTest(rows=len(rows)),self.assertRaises(Fault):host.driver_measurement(render(rows),NONCE)
        changed=copy.deepcopy(final);changed["tmpfs"]["identity"][1]+=1
        with self.assertRaises(Fault):host.driver_measurement(render([ready,changed]),NONCE)
        with self.assertRaises(Fault):host.driver_measurement("=== RUN: Test\n"+render([ready,final]),NONCE)


if __name__=="__main__":unittest.main()
