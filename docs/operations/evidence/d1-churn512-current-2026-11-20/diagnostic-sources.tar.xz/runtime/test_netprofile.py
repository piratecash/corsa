import copy
import json
from pathlib import Path
import struct
import time
import unittest

import netprofile as subject


def initial():return json.loads(Path(__file__).with_name("inventory.fixture.json").read_text())
def nla(kind,value):
    size=4+len(value);return struct.pack("<HH",size,kind)+value+b"\0"*((-size)%4)
def rewrite(raw,path,value):
    items=subject.attrs(raw)
    items[path[0]]=rewrite(items.get(path[0],b""),path[1:],value) if len(path)>1 else value
    return subject.encode_attrs(items)
def replace_attr(row,key,raw):
    for item in row["attrs"]:
        if item["type"]==key:item["hex"]=raw.hex();item.pop("nested",None);return
    row["attrs"].append({"type":key,"hex":raw.hex()})
def header_change(row,offset,value):
    raw=bytearray.fromhex(row["header_hex"]);struct.pack_into("<I",raw,offset,value);row["header_hex"]=raw.hex()
def post():
    value=initial();d=value["rtnetlink"]
    for slot in range(768):
        address=bytes([10,77,slot//254,slot%254+1]).hex()
        d["addresses_v4"].append({"type":20,"header_hex":"022080fe01000000","attrs":[{"type":k,"hex":v} for k,v in {1:address,2:address,3:"6c6f00",8:"80000000",6:"ff"*8+"00"*8}.items()]})
        d["routes_v4"].append({"type":24,"header_hex":"02200000ff02fe0200000000","attrs":[{"type":k,"hex":v} for k,v in {15:"ff000000",1:address,7:address,4:"01000000"}.items()]})
    return value


class FinitePolicyTests(unittest.TestCase):
    def test_actual_initial_and_exact_post_delta(self):
        before=subject.validate(initial(),0)
        after=subject.validate(post(),768,before)
        self.assertEqual(after["addresses_v4"],769);self.assertEqual(after["routes_v4"],771)
        self.assertEqual(after["link_identity_sha256"],before["link_identity_sha256"])

    def test_critical_link_changes_refuse(self):
        def up(v):
            x=v["rtnetlink"]["links"][1];header_change(x,8,0x81);x["flags"]=0x81
        def master(v):replace_attr(v["rtnetlink"]["links"][1],10,b"\1\0\0\0")
        def peer(v):replace_attr(v["rtnetlink"]["links"][1],37,b"\0"*4)
        def remote(v):
            row=v["rtnetlink"]["links"][1];raw=bytearray(subject.row_attrs(row)[18]);raw[-1]=1;replace_attr(row,18,raw)
        def config(v):
            row=v["rtnetlink"]["links"][0];replace_attr(row,26,rewrite(subject.row_attrs(row)[26],[2,1],b"\0"*132))
        def unknown_nested(v):
            row=v["rtnetlink"]["links"][0];replace_attr(row,26,rewrite(subject.row_attrs(row)[26],[10,999],b"\0"))
        def token(v):
            row=v["rtnetlink"]["links"][0];replace_attr(row,26,rewrite(subject.row_attrs(row)[26],[10,7],b"\1"+b"\0"*15))
        for change in [up,master,peer,remote,config,unknown_nested,token]:
            value=initial();change(value)
            with self.subTest(change=change.__name__),self.assertRaises(ValueError):subject.validate(value,0)

    def test_unknown_even_down_interface_or_address_refuses(self):
        value=initial();value["rtnetlink"]["links"].append(copy.deepcopy(value["rtnetlink"]["links"][1]))
        with self.assertRaises(ValueError):subject.validate(value,0)
        value=initial();header_change(value["rtnetlink"]["addresses_v4"][0],4,2)
        with self.assertRaises(ValueError):subject.validate(value,0)

    def test_route_and_policy_rule_escape_refuses(self):
        for family in ("routes_v4","routes_v6"):
            value=initial();replace_attr(value["rtnetlink"][family][0],4,struct.pack("<I",2))
            with self.subTest(family=family),self.assertRaises(ValueError):subject.validate(value,0)
        value=initial();replace_attr(value["rtnetlink"]["rules_v4"][0],3,b"gre0\0")
        with self.assertRaises(ValueError):subject.validate(value,0)
        value=post();value["rtnetlink"]["routes_v4"].pop()
        with self.assertRaises(ValueError):subject.validate(value,768)

    def test_namespace_indices_and_sysfs_attachment_stay_bound(self):
        before=subject.validate(initial(),0)
        value=post();value["netns"]="net:[999]"
        with self.assertRaises(ValueError):subject.validate(value,768,before)
        value=post();row=value["rtnetlink"]["links"][1];header_change(row,4,99);row["index"]=99;value["sysfs"]["tunl0"]["ifindex"]="99"
        with self.assertRaises(ValueError):subject.validate(value,768,before)
        value=initial();value["sysfs"]["tunl0"]["iflink"]="2"
        with self.assertRaises(ValueError):subject.validate(value,0)

    def test_only_counter_cache_leaves_are_dynamic(self):
        value=initial();row=value["rtnetlink"]["links"][0]
        replace_attr(row,23,b"\xff"*200)
        raw=subject.row_attrs(row)[26]
        for path,size in [([10,3],304),([10,5],16),([10,6],56)]:raw=rewrite(raw,path,b"\x01"*size)
        replace_attr(row,26,raw)
        subject.validate(value,0)
        replace_attr(row,23,b"\0")
        with self.assertRaises(ValueError):subject.validate(value,0)

    def test_permanent_mac_is_shaped_and_bound_within_attempt(self):
        before=subject.validate(initial(),0)
        value=initial();row=value["rtnetlink"]["links"][6];mac=bytearray(subject.row_attrs(row)[54]);mac[0]^=4;replace_attr(row,54,mac)
        subject.validate(value,0) # New namespace may mint a different qualified identity.
        with self.assertRaises(ValueError):subject.validate(value,0,before)
        for bad in [b"\0"*15,b"\3"+b"\0"*15,b"\0"*16,b"\2"+b"\0"*14+b"\1"]:
            value=initial();replace_attr(value["rtnetlink"]["links"][6],54,bad)
            with self.assertRaises(ValueError):subject.validate(value,0)

    def test_address_lifetimes_are_configuration_not_volatile(self):
        value=initial();row=value["rtnetlink"]["addresses_v4"][0]
        replace_attr(row,6,b"\1\0\0\0"+b"\xff"*4+b"\0"*8)
        with self.assertRaises(ValueError):subject.validate(value,0)


def message(kind,seq=1001,port=99,flags=2,body=b"\0"*4):
    size=16+len(body);return struct.pack("<IHHII",size,kind,flags,seq,port)+body+b"\0"*((-size)%4)


class MultipartTests(unittest.TestCase):
    def test_terminal_and_header_refusals(self):
        good=message(3);self.assertEqual(subject.decode_datagram(good,1001,99,16,16),([],True))
        for raw in [message(3,seq=1002),message(3,port=98),message(3,flags=0x12),message(3,flags=0x22),message(2),message(3,body=b"\1\0\0\0"),good+good,good[:-1]]:
            with self.subTest(raw=raw[:16].hex()),self.assertRaises(ValueError):subject.decode_datagram(raw,1001,99,16,16)

    def test_kernel_peer_and_truncation_refusals(self):
        class FakeSocket:
            def __init__(self,peer=(0,0),flags=0,extra=False):self.peer,self.flags,self.extra=peer,flags,extra;self.calls=0
            def getsockname(self):return (99,0)
            def settimeout(self,value):pass
            def setblocking(self,value):pass
            def sendto(self,*args):pass
            def recvmsg(self,size):
                self.calls+=1
                if self.calls==1:return message(3),[],self.flags,self.peer
                if self.extra:return message(3),[],0,(0,0)
                raise BlockingIOError()
        self.assertEqual(subject.dump(FakeSocket(),18,16,0,16,1001,time.monotonic()+1,[0]),[])
        for sock in [FakeSocket(peer=(1,0)),FakeSocket(peer=(0,1)),FakeSocket(flags=0x20),FakeSocket(flags=0x8),FakeSocket(extra=True)]:
            with self.assertRaises(ValueError):subject.dump(sock,18,16,0,16,1001,time.monotonic()+1,[0])


if __name__=="__main__":unittest.main()
