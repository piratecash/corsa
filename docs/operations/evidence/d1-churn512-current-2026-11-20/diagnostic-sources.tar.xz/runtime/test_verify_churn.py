import json
import unittest

from verify_churn import PHASES, validate_driver, validate_service


class ChurnEvidenceTest(unittest.TestCase):
    def setUp(self):
        def identities(values):
            return [f"{value:040x}" for value in values]

        self.rosters = {
            "initial": identities(range(1, 513)),
            "survivors": identities(range(1, 257)),
            "replacement": identities([*range(1, 257), *range(513, 769)]),
            "closed": [],
        }
        self.lookups = {}
        self.snapshot = {}
        for name, size, _ in PHASES:
            roster = self.rosters[name]
            first, second = roster[:size // 2], roster[size // 2:]
            pairs = list(zip(second, first)) if name == "initial" else list(zip(first, second))
            if name == "replacement":
                pairs += list(zip(second, first))
            self.lookups[name] = pairs
            self.snapshot[name] = {
                "MembershipComplete": True, "ActiveCount": size, "F1Count": size,
                "RegistryVisits": size, "Rows": [
                    {"Identity": peer, "ConnID": int(peer, 16), "PublishedF1": True}
                    for peer in roster
                ],
            }
            self.snapshot[name]["Rows"] += [
                {"Identity": "", "ConnID": 0, "PublishedF1": False}
                for _ in range(512 - size)
            ]

    def driver_log(self):
        lines = []
        sequence = 40
        for name, _, _ in PHASES:
            lines.append(f"D1_CHURN512_PHASE {name} {json.dumps(self.rosters[name])}")
            for source, target in self.lookups[name]:
                sequence += 1
                lines.append(f"D1_CHURN512_ANSWER {sequence} {source} {target}")
        return "\n".join(lines)

    def service_log(self):
        return "\n".join("D1_CHURN512_MEMBERS " + json.dumps(self.snapshot[name])
                         for name in self.snapshot)

    def groups(self):
        return validate_driver(self.driver_log())[0]

    def test_complete_work_and_membership(self):
        groups, answers = validate_driver(self.driver_log())
        self.assertEqual(sum(map(len, answers.values())), 896)
        self.assertEqual(len(groups["initial"] | groups["replacement"]), 768)
        self.assertEqual([len(cut) for cut in validate_service(self.service_log(), groups).values()],
                         [512, 256, 512, 0])

    def test_old_target_history_plan_refuses(self):
        self.lookups["initial"]=[(target,source) for source,target in self.lookups["initial"]]
        with self.assertRaisesRegex(ValueError,"target history"):
            self.groups()

    def test_missing_answer(self):
        self.lookups["replacement"].pop()
        with self.assertRaisesRegex(ValueError, "incomplete verified answers"):
            self.groups()

    def test_survivor_without_lookup(self):
        self.lookups["survivors"][-1] = self.lookups["survivors"][0]
        with self.assertRaisesRegex(ValueError, "every peer"):
            self.groups()

    def test_replacement_without_inbound_answer(self):
        self.lookups["replacement"][255] = self.lookups["replacement"][254]
        with self.assertRaisesRegex(ValueError, "all send and receive"):
            self.groups()

    def test_missing_final_population(self):
        del self.snapshot["closed"]
        with self.assertRaisesRegex(ValueError, "missing service membership witness for closed"):
            validate_service(self.service_log(), self.groups())

    def test_survivor_connid_changed(self):
        self.snapshot["survivors"]["Rows"][0]["ConnID"] = 1025
        with self.assertRaisesRegex(ValueError, "survivor ConnID changed"):
            validate_service(self.service_log(), self.groups())

    def test_replacement_reused_disconnected_connid(self):
        self.snapshot["replacement"]["Rows"][511]["ConnID"] = 512
        with self.assertRaisesRegex(ValueError, "replacement reused"):
            validate_service(self.service_log(), self.groups())

    def test_partial_service_snapshot(self):
        self.snapshot["replacement"]["MembershipComplete"] = False
        with self.assertRaisesRegex(ValueError, "missing service membership witness for replacement"):
            validate_service(self.service_log(), self.groups())

    def test_missing_fixed_zero_rows_refuses(self):
        self.snapshot["closed"]["Rows"] = []
        with self.assertRaisesRegex(ValueError, "incomplete fixed membership rows"):
            validate_service(self.service_log(), self.groups())

    def test_hidden_extra_member_refuses(self):
        self.snapshot["survivors"]["Rows"][-1] = {"Identity": "f"*40, "ConnID": 9999, "PublishedF1": True}
        with self.assertRaisesRegex(ValueError, "unaccounted membership rows"):
            validate_service(self.service_log(), self.groups())
