"""Churn512 container adapter. Import performs no reads, mutations or processes."""
import base64
import hashlib
import os
from pathlib import Path
import re
import resource
import selectors
import signal
import stat
import subprocess
import sys
import time

import sg32_service as old
import netprofile
from sg32_common import need, strict_json, encode

INPUTS = ("corsad", "c2driver", "topology", "worker.py", "netprofile.py", "network-profile.json", "sg32_common.py", "sg32_service.py", "clockprobe.py")
PHASES = ("initial", "survivors", "replacement", "closed")
BOOTSTRAP = "import sys;sys.path.insert(0,'/inputs');import worker;sys.exit(worker.main())"
CGROOT = Path("/sys/fs/cgroup")
CGFILES = ("memory.max", "memory.swap.max", "memory.peak", "memory.current", "memory.events",
           "cpu.max", "cpu.stat", "pids.max", "pids.current", "pids.events", "cgroup.procs")


def emit(packet):
    old.emit(packet)


def read(path, limit=8192):
    fd = os.open(path, os.O_RDONLY | os.O_CLOEXEC | os.O_NOFOLLOW)
    try:
        raw = os.read(fd, limit + 1)
        need(len(raw) <= limit, "read-bound")
        return raw
    finally:
        os.close(fd)


def namespace():
    # Full finite SG512 network policy is checked at explicit phase barriers.
    # Do not silently reinterpret the old S6 strict-lo gate as this contract.
    value = os.readlink("/proc/self/ns/net")
    need(re.fullmatch(r"net:\[[1-9][0-9]*\]", value), "network-namespace")
    return value


def file_sha(path, limit, follow=False):
    fd = os.open(path, os.O_RDONLY | os.O_CLOEXEC | (0 if follow else os.O_NOFOLLOW))
    try:
        value, total = hashlib.sha256(), 0
        while True:
            part = os.read(fd, min(1024*1024, limit+1-total))
            if not part: break
            total += len(part); need(total <= limit, "file-hash-bound"); value.update(part)
        need(total > 0, "empty-hash-input")
        return value.hexdigest()
    finally: os.close(fd)


class Group:
    """Read-only FDs preserve the exact kernel cgroup-file incarnation."""
    def __init__(self, memory, pids):
        need(read("/proc/self/cgroup", 4096) == b"0::/\n", "private-cgroup-root")
        self.fds = {}
        try:
            for name in CGFILES:
                self.fds[name] = os.open(CGROOT / name, os.O_RDONLY | os.O_CLOEXEC | os.O_NOFOLLOW)
            self.ids = {name: self.identity(fd) for name, fd in self.fds.items()}
            self.memory, self.pids = memory, pids
        except BaseException:
            self.close()
            raise

    @staticmethod
    def identity(fd):
        value = os.fstat(fd)
        return [value.st_dev, value.st_ino]

    def close(self):
        for fd in self.fds.values():
            os.close(fd)
        self.fds = {}

    def snapshot(self):
        before = time.monotonic_ns()
        result = {}
        for name, fd in self.fds.items():
            need(self.identity(fd) == self.ids[name], "cgroup-file-incarnation")
            os.lseek(fd, 0, os.SEEK_SET)
            value = os.read(fd, 8193)
            need(len(value) <= 8192, "cgroup-read-bound")
            if name in ("memory.events", "cpu.stat", "pids.events"):
                lines = [line.split() for line in value.decode("ascii").splitlines()]
                need(all(len(line) == 2 and line[1].isdigit() for line in lines), "cgroup-counter-format")
                values = {key: int(val) for key, val in lines}
                need(len(values) == len(lines), "cgroup-counter-duplicate")
                result[name] = values
            elif name == "cpu.max":
                need(value == b"100000 100000\n", "cpu-limit")
                result[name] = value.decode().strip()
            elif name == "cgroup.procs":
                values = value.split()
                need(len(values) <= self.pids and all(x.isdigit() and int(x) > 0 for x in values), "cgroup-procs")
                result[name] = sorted(int(x) for x in values)
                need(len(set(result[name])) == len(result[name]), "cgroup-procs-duplicate")
            else:
                need(value.strip().isdigit(), "cgroup-scalar")
                result[name] = int(value)
        need(result["memory.max"] == self.memory and result["memory.swap.max"] == 0 and
             result["pids.max"] == self.pids and 0 < result["memory.peak"] <= self.memory,
             "actual-group-budget")
        need(all(result["memory.events"].get(key) == 0 for key in ("max", "oom", "oom_kill")) and
             result["pids.events"].get("max") == 0, "group-resource-refusal")
        return {"before_ns": before, "after_ns": time.monotonic_ns(), "files": self.ids,
                "values": result, "netns": namespace()}


def birth(pid):
    raw = read(f"/proc/{pid}/stat", 4096).decode()
    close = raw.rfind(")")
    fields = raw[close + 1:].split()
    need(close > 0 and len(fields) >= 20 and int(raw[:raw.index("(")].strip()) == pid,
         "owned-process-stat")
    need(read(f"/proc/{pid}/cgroup", 4096) == b"0::/\n", "owned-process-cgroup")
    return {"pid": pid, "ppid": int(fields[1]), "start_ticks": int(fields[19])}


def sampler(nonce):
    group = Group(512000000, 64)
    try:
        network=netprofile.snapshot(768)
        emit({"kind": "SAMPLER_READY", "nonce": nonce, "pid": os.getpid(), "network":network,"facts": group.snapshot()})
        command = old.control(old.bounded_control_line(sys.stdin.buffer, time.monotonic() + 20), nonce)
        need(command.keys() == {"kind", "nonce", "node", "network"} and command["kind"] == "NODE" and command["network"]==network, "sampler-node-command")
        node = command["node"]
        need(node == birth(node["pid"]) and node["ppid"] == 1, "sampler-node-birth")
        ordinal, pending = 0, False
        with selectors.DefaultSelector() as selector:
            selector.register(sys.stdin.buffer, selectors.EVENT_READ)
            while ordinal < 340:
                if selector.select(.5):
                    packet = old.control(old.read_line(sys.stdin.buffer), nonce)
                    if packet == {"kind": "STOPPING", "nonce": nonce}:
                        need(not pending, "sampler-stopping-order"); pending=True
                        emit({"kind":"STOPPING_ACK","nonce":nonce,"node":node})
                        continue
                    need(pending and packet == {"kind": "STOP", "nonce": nonce}, "sampler-stop")
                    final_network=netprofile.snapshot(768,network)
                    facts = group.snapshot()
                    need(facts["values"]["cgroup.procs"] == sorted([1, os.getpid()]), "sampler-post-reap-members")
                    emit({"kind": "SAMPLER_FINAL", "nonce": nonce, "ordinal": ordinal,
                          "facts": facts, "node_reaped": node,"network":final_network})
                    return 0
                if not pending: need(birth(node["pid"]) == node, "sampler-node-incarnation")
                facts = group.snapshot()
                members=set(facts["values"]["cgroup.procs"])
                need(({1,os.getpid()} <= members <= {1,os.getpid(),node["pid"]}) if pending else
                     members == {1,os.getpid(),node["pid"]}, "sampler-live-members")
                emit({"kind": "SAMPLE", "nonce": nonce, "ordinal": ordinal, "facts": facts})
                ordinal += 1
        raise old.Fault("sampler-deadline")
    finally:
        group.close()


def keeper(nonce, cli_sha):
    need(os.getpid() == 1 and (os.getuid(), os.getgid()) == (501, 20), "keeper-owner")
    start, checked, owned = time.monotonic(), [], []
    secret, netns = old.read_secret(), namespace()
    network_before=netprofile.snapshot(0)
    need(network_before["netns"]==netns,"before-helper-netns")
    emit({"kind": "SECRET_ATTACHED", "nonce": nonce, "netns": netns,"network":network_before})
    packet=old.control(old.bounded_control_line(sys.stdin.buffer,start+20),nonce)
    need(packet=={"kind":"NETWORK_CHECK","nonce":nonce,"netns":netns},"post-helper-check-order")
    network=netprofile.snapshot(768,network_before)
    emit({"kind":"NETWORK_POST","nonce":nonce,"network":network})
    packet = old.control(old.bounded_control_line(sys.stdin.buffer, start + 20), nonce)
    need(packet == {"kind": "CONTINUE", "nonce": nonce, "netns": netns,"network_identity":network["link_identity_sha256"]} and
         secret == old.read_secret() and namespace() == netns and time.monotonic() < start + 20,
         "keeper-handoff-secret-or-network")
    continued=netprofile.snapshot(768,network_before)
    need(continued==network,"network-changed-before-continue")
    emit({"kind":"NETWORK_CONTINUED","nonce":nonce,"network":continued})
    resource.setrlimit(resource.RLIMIT_NOFILE, (4096, 4096))
    need(resource.getrlimit(resource.RLIMIT_NOFILE) == (4096, 4096), "keeper-nofile")
    group = Group(512000000, 64)
    selector = selectors.DefaultSelector()
    records, host_buffer, relay_tail, host_messages = [], bytearray(), bytearray(), []
    node = sample = None
    try:
        initial = group.snapshot()
        need(initial["values"]["cgroup.procs"] == [1], "waiting-keeper-only")
        emit({"kind": "INITIAL", "nonce": nonce, "facts": initial})
        def attach(child, role):
            for name, stream in (("out", child.p.stdout), ("err", child.p.stderr)):
                selector.register(stream, selectors.EVENT_READ, (child, role, name))
        def pump(deadline):
            need(time.monotonic() < deadline, "keeper-phase-deadline")
            for key, _ in selector.select(min(.05, max(0, deadline-time.monotonic()))):
                child, role, stream = key.data
                raw = os.read(key.fd, 16384)
                if role == "host":
                    need(bool(raw),"host-control-eof"); host_buffer.extend(raw);need(len(host_buffer)<=8192,"host-control-limit")
                    while b"\n" in host_buffer:
                        line,_,rest=host_buffer.partition(b"\n");host_buffer[:]=rest
                        host_messages.append(old.control(line,nonce));need(len(host_messages)<=4,"host-message-bound")
                    continue
                if not raw:
                    selector.unregister(key.fileobj)
                    child.eof.add(stream)
                if role == "node":
                    old.log_chunk(child, stream, raw, secret, nonce, eof=not raw)
                    if stream == "out" and raw:
                        relay_tail.extend(raw)
                        need(len(relay_tail) <= 131072, "relay-log-line-limit")
                        while b"\n" in relay_tail:
                            line, _, rest = relay_tail.partition(b"\n"); relay_tail[:] = rest
                            match = re.fullmatch(rb"D1_CHURN512_RELAY_ID ([0-9a-f]{40})", line)
                            if match:
                                need(not any(x["kind"]=="RELAY_ID" for x in records), "duplicate-relay-id")
                                records.append({"kind":"RELAY_ID","identity":match[1].decode()})
                else:
                    child.buffers[stream].extend(raw)
                    need(stream == "out" or not child.buffers[stream], "sampler-stderr")
                    while b"\n" in child.buffers[stream]:
                        line, _, rest = child.buffers[stream].partition(b"\n"); child.buffers[stream][:] = rest
                        value = strict_json(line); need(value.get("nonce")==nonce,"sampler-nonce")
                        records.append(value);emit(value)
        sample = old.OwnedChild(["/usr/bin/python3","-I","-S","-B","-c",BOOTSTRAP,"sampler",nonce], owned,
                                {"PATH":"/usr/bin:/bin","LC_ALL":"C"}, True)
        attach(sample,"sampler")
        while not any(x["kind"]=="SAMPLER_READY" for x in records):
            need(sample.p.poll() is None,"sampler-early-exit");pump(start+20)
        sampler_network=next(x["network"] for x in records if x["kind"]=="SAMPLER_READY")
        need(sampler_network==network,"sampler-network-bind")
        env=old.daemon_environment(secret)
        env.update(CORSA_MAX_INCOMING_PEERS="512",CORSA_MAX_OUTGOING_PEERS="8",CORSA_MAX_TOTAL_CONNECTIONS="520")
        need(file_sha("/inputs/corsad",128*1024**2)==cli_sha,"daemon-input-sha")
        node=old.OwnedChild(["/inputs/corsad"],owned,env);attach(node,"node")
        original=birth(node.p.pid);need(original["ppid"]==1,"owned-node-parent")
        need(file_sha(f"/proc/{node.p.pid}/exe",128*1024**2,follow=True)==cli_sha and birth(node.p.pid)==original,"actual-daemon-exe")
        emit({"kind":"NODE_BOUND","nonce":nonce,"node":original,"exe_sha256":cli_sha})
        sample.send({"kind":"NODE","nonce":nonce,"node":original,"network":network})
        while True:
            need(node.p.poll() is None and sample.p.poll() is None,"startup-child-exit");pump(start+20)
            candidates=[x for x in records if x["kind"]=="RELAY_ID"]
            if not candidates:continue
            try:server,started_at=old.node_status(secret)
            except (OSError,old.http.client.HTTPException,old.Fault):continue
            need(server==candidates[0]["identity"] and birth(node.p.pid)==original,"readiness-relay-binding")
            emit({"kind":"READY","nonce":nonce,"identity":server,"started_at":started_at,"node":original})
            break
        selector.register(sys.stdin.buffer,selectors.EVENT_READ,(None,"host","in"))
        stopped=False
        # Pump host controls separately so no control or raw line is inferred from EOF.
        while not stopped:
            need(time.monotonic()<start+150 and node.p.poll() is None and sample.p.poll() is None,"work-child-or-deadline")
            pump(start+150)
            while host_messages:
                value=host_messages.pop(0)
                if value.get("kind")=="CHECK":
                    need(value.keys()=={"kind","nonce","phase"} and len(checked)<4 and value["phase"]==PHASES[len(checked)],"host-phase-order")
                    phase_network=netprofile.snapshot(768,network_before)
                    checked.append(value["phase"]);emit({"kind":"STATE_CHECK","nonce":nonce,"phase":value["phase"],"network":phase_network,**old.state_walk()})
                else:
                    need(value=={"kind":"STOP","nonce":nonce} and checked==list(PHASES) and not host_buffer and not host_messages,"host-stop-contract");stopped=True
        selector.unregister(sys.stdin.buffer)
        stop=min(start+165,time.monotonic()+15)
        sample.send({"kind":"STOPPING","nonce":nonce})
        ack_deadline=min(stop,time.monotonic()+2)
        while not any(x["kind"]=="STOPPING_ACK" for x in records):pump(ack_deadline)
        node.p.send_signal(signal.SIGTERM)
        while node.p.poll() is None or node.eof!={"out","err"}:pump(stop)
        need(node.p.wait(timeout=.001)==0,"daemon-normal-exit")
        emit({"kind":"NODE_REAP","nonce":nonce,"node":original,"exit":0})
        sample.send({"kind":"STOP","nonce":nonce});sample.p.stdin.close()
        while sample.p.poll() is None or sample.eof!={"out","err"}:pump(min(start+170,stop))
        need(sample.p.wait(timeout=.001)==0 and any(x["kind"]=="SAMPLER_FINAL" for x in records),"sampler-normal-reap")
        final_network=netprofile.snapshot(768,network_before)
        final_state=old.state_walk()
        final=group.snapshot();need(final["values"]["cgroup.procs"]==[1],"final-keeper-only")
        emit({"kind":"FINAL","nonce":nonce,"facts":final,"node_exit":0,"sampler_exit":0,
              "network":final_network,"checked_phases":checked,"keeper_exit_tail":"UNKNOWN","shared_page_attribution":"UNKNOWN",**final_state})
        return 0
    finally:
        for child in reversed(owned):child.terminate(time.monotonic()+2)
        selector.close();group.close()


def driver_tmpfs():
    def mount_record():
        raw=old.clockprobe.read_file("/proc/self/mountinfo",262144)
        need(raw.endswith(b"\n"),"driver-mountinfo-complete")
        rows=raw.splitlines();need(len(rows)<=128,"driver-mountinfo-count")
        matches=[]
        for row in rows:
            need(len(row)<=4096 and row.count(b" - ")==1,"driver-mountinfo-framing")
            left,right=row.split(b" - ");fields,tail=left.split(),right.split()
            need(len(fields)>=6 and len(tail)==3,"driver-mountinfo-fields")
            if fields[4]!=b"/tmp":continue
            need(len(fields)==6 and re.fullmatch(rb"[1-9][0-9]*",fields[0]) and re.fullmatch(rb"[0-9]+:[0-9]+",fields[2]) and
                 fields[3]==b"/" and tail[0]==tail[1]==b"tmpfs" and b"rw" in fields[5].split(b",") and
                 b"ro" not in fields[5].split(b",") and b"rw" in tail[2].split(b",") and b"ro" not in tail[2].split(b","),"driver-tmpfs-mount")
            matches.append((row,fields))
        need(len(matches)==1,"driver-tmpfs-one-mount")
        return matches[0]
    fd=os.open("/tmp",os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW|os.O_CLOEXEC)
    try:
        before=os.fstat(fd)
        need(stat.S_ISDIR(before.st_mode) and (before.st_uid,before.st_gid,stat.S_IMODE(before.st_mode))==(501,20,0o700),"driver-tmpfs-permissions")
        row,fields=mount_record()
        need(fields[2].decode("ascii")==str(os.major(before.st_dev))+":"+str(os.minor(before.st_dev)),"driver-tmpfs-device")
        space=os.fstatvfs(fd)
        need(type(space.f_frsize) is int and 0<space.f_frsize<=65536 and type(space.f_blocks) is int and space.f_blocks>0 and
             0<space.f_frsize*space.f_blocks<=16777216 and not space.f_flag&os.ST_RDONLY,"driver-tmpfs-capacity")
        after=os.fstat(fd);named=os.lstat("/tmp")
        identity=lambda info:(info.st_dev,info.st_ino,info.st_uid,info.st_gid,info.st_mode)
        need(identity(before)==identity(after)==identity(named) and mount_record()[0]==row,"driver-tmpfs-changed")
        return {"netns":namespace(),"path":"/tmp","uid":501,"gid":20,"mode":0o700,"fstype":"tmpfs","mount_id":int(fields[0]),
                "device":fields[2].decode("ascii"),"mountinfo_sha256":hashlib.sha256(row).hexdigest(),
                "capacity_bytes":space.f_frsize*space.f_blocks,"frsize":space.f_frsize,"blocks":space.f_blocks,
                "identity":[before.st_dev,before.st_ino]}
    finally:os.close(fd)


def driver(nonce, relay):
    need((os.getuid(),os.getgid())==(501,20) and re.fullmatch(r"[0-9a-f]{40}",relay),"driver-identity")
    resource.setrlimit(resource.RLIMIT_NOFILE,(4096,4096))
    env={"PATH":"/usr/bin:/bin","LC_ALL":"C","HOME":"/tmp","TMPDIR":"/tmp","GOMAXPROCS":"1",
         "D1_CHURN512_LAB":"1","D1_CHURN512_RELAY_ID":relay}
    tmpfs=driver_tmpfs()
    emit({"kind":"DRIVER_TMPFS_READY","nonce":nonce,"tmpfs":tmpfs})
    child=subprocess.Popen(["/inputs/c2driver","-test.run=^TestD1Churn512ExternalProcess$","-test.v","-test.timeout=120s"],env=env)
    try:
        result=child.wait(timeout=123)
    finally:
        if child.poll() is None:child.kill();child.wait(timeout=2)
    group=Group(268435456,32)
    try:
        final_network=netprofile.snapshot(768)
        emit({"kind":"DRIVER_FINAL","nonce":nonce,"tmpfs":driver_tmpfs(),"network":final_network,"facts":group.snapshot(),"test_exit":result,"keeper_exit_tail":"UNKNOWN"})
    finally:group.close()
    return result


def main():
    args=sys.argv[1:]
    need(len(args)>=2 and args[0] in ("preparer","keeper","sampler","driver") and re.fullmatch(r"[0-9a-f]{32}",args[1]),"worker-args")
    role,nonce=args[:2]
    old.RAW_LIMIT=36*1024**2
    if role=="preparer":
        need(len(args)==2,"preparer-args")
        old.INPUTS=INPUTS
        return old.preparer(nonce)
    if role=="sampler":need(len(args)==2,"sampler-args");return sampler(nonce)
    if role=="driver":need(len(args)==3,"driver-args");return driver(nonce,args[2])
    need(len(args)==3 and re.fullmatch(r"[0-9a-f]{64}",args[2]),"keeper-args")
    return keeper(nonce,args[2])


if __name__=="__main__":
    try:raise SystemExit(main())
    except Exception as error:
        emit({"kind":"ERROR","reason":str(error)[:128] if isinstance(error,old.Fault) else type(error).__name__})
        raise SystemExit(2)
