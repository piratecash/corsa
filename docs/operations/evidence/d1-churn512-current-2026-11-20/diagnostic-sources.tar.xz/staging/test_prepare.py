from pathlib import Path
import json
import os
import tempfile
import unittest
import prepare as p

class Tests(unittest.TestCase):
    def test_only_cli_and_provenance_change_old_eight_rows_code_preserved(self):
        names=('corsad','c2driver','topology','worker.py','netprofile.py','network-profile.json','sg32_common.py','sg32_service.py','clockprobe.py')
        old={'files':{n:{'path':'/old/'+n,'sha256':'a'*64,'bytes':1} for n in names},'code':{'host.py':'b'*64},'profile':'same-scenario','source_commit':'old','inputs_ready':True,'reviewer_accepted':True,'tester_accepted':True}
        new=p.candidate_handoff(old,{'path':'/new/cli','sha256':'c'*64,'bytes':2},{'path':'/new/result','sha256':'d'*64},Path('/new/runs'),{'source':'actual'})
        self.assertEqual(new['code'],old['code']);self.assertTrue(old['inputs_ready']);self.assertFalse(new['inputs_ready']);self.assertFalse(new['reviewer_accepted']);self.assertFalse(new['tester_accepted'])
        self.assertEqual([k for k in names if new['files'][k]!=old['files'][k]],['corsad'])
    def test_actual_eligible_atime_read_and_symlink_refusal(self):
        with tempfile.TemporaryDirectory() as temp:
            path=Path(temp).resolve()/'own';path.write_bytes(b'input');path.chmod(0o400);s=path.stat();os.utime(path,ns=(946684800000000000,s.st_mtime_ns));self.assertEqual(p.read(path,8),b'input')
            link=path.with_name('link');link.symlink_to(path)
            with self.assertRaises(ValueError):p.read(link,8)
            with self.assertRaises(ValueError):p.read(path,4)
    def test_run_parent_exact_empty_owner_mode(self):
        with tempfile.TemporaryDirectory() as temp:
            path=Path(temp).resolve()/'runs';path.mkdir(mode=0o700);self.assertTrue(p.check_run_parent(path)['empty'])
            (path/'unexpected').write_bytes(b'x')
            with self.assertRaises(ValueError):p.check_run_parent(path)
            (path/'unexpected').unlink();path.chmod(0o755)
            with self.assertRaises(ValueError):p.check_run_parent(path)
    def test_private_build_mode_to_public_copy_original_unmodified(self):
        with tempfile.TemporaryDirectory() as temp:
            root=Path(temp).resolve();original=root/'build-elf';original.write_bytes(b'public-code');original.chmod(0o700);before=p.identity(original.lstat())
            row,data=p.stage_public_cli({'path':str(original),'bytes':11,'sha256':p.sha(b'public-code')},root/'public-inputs')
            self.assertEqual(p.identity(original.lstat()),before);self.assertEqual(data['copy']['mode'],'0o444');self.assertEqual(data['copy']['uid'],501);self.assertEqual(data['copy']['gid'],20);self.assertEqual(Path(row['path']).read_bytes(),b'public-code')
            self.assertEqual({x.name for x in (root/'public-inputs').iterdir()},{'corsad'})
    def test_staging_bad_content_or_existing_directory_refuses(self):
        with tempfile.TemporaryDirectory() as temp:
            root=Path(temp).resolve();original=root/'build-elf';original.write_bytes(b'x');original.chmod(0o700)
            with self.assertRaises(ValueError):p.stage_public_cli({'path':str(original),'bytes':1,'sha256':'0'*64},root/'never-created')
            self.assertFalse((root/'never-created').exists());existing=root/'existing';existing.mkdir(mode=0o700)
            with self.assertRaises(ValueError):p.stage_public_cli({'path':str(original),'bytes':1,'sha256':p.sha(b'x')},existing)

if __name__=='__main__':unittest.main()
