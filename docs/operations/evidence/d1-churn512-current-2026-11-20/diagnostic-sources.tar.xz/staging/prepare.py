"""Only bind one actual new CLI into unchanged SG512 inputs; never start a job."""
from pathlib import Path
import copy
import hashlib
import json
import os
import stat

HERE=Path(__file__).resolve().parent

def need(ok,why):
    if not ok:raise ValueError(why)
def identity(s):return(s.st_dev,s.st_ino,s.st_uid,s.st_gid,s.st_mode,s.st_nlink,s.st_size,s.st_mtime_ns,s.st_ctime_ns)
def read(path,limit):
    path=Path(path);s=path.lstat()
    need(path.is_absolute() and path.resolve(strict=True)==path and stat.S_ISREG(s.st_mode) and s.st_nlink==1 and s.st_uid==501 and not s.st_mode&0o022 and 0<s.st_size<=limit,'safe bounded input')
    with os.fdopen(os.open(path,os.O_RDONLY|os.O_CLOEXEC|os.O_NOFOLLOW),'rb') as stream:
        need(identity(os.fstat(stream.fileno()))==identity(s),'changed open input');raw=stream.read(s.st_size+1)
        need(len(raw)==s.st_size and identity(os.fstat(stream.fileno()))==identity(s),'changed bounded input')
    need(identity(path.lstat())==identity(s),'changed input path');return raw
def sha(raw):return hashlib.sha256(raw).hexdigest()
def pinned(row,limit):
    raw=read(Path(row['path']),limit);need(len(raw)==row['bytes'] and sha(raw)==row['sha256'],'pinned public input changed');return raw
def check_run_parent(path):
    s=path.lstat();need(path.is_absolute() and path.resolve(strict=True)==path and stat.S_ISDIR(s.st_mode) and s.st_uid==501 and s.st_gid==20 and stat.S_IMODE(s.st_mode)==0o700 and not any(path.iterdir()),'new own empty501:20/0700 run-parent')
    return {'path':str(path),'uid':s.st_uid,'gid':s.st_gid,'mode':oct(stat.S_IMODE(s.st_mode)),'empty':True,'device':s.st_dev,'inode':s.st_ino}
def stage_public_cli(cli,directory):
    original=Path(cli['path']);before=original.lstat();original_identity=identity(before)
    raw=read(original,128*1024**2)
    need(len(raw)==cli['bytes'] and sha(raw)==cli['sha256'],'original public CLI binding')
    need(not directory.exists(),'fresh own public directory required');directory.mkdir(mode=0o700)
    parent=check_run_parent(directory);target=directory/'corsad'
    with os.fdopen(os.open(target,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_CLOEXEC|os.O_NOFOLLOW,0o600),'wb') as stream:
        need(stream.write(raw)==len(raw),'full public CLI copy');stream.flush();os.fsync(stream.fileno());os.fchmod(stream.fileno(),0o444)
        copied=os.fstat(stream.fileno())
        need(stat.S_ISREG(copied.st_mode) and copied.st_uid==501 and copied.st_gid==20 and copied.st_nlink==1 and stat.S_IMODE(copied.st_mode)==0o444 and copied.st_size==len(raw),'public CLI copy custody/mode')
    need(identity(target.lstat())==identity(copied) and read(target,128*1024**2)==raw,'public CLI readback/custody')
    need(identity(original.lstat())==original_identity,'original CLI metadata/content identity changed')
    after=directory.lstat();need((after.st_dev,after.st_ino,after.st_uid,after.st_gid,after.st_mode)==(parent['device'],parent['inode'],501,20,stat.S_IFDIR|0o700) and {p.name for p in directory.iterdir()}=={'corsad'},'public directory custody/membership')
    row={'path':str(target),'sha256':cli['sha256'],'bytes':cli['bytes']}
    data={'scope':'PUBLIC_CLI_COPY_ONLY_NOT_EXECUTED','original':{'path':str(original),'uid':before.st_uid,'gid':before.st_gid,'mode':oct(stat.S_IMODE(before.st_mode)),'device':before.st_dev,'inode':before.st_ino,'nlink':before.st_nlink,'bytes':before.st_size,'sha256':cli['sha256']},'copy':dict(row,uid=copied.st_uid,gid=copied.st_gid,mode=oct(stat.S_IMODE(copied.st_mode)),nlink=copied.st_nlink,device=copied.st_dev,inode=copied.st_ino),'directory':dict(parent,empty=False),'original_metadata_unchanged':True,'original_bytes_unchanged':True,'ELF_executed':False}
    return row,data
def candidate_handoff(old,cli,receipt,run_parent,provenance):
    need(set(old['files'])=={'corsad','c2driver','topology','worker.py','netprofile.py','network-profile.json','sg32_common.py','sg32_service.py','clockprobe.py'},'same nine inputs')
    out=copy.deepcopy(old);out['files']['corsad']={key:cli[key] for key in ('path','sha256','bytes')}
    out.update(source_commit='08c3c5ea0c7d6bc34c634060d1a5990d0ca745a6',run_parent=str(run_parent),build_receipt=receipt,inputs_ready=False,reviewer_accepted=False,tester_accepted=False)
    out['current_candidate_provenance']=provenance
    need({k:v for k,v in out['files'].items() if k!='corsad'}=={k:v for k,v in old['files'].items() if k!='corsad'} and out['code']==old['code'] and out['profile']==old['profile'],'old worker/driver/topology/oracles changed')
    return out
def write(name,row):
    with (HERE/name).open('x') as stream:stream.write(json.dumps(row,sort_keys=True,indent=2)+'\n')
def main():
    os.umask(0o077);need((os.getuid(),os.getgid())==(501,20),'owner501:20')
    pins=json.loads(read(HERE/'PINNED.json',65536));old=json.loads(pinned(pins['legacy_handoff'],65536));result_raw=pinned(pins['actual_build_result'],65536);result=json.loads(result_raw)
    need(result['status']=='DAEMON_BUILT' and result['error'] is None and result['cleanup_confirmed'] is True and result['ELF_executed'] is False and len(result['steps'])==4 and all(x['exit']==0 for x in result['steps']),'actual new CLI build did not close')
    tester=json.loads(pinned(pins['actual_testerdatapath'],65536));need(tester['status']=='INDEPENDENT_TESTER_CLI_BUILD_DATA_ACCEPTED' and tester['result_sha256']==sha(result_raw),'actual TESTER data binding')
    need(result['artifact']==pins['cli'] and result['artifact']['executed'] is False,'actual CLI artifact binding')
    cli_raw=read(Path(pins['cli']['path']),128*1024**2);need(len(cli_raw)==pins['cli']['bytes'] and sha(cli_raw)==pins['cli']['sha256'],'new CLI bytes')
    del cli_raw
    for row in pins['runtime_files'].values():pinned(row,128*1024)
    for row in pins['reused_rows'].values():
        raw=read(Path(row['path']),128*1024**2);need(len(raw)==row['bytes'] and sha(raw)==row['sha256'],'unchanged driver/topology/reader input')
    for key in ('subject_manifest','compiled_manifest','private_overlay','build_handoff'):pinned(pins[key],1024**2)
    need(result['role_manifest_sha256']=='fdd45820d3af22e46101ba3b7e9212cfdf59cfcaa1232b5169e59aba6a90dd7e' and result['source_file_count']==2498,'exact role34 subject')
    need(sha(read(Path(result['work'])/'SOURCE-MANIFEST.json',1024**2))==pins['compiled_manifest']['sha256'],'actual compiled manifest')
    for name in ('HANDOFF.PREPARED.json','READONLY-PREFLIGHT.json','ONE-ATTEMPT-CLAIM.json'):need(not (HERE/name).exists(),'fresh unclaimed runtime package')
    parent=HERE/'runs'
    if not parent.exists():parent.mkdir(mode=0o700)
    parent_data=check_run_parent(parent)
    provenance={key:pins[key] for key in ('subject_manifest','compiled_manifest','private_overlay','build_handoff','actual_testerdatapath')}
    provenance.update(role_manifest_sha256=result['role_manifest_sha256'],tested_role_files=34,compiled_source_files=2498,private_overlay_files=5,commit=pins['commit'],lineage_scope='Root verified all2093committedGo files equal frozen tested subject before five private diagnostic posts; exact compiled manifest separately pinned.')
    receipt={key:pins['actual_build_result'][key] for key in ('path','sha256')}
    public_cli,staging=stage_public_cli(pins['cli'],HERE/'public-inputs');write('STAGING-DATA.json',staging)
    handoff=candidate_handoff(old,public_cli,receipt,parent,provenance)
    write('HANDOFF.PREPARED.json',handoff)
    preflight={'scope':'READONLY_SINGLE_CURRENT_INPUT_REBIND_ONLY_NOT_RUNTIME','new_cli':handoff['files']['corsad'],'public_cli_staging':staging,'eight_rows_unchanged':True,'host_code_unchanged':True,'runtime_entrypoint':pins['runtime_files']['run_host.py'],'run_parent':parent_data,'prepared_handoff_sha256':sha(read(HERE/'HANDOFF.PREPARED.json',65536)),'ready':False,'resource_job_started':False,'limitations':['False readiness is intentional until final runtime CODE/DATA approval.','Old completed shoulder is retained; no old A/B, driver or topology rebuild.']}
    check_run_parent(parent);write('READONLY-PREFLIGHT.json',preflight);print(json.dumps(preflight,sort_keys=True))

if __name__=='__main__':main()
