# Одна current SG512 попытка: только новая CLI-привязка

Source/data-пакет не запускает процессы, контейнеры, приложения или Docker.
Прежние host/worker/verify/canonical/netprofile/run_host.py вызываются из
побайтно неизменённого `d1-churn512-runtime-inert-v7`. Новый собственный
HANDOFF/claim/run-parent живёт здесь; исторический claim/result не меняется.

Actual CLI32424079B SHA4010d590… собран и независимо DATA-проверен, не
исполнялся. Driver6505…/topology873b… и остальные8input rows неизменны.
Продуктовый код соответствует коммиту08c3c5ea… (Root сверил все2093Go files
с протестированным frozen срезом до5приватных posts); исходная compiled
2498file manifest и точный role34/private5 overlay закреплены отдельно.

V1 HANDOFF 98f7 saved byte-exact in PREPARED_UNSTAGED.json; V1 was NOT RUN.
The original public CLI is UID501:GID0/mode0700: unchanged ROOT preparer
with CHOWN alone cannot read it. No permissions/capabilities/oracles widened.

V2 prepare.py stages ONLY that public ELF into fresh own public-inputs
UID501:GID20/mode0700, file corsad UID501:GID20/mode0444/nlink1.
Exact size/SHA/full readback and immutable identity checks cover the copy,
original bytes/metadata and directory membership. Read atime is intentionally
excluded from immutable identity. Original build ELF mode0700 is unchanged.
STAGING-DATA.json binds both paths and UID/GID/mode/dev/inode/SHA.
This is current byte/custody evidence, not crash durability. Eight old rows
and all old runtime code remain exact.

`prepare.py` читает только конкретные actual receipts/bytes. Создаёт
собственный пустой501:20/0700 `runs`, подтверждает отсутствие claim,
записывает HANDOFF.PREPARED.json с inputs_ready/tester/reviewer **false**.
Это намеренно неисполняемый срез до финального CODE/DATA review.
Root затем создаёт конечный HANDOFF.json из этих же actual fields,
устанавливая readiness только после реального ревью. Поскольку старый
host проверяет их true, его readonly --check применяется к финальному файлу.

Readonly preflight без запуска:
`python3 ../d1-churn512-runtime-inert-v7/run_host.py <новый HANDOFF.json> --check <его SHA256>`.
Только Root после известного закрытия предыдущих job запускает тот же entry
с `--run <SHA256>`; это одна current попытка, не old A/B и не публичная активация.

Профиль и oracle прежние:512→256→512→0,768identity,896ответов,512целей;
service+keeper+sampler1CPU/512000000B/64PID без swap, driver1CPU/256MiB/32PID;
preparerCHOWN-only и краткий topologyNET_ADMIN-only удалены до полезной работы.
180с с подготовкой+30с cleanup, ≥10GiB плюс inputs, heavy-lock; прежние
full-RAW/STATE/FD/grouppeak/CPU/events/ConnID/cleanup проверки без вычитаний.
При ошибке/OOM/timeout/неполных данных STOP без повтора и роста лимитов;
UNKNOWN удерживает lock. Общих host hard caps/no-swap и жёсткой дисковой
квоты нет; shared-page attribution/keeper exit-tail/RSS/preparer cost UNKNOWN.

Новых метрик/gates, combined1024+10k, сборок драйвера или topology нет.
Успех относится к выбранной F1/churn нагрузке закрытого Responder среза,
не означает завершения O1a/всего13b-D1, G2, активации или выпуска.
