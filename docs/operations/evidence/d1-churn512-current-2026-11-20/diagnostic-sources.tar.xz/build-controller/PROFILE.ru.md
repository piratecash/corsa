# Одна сборка current CLI для прежнего SG512

Прежний offline Go1.27.4 controller600с работы+30с cleanup под heavy-lock,
GOMAXPROCS2, -p1, GOMEMLIMIT768MiB; Linuxarm64/CGO0/trimpath,
`-tags=d1_resource_probe`, buildvcsfalse/modreadonly. Только установленный
локальный Go и имеющиеся зависимости, GOPROXY/GOSUMDB/telemetry off;
Seatbelt запрещает сеть и запись в скопированные исходники. Ничего не
скачивается/не устанавливается. Общих host CPU/RAM/PID hard caps/no-swap нет.

Перед стартом≥10GiB; до6GiB собственных файлов по фазовым проверкам,
RAW≤1MiB. Жёсткой дисковой квоты нет; программные сроки не гарантируют
остановку зависшего I/O. Ошибка/OOM/timeout/неполные свидетельства — STOP
без повторов/роста лимитов, журналы сохранить; UNKNOWN удерживает lock.

Вход — frozen2498 source GoQA-v3 base1b97da9+34rolefiles и ровно5private
diagnostic posts. LocalRoleResponder/F1+R сохраняется. Одна CLI compilation,
затем SHA/static ELF/BuildInfo с точным прежним списком dependencies;
исходники повторно сверяются. Go-тесты, полученный ELF, daemon/driver/
topology/VM/piratecashd не запускаются. Это подготовка одной новой current
ресурсной попытки; старый baseline не пересобирается и не повторяется.

Локальная защита прежнего наблюдённого cleanup-дефекта: OSError/EPERM при
проверке группы или poll — UNKNOWN, а не отсутствие. PID/PGID команды
сохраняются до poll; STOP/result записывается до live HOLD с точным ownlock.
Неизвестное завершение не превращается в обычный выход контроллера.
