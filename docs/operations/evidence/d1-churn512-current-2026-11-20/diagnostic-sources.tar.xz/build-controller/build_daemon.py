"""Single offline Linux arm64 current closed-role diagnostic daemon compilation; never executes the artifact."""
from pathlib import Path
import hashlib
import importlib.util
import json
import os
import shutil
import signal
import stat
import subprocess
import time
import uuid

HERE=Path(__file__).resolve().parent
REPO=HERE.parents[4]
OLD=Path('/private/tmp/corsa-d1-closed-role-goqa-603de9b66d0b45e7be054a3e2f8aa56d')
SOURCE=HERE.parent/'d1-sg512-closed-role-daemon-source-v2'
OLD_MANIFEST_SHA='7a025cd075cc42ed6ddd669b553b3a41c3c6cb90cc1f008f907328ae917f322f'
GO='/usr/local/go/bin/go'
LOCK=Path('/private/tmp/corsa-heavy-run.lock')


def sha(path):
    h=hashlib.sha256()
    with path.open('rb') as stream:
        for part in iter(lambda:stream.read(1024*1024),b''):h.update(part)
    return h.hexdigest()


def stamp(path):
    s=path.lstat();return tuple(getattr(s,k) for k in ('st_dev','st_ino','st_uid','st_gid','st_mode','st_size','st_mtime_ns','st_ctime_ns'))


def inventory(path):return {str(p.relative_to(path)):sha(p) for p in sorted(path.rglob('*')) if p.is_file()}


def work_volume(root):
    """Phase accounting: only own ephemeral tmp/cache may vanish concurrently."""
    root=Path(root)
    def scan(directory,ephemeral=False):
        try:
            with os.scandir(directory) as iterator:
                entries=list(iterator)
        except FileNotFoundError:
            if ephemeral:return 0
            raise
        total=0
        for entry in entries:
            volatile=ephemeral or (directory==root and entry.name in ("tmp","cache"))
            try:info=entry.stat(follow_symlinks=False)
            except FileNotFoundError:
                if volatile:continue
                raise
            if stat.S_ISREG(info.st_mode):total+=info.st_size
            elif stat.S_ISDIR(info.st_mode):total+=scan(Path(entry.path),volatile)
            else:raise RuntimeError("unexpected own work entry type: "+entry.path)
        return total
    return scan(root)


def raw_bytes(root):
    return sum(p.stat().st_size for p in Path(root).glob('*.std*'))


def probe_group_absent(pid,probe=os.killpg):
    try:probe(pid,0)
    except ProcessLookupError:return True
    except OSError:return False
    return False

def persist_active(work,attempt,row):
    assert row['pid']==row['pgid'] and row['pid']>1
    (work/'ACTIVE-COMMAND.json').write_text(json.dumps(dict(controller_pid=os.getpid(),controller_pgid=os.getpgrp(),attempt_id=attempt,**row),indent=2)+'\n')

def main():
    os.umask(0o077)
    if os.getpid()!=os.getpgrp():os.setsid()
    start=time.monotonic();deadline=start+600;cleanup_end=start+630
    manifest=json.loads((HERE/'MANIFEST.json').read_bytes())
    assert manifest['build_controller_sha256']==sha(Path(__file__))
    assert sha(SOURCE/'MANIFEST.json')==manifest['overlay_manifest_sha256']
    overlay=json.loads((SOURCE/'MANIFEST.json').read_bytes())
    assert overlay['subject_manifest_sha256']==OLD_MANIFEST_SHA and overlay['subject_file_count']==2498
    assert sha(SOURCE/'REUSE-ABI.json')==overlay['reused_input_report_sha256']
    for rel,row in overlay['overlay_files'].items():assert sha(SOURCE/'posts'/rel)==row['after_sha256']
    attempt=uuid.uuid4().hex;work=Path('/private/tmp/corsa-d1-sg512-closed-role-daemon-'+attempt)
    assert shutil.disk_usage('/private/tmp').free>=10*1024**3
    work.mkdir(mode=0o700);LOCK.mkdir(mode=0o700)
    owner=f'name=d1-sg512-closed-role-daemon\npid={os.getpid()}\npgid={os.getpgrp()}\nattempt_id={attempt}\n'.encode();(LOCK/'owner').write_bytes(owner)
    custody=(stamp(LOCK),stamp(LOCK/'owner'));steps=[];child=None;known=True;error=None;artifact=None
    env={**os.environ,'GOROOT':'/usr/local/go','GOENV':'off','GOWORK':'off','GOVCS':'*:off','GODEBUG':'','GOTOOLCHAIN':'local','GOPROXY':'off','GOSUMDB':'off','GOTELEMETRY':'off','GOMAXPROCS':'2','GOMEMLIMIT':'768MiB','GOFLAGS':'-p=1','GOCACHE':str(work/'cache'),'GOMODCACHE':str(REPO/'.gomodcache'),'TMPDIR':str(work/'tmp'),'CGO_ENABLED':'0','GOOS':'linux','GOARCH':'arm64','GOARM64':'v8.0'}
    def volume():return work_volume(work)
    def group_absent():
        nonlocal known
        if not child:return True
        if probe_group_absent(child.pid):return True
        known=False;return False
    def poll_owned():
        nonlocal known
        try:return child.poll()
        except OSError:
            known=False
            raise
    def run(name,args,cwd):
        nonlocal child
        assert time.monotonic()<deadline and volume()<=6*1024**3
        policy='(version 1)(allow default)(deny network*)(deny file-write* (subpath '+json.dumps(str(work/'source'))+'))'
        row=dict(phase=name,argv=args,pid=None,exit=None,stdout=str(work/(name+'.stdout')),stderr=str(work/(name+'.stderr')))
        steps.append(row)
        with (work/(name+'.stdout')).open('xb') as out,(work/(name+'.stderr')).open('xb') as err:
            child=subprocess.Popen(['/usr/bin/sandbox-exec','-p',policy,*args],cwd=cwd,env=env,stdout=out,stderr=err,start_new_session=True)
            row['pid']=child.pid;row['pgid']=child.pid
            persist_active(work,attempt,row)
            while poll_owned() is None:
                assert time.monotonic()<deadline and raw_bytes(work)<=1024**2 and volume()<=6*1024**3,'deadline/RAW/file bound'
                time.sleep(.1)
        assert raw_bytes(work)<=1024**2,'aggregate RAW bound after command'
        row['exit']=child.returncode
        assert group_absent(),'owned command group remains'
        assert child.returncode==0,name+' failed'
    try:
        old_raw=(OLD/'SOURCE-MANIFEST.json').read_bytes();assert hashlib.sha256(old_raw).hexdigest()==OLD_MANIFEST_SHA
        frozen=json.loads(old_raw);assert len(frozen)==2498 and inventory(OLD/'source')==frozen
        assert all(frozen[k]==v['before_sha256'] for k,v in overlay['overlay_files'].items())
        src=work/'source';src.mkdir();(work/'tmp').mkdir();(work/'artifacts').mkdir()
        for relative,digest in frozen.items():
            parts=Path(relative).parts;assert parts and not Path(relative).is_absolute() and '..' not in parts
            original=OLD/'source'/relative;info=original.lstat();assert stat.S_ISREG(info.st_mode) and not original.is_symlink()
            copied=src/relative;copied.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(original,copied)
            assert sha(copied)==digest and time.monotonic()<deadline
        expected=dict(frozen)
        for rel,row in overlay['overlay_files'].items():
            shutil.copyfile(SOURCE/'posts'/rel,src/rel);expected[rel]=row['after_sha256']
        initial=inventory(src);assert initial==expected and len(initial)==2498
        assert sha(SOURCE/'SOURCE-MANIFEST.AFTER.json')==overlay['after_manifest_sha256']
        assert json.loads((SOURCE/'SOURCE-MANIFEST.AFTER.json').read_bytes())==initial
        (work/'SOURCE-MANIFEST.json').write_text(json.dumps(initial,sort_keys=True,indent=2)+'\n')
        assert volume()<=6*1024**3
        run('go-version',[GO,'version'],src);assert (work/'go-version.stdout').read_text().strip()=='go version go1.27.4 darwin/arm64'
        run('modules',[GO,'mod','verify'],src)
        out=work/'artifacts/corsad-diagnostic'
        run('daemon-build',[GO,'build','-mod=readonly','-buildvcs=false','-p=1','-trimpath','-tags=d1_resource_probe','-o',str(out),'./cmd/corsa-node'],src)
        guard_source=HERE.parent/'d1-churn512-runtime-inert-v7/canonical/sg32_common.py';assert sha(guard_source)==manifest['static_guard_sha256']
        spec=importlib.util.spec_from_file_location('staticguard',guard_source);guard=importlib.util.module_from_spec(spec);spec.loader.exec_module(guard);guard.static_elf(out.read_bytes())
        run('daemon-metadata',[GO,'version','-m',str(out)],src)
        metadata=(work/'daemon-metadata.stdout').read_text();assert sha(Path(manifest['prior_metadata_path']))==manifest['prior_metadata_sha256'];prior=Path(manifest['prior_metadata_path']).read_text()
        assert 'go1.27.4' in metadata and all(x in metadata for x in ('GOOS=linux','GOARCH=arm64','CGO_ENABLED=0','-trimpath=true','-tags=d1_resource_probe'))
        assert [x for x in metadata.splitlines() if x.startswith('\tdep\t')]==[x for x in prior.splitlines() if x.startswith('\tdep\t')]
        assert inventory(src)==initial and inventory(OLD/'source')==frozen and sha(SOURCE/'MANIFEST.json')==manifest['overlay_manifest_sha256']
        assert time.monotonic()<deadline and volume()<=6*1024**3
        artifact=dict(path=str(out),sha256=sha(out),bytes=out.stat().st_size,static_linux_arm64=True,executed=False)
    except BaseException as exc:
        error=repr(exc)
        if child:
            try:
                if poll_owned() is None:
                    os.killpg(child.pid,signal.SIGTERM)
                    try:child.wait(timeout=max(.001,min(10,cleanup_end-time.monotonic())))
                    except subprocess.TimeoutExpired:
                        os.killpg(child.pid,signal.SIGKILL)
                        try:child.wait(timeout=max(.001,cleanup_end-time.monotonic()))
                        except subprocess.TimeoutExpired:known=False
            except OSError as cleanup_error:
                known=False;error+='; cleanup='+repr(cleanup_error)
            group_absent()
            try:
                if steps and steps[-1]['pid']==child.pid:steps[-1]['exit']=poll_owned()
            except OSError as poll_error:
                known=False;error+='; final_poll='+repr(poll_error)
    result=dict(status='DAEMON_BUILT' if error is None else 'STOP',attempt_id=attempt,work=str(work),error=error,cleanup_confirmed=known,steps=steps,artifact=artifact,ELF_executed=False,base_commit=overlay['base_commit'],role_manifest_sha256=overlay['role_manifest_sha256'],overlay_manifest_sha256=manifest['overlay_manifest_sha256'],source_file_count=2498,work_limit_s=600,cleanup_end_s=630)
    (work/'result.json').write_text(json.dumps(result,indent=2)+'\n');shutil.copyfile(work/'result.json',HERE/'RESULT.json')
    if known:
        assert custody==(stamp(LOCK),stamp(LOCK/'owner')) and (LOCK/'owner').read_bytes()==owner and set(x.name for x in LOCK.iterdir())=={'owner'}
        (LOCK/'owner').unlink();LOCK.rmdir()
    print(json.dumps(result),flush=True)
    if not known:
        (work/'HOLD.json').write_text(json.dumps(dict(status='UNKNOWN_RETAIN_LOCK',controller_pid=os.getpid(),controller_pgid=os.getpgrp(),attempt_id=attempt,last_command=steps[-1] if steps else None),indent=2)+'\n')
        while True:
            try:time.sleep(1)
            except KeyboardInterrupt:pass
    if error:raise SystemExit(1)


if __name__=='__main__':main()
