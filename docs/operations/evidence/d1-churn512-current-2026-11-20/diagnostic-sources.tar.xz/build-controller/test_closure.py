from pathlib import Path
import errno
import json
import tempfile
import unittest
import build_daemon as b

class Tests(unittest.TestCase):
    def test_permission_and_other_oserror_never_mean_absent(self):
        def missing(pid,signal):raise ProcessLookupError(errno.ESRCH,'gone')
        def denied(pid,signal):raise PermissionError(errno.EPERM,'not permitted')
        def error(pid,signal):raise OSError(errno.EIO,'unavailable')
        self.assertTrue(b.probe_group_absent(99,missing))
        for probe in (denied,error,lambda pid,signal:None):self.assertFalse(b.probe_group_absent(99,probe))
    def test_actual_custody_json_before_poll_and_result_before_hold(self):
        with tempfile.TemporaryDirectory() as temp:
            row={'phase':'fake-owned','argv':['never-executed'],'pid':99,'pgid':99,'exit':None}
            b.persist_active(Path(temp),'a'*32,row)
            saved=json.loads((Path(temp)/'ACTIVE-COMMAND.json').read_bytes())
            self.assertEqual(saved['pid'],99);self.assertEqual(saved['pgid'],99)
            self.assertEqual(saved['attempt_id'],'a'*32)
        source=Path(b.__file__).read_text();self.assertLess(source.index('persist_active(work,attempt,row)'),source.index('while poll_owned() is None:'))
        self.assertLess(source.index("(work/'result.json').write_text"),source.index("(work/'HOLD.json').write_text"))
        self.assertIn('except OSError as cleanup_error:',source)
        self.assertIn('except OSError as poll_error:',source)

if __name__=='__main__':unittest.main()
