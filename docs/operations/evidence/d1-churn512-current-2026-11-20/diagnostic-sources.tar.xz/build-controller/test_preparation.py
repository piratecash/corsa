from pathlib import Path
import hashlib
import json
import tempfile
import unittest
from unittest import mock
import build_daemon as b

class Tests(unittest.TestCase):
    def test_exact_five_overlay_files_and_role_not_overwritten(self):
        manifest=json.loads((b.SOURCE/'MANIFEST.json').read_bytes());self.assertEqual(len(manifest['overlay_files']),5)
        for rel,row in manifest['overlay_files'].items():self.assertEqual(b.sha(b.SOURCE/'posts'/rel),row['after_sha256'])
        diagnostic=(b.SOURCE/'posts/internal/core/node/find_node_resource_diagnostic.go').read_text()
        self.assertIn('LocalRole: findNodeRoleResponder,',diagnostic);self.assertNotIn('s.ownedFindNodeAdvertiseTest = true',diagnostic)
        self.assertIn('MaxActive: 512, MaxMembers: 512, MaxRegistryVisits: 1024,',diagnostic)
    def test_all_other2498_source_records_unchanged(self):
        before=json.loads((b.SOURCE/'SOURCE-MANIFEST.BEFORE.json').read_bytes());after=json.loads((b.SOURCE/'SOURCE-MANIFEST.AFTER.json').read_bytes());manifest=json.loads((b.SOURCE/'MANIFEST.json').read_bytes())
        self.assertEqual(len(before),2498);self.assertEqual(set(before),set(after))
        self.assertEqual({k for k in before if before[k]!=after[k]},set(manifest['overlay_files']))
        self.assertEqual(after['internal/core/node/find_node_owned_receive.go'],before['internal/core/node/find_node_owned_receive.go'])
    def test_reused_driver_topology_and_transport_abi_receipt(self):
        report=json.loads((b.SOURCE/'REUSE-ABI.json').read_bytes());self.assertTrue(report['accepted_for_rebinding']);self.assertTrue(report['unchanged_dependency_records_actual_source_rehashed'])
        self.assertEqual(len(report['unchanged_protocol_domain_sessionv2_and_module_records']),149);self.assertEqual(len(report['exact_driver_tls_wire_helper_segments']),6)
        self.assertEqual(report['reused_inputs']['c2driver']['sha256'],'6505bd130485342c572f2bc0890ed5f143cf87ee392c87adf9675d6bc32b305e')
        self.assertEqual(report['reused_inputs']['topology']['sha256'],'873b7fc6411541659c3375ef7572e627f245a918a187fcd0295ee1df59f447d5')
    def test_controller_compile_only_same_limits_and_no_driver_build(self):
        raw=Path(b.__file__).read_text()
        self.assertIn("deadline=start+600;cleanup_end=start+630",raw)
        self.assertIn("run('daemon-build',[GO,'build'",raw)
        self.assertNotIn("run('driver-build'",raw);self.assertNotIn("[GO,'test'",raw)
        self.assertIn("'GOMAXPROCS':'2','GOMEMLIMIT':'768MiB'",raw);self.assertIn("'GOPROXY':'off'",raw)
    def test_phase_accounting_own_volatile_tmp_absence_only(self):
        with tempfile.TemporaryDirectory() as temp:
            root=Path(temp);(root/'tmp').mkdir();(root/'source').mkdir();(root/'source/input').write_bytes(b'abc')
            self.assertEqual(b.work_volume(root),3)
            (root/'foreign-link').symlink_to(root/'source/input')
            with self.assertRaises(RuntimeError):b.work_volume(root)

if __name__=='__main__':unittest.main()
