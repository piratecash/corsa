# Single short census component — runtime SOURCE rebind

SOURCE ONLY. No VM/claim/lock/process is created here. `FROZEN.PENDING.json` contains actual compiled helper/diagnostic source DATA pins; `FROZEN.json` is deliberately absent until Root accepts those saved results and the source package. Original periodic540/reconnect225 profiles, failed runs and archives remain unchanged.

This is **COMPONENT_CENSUS_DIAGNOSTIC**, transported as `reconnect` by the existing pinned Native worker7b75/kernel9ffe. Host HANDOFF/expected metadata require the explicit component purpose. The native worker profile/event format remains `d1-o1a-native-v1` for byte-compatible transport; four native events, RAW bounds, fences, independent stopped ACK and all actual input checks are unchanged. No ordinary O‑1a metric admission, bandwidth conclusion or public activation follows from this component result.

The dedicated profile f848 has startup lead10s/duration20s/window2..15s/disconnect6s/Go timeout90s; original two Off-role Full nodes and10k route setup, no new FIND_NODE traffic. The C test wrapper120s preserves the original+30 margin; guest/host outer600/610/620/export30/650 and660/680/698/700 stay unchanged. A short startup/reconnect/readiness refusal is retained rather than automatically extending the window or repeating the run.

After actual helper DATA acceptance, Root may promote the pending reference by a DATA-only JSON copy with `status=ACTUAL_HELPERS_BOUND_NOT_RUNTIME`. Fresh source SUMS readback is required before entry, as with the accepted parent binder. It then invokes:

```
python3 prepare.py /ABS/accepted-kernel/result.json /ABS/component-pack/RESULT.json
```

The accepted parent kernel qualification and all input hashes remain in effect. The pack must be `COMPONENT_INITRD_BYTE_VERIFIED`, one output `reconnect`, with component assembly scope/source1348/c60. All same-kernel inputs/helper result references are rehashed. The parent accepted finalizer reconnect archive/boot record is the immutable comparison reference.

The exact allowed archive change is seventeen payloads plus boot: nine diagnostic Go sources (six changes/three additions), the same four newly rebuilt baseline+diagnostic ELFs, PID1/capexec/exporter, and component `config/reconnect.json`; one new source/censusdiag directory. The three finalizer Go posts and all other original640 SUT/705 stand paths remain byte-identical. New selected count1348/stand7086aac. The binder verifies whole member inventory/metadata equality outside that set, plus exact boot inventory deltas and fresh attempt. Audited fixture/nft0555 modes remain mandatory.

Generated `support.py`/`ack.py` are byte-exact accepted originals. `check_capture`, `check_lifecycle` and `successful_guest` function bodies are unchanged. `launch.py` changes only strict purpose/workload/assembly source bindings and adds the purpose to retained expected/receipt metadata. `verify.py` changes only reconnect profile SHA f848, input count1366 and result scope. It accepts no original metric profile. Existing `replay()` requires exact Go PASS/export and yields component transport evidence pending journal review. On a normal Go FAIL, use the unchanged stopped lifecycle/guest-receipt checks and saved capsule bytes to localize the closed diagnostic; do not convert that failure into functional PASS or invoke a standard O‑1a admission checker. Hidden/unsaved cause remains UNKNOWN.

The newly generated runtime has CODE/ROOT false and cannot start. Root and independent reviewer must first accept complete actual archive/member/config readback and source hashes, then Root alone promotes readiness and runs a fresh single component. No old480s run is repeated. No helper/source rebuild, new kernel/worker, resources, schema/clock gate or acceptance threshold is introduced by this binder.
