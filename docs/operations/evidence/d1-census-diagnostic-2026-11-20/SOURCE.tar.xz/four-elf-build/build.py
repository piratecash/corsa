"""Compile four original baseline targets with exact tested census diagnostics; never run ELF."""

import argparse
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import shutil
import signal
import sys
import tarfile
import time
import uuid

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
REPO = HERE.parents[4]
BASE = HERE.parents[1] / "2026-11-17/d1-o1a-v2672-baseline"
ORIGINAL = HERE.parents[1] / "2026-11-17/d1-o1a-v2672-build"
PLAN = HERE
QA = HERE.parent / "d1-o1a-census-diagnostic-goqa-v1"
TESTED_SOURCE = Path("/private/tmp/corsa-d1-census-diagnostic-goqa-67b5e77b36a348158c4e3c0c046974b5/SOURCE-MANIFEST.json")
VALIDATOR_RESULT = Path("/private/tmp/corsa-d1-o1a-census-component-validator-2b738a367413495499af3b1c239e838a/RESULT.json")
HELPERS = HERE.parents[1] / "2026-11-12"
TIMED = HELPERS / "d1-full512-timed-build-runner"
ELF = HELPERS / "d1-full512-native-inputs"
sys.path[:0] = list(map(str, (BASE, TIMED, ELF)))
from check_linux_graph import summarize
from package_initrd import require_static_arm64
sys.path.insert(0, str(HERE))
from process import UnconfirmedProcess, run

COMMIT = "4fcc2f7245095fc43d2225f0f0065f4ce3b26113"
GOROOT = Path("/usr/local/go")
GO = GOROOT / "bin/go"
LOCK = Path("/private/tmp/corsa-heavy-run.lock")
WORK = LOCK.parent / ("corsa-o1a-census-diagnostic-elf-build-" + uuid.uuid4().hex)
GIB, MIB = 1024**3, 1024**2
NODE = "github.com/piratecash/corsa/internal/core/node"
APPS = "github.com/piratecash/corsa/internal/testutil/loadstand/"
STAGES = (
    ("NODE", "node.test", ["test", "-c"], "./internal/core/node", NODE + ".test"),
    ("fullnode", "loadstand-full", ["build"], "./internal/testutil/loadstand/fullnode", APPS + "fullnode"),
    ("linuxhelper", "loadstand-linuxhelper", ["build"], "./internal/testutil/loadstand/linuxhelper", APPS + "linuxhelper"),
    ("sdkedge", "loadstand-sdkedge", ["build"], "./internal/testutil/loadstand/sdkedge", APPS + "sdkedge"),
)
OPTIONS = ["-mod=readonly", "-trimpath", "-buildvcs=false"]
TARGET = {"GOOS": "linux", "GOARCH": "arm64", "GOARM64": "v8.0", "CGO_ENABLED": "0"}


def digest(path):
    checksum = hashlib.sha256()
    with path.open("rb") as source:
        for chunk in iter(lambda: source.read(MIB), b""):
            checksum.update(chunk)
    return checksum.hexdigest()


def need(condition, reason):
    if not condition:
        raise ValueError(reason)


def bound_files():
    return [HERE / name for name in ("build.py", "process.py", "test_build.py", "PROFILE.ru.md")] + [
        ORIGINAL / "REQUEST.json", ORIGINAL / "source.tar.gz", BASE / "check_linux_graph.py",
        QA / "MANIFEST.json", TESTED_SOURCE, VALIDATOR_RESULT,
        HERE.parent / "d1-o1a-census-component-profile-v1/component.json",
        BASE / "LINUX-INPUTS.json", BASE / "SOURCE.txt", ELF / "package_initrd.py", GO,
        GOROOT / "pkg/tool/darwin_arm64/compile", GOROOT / "pkg/tool/darwin_arm64/link",
        GOROOT / "pkg/tool/darwin_arm64/asm",
        PLAN / "SOURCE-PLAN.json", PLAN / "GRAPH-EXPECTATIONS.json",
        PLAN / "measured.expected.manifest", PLAN / "stand.expected.manifest",
        *[PLAN / "posts" / name for name in sorted(overlay_pins())],
    ]


def overlay_pins():
    return json.loads((PLAN / "SOURCE-PLAN.json").read_bytes())["allowed_overlay_files"]


def check_request(request_path):
    need(digest(ORIGINAL / "REQUEST.json") == "745eefbb111b761e76556cc51e02dd735d0baa88779a23237bc336f8aeef30a8", "original request differs")
    need(digest(ORIGINAL / "source.tar.gz") == "7c24787328e87934d135471171b75ed4bf5a91ca558d4de8b4e06711842607ea", "original export differs")
    need(digest(QA / "MANIFEST.json") == "f83819d0d4c30bd2592b0b2f792646664cb75ea82fd771fb38ea50dd92bc3750", "combined tested posts changed")
    need(digest(TESTED_SOURCE) == "1a4d80bf5a8861e032bb344b2ca5e9d4b6a2e67f24b40731e915c5c976b1e5a3", "tested full source changed")
    need(digest(VALIDATOR_RESULT) == "a05d9d0543d53fff65156de6dcb3fba2a1bbe67872ec8709f59c018f8d685754", "original Go validator result changed")
    original = json.loads((ORIGINAL / "REQUEST.json").read_bytes())
    need(original["commit"] == COMMIT and all(digest(Path(name)) == value for name, value in original["files"].items()), "original pinned inputs changed")
    raw = request_path.read_bytes()
    request = json.loads(raw)
    need(request == {"commit": COMMIT, "files": {str(p): digest(p) for p in bound_files()}},
         "build source, tools or manifest changed")
    return hashlib.sha256(raw).hexdigest()


def graph_matches(actual, expected):
    # The stream includes absolute paths under the new export and Go cache.
    return all(actual[key] == value for key, value in expected.items() if key != "graph_sha256")


def buildinfo_matches(info, package, modules):
    lines = info.splitlines()
    need(lines and lines[0].endswith(": go1.27.4") and f"\tpath\t{package}" in lines,
         "wrong toolchain or build path")
    dependencies, settings = {}, {}
    for line in lines[1:]:
        row = line.strip().split("\t")
        if row[0] == "dep":
            need(len(row) == 4 and row[1] not in dependencies, "invalid dependency metadata")
            dependencies[row[1]] = {"version": row[2], "sum": row[3]}
        if row[0] == "build":
            need(len(row) == 2 and "=" in row[1], "invalid build setting")
            name, value = row[1].split("=", 1)
            need(name not in settings, "duplicate build setting")
            settings[name] = value
    need(dependencies == modules, "compiled module closure changed")
    need(all(settings.get(k) == v for k, v in (TARGET | {"-trimpath": "true"}).items()),
         "wrong target or build flags")


def build_env(work):
    return TARGET | {
        "PATH": "/usr/bin:/bin", "GOROOT": str(GOROOT), "GOTOOLCHAIN": "local",
        "GOENV": "off", "GOWORK": "off", "GOTELEMETRY": "off", "GOPROXY": "off",
        "GOSUMDB": "off", "GOVCS": "*:off", "GOMAXPROCS": "2", "GOMEMLIMIT": "768MiB",
        "GOCACHE": str(work / "cache"), "GOMODCACHE": str(REPO / ".gomodcache"),
        "GOPATH": str(work / "gopath"), "GOTMPDIR": str(work / "tmp"), "TMPDIR": str(work / "tmp"),
        "LANG": "C", "LC_ALL": "C",
    }


def build_command(work, args):
    policy = '(version 1) (allow default) (deny network*) (deny file-write*) ' + (
        f'(allow file-write* (subpath {json.dumps(str(work))}) (literal "/dev/null")) '
        f'(deny file-write* (subpath {json.dumps(str(work / "source"))}))'
    )
    return ["/usr/bin/sandbox-exec", "-p", policy, str(GO), *args]


def check_space(work):
    need(shutil.disk_usage(work).free >= 10 * GIB, "less than 10 GiB free")
    if work != LOCK.parent:
        used = sum(p.stat().st_size for p in work.rglob("*") if p.is_file() and not p.is_symlink())
        need(used <= 6 * GIB, "workspace exceeded 6 GiB")


def inventory(source):
    result = {}
    for entry in source.rglob("*"):
        need(not entry.is_symlink(), "link appeared in source")
        if entry.is_file():
            result[entry.relative_to(source).as_posix()] = digest(entry)
        else:
            need(entry.is_dir(), "irregular source input")
    return dict(sorted(result.items()))


def checked_overlay(before, posts, pins):
    need(set(posts) == set(pins) and len(pins) == 12, "exact twelve tested posts required")
    after = dict(before)
    for name, pin in pins.items():
        path = PurePosixPath(name)
        need(name == path.as_posix() and not path.is_absolute() and ".." not in path.parts
             and name.startswith("internal/testutil/loadstand/"), "overlay outside closed stand")
        if pin["before_sha256"] is None:
            need(name not in before, "new post collides with original source")
        else:
            need(before.get(name) == pin["before_sha256"], "overlay before differs")
        need(hashlib.sha256(posts[name]).hexdigest() == pin["after_sha256"], "overlay after differs")
        after[name] = pin["after_sha256"]
    need({n for n in set(before) | set(after) if before.get(n) != after.get(n)} == set(pins), "overlay delta differs")
    need(len(after) == len(before) + 3, "exactly three new stand source files required")
    return dict(sorted(after.items()))


def export_source(work):
    source = work / "source"
    source.mkdir(mode=0o700)
    wanted = {}
    with tarfile.open(ORIGINAL / "source.tar.gz", "r:gz") as archive:
        need(archive.pax_headers.get("comment") == COMMIT, "archive commit differs")
        members = archive.getmembers()
        need(len(members) <= 10000, "source archive inventory exceeded")
        paths = set()
        for entry in members:
            path = PurePosixPath(entry.name)
            need(path.parts and not path.is_absolute() and ".." not in path.parts
                 and path not in paths and (entry.isdir() or entry.isfile()), "unexpected source archive member")
            paths.add(path)
            if entry.isfile():
                need(0 <= entry.size <= 16 * MIB, "source file exceeded")
                with archive.extractfile(entry) as inp:
                    data = inp.read(entry.size + 1)
                need(len(data) == entry.size, "source archive truncated")
                wanted[path.as_posix()] = hashlib.sha256(data).hexdigest()
        archive.extractall(source, members=members)
    before = inventory(source)
    need(before == wanted, "extracted full source differs")
    pins = overlay_pins()
    posts = {name:(PLAN / "posts" / name).read_bytes() for name in pins}
    expected = checked_overlay(before, posts, pins)
    for name, raw in posts.items():
        target = source / name
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(raw)
    after = inventory(source)
    need(after == expected, "full source after overlay differs")
    need(after == json.loads(TESTED_SOURCE.read_bytes()) and len(after) == 2450, "artifact source is not exact tested subject or contains QA-only validator")
    for name, data in (("source-before.json", before), ("source-after.json", after)):
        (work / name).write_text(json.dumps(data, indent=2, sort_keys=True) + "\n")
    return source


def execute(request, approved):
    origin = time.monotonic()
    need(check_request(request) == approved, "exact request hash required")
    check_space(LOCK.parent)
    need(not os.path.lexists(WORK), "work directory already exists")
    interrupted = False

    def stop(_sig, _frame):
        nonlocal interrupted
        interrupted = True

    for sig in (signal.SIGINT, signal.SIGTERM):
        signal.signal(sig, stop)
    LOCK.mkdir(mode=0o700)
    owner = LOCK / "owner"
    claim = f"{os.getpid()} {approved}\n"
    owner.write_text(claim)
    stamp = LOCK.stat().st_ino, owner.stat().st_ino
    safe, owned_work = True, False
    try:
        WORK.mkdir(mode=0o700)
        owned_work = True
        for name in ("cache", "tmp", "gopath", "raw"):
            (WORK / name).mkdir(mode=0o700)
        source = export_source(WORK)
        expected = {key:value["expected_semantic_graph"] for key,value in json.loads((PLAN / "GRAPH-EXPECTATIONS.json").read_bytes()).items()}
        env = build_env(WORK)
        absolute_end = origin + 1200

        def go(label, args, limit=MIB):
            out, err = run(build_command(WORK, args), env=env, cwd=source, raw=WORK / "raw", label=label,
                           work_end=phase_end, cleanup_end=phase_end + 30,
                           stopped=lambda: interrupted, stdout_limit=limit)
            need(err.stat().st_size == 0, f"{label} emitted stderr")
            return out

        artifacts = {}
        for key, artifact, operation, target, package in STAGES:
            phase_end = min(time.monotonic() + 600, absolute_end)
            check_space(WORK)
            need(check_request(request) == approved, "request changed between build stages")
            list_flags = ["-test"] if key == "NODE" else []

            def check_graph(boundary):
                graph = go(f"{key}-{boundary}", ["list", *OPTIONS, "-deps", "-json", *list_flags, target], 4 * MIB)
                need(graph_matches(summarize(graph, source, WORK / "cache"), expected[key]),
                     f"{key} selected a different graph at {boundary}")

            check_graph("before")
            output = WORK / artifact
            go(f"{key}-compile", [*operation, "-p=1", *OPTIONS, "-o", str(output), target])
            need(output.resolve(strict=True) == output and output.is_file() and 0 < output.stat().st_size <= 96 * MIB,
                 f"{key} unexpected artifact")
            elf = output.read_bytes()
            require_static_arm64(elf)
            if key == "NODE":
                need((NODE + ".TestLoadStandLinuxRouteWireNative").encode() + b"\0" in elf,
                     "O-1a test symbol missing")
            info = go(f"{key}-metadata", ["version", "-m", str(output)]).read_text()
            buildinfo_matches(info, package, expected[key]["modules"])
            check_graph("after")
            check_space(WORK)
            need(check_request(request) == approved, "inputs changed during build")
            need(not interrupted and time.monotonic() < phase_end, "build phase expired")
            artifacts[artifact] = {"sha256": digest(output), "bytes": output.stat().st_size}
        need(inventory(source) == json.loads((WORK / "source-after.json").read_bytes()), "source changed during compilation")
        result = {"status": "BUILT_NOT_EXECUTED", "subject": "COMPONENT_ONLY_BASELINE_PLUS_EXACT_FINALIZER_AND_CLOSED_CENSUS_DIAGNOSTICS", "commit": COMMIT, "request": approved, "artifacts": artifacts, "source_groups_original_Go_API": json.loads((PLAN / "SOURCE-PLAN.json").read_bytes())["source_groups"], "source_before_sha256": digest(WORK / "source-before.json"), "source_after_sha256": digest(WORK / "source-after.json"), "commands": [json.loads(path.read_bytes()) for path in sorted((WORK / "raw").glob("*.process.json"))]}
        (WORK / "result.json").write_text(json.dumps(result, indent=2) + "\n")
    except UnconfirmedProcess:
        safe = False
        (WORK / "result.json").write_text(json.dumps({"status":"RECOVERY_REQUIRED", "reason":"own process group closure UNKNOWN", "work":str(WORK), "lock":str(LOCK), "owner":claim})+"\n")
        raise
    except (OSError, ValueError, tarfile.TarError) as exc:
        if owned_work:
            (WORK / "result.json").write_text(json.dumps({"status": "REFUSED", "error": str(exc)}) + "\n")
        raise
    finally:
        if safe:
            need((LOCK.stat().st_ino, owner.stat().st_ino) == stamp and owner.read_text() == claim,
                 "lock ownership changed")
            owner.unlink()
            LOCK.rmdir()
        else:
            print(json.dumps({"status":"HOLD", "work":str(WORK), "reason":"own process group closure UNKNOWN; lock retained"}), flush=True)
            while True:
                time.sleep(1)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--execute", metavar="APPROVED_REQUEST_SHA256")
    args = parser.parse_args()
    request = HERE / "REQUEST.json"
    try:
        if args.execute:
            execute(request, args.execute)
        else:
            print(check_request(request))
    except (OSError, ValueError, tarfile.TarError, UnconfirmedProcess) as error:
        parser.exit(1, f"O-1a baseline build refused: {error}\n")
