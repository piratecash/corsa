# Four original diagnostic baseline targets

SOURCE-only prepared controller. REQUEST SHA-256 `20f2882cf7525868a7c557e957436e843b24f0b0ea3f82247bee2254ab8cbd02`. Root may execute only after CODE/read-only preflight and known closure of the previous heavy job. No app/ELF/VM execution in this job.

Read-only preflight:
```sh
python3 /Users/hades/Documents/repos/corsa/docs/_internal/d1-artifacts/2026-11-20/d1-o1a-census-diagnostic-elf-build-v1/build.py
```
One compile-only job:
```sh
python3 /Users/hades/Documents/repos/corsa/docs/_internal/d1-artifacts/2026-11-20/d1-o1a-census-diagnostic-elf-build-v1/build.py --execute 20f2882cf7525868a7c557e957436e843b24f0b0ea3f82247bee2254ab8cbd02
```

Accepted parent builder/process retains deadlines/flags/offline/UNKNOWN liveHOLD. Scope is COMPONENT_CENSUS_DIAGNOSTIC. Immutable original4fcc export +12exact combined posts from GoQA MANIFESTf83819… produces the exact tested2450 full files/1348selected sourcefiles; host-QA validator file is absent. Original Go source API already PASS640b70de/7086aac… on that exact source. All4semanticgraphs may differ only in selected permitted post hashes and ONE new stdlib-only censusdiag package/file; module closures26/23/5/23 and Node generatedtestmain remain exact. No source wildcard or module relaxation.

Seven inherited pure controller testfunctions pass, plus actual readonly input/provenance check. Artifact SHA/metadata and graph streams are NOT_BUILT until Root execution. Source/archive/helper/runtime preparation is separate. Original failedperiodic, original metric profiles, oldELFs and currentFullResponder subjects stay separate.
