# Четыре diagnostic baseline ELF, compile-only

Один job исходного4fcc+точных3finalizer+9diagnostic posts. Scope COMPONENT_CENSUS_DIAGNOSTIC, не current FullResponder, не O‑1a metric admission и не повтор480с. Никаких QA-only validator файлов в artifact subject.

Прежние четыре последовательные цели/flags: Node `go test -c ./internal/core/node`, Full/helper/SDK `go build` соответствующих прежних entrypoints; `-p=1 -mod=readonly -trimpath -buildvcs=false -o OWN_OUTPUT`. Локальный Go1.27.4, GOOSlinux/GOARCHarm64/GOARM64v8.0/CGO0; прежние26/23/5/23module version+sums, без tags/добавочныхldflags. До/после — полный semantic graph; Node generatedtestmain прежний, новая stdlib-only censusdiag package единственная добавка. Только чтение ELF/BuildInfo, никаких запусков.

600с на фазу внутри общего1200с рабочего бюджета+30с очистки, heavy-lock. GOMAXPROCS2/GOMEMLIMIT768MiB/-p1 мягкие; aggregate host hardcaps/no-swap и жёсткой diskquota нет. До6GiB своих файлов по фазовым проверкам, ≥10GiB свободно. stdout1MiB (graph4MiB),stderr1MiB накоманду. Сеть запрещена sandbox, write вimmutable sourceinputs/посторонние каталоги запрещён; localdeps/cache только.

Ошибка/OOM/timeout/неполныеmetadata/неожиданныйgraph — STOP без повтора/скачиваний/росталимитов. Неизвестное закрытие ownPID/PGID сохраняет result и liveHOLD с исходным ownlock; OSError/EPERM не считается отсутствием. Только свои ресурсы. Source/archive/profile/preexisting failed baselines сохраняются. ЗависшийFS может превысить программные сроки.

Это только четыре сборки. Source archive/новые componenthelpers, data initrd/runtime, Corsa/пираtecashd/VM, Go выполнение тестов, коммит и выпуск в этот job не входят. Оригинальные GoQA/валидатор уже имеют отдельные фактические результаты; их metadata закреплены во входах. Клиентские/демонные сети не запускаются.
