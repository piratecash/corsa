import errno
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
import build
import process

class LeaveHold(BaseException):pass

class BuildTests(unittest.TestCase):
 def test_original_four_targets_and_flags_retained(self):
  self.assertEqual([(s[0],s[1],s[2],s[3]) for s in build.STAGES],[('NODE','node.test',['test','-c'],'./internal/core/node'),('fullnode','loadstand-full',['build'],'./internal/testutil/loadstand/fullnode'),('linuxhelper','loadstand-linuxhelper',['build'],'./internal/testutil/loadstand/linuxhelper'),('sdkedge','loadstand-sdkedge',['build'],'./internal/testutil/loadstand/sdkedge')])
  self.assertEqual(build.OPTIONS,['-mod=readonly','-trimpath','-buildvcs=false'])
  self.assertEqual(build.build_env(Path('/private/tmp/fixture'))['GOPROXY'],'off')
 def test_semantic_graph_is_exact_except_relocated_stream_hash(self):
  old={'graph_sha256':'old','tracked_files':{'a.go':'before'},'module_count':5}
  self.assertTrue(build.graph_matches(old|{'graph_sha256':'new'},old))
  for delta in ({'tracked_files':{'a.go':'new'}},{'module_count':6}):
   self.assertFalse(build.graph_matches(old|delta,old))
 def test_buildinfo_closure_and_abi(self):
  deps={'example.org/module':{'version':'v1.2.3','sum':'h1:test'}}
  info='\n'.join(['node.test: go1.27.4',f'\tpath\t{build.NODE}.test','\tdep\texample.org/module\tv1.2.3\th1:test']+[f'\tbuild\t{k}={v}' for k,v in (build.TARGET|{'-trimpath':'true'}).items()])
  build.buildinfo_matches(info,build.NODE+'.test',deps)
  for broken in (info.replace('go1.27.4','go1.27.3'),info.replace('arm64','amd64'),info.replace('h1:test','h1:changed'),info+'\n\tbuild\tGOOS=linux'):
   with self.subTest(broken=broken),self.assertRaises(ValueError):build.buildinfo_matches(broken,build.NODE+'.test',deps)
 def test_unknown_group_is_never_absent(self):
  for exc in (PermissionError(errno.EPERM,'denied'),OSError(errno.EIO,'unknown')):
   with patch.object(process.os,'killpg',side_effect=exc):self.assertTrue(process.group_present(12345))
  with patch.object(process.os,'killpg',side_effect=ProcessLookupError()):self.assertFalse(process.group_present(12345))
 def test_exact_existing_overlay_and_refusal(self):
  pins=build.overlay_pins();before={n:p['before_sha256'] for n,p in pins.items() if p['before_sha256'] is not None}
  posts={n:(build.PLAN/'posts'/n).read_bytes() for n in pins}
  got=build.checked_overlay(before,posts,pins)
  self.assertEqual(got,{n:p['after_sha256'] for n,p in pins.items()})
  with self.assertRaisesRegex(ValueError,'twelve tested'):build.checked_overlay(before,posts|{'extra.go':b'bad'},pins)
  changed=dict(before);changed[next(iter(changed))]='wrong'
  with self.assertRaisesRegex(ValueError,'before differs'):build.checked_overlay(changed,posts,pins)
 def test_wrong_approval_never_claims_lock(self):
  with tempfile.TemporaryDirectory() as folder,patch.object(build,'check_request',return_value='expected'):
   lock=Path(folder)/'lock'
   with patch.object(build,'LOCK',lock),self.assertRaisesRegex(ValueError,'exact request'):build.execute(None,'wrong')
   self.assertFalse(lock.exists())
 def test_sequence_stop_and_unknown_hold_persist_result(self):
  expected={k:v['expected_semantic_graph'] for k,v in json.loads((build.PLAN/'GRAPH-EXPECTATIONS.json').read_bytes()).items()}
  for failure in (None,ValueError('compile failed'),build.UnconfirmedProcess('unknown closure')):
   with self.subTest(failure=failure),tempfile.TemporaryDirectory() as folder:
    work,lock=Path(folder).resolve()/'work',Path(folder).resolve()/'lock';compiled=[]
    def fake_export(own):
     src=own/'source';src.mkdir()
     for name in ('source-before.json','source-after.json'):(own/name).write_text('{}\n')
     return src
    def fake_run(argv,*,raw,label,**_opts):
     if label.endswith('-compile'):
      compiled.append(label)
      if label=='fullnode-compile' and failure:raise failure
      Path(argv[argv.index('-o')+1]).write_bytes((build.NODE+'.TestLoadStandLinuxRouteWireNative').encode()+b'\0')
     out,err=raw/(label+'.stdout'),raw/(label+'.stderr');out.touch();err.touch();return out,err
    with patch.multiple(build,WORK=work,LOCK=lock,run=fake_run,check_request=lambda _:'approved',check_space=lambda _:None,export_source=fake_export,summarize=lambda g,*_:expected[g.name.split('-')[0]],require_static_arm64=lambda _:None,buildinfo_matches=lambda *_:None),patch.object(build.signal,'signal'),patch.object(build.time,'sleep',side_effect=LeaveHold):
     if failure:
      with self.assertRaises(LeaveHold if isinstance(failure,build.UnconfirmedProcess) else ValueError):build.execute(None,'approved')
     else:build.execute(None,'approved')
    status='RECOVERY_REQUIRED' if isinstance(failure,build.UnconfirmedProcess) else 'REFUSED' if failure else 'BUILT_NOT_EXECUTED'
    self.assertEqual(json.loads((work/'result.json').read_bytes())['status'],status)
    self.assertEqual(lock.exists(),status=='RECOVERY_REQUIRED')
    self.assertEqual(compiled,[s[0]+'-compile' for s in build.STAGES[:2 if failure else 4]])

if __name__=='__main__':unittest.main()
