import copy,json,unittest
import prepare as p

class Tests(unittest.TestCase):
 def setUp(self):
  self.old=p.old_data()['actual_four_ELF']
  # Fixture-only replacement values; never written to BINDING/INPUTS/runtime.
  self.new={n:{'bytes':v['bytes']+i+1,'sha256':str(i+1)*64} for i,(n,v) in enumerate(self.old.items())}
  self.profile=p.read(p.PROFILE)
 def test_go_change_only_four_artifacts_archive_count_and_component_profile(self):
  root=p.DATA/'pid1-source';config=p.read(root/'cmd/o1a-init/config.go');frozen=p.read(root/'cmd/o1a-init/frozen.go');exporter=p.read(root/'cmd/journal-export/main.go')
  got,fg,ex=p.go_sources(config,frozen,exporter,self.old,self.new,'a'*64,self.profile)
  self.assertIn(b'const SourceFiles=1348',got);self.assertIn(('const SourceArchiveSHA="'+'a'*64+'"').encode(),got)
  self.assertEqual(ex,exporter.replace(p.OLD_PROFILE_SHA.encode(),p.PROFILE_SHA.encode()))
  self.assertIn(p.PROFILE_SHA.encode(),fg);self.assertIn(b'Bytes:862',fg)
  self.assertEqual(got.replace(b'const SourceFiles=1348',b'const SourceFiles=1345').replace(('const SourceArchiveSHA="'+'a'*64+'"').encode(),('const SourceArchiveSHA="'+p.OLD_ARCHIVE+'"').encode()),config)
 def test_c_policy_argv_unchanged_except_exact_timeout_and_data_header(self):
  root=p.DATA/'capexec-source';oldcap=p.read(root/'capexec.c');oldhead=p.read(root/'frozen_inputs.h')
  header,cap=p.c_sources(oldhead,oldcap,self.old,self.new,self.profile)
  self.assertEqual(cap.replace(b'"-test.timeout=120s"',b'"-test.timeout=255s"'),oldcap)
  self.assertIn(b'"-test.timeout=570s"',cap)
  for n,macro in p.MACROS.items():self.assertIn(('#define '+macro+' "'+self.new[n]['sha256']+'"').encode(),header)
  self.assertEqual(p.file_sha(root/'guest_policy.h'),'699c0a05f15cdf93c620326a2bc1112b53932f06dc08bd6a343076b22416162c')
 def test_literal_refusal_does_not_silently_change_unknown_source(self):
  with self.assertRaisesRegex(ValueError,'missing/ambiguous'):p.one(b'not expected',b'old',b'new')
  with self.assertRaisesRegex(ValueError,'missing/ambiguous'):p.one(b'oldold',b'old',b'new')
 def test_pending_package_has_no_runtime_or_fabricated_binding(self):
  self.assertFalse((p.HERE/'BINDING.json').exists());self.assertFalse((p.HERE/'INPUTS.json').exists())
  self.assertEqual(p.REQUEST,'20f2882cf7525868a7c557e957436e843b24f0b0ea3f82247bee2254ab8cbd02')
  self.assertEqual(p.file_sha(p.PROFILE),p.PROFILE_SHA)

if __name__=='__main__':unittest.main()
