"""Data-only component inputs; refused until exact actual four-ELF binding exists."""
import argparse,copy,difflib,hashlib,importlib.util,json,os,re,stat,sys,uuid
from pathlib import Path
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent;DAY=HERE.parent
BUILD=DAY/'d1-o1a-census-diagnostic-elf-build-v1'
QA=DAY/'d1-o1a-census-diagnostic-goqa-v1'
BASE=DAY.parent/'2026-11-17/d1-o1a-v2672-build'
DATA=Path('/private/tmp/corsa-o1a-baseline-finalizer-inputs-cc481326e8504a94a20da6c792be66c4')
PACKER=DAY.parent/'2026-11-18/d1-o1a-guest-source-inputs/prepare_sources.py'
PROFILE=DAY/'d1-o1a-census-component-profile-v1/component.json'
VALIDATOR=Path('/private/tmp/corsa-d1-o1a-census-component-validator-2b738a367413495499af3b1c239e838a/RESULT.json')
TESTED=Path('/private/tmp/corsa-d1-census-diagnostic-goqa-67b5e77b36a348158c4e3c0c046974b5/SOURCE-MANIFEST.json')
REQUEST='20f2882cf7525868a7c557e957436e843b24f0b0ea3f82247bee2254ab8cbd02'
COMMIT='4fcc2f7245095fc43d2225f0f0065f4ce3b26113'
PROFILE_SHA='f84856cfa6f3c3d39f4f5d69487c5d968106aeea77b16f8a3d7bf864266e7369'
OLD_PROFILE_SHA='36a65318713e5b4cb795749a4a5e12424cdfe905760f3a352b7ac602040621de'
OLD_ARCHIVE='71569cb33f466e7d3a896bcdf6e4fd2463b333db3b45339ae70c0661b20763c9'
NAMES=('node.test','loadstand-full','loadstand-linuxhelper','loadstand-sdkedge')
MACROS={'node.test':'NODE_SHA','loadstand-full':'FULL_SHA','loadstand-linuxhelper':'HELPER_SHA','loadstand-sdkedge':'TARGET_SHA'}
def need(v,s):
 if not v:raise ValueError(s)
def sha(raw):return hashlib.sha256(raw).hexdigest()
def read(path,cap=2*1024**2):
 s=path.lstat();need(stat.S_ISREG(s.st_mode) and s.st_size<=cap,'bounded regular input')
 with path.open('rb') as f:raw=f.read(s.st_size+1)
 need(len(raw)==s.st_size,'input changed');return raw
def file_sha(path,cap=96*1024**2):
 s=path.lstat();need(stat.S_ISREG(s.st_mode) and s.st_size<=cap,'bounded regular input');h=hashlib.sha256();left=s.st_size
 with path.open('rb') as f:
  while left:
   raw=f.read(min(left,1024**2));need(raw,'truncated input');h.update(raw);left-=len(raw)
  need(not f.read(1),'growing input')
 a=path.lstat();key=lambda x:(x.st_dev,x.st_ino,x.st_mode,x.st_uid,x.st_gid,x.st_nlink,x.st_size,x.st_mtime_ns,x.st_ctime_ns)
 need(key(a)==key(s),'input identity changed');return h.hexdigest()
def one(raw,old,new):need(raw.count(old)==1,'missing/ambiguous literal');return raw.replace(old,new)
def old_data():
 need(file_sha(DATA/'RESULT.json')=='d41d1bd2f6566efe611cd6db92355b735e9b1e8074c828e01dde15d8ae1b73e5','old source receipt changed')
 return json.loads(read(DATA/'RESULT.json'))
def stage_binding(path,result_sha):
 need(re.fullmatch('[0-9a-f]{64}',result_sha) is not None and file_sha(path)==result_sha,'actual result SHA')
 r=json.loads(read(path));need(r['status']=='BUILT_NOT_EXECUTED' and r['request']==REQUEST and r['commit']==COMMIT and set(r['artifacts'])==set(NAMES),'actual compiler subject')
 source=path.parent/'source-after.json';need(file_sha(source)==r['source_after_sha256'] and json.loads(read(source))==json.loads(read(TESTED)),'artifact subject differs/QA-only validator leaked')
 for n,row in r['artifacts'].items():need(0<row['bytes']<=96*1024**2 and file_sha(path.parent/n)==row['sha256'] and (path.parent/n).stat().st_size==row['bytes'],'artifact bytes')
 need(len(r['commands'])==16 and all(c['returncode']==0 and c['closure']=='CONFIRMED_ABSENT' for c in r['commands']),'compiler command closure')
 return {'scope':'ACTUAL_COMPONENT_FOUR_ELF_DATA_ONLY','result':str(path),'result_sha256':result_sha,'request_sha256':REQUEST,'artifacts':r['artifacts'],'source_after':str(source),'source_after_sha256':r['source_after_sha256']}
def checked_binding():
 b=json.loads(read(HERE/'BINDING.json'));need(stage_binding(Path(b['result']),b['result_sha256'])==b,'binding differs');return b

def go_sources(raw_config,raw_frozen,raw_exporter,old,new,archive,profile):
 config=one(raw_config,('const SourceArchiveSHA="'+OLD_ARCHIVE+'"').encode(),('const SourceArchiveSHA="'+archive+'"').encode())
 config=one(config,b'const SourceFiles=1345',b'const SourceFiles=1348')
 frozen=raw_frozen
 for n in NAMES:
  a=f'"/bin/{n}":{{Bytes:{old[n]["bytes"]},SHA256:"{old[n]["sha256"]}"}}'.encode();z=f'"/bin/{n}":{{Bytes:{new[n]["bytes"]},SHA256:"{new[n]["sha256"]}"}}'.encode();frozen=one(frozen,a,z)
 frozen=one(frozen,('"reconnect":'+json.dumps(read(BASE.parent/'d1-o1a-v2672-baseline/reconnect.json').decode())+',').encode(),('"reconnect":'+json.dumps(profile.decode())+',').encode())
 frozen=one(frozen,('"/config/reconnect.json":{Bytes:853,SHA256:"'+OLD_PROFILE_SHA+'"}').encode(),('"/config/reconnect.json":{Bytes:'+str(len(profile))+',SHA256:"'+PROFILE_SHA+'"}').encode())
 exporter=one(raw_exporter,OLD_PROFILE_SHA.encode(),PROFILE_SHA.encode())
 return config,frozen,exporter

def c_sources(raw_header,raw_capexec,old,new,profile):
 header=raw_header
 for n,macro in MACROS.items():header=one(header,('#define '+macro+' "'+old[n]['sha256']+'"').encode(),('#define '+macro+' "'+new[n]['sha256']+'"').encode())
 old_profile=read(BASE.parent/'d1-o1a-v2672-baseline/reconnect.json')
 header=one(header,('static const char profile_reconnect[] = '+json.dumps(old_profile.decode())+';').encode(),('static const char profile_reconnect[] = '+json.dumps(profile.decode())+';').encode())
 capexec=one(raw_capexec,b'"-test.timeout=255s"',b'"-test.timeout=120s"')
 return header,capexec

def template_rebind(template,files,new,archive,profile):
 out=copy.deepcopy(template);cfg=out['config'];need(out['status']=='TEMPLATE_NOT_RUNNABLE' and cfg['source_archive_sha256']==OLD_ARCHIVE,'old template')
 cfg.update(source_archive_sha256=archive,workload='reconnect',profile_sha256=PROFILE_SHA)
 existing={n[8:] for n in cfg['files'] if n.startswith('/source/')};need(len(existing)==1345 and existing<set(files) and len(files)==1348,'three new source paths only')
 for name in list(cfg['files']):
  if name.startswith('/source/'):del cfg['files'][name]
 cfg['files'].update({'/source/'+n:{'sha256':sha(raw),'bytes':len(raw)} for n,raw in files.items()})
 for n in NAMES:cfg['files']['/bin/'+n]=new[n]
 cfg['files']['/config/reconnect.json']={'sha256':PROFILE_SHA,'bytes':len(profile)}
 need(cfg['files']['/bin/capexec']==cfg['files']['/bin/journal-export']=={'bytes':None,'sha256':None},'helper hashes not yet known')
 return out

def inputs():
 old=old_data();b=checked_binding()
 files=[HERE/'prepare.py',HERE/'test_prepare.py',HERE/'README.ru.md',HERE/'BINDING.json',PACKER,PROFILE,VALIDATOR,TESTED,BASE/'source.tar.gz',QA/'MANIFEST.json',BUILD/'measured.expected.manifest',BUILD/'stand.expected.manifest',BASE.parent/'d1-o1a-v2672-baseline/reconnect.json',DAY/'d1-o1a-capexec-no-pie-v1/source/capexec.c',DATA/'RESULT.json',DATA/'SOURCE-ARCHIVE.json',Path(b['result']),Path(b['source_after'])]
 files += [Path(b['result']).parent/n for n in NAMES]
 files += [QA/'posts'/n for n in json.loads(read(QA/'MANIFEST.json'))['files']]
 for kind in ('pid1-source','capexec-source'):files += [DATA/kind/n for n in old['helper_sources'][kind]['source_files']]
 return files

def check():
 raw=read(HERE/'INPUTS.json');need(json.loads(raw)=={'scope':'COMPONENT_DATA_PREPARATION_ONLY','files':{str(p):{'sha256':file_sha(p),'bytes':p.stat().st_size} for p in inputs()}},'frozen inputs differ')
 need(file_sha(PROFILE)==PROFILE_SHA and file_sha(QA/'MANIFEST.json')=='f83819d0d4c30bd2592b0b2f792646664cb75ea82fd771fb38ea50dd92bc3750','profile/combined posts')
 need(file_sha(TESTED)=='1a4d80bf5a8861e032bb344b2ca5e9d4b6a2e67f24b40731e915c5c976b1e5a3' and file_sha(VALIDATOR)=='a05d9d0543d53fff65156de6dcb3fba2a1bbe67872ec8709f59c018f8d685754','original Go source API inputs')
 return sha(raw)

def bind(result,result_sha):
 need(not os.path.lexists(HERE/'BINDING.json') and not os.path.lexists(HERE/'INPUTS.json'),'one fresh exact data bind only')
 b=stage_binding(result,result_sha);(HERE/'BINDING.json').write_text(json.dumps(b,indent=2,sort_keys=True)+'\n')
 frozen={'scope':'COMPONENT_DATA_PREPARATION_ONLY','files':{str(p):{'sha256':file_sha(p),'bytes':p.stat().st_size} for p in inputs()}}
 (HERE/'INPUTS.json').write_text(json.dumps(frozen,indent=2,sort_keys=True)+'\n');print(json.dumps({'status':'DATA_BOUND_NOT_EXECUTED','input_sha256':check()}))

def prepare(approved):
 need(check()==approved,'exact frozen input SHA required');b=checked_binding();old=old_data();new=b['artifacts'];profile=read(PROFILE)
 out=Path('/private/tmp')/('corsa-o1a-census-component-inputs-'+uuid.uuid4().hex);out.mkdir(mode=0o700);print(json.dumps({'owned_output':str(out)}),flush=True)
 spec=importlib.util.spec_from_file_location('accepted_source_packer',PACKER);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
 files=m.load_sources(BASE/'source.tar.gz','7c24787328e87934d135471171b75ed4bf5a91ca558d4de8b4e06711842607ea',COMMIT)
 for n,pin in json.loads(read(QA/'MANIFEST.json'))['files'].items():
  raw=read(QA/'posts'/n);need(sha(raw)==pin['after_sha256'] and (n not in files if pin['before_sha256'] is None else sha(files[n])==pin['before_sha256']),'scoped before/after');files[n]=raw
 need(len(files)==1348 and all(json.loads(read(Path(b['source_after'])))[n]==sha(raw) for n,raw in files.items()),'actual compiled selected source')
 for group,raw in m.manifests(files).items():need(raw==read(BUILD/(group+'.expected.manifest')),'canonical source manifest')
 packed=m.pack(out/'guest-sources.tar.gz',files);archive=packed['archive_sha256'];packed['base_commit']=packed.pop('commit');packed['base_export_build_request_sha256']=packed.pop('build_request_sha256');packed.update(scope='COMPONENT_CENSUS_DIAGNOSTIC_NO_METRIC_ADMISSION',build_request_sha256=REQUEST,actual_build_result_sha256=b['result_sha256'],profile_sha256=PROFILE_SHA,original_Go_source_API='REUSED_ACTUAL_PASS_EXACT_2450_SOURCE_IDENTITY')
 (out/'SOURCE-ARCHIVE.json').write_text(json.dumps(packed,indent=2,sort_keys=True)+'\n')
 go=DATA/'pid1-source';cs=DATA/'capexec-source'
 config,frozen,exporter=go_sources(read(go/'cmd/o1a-init/config.go'),read(go/'cmd/o1a-init/frozen.go'),read(go/'cmd/journal-export/main.go'),old['actual_four_ELF'],new,archive,profile)
 header,capexec=c_sources(read(cs/'frozen_inputs.h'),read(cs/'capexec.c'),old['actual_four_ELF'],new,profile)
 source_changes={'pid1-source':{'cmd/o1a-init/config.go':config,'cmd/o1a-init/frozen.go':frozen,'cmd/journal-export/main.go':exporter,'BOOT-CONFIG.TEMPLATE.json':(json.dumps(template_rebind(json.loads(read(go/'BOOT-CONFIG.TEMPLATE.json')),files,new,archive,profile),indent=2,sort_keys=True)+'\n').encode()},'capexec-source':{'frozen_inputs.h':header,'capexec.c':capexec}}
 output_sources={}
 for kind in ('pid1-source','capexec-source'):
  dest=out/kind;dest.mkdir(mode=0o700);records={};diff=[]
  for name,row in old['helper_sources'][kind]['source_files'].items():
   before=read(DATA/kind/name);need(sha(before)==row['sha256'] and len(before)==row['bytes'],'old helper bytes')
   after=source_changes[kind].get(name,before)
   if kind=='capexec-source' and name=='test_source_binding.py':
    after,replacements=re.subn(rb"self\.assertEqual\(hashlib\.sha256\(\(HERE/'frozen_inputs.h'\)\.read_bytes\(\)\)\.hexdigest\(\),'[0-9a-f]{64}'\)",("self.assertEqual(hashlib.sha256((HERE/'frozen_inputs.h').read_bytes()).hexdigest(),"+repr(sha(header))+")").encode(),after)
    need(replacements==1,'exact old C header test pin required')
    after=one(after,b'old.splitlines() if x.startswith(prefix)',b'old.replace(\'"-test.timeout=255s"\', \'"-test.timeout=120s"\').splitlines() if x.startswith(prefix)')
   target=dest/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(after);records[name]={'sha256':sha(after),'bytes':len(after)}
   if after!=before:diff.extend(difflib.unified_diff(before.decode().splitlines(True),after.decode().splitlines(True),fromfile=kind+'/before/'+name,tofile=kind+'/after/'+name))
  (dest/'SHA256SUMS').write_text(''.join(v['sha256']+'  '+n+'\n' for n,v in sorted(records.items())))
  output_sources[kind]={'source_path':str(dest),'source_files':records,'source_sums_sha256':file_sha(dest/'SHA256SUMS')};(out/(kind+'.diff')).write_text(''.join(diff))
 (out/'component.json').write_bytes(profile)
 need(check()==approved,'inputs changed during data preparation')
 result={'scope':'COMPONENT_CENSUS_DIAGNOSTIC_NO_METRIC_ADMISSION','status':'COMPONENT_INPUTS_SOURCE_ONLY_NOT_HELPERS_OR_RUNTIME','input_sha256':approved,'source_archive':{'path':str(out/'guest-sources.tar.gz'),'sha256':archive,'bytes':packed['archive_bytes']},'source_groups':packed['source_groups'],'original_Go_source_API':'ACTUAL_PASS_REUSED_BY_EXACT_SUBJECT','four_ELF':new,'helper_sources':output_sources,'profile':{'path':str(out/'component.json'),'sha256':PROFILE_SHA,'bytes':len(profile)},'helpers':'NOT_BUILT','runtime_ready':False,'resource_execution':False}
 need(sum(f.stat().st_size for f in out.rglob('*') if f.is_file())<=64*1024**2,'phase outputs exceeded64MiB');(out/'RESULT.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n');print(json.dumps({'result':str(out/'RESULT.json'),'archive_sha256':archive,'scope':result['scope']}))

if __name__=='__main__':
 parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--bind-result',type=Path);parser.add_argument('--result-sha');parser.add_argument('--execute');a=parser.parse_args()
 if a.bind_result:
  need(a.result_sha is not None and a.execute is None,'exact actual result SHA required');bind(a.bind_result,a.result_sha)
 elif a.execute:prepare(a.execute)
 else:print(check())
