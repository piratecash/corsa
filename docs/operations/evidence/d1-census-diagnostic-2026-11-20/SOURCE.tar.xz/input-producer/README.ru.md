# Pending component source-data rebind

SOURCE-only producer, not executed. BINDING.json/INPUTS.json deliberately absent: actual four artifact SHA and result path are not guessed. No runtime/HANDOFF exists. Root will supply the exact successful20f288… compiler result after independent DATA review.

Data-only bind after CODE and actual compiler result:

```sh
python3 prepare.py --bind-result /ABS/ACTUAL/result.json --result-sha FULL_ACTUAL_SHA
```

It checks all4 artifact bytes,16normal compiler receipts, request/base identity and exact2450 after-source map1a4d (no QA-only validator); then writes fresh one-shot BINDING/INPUTS and prints the input SHA. Root may then execute the data preparer with `python3 prepare.py --execute EXACT_INPUT_SHA`. A missing/mismatched actual bind refuses; no app/Go/C/Docker/VM/resources are run. Output goes only to a fresh own tmp directory; source-only preflight/tests do not execute this phase.

Inputs reuse exact original4fcc plus12GoQA-tested posts/f838…, original source API PASS a05d640/708 and exact2450 file identity. No duplicate Go source API job needed if compiler before/after hashes match. Data source tar has1348selected Go files +two canonical manifests; measured640b70de unchanged, stand7086aac…; new source archive SHA only after actual packing. The original metric profiles/failedperiodic archives are preserved.

PID1 source family derives from accepted rooted baseline d38f inputs: only SourceArchiveSHA/SourceFiles1348, four FrozenArtifacts, component862B/profilef848 in FrozenProfiles+config artifact and Boot template; exporter main's hardcoded reconnect profile SHA36a→f848. Root compiles PID1+exporter together in ONE existing600+30/offline soft-Go profile. Codec, context/cap/mount/root0755/lifecycle/fences and periodic profile28… are unchanged. Helpers remain NOT_BUILT in data result.

Capexec parameter delta: actual four header SHA, literal component profile_reconnect, one exact `-test.timeout=255s`→`-test.timeout=120s` branch; original periodic570s unchanged. This preserves the existing test timeout = profile timeout +30s margin (component90s +30s), not a90s hard process stop. Selected test name/argv order/env/4caps/NNP/core0/filter code remain unchanged. Policy699c factory still147/52; C compile separate accepted180+30/1CPU/1024MiB/64PID cap0/offline controller. Source-binding test updates only new header expected hash and explicitly permits that exact timeout literal in its old reference; remaining argv/cap checks remain. No native policy rerun/new audit gate is required for these data parameters.

Data/output phase own files≤64MiB by final check, pinned existing inputs; Root invokes under its accepted data-job accounting/reserves. No aggregate hard caps/diskquota claimed. Error→STOP/no rerun/increase; retain available own output and logs. No exporter binary reused under a false old profile SHA. Future runtime must bind actual new helper outputs and explicit COMPONENT_CENSUS_DIAGNOSTIC purpose; no old O‑1a metric admission, no identical480s repeat or publicactivation/release.
