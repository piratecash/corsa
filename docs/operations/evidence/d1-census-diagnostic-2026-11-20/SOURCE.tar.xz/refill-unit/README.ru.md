# Deterministic full-receipt rate-refill mechanism

SOURCE-only one new Go test file on exact current21b146e076789c551a95a82d759f96557de09167; no product edits, no tracked files changed, no Go execution by the preparer. Relevant production observer/handler/limiter/routing code and existing fixtures are byte-identical to actual1ad46 diagnostic source (RELEVANT-SOURCE.json). Root runs only the named test under its existing offline600+30/soft2CPU/768MiB/-p1 test job; no VM or baseline four-artifact rebuild.

`TestLoadStandRouteWireFullReceiptRefillContrast` uses the real seed projection/100-chunk serializer, receive handler, identity-keyed limiter, `Table.RemoveDirectPeer`, recordFullReceive and captureFullReceipts. Initial10k receive pass is outside the observer window and provably drains burst10000. The original same penalty bucket/key is retained over MarkReconnected. Actual table withdrawal makes all former claims unusable. A legitimate newer replacement claim strictly exceeds each actual withdrawn watermark, so stale sequence refusal cannot contaminate the50s positive control. Only replacement100frames/10kclaims are observed under budget10000; there is no two-connection aggregate-budget confound.

The manual limiter clock advances16s or50s, while the independent finite frame window is advanced from1→15→21. No sleeps, sockets, Service.Run, new seed/capacity, timeout/window change, token reset or limiter/oracle override. The expected contrast is actualhandler accepts3200/10000 replacement rows, then strict receipt fails/passes. Before capture, wire observer must contain all100frames/10000claims and remain complete, distinguishing handler admission from acquisition/window/budget failures.

This establishes a reachable short-profile confound only. The unit's valid recovery sequence is newer than the withdrawn row; the native component's actual per-frame sequence/admission/inner failure state was not serialized. Consequently even a passing contrast is NOT proof that the saved30s component or480s periodic failure had this cause. Original reconnection lead90+disconnect15 permits the50s refill, whereas shortened component lead10+6 may not. No product limiter change or relaxation is proposed from a single coarse `full_receipt` stage.

Suggested Root command on an isolated exact source copy + this one post:

```
go test -mod=readonly -p=1 -count=1 -timeout=90s -json ./internal/core/node -run '^TestLoadStandRouteWireFullReceiptRefillContrast$'
```

Host QA must show one outer/two child cases and preserve the two exact logged counts; current Go test remains NOT_RUN here. If mechanism does not uniquely identify saved runtime cause, a bounded finite first-failure category guard at the existing observer refusal site is preferable to another identical VM/480s run. It must retain existing errors.Is/failclosed and report no raw error text/keys/identities.
