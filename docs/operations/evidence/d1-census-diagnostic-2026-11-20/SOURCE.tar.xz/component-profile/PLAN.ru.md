# COMPONENT_CENSUS_DIAGNOSTIC — короткая проверка census

SOURCE-only план, НЕ запуск и НЕ O‑1a admission. Исходные periodic540/reconnect225 JSON, их ELF/initrds и failed5a369 сохраняются неизменными. Новая ветка — ordinary Off baseline4fcc+finalizer+closed-stage diagnostics; не current FullResponder candidate.

## Конкретный профиль

`component.json`: SHA `f84856cfa6f3c3d39f4f5d69487c5d968106aeea77b16f8a3d7bf864266e7369`,862B. Два Full/два hubs/quiet/Seed13/одна инициирующая сторона/10k routes и receipt budget10k/MaxEndpoints4. Новые параметры только отдельного component профиля:

| Параметр | Секунды |
|---|---:|
| StartupLead |10|
| Plan.Duration / sample interval |20 /5|
| Begin / DisconnectAt / End |2 /6 /15|
| Timeout |90|
| Cleanup (прежний) |20|

Остальные Limits сохраняются: RouteReady35,Readiness30,Action8,ReceiptDrain8,AllowedLateness8,MaxActions128,MaxSamples96,Trace4MiB. JournalDir остаётся `/profiles/o1a-reconnect-journal` внутри свежего гостя. RequiredFullSource=connect, RequireReconnect=true. Никакого FIND_NODE/DM/gossip traffic, новых members, CM backoff/slot policies, route oracle или metric thresholds.

Исходные `profile.prepare`, `launch.selection` и plan validators принимают положительные целые миллисекунды и цепочку `0<2<6<15<20`. Budget predicate: `20cleanup <90timeout−20duration−10lead =60`; остаётся прежний40с запас после lead+duration+cleanup. Sample offsets5/10/15/20:4 samples,+2=6≤96; quiet не создаёт churn start/stop. Launch.MaxEndpoints4 допускает прежнюю/replacement sessions, history8 при original census allocation. Reconnect задаётся исходным one-shot disconnect; это не restart процесса.

Go validator пока НЕ запускался: VALIDATION-PROOF.json — source inspection, не PASS Go. `VALIDATE-PROFILE-QA-ONLY.go.txt` даёт ровно один короткий тест исходных unexported Go APIs и три отрицательных изменения. Root может вставить его в ОТДЕЛЬНУЮ временную QA-копию Node package. Не включать его в четыре artifact binaries/source archive: он добавил бы отдельный stand test и изменил subject. Его исключение из artifact source должно быть явным, не wildcard.

## Почему этот сценарий может быть коротким

Origin=фактический BootTime sample+10. Window=[sample+12,sample+25], one-shot disconnect=sample+16. Первоначальная пара должна быть зарегистрирована до Begin; затем здоровый исходный CM реконнектится немедленно по прежнему WasHealthy path, без изменения backoff. Новая connect-full передача должна успеть до End; census после конца плана не ранее sample+30. Это не обещание физических сроков: ten-second startup allowance короче отдельных permitted startup budgets. При позднем startup исходный epoch guard откажет; при медленном reconnect/full-frame capture исходный oracle также может отказать. Такой отказ сохраняется, лимиты автоматически не растут и идентичного повтора нет.

Connect-full component не проверяет periodic5-minute full/cache history. Его PASS НЕ объясняет и НЕ опровергает прежний480.60с отказ; его цель — проверить закрытый diagnostic channel и тот же census/full-receipt path на коротком отдельном сценарии. Даже если исходный Go test выдаст PASS и рассчитает rates, итоговая квалификация только COMPONENT, никогда original O‑1a Bps PASS, published K11 или S6/D1/G2 acceptance.

## Минимальные сборки и данные

1. После CODE/короткого Go QA диагностических posts собрать четыре исходных продукта (`internal/core/node` test ELF,fullnode,linuxhelper,sdkedge) из точного4fcc+3existingfinalizer+diagnostic subject. Original Go1.27.4/CGO0/Linuxarm64/flags/mods сохраняются. Tiny censusdiag leaf добавляет только stdlib package, не core/rpc в helper. До actual graph readback нельзя объявлять module closure проверенной; ожидается прежняя26/23/5/23. Measured640/b70de не меняется; новый stand/count/hash вычисляется по реальным frozen bytes, не старому52e346 и не непроверенному предположению после gofmt.
2. Новый source archive и оригинальный Go source API readback по этому subject. Отдельный component JSON фиксируется вне Go source snapshots. Новые четыре ELF, source archive и source file count фактически связываются до helper компиляции.
3. Rooted PID1 family переиспользовать с точечными bindings: SourceArchiveSHA/SourceFiles/FrozenArtifacts для четырёх ELF и component `/config/reconnect.json`, FrozenProfiles[reconnect]=component bytes. Периодический профиль и root0755/caps/namespace checks/child reap/600−610−620/export30/poweroff650 не меняются. Никаких будущих SHA.
4. Exporter36ed НЕЛЬЗЯ переиспользовать как бинарник: его main жёстко проверяет старый reconnect profile SHA36a653. Нужна одна маленькая Linuxarm64 Go компиляция exporter с единственной заменой expected reconnect SHA→f84856; capsule codec/format/Binding.Validate/workload остаются побайтно прежними. Для component source/mode неизвестные данные не маскируются старым SHA.
5. Capexec: прежние C capability/filter/control функции и policy699c/147instructions/52controls неизменны. Data header получает реальные четыре ELF SHA и новый literal profile_reconnect; fixed reconnect `-test.timeout=225s` меняется ровно на90s, periodic540 остаётся. Имя selected Node test, argv/env keys, scopes и helpers не меняются. Это один явно описанный parameter-only C delta; source guard должен разрешать только эту конкретную строку, не снимать argv checks. Одна compile-only C job по принятому профилю; ELF до отдельного runtime не исполняется. Прежние native policy controls применимы к неизменной policy/code, не нужно новой политической экспертизы из-за header/time parameter.
6. Один component initrd с transport Workload=reconnect и фактическими новыми helpers/четырьмя ELF/source files/profile. Original `config/periodic.json` можно сохранить как неизменный dormant asset для принятого schema. Все audit modes0555/остальные metadata, nft closure и kernel9ffe прежние. Полный cpio readback связывает только точные разрешённые изменения; original archives не переписываются.

## Переиспользование NativeVZ без нового Swift

Worker7b75 принимает только periodic/reconnect и печатает fixed transport profile `d1-o1a-native-v1`. Оставить Workload=reconnect и этот transport envelope: новая внешняя scope должна быть ЯВНО `COMPONENT_CENSUS_DIAGNOSTIC`. Самый узкий host-only вариант — добавить фиксированное поле `purpose` в новый dedicated HANDOFF и точный validator этого package; grant SHA криптографически связывает его с запуском. Native event/Binding/schema и Swift не меняются. Metadata/profile SHA, paths и отчёт выделяются в свежий component package/attempt, не принимаются обычным verifier с original reconnect SHA.

Отдельный host verifier сохраняет все original lifecycle/RAW/normal exit/reap/custody/three-actor ACK predicates; меняются только known source count/profile/source archive pins и outcome scope `COMPONENT_ONLY_NO_METRIC_ADMISSION`. Он не вызывает обычный journal/rate admission checker для присвоения O‑1a PASS. ACK по-прежнему подтверждает остановку, не функциональный успех. Никаких новых JSON/RPC/FD transports не требуется.

Тот же kernel9ffe/no NIC/disks/sharing,2vCPU/1536MiB и full worker660/680/698/700 можно сохранить. Это существующие ВНЕШНИЕ максимальные fences; они не превращаются в90секундную аппаратную гарантию. Go context/outer test timeout90 — внутренние программные бюджеты. Зависший FS/Virtualization может превысить их; UNKNOWN сохраняет lock и запрещает следующий запуск. Только свои ресурсы/журналы, без piratecashd/downloads/public connections.
