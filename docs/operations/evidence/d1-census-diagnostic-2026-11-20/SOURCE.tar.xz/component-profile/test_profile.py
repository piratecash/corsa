"""Arithmetic/source provenance only; original Go validator remains NOT_RUN."""
import hashlib,json,unittest
from pathlib import Path
HERE=Path(__file__).resolve().parent
ORIGINAL=HERE.parent.parent/'2026-11-17/d1-o1a-v2672-baseline/reconnect.json'
class Tests(unittest.TestCase):
 def test_only_component_time_and_sampling_fields_differ(self):
  new=json.loads((HERE/'component.json').read_bytes());old=json.loads(ORIGINAL.read_bytes())
  for key in ('Timeout','StartupLead','Begin','End','DisconnectAt'):new[key]=old[key]
  for key in ('Duration','SampleInterval'):new['Plan'][key]=old['Plan'][key]
  self.assertEqual(new,old)
 def test_source_time_predicates_and_original_margin(self):
  p=json.loads((HERE/'component.json').read_bytes());duration=p['Plan']['Duration']
  self.assertTrue(0<p['Begin']<p['DisconnectAt']<p['End']<duration)
  self.assertTrue(p['Limits']['Cleanup']<p['Timeout']-duration-p['StartupLead'])
  self.assertEqual(p['Timeout']-duration-p['StartupLead']-p['Limits']['Cleanup'],40*10**9)
  self.assertEqual(duration//p['Plan']['SampleInterval'],4)
  self.assertLessEqual(4+2,p['Limits']['MaxSamples'])
 def test_original_profiles_retained_and_private_QA_not_artifact_source(self):
  self.assertEqual(hashlib.sha256(ORIGINAL.read_bytes()).hexdigest(),'36a65318713e5b4cb795749a4a5e12424cdfe905760f3a352b7ac602040621de')
  text=(HERE/'VALIDATE-PROFILE-QA-ONLY.go.txt').read_text();self.assertIn('p.prepare(loadstand.LaunchNonce{1})',text);self.assertIn('QA-ONLY',text)
  self.assertFalse((HERE/'posts').exists())
if __name__=='__main__':unittest.main()
