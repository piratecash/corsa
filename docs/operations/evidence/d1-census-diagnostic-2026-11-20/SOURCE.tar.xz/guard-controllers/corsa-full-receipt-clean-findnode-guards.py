import os,sys,json,hashlib,subprocess,shutil,stat
from pathlib import Path
R=Path('/Users/hades/Documents/repos/corsa');P=R/'docs/_internal/d1-artifacts/2026-11-20/d1-o1a-full-receipt-refill-unit-v2'
sys.path.insert(0,str(R/'docs/_internal/d1-artifacts/2026-11-20/d1-o1a-capexec-seccomp-build-v1'))
from common import Job,need,sha
M=json.loads((P/'MANIFEST.json').read_text());name,row=next(iter(M['files'].items()));need(subprocess.check_output(['git','rev-parse','HEAD'],cwd=R).decode().strip()==M['base_commit'],'HEAD drift');need(subprocess.check_output(['git','diff','--name-only'],cwd=R)==b'','tracked changes');need(sha(R/name)==row['after_sha256'],'new test drift')
files=subprocess.check_output(['git','ls-files','--'],cwd=R).decode().splitlines()+[name]
before={n:sha(R/n) for n in files};os.umask(0o077)
if os.getpid()!=os.getpgrp():os.setsid()
j=Job('full-receipt-clean-findnode-guards',600,2*1024**3);error=None;counts=None
try:
 need(shutil.disk_usage('/private/tmp').free>=10*1024**3,'host free')
 for n in ('source','cache','tmp'):(j.work/n).mkdir()
 source=j.work/'source'
 for n,h in before.items():
  q=source/n;q.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(R/n,q);need(sha(q)==h,'copied source drift');q.chmod(0o444)
 (j.work/'SOURCE-MANIFEST.json').write_text(json.dumps(before,sort_keys=True,indent=2)+'\n')
 env=os.environ.copy();env.update(GOCACHE=str(j.work/'cache'),GOMODCACHE=str(R/'.gomodcache'),TMPDIR=str(j.work/'tmp'),GOPROXY='off',GOSUMDB='off',GOTOOLCHAIN='local',GOTELEMETRY='off',GOMAXPROCS='2',GOMEMLIMIT='768MiB',GOFLAGS='-p=1',GOOS='darwin',GOARCH='arm64',CGO_ENABLED='0',GOENV='off',GOWORK='off')
 old=json.loads(Path('/private/tmp/corsa-d1-native-responder-goqa-bbc0b7455f5a4a269692df9953b0c93f/result.json').read_text());step=next(x for x in old['steps'] if x.get('phase')=='findnode-guards');pattern=next(x for x in step['argv'] if x.startswith('-run='));expected=set(step['tests']['passed'])
 policy='(version 1)(allow default)(deny network*)(deny file-write* (subpath '+json.dumps(str(source))+'))(deny file-write* (subpath '+json.dumps(str(R))+'))'
 raw=j.run('findnode-guards',['/usr/bin/sandbox-exec','-p',policy,'/usr/local/go/bin/go','test','-mod=readonly','-p=1','-count=1','-timeout=90s','-json',pattern,'./internal/core/findnode'],cwd=source,env=env)
 es=[json.loads(x) for x in raw.splitlines()];need(not any(x.get('Action') in ('fail','skip') for x in es),'GoFAIL/SKIP');passed=[x['Test'] for x in es if x.get('Action')=='pass' and x.get('Test')];need({x for x in passed if '/' not in x}==expected,'inventory')
 counts={'outer':len(expected),'child':sum('/' in x for x in passed)}
 need({n:sha(R/n) for n in files}==before and {n:sha(source/n) for n in files}==before,'source afterdrift')
 previous=Path('/private/tmp/corsa-d1-o1a-full-receipt-source-guards-d5e71e2487904b8bb441a96c25db2740');go_after={n:sha(R/n) for n in before if n.endswith('.go') or n in ('go.mod','go.sum')};need(go_after==json.loads((previous/'SOURCE-BEFORE.json').read_text()),'previous2103scopechanged');(j.work/'GO-SOURCE-AFTER.json').write_text(json.dumps(go_after,sort_keys=True,indent=2)+'\n')
except BaseException as e:error=str(e)
j.finish({'status':'CLEAN_FINDNODE_SOURCE_GUARDS_PASS' if error is None else 'FAILED','error':error,'tests':counts,'base':M['base_commit'],'new_test_sha256':row['after_sha256'],'isolated_source_files':len(before),'scope':'ONLY_FAILED_GUARDS_RERUN_ON_EXACT_TRACKED_SOURCE_WITHOUT_IGNORED_ARTIFACTS','original_scanner_unchanged':True,'app_or_VM_executed':False})
if error:raise SystemExit(1)
