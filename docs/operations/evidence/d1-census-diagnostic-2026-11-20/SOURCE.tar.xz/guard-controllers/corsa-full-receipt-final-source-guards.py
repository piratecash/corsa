import os,sys,json,hashlib,subprocess,shutil
from pathlib import Path
R=Path('/Users/hades/Documents/repos/corsa');P=R/'docs/_internal/d1-artifacts/2026-11-20/d1-o1a-full-receipt-refill-unit-v2'
sys.path.insert(0,str(R/'docs/_internal/d1-artifacts/2026-11-20/d1-o1a-capexec-seccomp-build-v1'))
from common import Job,need,sha
M=json.loads((P/'MANIFEST.json').read_text());need(subprocess.check_output(['git','rev-parse','HEAD'],cwd=R).decode().strip()==M['base_commit'],'HEAD drift')
name,row=next(iter(M['files'].items()));post=P/'posts'/name;need(len(M['files'])==1 and row['before_sha256'] is None and sha(R/name)==row['after_sha256'] and sha(post)==row['after_sha256'],'single test overlay')
pattern='^(TestD1FindNodeResourceDiagnosticExistingGuardBoundaries|TestD1FindNodeResourceDiagnosticSourceClosure|TestFindNodeLocalRoleClosedSource|TestFindNodeLocalRoleSourceControls|TestOwnedAnswerClosedSource|TestOwnedAnswerSourceControls|TestOwnedAutomaticEndpointTraceClosedSource|TestOwnedAutomaticEndpointTraceSourceControls|TestOwnedBareV2PilotAdvertisementSourceControls|TestOwnedFlowClosedSource|TestOwnedFlowSourceControls|TestOwnedLocalNodeClosedSource|TestOwnedLocalNodeSourceControls|TestOwnedNodeObservationClosedSource|TestOwnedNodeObservationSourceControls|TestOwnedNodeReceiveClosedSource|TestOwnedNodeReceiveSourceControls|TestOwnedReadyClosedSource|TestOwnedReadySourceControls|TestOwnedTerminalClosedSourceContract)$'
expected={'TestOwnedNodeObservationSourceControls', 'TestOwnedTerminalClosedSourceContract', 'TestOwnedNodeReceiveSourceControls', 'TestFindNodeLocalRoleClosedSource', 'TestD1FindNodeResourceDiagnosticExistingGuardBoundaries', 'TestD1FindNodeResourceDiagnosticSourceClosure', 'TestOwnedReadySourceControls', 'TestFindNodeLocalRoleSourceControls', 'TestOwnedFlowSourceControls', 'TestOwnedAutomaticEndpointTraceClosedSource', 'TestOwnedBareV2PilotAdvertisementSourceControls', 'TestOwnedLocalNodeSourceControls', 'TestOwnedAnswerClosedSource', 'TestOwnedAnswerSourceControls', 'TestOwnedNodeReceiveClosedSource', 'TestOwnedFlowClosedSource', 'TestOwnedReadyClosedSource', 'TestOwnedNodeObservationClosedSource', 'TestOwnedAutomaticEndpointTraceSourceControls', 'TestOwnedLocalNodeClosedSource'}
files=subprocess.check_output(['git','ls-files','--','*.go','go.mod','go.sum'],cwd=R).decode().splitlines()
def sources():return {n:sha(R/n) for n in files}
files.append(name)
before=sources();os.umask(0o077)
if os.getpid()!=os.getpgrp():os.setsid()
j=Job('full-receipt-source-guards',600,2*1024**3);error=None;counts=None
try:
 need(shutil.disk_usage('/private/tmp').free>=10*1024**3,'host free')
 for n in ('cache','tmp'):(j.work/n).mkdir()
 (j.work/'SOURCE-BEFORE.json').write_text(json.dumps(before,sort_keys=True,indent=2)+'\n')
 overlay=j.work/'overlay.json';overlay.write_text(json.dumps({'Replace':{str(R/name):str(post)}})+'\n')
 env=os.environ.copy();env.update(GOCACHE=str(j.work/'cache'),GOMODCACHE=str(R/'.gomodcache'),TMPDIR=str(j.work/'tmp'),GOPROXY='off',GOSUMDB='off',GOTOOLCHAIN='local',GOTELEMETRY='off',GOMAXPROCS='2',GOMEMLIMIT='768MiB',GOFLAGS='-p=1',GOOS='darwin',GOARCH='arm64',CGO_ENABLED='0',GOENV='off',GOWORK='off')
 policy='(version 1)(allow default)(deny network*)(deny file-write* (subpath '+json.dumps(str(R))+'))'
 raw=j.run('selected-tests',['/usr/bin/sandbox-exec','-p',policy,'/usr/local/go/bin/go','test','-overlay='+str(overlay),'-mod=readonly','-p=1','-count=1','-timeout=90s','-json','-tags=d1_resource_probe','./internal/core/node','-run',pattern],cwd=R,env=env)
 events=[json.loads(x) for x in raw.splitlines()];need(not any(x.get('Action') in ('fail','skip') for x in events),'Go FAIL/SKIP')
 passed=[x['Test'] for x in events if x.get('Action')=='pass' and x.get('Test')];need({n for n in passed if '/' not in n}==expected,'test inventory')
 counts={'outer':len(expected),'child':sum('/' in n for n in passed)}

 raw2=j.run('findnode-guards',['/usr/bin/sandbox-exec','-p',policy,'/usr/local/go/bin/go','test','-mod=readonly','-p=1','-count=1','-timeout=90s','-json','-run=^(TestCandidateInactiveCallGraphAndInventories|TestCandidateSourceCompanionClosedRoots|TestCandidateSourceTypeReferencesAndDeclarations|TestCandidateCapacityClosedRootsAndLogicalBoundary|TestCandidateCapacityGuardRejectsActivationAndMissingFinalCheck)$','./internal/core/findnode'],cwd=R,env=env)
 ev2=[json.loads(x) for x in raw2.splitlines()];need(not any(x.get('Action') in ('fail','skip') for x in ev2),'findnodeFAIL/SKIP');need({x['Test'] for x in ev2 if x.get('Action')=='pass' and x.get('Test') and '/' not in x['Test']}=={'TestCandidateCapacityGuardRejectsActivationAndMissingFinalCheck', 'TestCandidateSourceCompanionClosedRoots', 'TestCandidateCapacityClosedRootsAndLogicalBoundary', 'TestCandidateSourceTypeReferencesAndDeclarations', 'TestCandidateInactiveCallGraphAndInventories'},'findnodeinventory')
 counts['findnode_outer']=5;counts['findnode_child']=sum(x.get('Action')=='pass' and '/' in x.get('Test','') for x in ev2)
 after=sources();need(after==before and sha(post)==row['after_sha256'],'source changed');(j.work/'SOURCE-AFTER.json').write_text(json.dumps(after,sort_keys=True,indent=2)+'\n')
except BaseException as e:error=str(e)
j.finish({'status':'FORMATTED_TEST_SOURCE_GUARDS_PASS' if error is None else 'FAILED','error':error,'tests':counts,'base':M['base_commit'],'manifest_sha256':sha(P/'MANIFEST.json'),'scope':'FORMATTED_TEST_AND_SOURCE_INVENTORY_QA_ONLY','app_or_Linux_ELF_executed':False,'virtual_test_path':name,'overlay_sha256':row['after_sha256']})
if error:raise SystemExit(1)
