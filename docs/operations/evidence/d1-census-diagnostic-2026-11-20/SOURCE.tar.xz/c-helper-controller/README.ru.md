# Component census diagnostic helper build — SOURCE ONLY

This controller is UNBOUND / NOT_EXECUTED. No FROZEN.json/source directory is invented. After Root accepts actual data preparation, bind both helper controllers with:

```
python3 ../d1-o1a-census-component-go-helper-build-v1/bind.py --result /ABS/ACTUAL_COMPONENT_INPUTS/RESULT.json --sha EXACT_RESULT_SHA
```

The binder requires exact component scope/profile/708 source identity and source inventories, copies all helper input bytes, and records actual source/result hashes. Fresh one-shot binding; no build or ELF execution. Root must independently accept the data output and fresh source manifest before invoking the controller. The old source archive/API acceptance is reused only by exact2450 source identity (original API640/708 actually passed); no duplicate API build command.

Root then invokes `python3 c_build.py`: same accepted separate180s+30s cleanup/1CPU/1024MiB/64PID/noSwap, cap-dropALL, user501:20, networknone/read-only-root, only own input/output binds and128MiB noexec tmpfs, pinned existing45ccc image/no pull. Static ET_EXEC/noINTERP/noDYNAMIC oracle, full -Wall/-Wextra/-Werror/-no-pie. Two exact compiles then pure factory dumper only; capexec/filter never executed. Policy699c unchanged/147 instructions/52 exact controls. One C parameter branch255→120s retains original profile+30 margin; periodic570 unchanged. No actual90s hard stop claimed. C execution/inspect/ambiguous-create handling is byte-exact accepted controller except joblabel and local copy of same pure policy_data reader import (so prebind pure tests work). Source metadata new input hashes only.

Seven existing small controller tests passed prebind (inspect/limits/mounts/staticflags/script). The accepted uncertain-create UNKNOWN/HOLD handling remains unchanged; its prior main/FROZEN-dependent test is not repeated before a real binding. Full source-binding/policy pure tests remain available in bound `source/`. Error/OOM/timeout/unknown semantics unchanged; no repeat/increase, unknown holds lock. No host hard caps/hard diskquota claimed.

These helpers support only COMPONENT_CENSUS_DIAGNOSTIC; no O1a metric/Bps admission, public activation or release. Original four diagnostic Go ELFs are inputs elsewhere and never run by these builds. No Docker image is created or deleted.
