"""Capture the three native-worker streams without starting a VM in tests."""
from contextlib import ExitStack
from dataclasses import dataclass, field
import hashlib
import json
import os
from pathlib import PurePosixPath
import re
import selectors
import signal
import subprocess
import time


SECOND = 1_000_000_000
LIMITS = {"console": 32 * 1024**2, "native": 16 * 1024, "stderr": 4096}
PROFILE = "d1-o1a-native-v1"


@dataclass(frozen=True)
class Binding:
    attempt_id: str
    workload: str
    config_sha256: str

    def validate(self):
        if (type(self.attempt_id) is not str or re.fullmatch('[0-9a-f]{32}', self.attempt_id) is None
                or type(self.workload) is not str or self.workload not in ('periodic', 'reconnect')
                or type(self.config_sha256) is not str or re.fullmatch('[0-9a-f]{64}', self.config_sha256) is None):
            raise ValueError("invalid exact O1a binding")

    def admission(self):
        self.validate()
        return f"O1A-NATIVE-WORKER-V1 {self.attempt_id} {self.workload} {self.config_sha256}\n".encode('ascii')


def worker_argv(command, attempt, origin, console_fd, binding):
    if type(binding) is not Binding:
        raise ValueError("typed O1a binding required")
    binding.validate()
    if (type(command) is not list or len(command) != 6 or any(type(x) is not str for x in command)
            or command[1] != '--worker' or command[2] != attempt or binding.attempt_id != attempt
            or type(origin) is not int or origin <= 0 or command[3] != str(origin)
            or type(console_fd) is not int or console_fd < 3):
        raise ValueError("worker command/binding mismatch")
    for value in (command[0], command[4], command[5]):
        path = PurePosixPath(value)
        if not path.is_absolute() or value != str(path) or any(p in ('.', '..') for p in path.parts) or any(c in value for c in '\\\r\n\x00'):
            raise ValueError("noncanonical worker input path")
    # NativeWorker argc9: console fd MUST precede workload/config SHA.
    return [*command, str(console_fd), binding.workload, binding.config_sha256]


def clock_ns():
    return time.clock_gettime_ns(time.CLOCK_MONOTONIC)


@dataclass(frozen=True)
class Deadlines:
    work: int = 660 * SECOND
    kill: int = 698 * SECOND
    reap: int = 700 * SECOND


@dataclass
class Capture:
    limit: int
    stream: object
    received: int = 0
    retained: int = 0
    eof: bool = False
    failed: bool = False
    digest: object = field(default_factory=hashlib.sha256)

    def consume(self, data):
        self.received += len(data)
        if self.failed:
            return
        data = memoryview(data)[:self.limit - self.retained]
        while data:
            try:
                count = self.stream.write(data)
                if not count:
                    raise OSError("empty raw write")
            except OSError:
                self.failed = True
                return
            self.digest.update(data[:count])
            self.retained += count
            data = data[count:]

    @property
    def complete(self):
        return self.eof and not self.failed and self.received == self.retained

    def receipt(self):
        return {"received": self.received, "retained": self.retained,
                "eof": self.eof, "sha256": self.digest.hexdigest()}


def saw_guest_stop(path, attempt, work, binding):
    # This is a scheduling hint only. The independent replay checks all rows.
    with path.open("rb") as stream:
        raw = stream.read(LIMITS["native"] + 1)
    if len(raw) > LIMITS["native"]:
        return False
    def unique(pairs):
        result = {}
        for key, value in pairs:
            if key in result:
                raise ValueError("duplicate native field")
            result[key] = value
        return result
    for line in raw.split(b"\n")[:-1]:
        try:
            row = json.loads(line, object_pairs_hook=unique)
        except ValueError:
            return False
        if (type(row) is dict and row.get("attempt_id") == attempt and type(row.get("seq")) is int and row.get("seq") == 3 and
                row.get("profile") == PROFILE and row.get("workload") == binding.workload and
                row.get("config_sha256") == binding.config_sha256 and
                row.get("event") == "guest_stopped" and "guest_error" in row and row["guest_error"] is None and
                type(row.get("elapsed_ns")) is int and 0 <= row["elapsed_ns"] < work):
            return True
    return False


def group_absent(pgid):
    try:
        os.killpg(pgid, 0)
    except ProcessLookupError:
        return True
    except PermissionError:
        return False
    return False


def collect(command, attempt, origin, directory, binding, limits=LIMITS, deadlines=Deadlines(), interrupted=lambda: False):
    # Validate binding/profile before creating RAW files or spawning a process.
    worker_argv(command, attempt, origin, 3, binding)
    if (type(deadlines) is not Deadlines or deadlines != Deadlines()
            or any(type(getattr(deadlines, key)) is not int for key in ('work', 'kill', 'reap'))
            or type(limits) is not dict or set(limits) != set(LIMITS)
            or any(type(v) is not int or not 0 < v <= LIMITS[k] for k, v in limits.items())
            or origin > clock_ns()):
        raise ValueError("invalid O1a capture resource profile")
    files = {"console": "console.raw", "native": "native.jsonl", "stderr": "stderr.raw"}

    with ExitStack() as stack:
        streams = {name: Capture(limits[name], stack.enter_context((directory / path).open("xb", buffering=0)))
                   for name, path in files.items()}
        selector = stack.enter_context(selectors.DefaultSelector())
        if interrupted() or clock_ns() - origin >= deadlines.work:
            raise ValueError("interrupted or expired before worker spawn")
        console_r, console_w = os.pipe()
        console = stack.enter_context(os.fdopen(console_r, "rb", buffering=0))
        try:
            child = subprocess.Popen(worker_argv(command, attempt, origin, console_w, binding), cwd=directory,
                                     env={"PATH": "/usr/bin:/bin", "LANG": "C", "LC_ALL": "C"},
                                     stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                     close_fds=True, pass_fds=(console_w,), start_new_session=True)
        finally:
            os.close(console_w)
        stack.enter_context(child.stdout)
        stack.enter_context(child.stderr)
        stack.enter_context(child.stdin)

        reason = None
        killed = False
        reaped_at = None
        group_gone = False

        def stop(why):
            nonlocal reason
            if reason is None:
                reason = why
                if child.poll() is None:
                    try:
                        os.killpg(child.pid, signal.SIGTERM)
                    except ProcessLookupError:
                        pass

        try:
            with (directory / "worker-start.json").open("xb") as record:
                record.write((json.dumps({"pid": child.pid, "pgid": child.pid, "attempt_id": attempt,
                                         "profile": PROFILE, "workload": binding.workload,
                                         "config_sha256": binding.config_sha256}) + "\n").encode())
                record.flush()
                os.fsync(record.fileno())
            for name, reader in (("console", console), ("native", child.stdout), ("stderr", child.stderr)):
                os.set_blocking(reader.fileno(), False)
                selector.register(reader, selectors.EVENT_READ, name)
            try:
                if interrupted() or clock_ns() - origin >= deadlines.work:
                    stop("interrupted or expired before admission")
                else:
                    token = binding.admission()
                    if child.stdin.write(token) != len(token):
                        raise OSError("short admission write")
                child.stdin.close()
            except OSError:
                stop("admission pipe failed")
            work_checked = False
            while True:
                now = clock_ns() - origin
                if child.poll() is not None and reaped_at is None:
                    reaped_at = now
                if reaped_at is not None and not selector.get_map():
                    break
                if now >= deadlines.reap:
                    stop("reap deadline")
                    break
                if interrupted():
                    stop("controller interrupted")
                if now >= deadlines.kill and child.poll() is None and not killed:
                    killed = True
                    stop("outer fence")
                    try:
                        os.killpg(child.pid, signal.SIGKILL)
                    except ProcessLookupError:
                        pass
                if not work_checked and now >= deadlines.work:
                    work_checked = True
                    if not saw_guest_stop(directory / files["native"], attempt, deadlines.work, binding):
                        stop("work deadline")
                for key, _ in selector.select(0.025):
                    stream = streams[key.data]
                    try:
                        data = os.read(key.fd, 64 * 1024)
                    except BlockingIOError:
                        continue
                    except OSError:
                        stop(f"{key.data} read failed")
                        selector.unregister(key.fileobj)
                        continue
                    if data:
                        stream.consume(data)
                        if stream.failed or stream.received > stream.limit:
                            stop(f"{key.data} retention limit or write failure")
                    else:
                        stream.eof = True
                        selector.unregister(key.fileobj)
        finally:
            if child.poll() is None:
                stop("exception or unconfirmed worker exit")
                if not killed:
                    killed = True
                    try:
                        os.killpg(child.pid, signal.SIGKILL)
                    except ProcessLookupError:
                        pass
                remaining = max(0, deadlines.reap - (clock_ns() - origin)) / SECOND
                try:
                    child.wait(timeout=remaining)
                except subprocess.TimeoutExpired:
                    pass
            if child.returncode is not None:
                if reaped_at is None:
                    reaped_at = clock_ns() - origin
                group_gone = group_absent(child.pid)
            for stream in streams.values():
                try:
                    os.fsync(stream.stream.fileno())
                except OSError:
                    stream.failed = True
                    stop("RAW sync failed")

        confirmed = (reaped_at is not None and group_gone and all(stream.complete for stream in streams.values()))
        return {"profile": PROFILE, "workload": binding.workload, "config_sha256": binding.config_sha256,
                "worker_pid": child.pid, "worker_exit": child.returncode,
                "worker_reaped": reaped_at is not None, "worker_reaped_ns": reaped_at,
                "owned_group_absent": group_gone, "controller_stop": reason is not None,
                "stop_reason": reason, "outer_kill": killed, "capture_complete": confirmed,
                "captures": {name: stream.receipt() for name, stream in streams.items()}}
