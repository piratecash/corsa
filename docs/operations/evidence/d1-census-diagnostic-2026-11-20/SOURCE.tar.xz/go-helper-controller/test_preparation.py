import io,json,struct,tempfile,unittest
from pathlib import Path
import common,rebuild as host_build

class Tests(unittest.TestCase):
 def test_exact_go_cases_and_refuse_missing_failure_skip(self):
  rows=[dict(Package=p,Test=t,Action='pass') for p,tests in host_build.EXPECTED.items() for t in tests]
  raw=lambda value:b'\n'.join(json.dumps(row).encode() for row in value)
  host_build.go_passes(raw(rows))
  for bad in (rows[:-1],rows+[dict(Action='skip')],rows+[dict(Action='fail')]):
   with self.assertRaises(RuntimeError):host_build.go_passes(raw(bad))
 def test_static_arm64_guard(self):
  with tempfile.TemporaryDirectory() as temp:
   p=Path(temp)/'fixture';raw=bytearray(128);raw[:16]=b'\x7fELF\x02\x01\x01'+bytes(9)
   struct.pack_into('<HHIQQQIHHHHHH',raw,16,2,183,1,0,64,0,0,64,56,1,0,0,0);struct.pack_into('<IIQQQQQQ',raw,64,1,5,0,0,0,len(raw),len(raw),4096)
   p.write_bytes(raw);self.assertTrue(common.static_arm64(p)['static_arm64'])
   for kind in (2,3):
    bad=bytearray(raw);struct.pack_into('<I',bad,64,kind);p.write_bytes(bad)
    with self.assertRaises(RuntimeError):common.static_arm64(p)
 def test_snapshot_hash_and_file_bounds(self):
  with tempfile.TemporaryDirectory() as temp:
   root=Path(temp);p=root/'one';p.write_bytes(b'one')
   self.assertEqual(common.sha(p),'7692c3ad3540bb803c020b3aee66cd8887123234ea0c6e7143c0add73ff431ed')
   with self.assertRaises(RuntimeError):common.directory_bytes(root,2)
   (root/'linked').symlink_to(p)
   with self.assertRaises(RuntimeError):common.sha(root/'linked')
 def test_source_test_inventory_declared_ten(self):
  self.assertEqual(sum(len(v) for v in host_build.EXPECTED.values()),10)

 def test_test_only_profile_overlay_guards(self):
  import bind
  before=Path('/private/tmp/corsa-o1a-census-component-inputs-8eba82dda57843b99ff3999bd4ee91ee/pid1-source/cmd/o1a-init/config_test.go').read_bytes()
  after=bind.test_overlay(before)
  self.assertEqual(before.split(b'func TestOriginalBudgetsRemainNested')[0],after.split(b'func TestOriginalBudgetsRemainNested')[0])
  for token in (b'Work==600*time.Second&&Kill==610*time.Second&&Reap==620*time.Second&&Export==30*time.Second&&Poweroff==650*time.Second',b'want:=int64(540*time.Second)',b'window:=int64(240*time.Second)',b'lead:=int64(90*time.Second)'):self.assertIn(token,after)
  self.assertIn(b'want=int64(90*time.Second);window=int64(13*time.Second);lead=int64(10*time.Second)',after)
  for bad in (before+b' ',before.replace(b'540*time.Second',b'541*time.Second'),before.replace(b'600*time.Second',b'601*time.Second'),before.replace(b'225*time.Second',b'226*time.Second')):
   with self.assertRaisesRegex(ValueError,'unknown helper test preimage'):bind.test_overlay(bad)

if __name__=='__main__':unittest.main()
