# Component census diagnostic helper build — SOURCE ONLY

This controller is UNBOUND / NOT_EXECUTED. No FROZEN.json/source directory is invented. After Root accepts actual data preparation, bind both helper controllers with:

```
python3 ../d1-o1a-census-component-go-helper-build-v2/bind.py --result /ABS/ACTUAL_COMPONENT_INPUTS/RESULT.json --sha EXACT_RESULT_SHA
```

The binder requires exact component scope/profile/708 source identity and source inventories, copies all helper input bytes, and records actual source/result hashes. Fresh one-shot binding; no build or ELF execution. Root must independently accept the data output and fresh source manifest before invoking the controller. The old source archive/API acceptance is reused only by exact2450 source identity (original API640/708 actually passed); no duplicate API build command.

Root then invokes `python3 rebuild.py`: ONE offline local Go1.27.4 job under accepted heavy-lock600s+30s cleanup; GOMAXPROCS2/GOMEMLIMIT768MiB/-p1 are soft limits, workspace ≤2GiB final phase accounting (within6GiB allowed); ≥10GiB free. Six commands: exact version, ten existing PID1 pure tests, static Linuxarm64/CGO0 PID1 build+metadata, exporter build+metadata. Source snapshots readonly; sandbox denies network. Exporter entry has actual component f848 profile; codec unchanged. Root0755/caps/mounts/lifecycle unchanged. The resulting ELF is never executed here. Accepted common.py byte exact retains group UNKNOWN/hold-lock recovery. Missing/failed/OOM/timeout→STOP without repeat/increase; unknown closure retains own lock. No global host hard caps/noSwap guarantee or hard disk quota claimed.

Only ten existing PID1 tests are expected. Existing capsule codec tests/crosslanguage transport were accepted earlier and codec is unchanged; no blanket duplicate QA or new admission gate. Source parameter unit tests in the input preparer prove exact profile changes. Four small controller unit tests and two bounded fixture-only binder tests passed before actual data binding.

These helpers support only COMPONENT_CENSUS_DIAGNOSTIC; no O1a metric/Bps admission, public activation or release. Original four diagnostic Go ELFs are inputs elsewhere and never run by these builds. No Docker image is created or deleted.

Version2 adds ONLY one helper TEST-file overlay after actual data readback (no new source archive). Accepted data7c254... and all production/helper runtime sources unchanged. Exact preimage/postimage pins and TEST-ONLY.diff: `TestOriginalBudgetsRemainNested` now expects reconnect90/lead10/window13, periodic540/90/240 and wrapper600/610/620/30/650 exactly preserved. Same ten original named Go tests execute; no extra Go tests, source API or resource scenario. Four negative preimage mutations and positive prefix/budget readback in one pure Python test. v1 remains NOT_BUILT; C controller-v1/source unchanged and is bound directly from original data.
