"""One-shot DATA binding of the two prepared helper build controllers, no execution."""
import argparse,hashlib,json,os,re,stat,sys
from pathlib import Path
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent;DAY=HERE.parent
C=DAY/'d1-o1a-census-component-capexec-build-v1'
TEMPLATES={'pid1-source':DAY/'d1-o1a-baseline-finalizer-pid1-build-v1','capexec-source':DAY/'d1-o1a-baseline-finalizer-capexec-build-v1'}
TEMPLATE_SHA={'pid1-source': '5ce22c6b2a880679b34a61429d2235ae0c5bc74c0d5b1f6b4d189047dd56265a', 'capexec-source': '521e0c4a545ebec1a494b5a64e60a3c1e9cd69c1bdf87b3a55d088ed1b94c5c5'}
def need(v,why):
 if not v:raise ValueError(why)
def raw(p,cap=2*1024**2):
 s=p.lstat();need(stat.S_ISREG(s.st_mode) and s.st_size<=cap,'bounded regular input required')
 with p.open('rb') as f:r=f.read(s.st_size+1)
 need(len(r)==s.st_size,'input changed');return r
def sha(p):return hashlib.sha256(raw(p)).hexdigest()
# Exact test-only component adaptation; runtime source is not changed.
TEST_PATH='cmd/o1a-init/config_test.go'
TEST_BEFORE='f61d9887894e01d04f1e31a04a49b51f9a276b91c94240d8d088c1bf029b5e33'
TEST_AFTER='bca311a19b2a8e98a2daa2b2661bd0cd738f3333fe27e79ebfe45094aa68c2da'
def test_overlay(before):
 need(hashlib.sha256(before).hexdigest()==TEST_BEFORE,'unknown helper test preimage')
 after=raw(HERE/'posts/config_test.go')
 need(hashlib.sha256(after).hexdigest()==TEST_AFTER,'component test postimage changed')
 return after
def controller_check(folder):
 manifest=json.loads(raw(folder/'SOURCE.json'))
 for name,row in manifest['files'].items():need(sha(folder/name)==row['sha256'] and (folder/name).stat().st_size==row['bytes'],'controller source changed: '+name)
def bind(path,wanted):
 need(re.fullmatch('[0-9a-f]{64}',wanted) is not None and sha(path)==wanted,'data result hash')
 value=json.loads(raw(path));need(value['status']=='COMPONENT_INPUTS_SOURCE_ONLY_NOT_HELPERS_OR_RUNTIME' and value['scope']=='COMPONENT_CENSUS_DIAGNOSTIC_NO_METRIC_ADMISSION' and value['helpers']=='NOT_BUILT' and value['runtime_ready'] is False and value['resource_execution'] is False,'not exact unexecuted component data')
 need(value['profile']['sha256']=='f84856cfa6f3c3d39f4f5d69487c5d968106aeea77b16f8a3d7bf864266e7369' and value['source_groups']['stand']['files']==708 and value['source_groups']['stand']['sha256']=='6aacd581b6ee23fe91004f08d64e9a4ba1898e3659a6881d17901b41fbdd1b84','component source/profile')
 for folder in (HERE,C):controller_check(folder);need(not os.path.lexists(folder/'FROZEN.json') and not os.path.lexists(folder/'source'),'one fresh controller data bind only')
 plans=[]
 for kind,folder in (('pid1-source',HERE),('capexec-source',C)):
  row=value['helper_sources'][kind];source=Path(row['source_path']);need(source==path.parent/kind and source.resolve()==source,'foreign helper source')
  files={}
  for name,pin in row['source_files'].items():
   rel=Path(name);need(not rel.is_absolute() and '..' not in rel.parts and rel.as_posix()==name,'source path')
   data=raw(source/name);need(hashlib.sha256(data).hexdigest()==pin['sha256'] and len(data)==pin['bytes'],'helper source bytes');files[name]=data
  need(sha(source/'SHA256SUMS')==row['source_sums_sha256'],'helper source inventory changed')
  plans.append((kind,folder,row,files,raw(source/'SHA256SUMS')))
 for kind,folder,row,files,sums in plans:
  dest=folder/'source';dest.mkdir(mode=0o700)
  for name,data in files.items():target=dest/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data);need(sha(target)==row['source_files'][name]['sha256'],'copied source changed')
  if kind=='pid1-source':
   before=files[TEST_PATH];after=test_overlay(before);target=dest/TEST_PATH;target.write_bytes(after)
   source_rows=dict(row['source_files']);source_rows[TEST_PATH]={'bytes':len(after),'sha256':hashlib.sha256(after).hexdigest()}
   sums=''.join(v['sha256']+'  '+n+'\n' for n,v in sorted(source_rows.items())).encode()
  else:source_rows=row['source_files']
  (dest/'SHA256SUMS').write_bytes(sums)
  need(sha(TEMPLATES[kind]/'FROZEN.json')==TEMPLATE_SHA[kind],'accepted parent build template changed')
  frozen=json.loads(raw(TEMPLATES[kind]/'FROZEN.json'))
  frozen.update(scope='COMPONENT_CENSUS_DIAGNOSTIC_HELPER_BUILD_NOT_EXECUTED',data_preparation_result={'path':str(path),'sha256':wanted},source_files=source_rows,source_sums_sha256=hashlib.sha256(sums).hexdigest())
  if kind=='pid1-source':
   for key in ('readback_command_sha256','readback_files','readback_input_root','python_reference'):frozen.pop(key,None)
   frozen['original_Go_source_API']='REUSED_ACTUAL_PASS_EXACT_2450_SOURCE_IDENTITY'
   frozen['test_only_overlay']={'path':TEST_PATH,'before_sha256':TEST_BEFORE,'after_sha256':TEST_AFTER,'runtime_source_changed':False}
  else:
   need(sha(folder/'reference/policy_data.py')==row['source_files']['policy_data.py']['sha256'],'pure policy reader must be same actual source')
   frozen['build_script_sha256']=sha(folder/'build.sh')
  (folder/'FROZEN.json').write_text(json.dumps(frozen,indent=2,sort_keys=True)+'\n')
  controller_check(folder)
  print(json.dumps({'controller':str(folder),'status':'DATA_BOUND_NOT_EXECUTED','frozen_sha256':sha(folder/'FROZEN.json'),'source_sums_sha256':sha(dest/'SHA256SUMS')}))
 need(sha(path)==wanted,'data result changed during bind')
if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--result',type=Path,required=True);p.add_argument('--sha',required=True);a=p.parse_args();bind(a.result,a.sha)
