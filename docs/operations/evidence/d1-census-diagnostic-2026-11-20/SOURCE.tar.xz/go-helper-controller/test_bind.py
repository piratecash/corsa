import hashlib,json,tempfile,unittest
from pathlib import Path
from unittest import mock
import bind as b
class Tests(unittest.TestCase):
 def test_invalid_data_refuses_before_controller_or_mutation(self):
  with tempfile.TemporaryDirectory() as t:
   p=Path(t)/'RESULT.json';p.write_text('{}')
   with self.assertRaises((KeyError,ValueError)):b.bind(p,b.sha(p))
   self.assertEqual({x.name for x in p.parent.iterdir()},{'RESULT.json'})
 def test_exact_fixture_data_bind_and_one_shot_refusal(self):
  with tempfile.TemporaryDirectory() as t:
   root=Path(t).resolve();go=root/'go';c=root/'c';data=root/'data';data.mkdir()
   for folder in (go,c):folder.mkdir();(folder/'SOURCE.json').write_text('{"files":{}}')
   (go/'posts').mkdir();(go/'posts/config_test.go').write_bytes((Path(b.__file__).parent/'posts/config_test.go').read_bytes());(c/'reference').mkdir();(c/'reference/policy_data.py').write_bytes(b'# fixture pure reader\n');(c/'build.sh').write_bytes(b'# fixture static compiler args\n')
   families={};templates={}
   for kind in ('pid1-source','capexec-source'):
    s=data/kind;s.mkdir();files={b.TEST_PATH:Path('/private/tmp/corsa-o1a-census-component-inputs-8eba82dda57843b99ff3999bd4ee91ee/pid1-source/cmd/o1a-init/config_test.go').read_bytes()} if kind=='pid1-source' else {'policy_data.py':b'# fixture pure reader\n'}
    records={}
    for n,raw in files.items():
     target=s/n;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw);records[n]={'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
    (s/'SHA256SUMS').write_bytes(b'fixture inventory\n');families[kind]={'source_path':str(s),'source_files':records,'source_sums_sha256':b.sha(s/'SHA256SUMS')}
    old=root/('old-'+kind);old.mkdir();(old/'FROZEN.json').write_text('{"toolchain_files":{}}');templates[kind]=old
   r={'status':'COMPONENT_INPUTS_SOURCE_ONLY_NOT_HELPERS_OR_RUNTIME','scope':'COMPONENT_CENSUS_DIAGNOSTIC_NO_METRIC_ADMISSION','helpers':'NOT_BUILT','runtime_ready':False,'resource_execution':False,'profile':{'sha256':'f84856cfa6f3c3d39f4f5d69487c5d968106aeea77b16f8a3d7bf864266e7369'},'source_groups':{'stand':{'files':708,'sha256':'6aacd581b6ee23fe91004f08d64e9a4ba1898e3659a6881d17901b41fbdd1b84'}},'helper_sources':families}
   p=data/'RESULT.json';p.write_text(json.dumps(r))
   with mock.patch.object(b,'HERE',go),mock.patch.object(b,'C',c),mock.patch.object(b,'TEMPLATES',templates),mock.patch.object(b,'TEMPLATE_SHA',{k:b.sha(v/'FROZEN.json') for k,v in templates.items()}):
    b.bind(p,b.sha(p))
    for folder in (go,c):self.assertTrue((folder/'source').is_dir());self.assertEqual(json.loads((folder/'FROZEN.json').read_text())['data_preparation_result']['sha256'],b.sha(p))
    with self.assertRaisesRegex(ValueError,'one fresh'):b.bind(p,b.sha(p))
if __name__=='__main__':unittest.main()
