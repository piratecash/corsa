"""Assemble one component data archive from exact accepted helpers; no ELF execution."""
from pathlib import Path
import hashlib,json,os,secrets,shutil,sys
from assemble import assemble,exact
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE.parent/'d1-o1a-helper-build-v1'))
from common import Job,need,sha

def check(frozen):
    need(all(type(row) is dict for row in frozen['helpers'].values()),'actual helper records required')
    for name,row in frozen['helpers'].items():need(sha(row['path'])==row['sha256'] and Path(row['path']).stat().st_size==row['bytes'],'accepted helper changed: '+name)
    for name,digest in frozen['source'].items():need(sha(HERE/name)==digest,'assembly source changed')
    for name,digest in frozen['accepted_dependencies'].items():need(sha(name)==digest,'accepted dependency changed')
    need(sha(frozen['template_path'])==frozen['template_sha256'],'template changed')
    need(sha(frozen['prepared_input_result']['path'])==frozen['prepared_input_result']['sha256'],'prepared input data changed')
    need(sha(frozen['baseline_build_result']['path'])==frozen['baseline_build_result']['sha256'],'baseline build data changed')
    for row in frozen['helper_build_results'].values():need(sha(row['path'])==row['sha256'],'actual helper result changed')

def child(work):
    frozen=json.loads((HERE/'PACK-FROZEN.json').read_bytes());check(frozen)
    helpers={k:Path(v['path']) for k,v in frozen['helpers'].items()};outputs={}
    for phase in ('reconnect',):
        attempt=secrets.token_hex(16);p=work/(phase+'.cpio.gz')
        result=assemble(p,phase,attempt,helpers['init'],helpers['capexec'],helpers['exporter'])
        result['accepted_helpers']=frozen['helpers']
        receipt=work/(phase+'.assembly.json');receipt.write_text(json.dumps(result,sort_keys=True,indent=2)+'\n')
        outputs[phase]={'attempt_id':attempt,'config_sha256':result['config_sha256'],'archive':str(p),'archive_sha256':result['archive']['sha256'],'archive_bytes':result['archive']['bytes'],'receipt':str(receipt),'receipt_sha256':sha(receipt)}
    check(frozen);print(json.dumps(outputs,sort_keys=True))

def main():
    os.umask(0o077)
    if os.getpid()!=os.getpgrp():os.setsid()
    frozen=json.loads((HERE/'PACK-FROZEN.json').read_bytes());job=Job('initrd-data-assembly',600,1024**3);error=None;outputs=None
    try:
        need(shutil.disk_usage('/private/tmp').free>=10*1024**3,'free space')
        check(frozen)
        policy='(version 1)(allow default)(deny network*)'
        env={'PATH':'/usr/bin:/bin','HOME':str(job.work),'LC_ALL':'C','PYTHONDONTWRITEBYTECODE':'1'}
        raw=job.run('assemble-data',['/usr/bin/sandbox-exec','-p',policy,sys.executable,'-B',str(HERE/'pack_job.py'),'--child',str(job.work)],env=env)
        outputs=json.loads(raw);check(frozen)
    except BaseException as exc:error=str(exc)
    result=job.finish(dict(status='COMPONENT_INITRD_BYTE_VERIFIED' if error is None else 'FAILED',error=error,outputs=outputs,ELF_or_VM_executed=False))
    (HERE/'PACK-RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
    if error:raise SystemExit(1)

if __name__=='__main__':
    if len(sys.argv)==3 and sys.argv[1]=='--child':child(Path(sys.argv[2]))
    else:main()
