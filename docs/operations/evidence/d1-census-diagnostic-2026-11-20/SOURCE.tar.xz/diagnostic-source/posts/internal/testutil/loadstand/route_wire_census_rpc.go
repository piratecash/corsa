package loadstand

import (
	"context"
	"encoding/json"
	"reflect"

 "github.com/piratecash/corsa/internal/testutil/loadstand/censusdiag"

	"github.com/piratecash/corsa/internal/core/domain"
)

const RouteWireCensusCommand = "loadstandRouteWireCensus"
const routeWireCensusWitnessLimit = 1024

type routeWireCensusWitness struct {
	Version     uint8
	Launch      LaunchNonce
	Fingerprint LaunchFingerprint
	Identity    domain.PeerIdentity
	Clock       RouteWireClockDomain
	Census      RouteWireCommitment
}

// NewRouteWireCensusWitness binds the registry digest to the launch without
// exposing the census rows or the final frame counters.
func NewRouteWireCensusWitness(slot *ChildFinalSlot, identity domain.PeerIdentity, plan PlannedRouteWireObservation, clock RouteWireClockDomain, readClock func() (RouteWireClockDomain, error), read func() ([]RouteWireEndpointKey, error)) (func() (json.RawMessage, error), error) {
	if slot == nil || read == nil || identity.IsZero() ||
		!clock.valid() || readClock == nil ||
		slot.binding.nonce == (LaunchNonce{}) || slot.binding.fingerprint == (LaunchFingerprint{}) ||
		plan.Window == (LaunchNonce{}) || !plan.Bounds.valid() || plan.MaxEndpoints <= 0 {
		return nil, ErrInvalidConfiguration
	}
	launch := slot.binding
	return func() (json.RawMessage, error) {
		if current, err := readClock(); err != nil || current != clock {
			return nil, censusdiag.CensusFailure(censusdiag.CensusStageWitnessClockBefore, ErrFinalAccountingUnavailable)
		}
		rows, err := read()
		if err != nil {
            if stage, ok := censusdiag.CensusDiagnostic(err); ok { return nil, censusdiag.CensusFailure(stage, ErrFinalAccountingUnavailable) }
            return nil, ErrFinalAccountingUnavailable
        }
        if rows == nil || len(rows) > plan.MaxEndpoints { return nil, censusdiag.CensusFailure(censusdiag.CensusStageWitnessRows, ErrFinalAccountingUnavailable) }
		census, err := commitRouteWireWindow(RouteWireExpectation{Window: plan.Window, Bounds: plan.Bounds, Endpoints: rows}, identity)
		if err != nil {
			return nil, censusdiag.CensusFailure(censusdiag.CensusStageWitnessCommit, err)
		}
		if current, err := readClock(); err != nil || current != clock {
			return nil, censusdiag.CensusFailure(censusdiag.CensusStageWitnessClockAfter, ErrFinalAccountingUnavailable)
		}
		raw, err := json.Marshal(routeWireCensusWitness{Version: 1, Launch: launch.nonce, Fingerprint: launch.fingerprint, Identity: identity, Clock: clock, Census: census})
		if err != nil || len(raw) > routeWireCensusWitnessLimit {
			return nil, censusdiag.CensusFailure(censusdiag.CensusStageWitnessEncode, ErrFinalAccountingUnavailable)
		}
		return raw, nil
	}, nil
}

// ReadRouteWireCensus queries the currently owned FullNode before its Stop.
// expectedClock is the caller's independently read kernel clock domain.
func (p *Process) ReadRouteWireCensus(ctx context.Context, binding CompletedStartBinding, plan PlannedRouteWireObservation, expectedClock RouteWireClockDomain) (RouteWireCommitment, error) {
	if p == nil || p.finalRole != MemberFull || p.rpc == nil || p.artifacts == nil || p.artifacts.binding != binding.launch || !plan.Bounds.valid() {
		return RouteWireCommitment{}, censusdiag.CensusFailure(censusdiag.CensusStageProcessBinding, ErrFinalAccountingUnavailable)
	}
	select {
	case <-p.done:
		return RouteWireCommitment{}, censusdiag.CensusFailure(censusdiag.CensusStageProcessEndedBefore, ErrFinalAccountingUnavailable)
	default:
	}
	var raw json.RawMessage
	if err := p.rpc.Call(ctx, RouteWireCensusCommand, nil, &raw); err != nil {
		if stage, ok := censusdiag.CensusDiagnostic(err); ok { return RouteWireCommitment{}, censusdiag.CensusFailure(stage, err) }; return RouteWireCommitment{}, censusdiag.CensusFailure(censusdiag.CensusStageProcessRPC, err)
	}
	select {
	case <-p.done:
		return RouteWireCommitment{}, censusdiag.CensusFailure(censusdiag.CensusStageProcessEndedAfter, ErrFinalAccountingUnavailable)
	default:
	}
	if err := ctx.Err(); err != nil {
		return RouteWireCommitment{}, censusdiag.CensusFailure(censusdiag.CensusStageProcessContext, err)
	}
	commitment, err := decodeRouteWireCensusWitness(raw, binding, plan, expectedClock)
    if err != nil { return RouteWireCommitment{}, censusdiag.CensusFailure(censusdiag.CensusStageProcessDecode, err) }; return commitment, nil
}

func decodeRouteWireCensusWitness(raw json.RawMessage, binding CompletedStartBinding, plan PlannedRouteWireObservation, expectedClock RouteWireClockDomain) (RouteWireCommitment, error) {
	var w routeWireCensusWitness
	if len(raw) > routeWireCensusWitnessLimit || !canonicalLinuxJSON(raw, reflect.TypeFor[routeWireCensusWitness](), false) ||
		json.Unmarshal(raw, &w) != nil || w.Version != 1 || w.Launch != binding.launch.nonce || w.Fingerprint != binding.launch.fingerprint ||
		w.Identity != binding.RuntimeBinding().Identity || !expectedClock.valid() || w.Clock != expectedClock || !plan.Bounds.valid() || !acceptsRouteWireCommitment(&plan, w.Census) {
		return RouteWireCommitment{}, ErrFinalReportInvalid
	}
	return w.Census, nil
}

// Private fixture error annotation; success is never manufactured and the
// existing sentinel/unwrap chain is retained. No arbitrary cause is formatted.
func censusStageFailure(stage censusdiag.CensusStage, err error) error {
    if _, ok := censusdiag.CensusDiagnostic(err); ok { return err }
    return censusdiag.CensusFailure(stage, err)
}

// Error-body recognition only for the ORIGINAL fixture census command and
// HTTP503 in RPCClient.Call. Unknown/malformed bodies retain legacy refusal.
func decodeRouteWireCensusRPCDiagnostic(raw []byte) error {
    type failure struct { Error string `json:"error"` }
    if len(raw)>256 || !canonicalLinuxJSON(raw, reflect.TypeFor[failure](), false) { return nil }
    var body failure
    if json.Unmarshal(raw,&body)!=nil { return nil }
    stage,ok:=censusdiag.CensusDiagnosticFromRPCMessage(body.Error)
    if !ok { return nil }
    return censusdiag.CensusFailure(stage,ErrFamilyUnavailable)
}
