package fullwitness

import (
    "encoding/json"
    "errors"
        "strings"
    "testing"

    "github.com/piratecash/corsa/internal/core/rpc"
 "github.com/piratecash/corsa/internal/testutil/loadstand/censusdiag"
)

func TestCensusDiagnosticClosedStagesAndUnwrap(t *testing.T) {
    secret := errors.New("DO_NOT_LEAK_PRIVATE_PAYLOAD")
    for stage := censusdiag.CensusStageFullRegistry; stage <= censusdiag.CensusStageParentDecode; stage++ {
        t.Run(stage.Label(), func(t *testing.T) {
            err := censusdiag.CensusFailure(stage, secret)
            if !errors.Is(err, secret) || strings.Contains(err.Error(), secret.Error()) { t.Fatal("unwrap or fixed formatting") }
            if got, ok := censusdiag.CensusDiagnostic(err); !ok || got != stage { t.Fatal("typed stage lost") }
            if got, ok := censusdiag.CensusDiagnosticFromRPCMessage(censusdiag.CensusRPCMessage(stage)); !ok || got != stage { t.Fatal("exact RPC mapping") }
            for _, text := range []string{"rpc error: "+censusdiag.CensusRPCMessage(stage), censusdiag.CensusRPCMessage(stage)+" ", "prefix "+censusdiag.CensusRPCMessage(stage), censusdiag.CensusRPCMessage(stage)+secret.Error()} {
                if _, ok := censusdiag.CensusDiagnosticFromRPCMessage(text); ok { t.Fatal("non-exact text accepted") }
            }
        })
    }
    for _, stage := range []censusdiag.CensusStage{censusdiag.CensusStageNone, 255} {
        err := censusdiag.CensusFailure(stage, secret)
        if _, ok := censusdiag.CensusDiagnostic(err); ok || !errors.Is(err, secret) || strings.Contains(err.Error(), secret.Error()) { t.Fatal("unknown diagnostic escaped") }
    }
    if _, ok := censusdiag.CensusDiagnosticFromRPCMessage(secret.Error()); ok { t.Fatal("arbitrary secret accepted") }
}

func TestCensusRPCPublishesOnlyTypedClosedDiagnostic(t *testing.T) {
    for _, tc := range []struct{name string; callback error; label string}{
        {"typed", censusdiag.CensusFailure(censusdiag.CensusStageFullReceipt, errors.New("DO_NOT_LEAK")), censusdiag.CensusRPCMessage(censusdiag.CensusStageFullReceipt)},
        {"unknown", errors.New("DO_NOT_LEAK"), "fixture registry witness unavailable"},
        {"unknown enum", censusdiag.CensusFailure(255, errors.New("DO_NOT_LEAK")), "fixture registry witness unavailable"},
    } {
        t.Run(tc.name,func(t *testing.T) {
            table:=rpc.NewCommandTable()
            if err:=RegisterRouteWireCensus(table,"closed",func()(json.RawMessage,error){return nil,tc.callback});err!=nil{t.Fatal(err)}
            response:=table.Execute(rpc.CommandRequest{Name:"closed",Ctx:t.Context()})
            if response.ErrorKind!=rpc.ErrUnavailable || response.Data!=nil || response.Error==nil || response.Error.Error()!=tc.label || strings.Contains(response.Error.Error(),"DO_NOT_LEAK") { t.Fatal("unsafe/unavailable response") }
        })
    }
}
