package censusdiag

import "errors"

// Closed fixture diagnostics only. A label never authorizes a census or changes
// its success/failure; it contains no error text, address, identity or secret.
type CensusStage uint8

const (
    CensusStageNone CensusStage = iota
    CensusStageFullRegistry
    CensusStageFullReceipt
    CensusStageWitnessClockBefore
    CensusStageWitnessRows
    CensusStageWitnessCommit
    CensusStageWitnessClockAfter
    CensusStageWitnessEncode
    CensusStageProcessBinding
    CensusStageProcessEndedBefore
    CensusStageProcessRPC
    CensusStageProcessEndedAfter
    CensusStageProcessContext
    CensusStageProcessDecode
    CensusStageHelperBinding
    CensusStageHelperClockBefore
    CensusStageHelperClockAfter
    CensusStageHelperClockMismatch
    CensusStageHelperCommitConflict
    CensusStageParentBinding
    CensusStageParentRunning
    CensusStageParentClockBefore
    CensusStageParentClockAfter
    CensusStageParentState
    CensusStageParentWrite
    CensusStageParentRead
    CensusStageParentDecode
)

func (s CensusStage) Valid() bool { return s > CensusStageNone && s <= CensusStageParentDecode }

func (s CensusStage) Label() string {
    switch s {
    case CensusStageFullRegistry: return "full_registry"
    case CensusStageFullReceipt: return "full_receipt"
    case CensusStageWitnessClockBefore: return "witness_clock_before"
    case CensusStageWitnessRows: return "witness_rows"
    case CensusStageWitnessCommit: return "witness_commit"
    case CensusStageWitnessClockAfter: return "witness_clock_after"
    case CensusStageWitnessEncode: return "witness_encode"
    case CensusStageProcessBinding: return "process_binding"
    case CensusStageProcessEndedBefore: return "process_ended_before"
    case CensusStageProcessRPC: return "process_rpc"
    case CensusStageProcessEndedAfter: return "process_ended_after"
    case CensusStageProcessContext: return "process_context"
    case CensusStageProcessDecode: return "process_decode"
    case CensusStageHelperBinding: return "helper_binding"
    case CensusStageHelperClockBefore: return "helper_clock_before"
    case CensusStageHelperClockAfter: return "helper_clock_after"
    case CensusStageHelperClockMismatch: return "helper_clock_mismatch"
    case CensusStageHelperCommitConflict: return "helper_commit_conflict"
    case CensusStageParentBinding: return "parent_binding"
    case CensusStageParentRunning: return "parent_running"
    case CensusStageParentClockBefore: return "parent_clock_before"
    case CensusStageParentClockAfter: return "parent_clock_after"
    case CensusStageParentState: return "parent_state"
    case CensusStageParentWrite: return "parent_write"
    case CensusStageParentRead: return "parent_read"
    case CensusStageParentDecode: return "parent_decode"
    default: return "unknown"
    }
}

type censusFailure struct { stage CensusStage; cause error }

func (e *censusFailure) Error() string {
    if e == nil || !e.stage.Valid() { return "fixture census unavailable" }
    return "fixture census unavailable: stage=" + e.stage.Label()
}
func (e *censusFailure) Unwrap() error { if e == nil { return nil }; return e.cause }

// Unwrap retains errors.Is locally. Formatting never includes cause.Error().
func CensusFailure(stage CensusStage, cause error) error { return &censusFailure{stage:stage, cause:cause} }

func CensusDiagnostic(err error) (CensusStage, bool) {
    var e *censusFailure
    if errors.As(err, &e) && e != nil && e.stage.Valid() { return e.stage, true }
    return CensusStageNone, false
}

func CensusRPCMessage(stage CensusStage) string {
    if !stage.Valid() { return "fixture registry witness unavailable" }
    return "fixture registry witness unavailable: census_stage=" + stage.Label()
}

// Only the exact fixed server error-message is mapped. The caller separately
// verifies the authenticated launch-bound client, HTTP503, command and schema.
func CensusDiagnosticFromRPCMessage(raw string) (CensusStage, bool) {
    if len(raw) > 96 { return CensusStageNone, false }
    for s := CensusStageFullRegistry; s <= CensusStageParentDecode; s++ {
        if raw == CensusRPCMessage(s) { return s, true }
    }
    return CensusStageNone, false
}
