package loadstand

import (
    "encoding/json"
    "errors"
    "io"
    "net/http"
    "strings"
    "testing"

    "github.com/piratecash/corsa/internal/testutil/loadstand/censusdiag"
    "github.com/piratecash/corsa/internal/core/domain"
)

func TestRouteWireDiagnosticUnavailableOnlyAndLegacyAbsence(t *testing.T) {
    _, binding, expected := routeWireBoundedFixture(t, RouteWireWindowBounds{Begin:100,End:200})
    census,err:=commitRouteWireWindow(expected,binding.RuntimeBinding().Identity);if err!=nil{t.Fatal(err)}
    plan:=PlannedRouteWireObservation{Window:expected.Window,Bounds:expected.Bounds,MaxEndpoints:len(expected.Endpoints)}
    clock:=RouteWireClockDomain{BootID:"c481cc22-adf3-4d99-a4fe-de7f204e0ad6",Device:4,Inode:17}
    for _, ready:=range []bool{false,true} {
        for _, field:=range []string{"absent","1","0","null","255","\"1\"","{}"} {
            t.Run(field+map[bool]string{true:"-ready",false:"-unavailable"}[ready],func(t *testing.T){
                reply:=linuxRouteWireCensusReply{Nonce:binding.launch.nonce,Code:linuxResultUnavailable}
                if ready{reply.Code=linuxResultReady;reply.Census=&census;reply.Clock=&clock}
                raw,err:=json.Marshal(reply);if err!=nil{t.Fatal(err)}
                if field!="absent"{raw=append(append([]byte{},raw[:len(raw)-1]...),[]byte(",\"Diagnostic\":"+field+"}")...)}
                got,err:=decodeLinuxRouteWireCensusReply(linuxPacket{kind:linuxRouteWireCensusResult,id:4,ordinal:1,body:raw},4,binding.launch.nonce,&plan,clock)
                switch {
                case ready&&field=="absent":if err!=nil||got!=census{t.Fatal("legacy Ready changed")}
                case !ready&&field=="absent":if !errors.Is(err,ErrFinalAccountingUnavailable){t.Fatal("legacy Unknown changed")};if _,ok:=censusdiag.CensusDiagnostic(err);ok{t.Fatal("invented legacy stage")}
                case !ready&&field=="1":if !errors.Is(err,ErrFinalAccountingUnavailable){t.Fatal("typed refusal changed")};if stage,ok:=censusdiag.CensusDiagnostic(err);!ok||stage!=censusdiag.CensusStageFullRegistry{t.Fatal("stage lost")}
                default:if !errors.Is(err,ErrLinuxOwnerProtocol){t.Fatal("present malformed/Ready diagnostic accepted")}
                }
            })
        }
    }
    for _, body:=range []string{
        `{"Nonce":"`+binding.launch.nonce.String()+`","Code":4,"Diagnostic":1,"Diagnostic":2}`,
        `{"Nonce":"`+binding.launch.nonce.String()+`","Code":4,"diagnostic":1}`,
    }{if _,err:=decodeLinuxRouteWireCensusReply(linuxPacket{kind:linuxRouteWireCensusResult,id:4,ordinal:1,body:[]byte(body)},4,binding.launch.nonce,&plan,clock);!errors.Is(err,ErrLinuxOwnerProtocol){t.Fatal("noncanonical fields accepted")}}
}

func TestRouteWireWitnessPreservesTypedStagesAndDropsRawCause(t *testing.T) {
    _, binding, expected:=routeWireBoundedFixture(t,RouteWireWindowBounds{Begin:100,End:200})
    plan:=PlannedRouteWireObservation{Window:expected.Window,Bounds:expected.Bounds,MaxEndpoints:len(expected.Endpoints)}
    clock:=RouteWireClockDomain{BootID:"c481cc22-adf3-4d99-a4fe-de7f204e0ad6",Device:4,Inode:17}
    secret:=errors.New("DO_NOT_LEAK")
    for _, stage:=range []censusdiag.CensusStage{censusdiag.CensusStageFullRegistry,censusdiag.CensusStageFullReceipt,255}{
        witness,err:=NewRouteWireCensusWitness(&ChildFinalSlot{binding:binding.launch},binding.RuntimeBinding().Identity,plan,clock,func()(RouteWireClockDomain,error){return clock,nil},func()([]RouteWireEndpointKey,error){return nil,censusdiag.CensusFailure(stage,secret)})
        if err!=nil{t.Fatal(err)};_,err=witness()
        if !errors.Is(err,ErrFinalAccountingUnavailable)||strings.Contains(err.Error(),secret.Error()){t.Fatal("sentinel/raw cause changed")}
        got,ok:=censusdiag.CensusDiagnostic(err);if stage.Valid()&&(!ok||got!=stage)||!stage.Valid()&&ok{t.Fatal("typed-only preservation")}
    }
    witness,err:=NewRouteWireCensusWitness(&ChildFinalSlot{binding:binding.launch},binding.RuntimeBinding().Identity,plan,clock,func()(RouteWireClockDomain,error){return clock,nil},func()([]RouteWireEndpointKey,error){return nil,secret})
    if err!=nil{t.Fatal(err)};_,err=witness();if err!=ErrFinalAccountingUnavailable{t.Fatal("unknown callback not generic")}
}

func TestRouteWireDiagnosticParentKeepsPreciseCauseAndErrorIs(t *testing.T) {
    original:=censusdiag.CensusFailure(censusdiag.CensusStageFullReceipt,ErrFinalAccountingUnavailable)
    wrapped:=censusStageFailure(censusdiag.CensusStageParentDecode,original)
    if wrapped!=original||!errors.Is(wrapped,ErrFinalAccountingUnavailable){t.Fatal("precise inner stage overwritten")}
    ordinary:=errors.New("DO_NOT_LEAK")
    got:=censusStageFailure(censusdiag.CensusStageParentRead,ordinary)
    if !errors.Is(got,ordinary)||strings.Contains(got.Error(),ordinary.Error()){t.Fatal("local sentinel/format changed")}
}

func TestRouteWireWitnessFiniteFaultStages(t *testing.T) {
    _,binding,expected:=routeWireBoundedFixture(t,RouteWireWindowBounds{Begin:100,End:200})
    plan:=PlannedRouteWireObservation{Window:expected.Window,Bounds:expected.Bounds,MaxEndpoints:len(expected.Endpoints)}
    clock:=RouteWireClockDomain{BootID:"c481cc22-adf3-4d99-a4fe-de7f204e0ad6",Device:4,Inode:17}
    for _,tc:=range []struct{name string; stage censusdiag.CensusStage; sentinel error}{
        {"before",censusdiag.CensusStageWitnessClockBefore,ErrFinalAccountingUnavailable},
        {"rows",censusdiag.CensusStageWitnessRows,ErrFinalAccountingUnavailable},
        {"commit",censusdiag.CensusStageWitnessCommit,ErrFinalReportInvalid},
        {"after",censusdiag.CensusStageWitnessClockAfter,ErrFinalAccountingUnavailable},
    }{
        t.Run(tc.name,func(t *testing.T){
            calls:=0
            readClock:=func()(RouteWireClockDomain,error){calls++;got:=clock;if tc.name=="before"||tc.name=="after"&&calls==2{got.Inode++};return got,nil}
            read:=func()([]RouteWireEndpointKey,error){
                if tc.name=="rows"{return nil,nil}
                rows:=append([]RouteWireEndpointKey(nil),expected.Endpoints...)
                if tc.name=="commit"{rows[0].ConnID=0}
                return rows,nil
            }
            witness,err:=NewRouteWireCensusWitness(&ChildFinalSlot{binding:binding.launch},binding.RuntimeBinding().Identity,plan,clock,readClock,read)
            if err!=nil{t.Fatal(err)};_,err=witness();stage,ok:=censusdiag.CensusDiagnostic(err)
            if !ok||stage!=tc.stage||!errors.Is(err,tc.sentinel){t.Fatal("fault stage/sentinel changed")}
        })
    }
}

type censusDiagnosticTransport func(*http.Request)(*http.Response,error)
func (f censusDiagnosticTransport) RoundTrip(r *http.Request)(*http.Response,error){return f(r)}

func TestRouteWireRPCStageMappingOnlyOnOwnCensus503(t *testing.T) {
    message:=censusdiag.CensusRPCMessage(censusdiag.CensusStageFullReceipt)
    valid,_:=json.Marshal(map[string]string{"error":message})
    for _,tc:=range []struct{name,command,body string; status int; typed bool}{
        {"exact",RouteWireCensusCommand,string(valid),503,true},
        {"other command","getResourceUsage",string(valid),503,false},
        {"404",RouteWireCensusCommand,string(valid),404,false},
        {"unknown",RouteWireCensusCommand,`{"error":"DO_NOT_LEAK"}`,503,false},
        {"suffix",RouteWireCensusCommand,`{"error":"`+message+` DO_NOT_LEAK"}`,503,false},
        {"duplicate",RouteWireCensusCommand,`{"error":"`+message+`","error":"DO_NOT_LEAK"}`,503,false},
        {"foreign",RouteWireCensusCommand,`{"error":"`+message+`","secret":"DO_NOT_LEAK"}`,503,false},
        {"wrong case",RouteWireCensusCommand,`{"Error":"`+message+`"}`,503,false},
        {"null",RouteWireCensusCommand,`{"error":null}`,503,false},
        {"oversize",RouteWireCensusCommand,strings.Repeat(" ",257)+string(valid),503,false},
    }{
        t.Run(tc.name,func(t *testing.T){
            credentials,err:=NewCredentials();if err!=nil{t.Fatal(err)}
            client,err:=NewRPCClient(RPCOptions{Address:domain.ListenAddress("127.0.0.1:42051"),Credentials:credentials});if err!=nil{t.Fatal(err)}
            defer client.Close()
            client.http.Transport=censusDiagnosticTransport(func(*http.Request)(*http.Response,error){return &http.Response{StatusCode:tc.status,Body:io.NopCloser(strings.NewReader(tc.body))},nil})
            var raw json.RawMessage
            err=client.Call(t.Context(),tc.command,nil,&raw)
            stage,ok:=censusdiag.CensusDiagnostic(err)
            if !errors.Is(err,ErrFamilyUnavailable)||ok!=tc.typed||tc.typed&&stage!=censusdiag.CensusStageFullReceipt||strings.Contains(err.Error(),"DO_NOT_LEAK"){t.Fatal("unsafe/incorrect originalRPC status mapping")}
        })
    }
}
