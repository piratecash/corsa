"""Tiny provenance/non-authority checks, not a substitute for Go QA."""
import hashlib,json,re,unittest
from pathlib import Path
HERE=Path(__file__).resolve().parent
BASE=Path('/private/tmp/corsa-o1a-baseline-finalizer-build-c59004257e11496c84a1ba4a7f37f1e4/source')
POSTS=HERE/'posts'
class SourceTests(unittest.TestCase):
 def test_existing_posts_derive_exact_actual_baseline(self):
  before=json.loads((BASE.parent/'source-after.json').read_bytes());manifest=json.loads((HERE/'MANIFEST.json').read_bytes())
  for n,row in manifest['files'].items():
   if row['before_sha256'] is not None:self.assertEqual(before[n],row['before_sha256'])
   self.assertEqual(hashlib.sha256((POSTS/n).read_bytes()).hexdigest(),row['after_sha256'])
 def test_fullnode_changes_only_two_callback_annotations(self):
  n='internal/testutil/loadstand/fullnode/main.go';raw=(POSTS/n).read_text()
  raw=raw.replace('\n "github.com/piratecash/corsa/internal/testutil/loadstand/censusdiag"','')
  for tag in ('FullRegistry','FullReceipt'):
   self.assertEqual(raw.count('return nil, censusdiag.CensusFailure(censusdiag.CensusStage'+tag+', err)'),1)
   raw=raw.replace('return nil, censusdiag.CensusFailure(censusdiag.CensusStage'+tag+', err)','return nil, err')
  self.assertEqual(raw,(BASE/n).read_text())
 def test_tiny_leaf_stdlib_only_and_no_new_lifecycle_operations(self):
  leaf=(POSTS/'internal/testutil/loadstand/censusdiag/diagnostic.go').read_text();self.assertIn('import "errors"',leaf);self.assertNotIn('github.com',leaf)
  for f in POSTS.rglob('*.go'):
   if f.name.endswith('_test.go'):continue
   old=(BASE/f.relative_to(POSTS)).read_text() if (BASE/f.relative_to(POSTS)).exists() else ''
   new=f.read_text()
   for token in ('exec.Command(', 'net.Listen(', 'ListenAndServe(', 'time.NewTimer(', 'context.WithTimeout(', 'go func(', '.Signal('):self.assertEqual(new.count(token),old.count(token),str(f)+token)
 def test_non_census_rpc_branch_and_success_decoder_remain_fixed(self):
  n='internal/testutil/loadstand/rpc.go';raw=(POSTS/n).read_text();old=(BASE/n).read_text()
  start=raw.index('\tcase http.StatusNotFound:');end=raw.index('\n\tcase http.StatusForbidden',start)
  self.assertIn('if command == RouteWireCensusCommand',raw[start:end]);self.assertIn('decodeRouteWireCensusRPCDiagnostic(raw)',raw[start:end])
  self.assertEqual(raw[:start]+ '\tcase http.StatusNotFound, http.StatusServiceUnavailable:\n\t\treturn ErrFamilyUnavailable'+raw[end:],old)
 def test_presence_and_positive_enum_checks_are_explicit(self):
  raw=(POSTS/'internal/testutil/loadstand/linux_helper_protocol.go').read_text()
  for marker in ('diagnosticPresent := fields["Diagnostic"]','if !diagnosticPresent','if !reply.Diagnostic.Valid()','if diagnosticPresent || reply.Code != linuxResultReady'):
   self.assertIn(marker,raw)
  self.assertEqual(len(re.findall(r'func Test\w+\(',''.join(p.read_text() for p in POSTS.rglob('*_test.go')))),7)
if __name__=='__main__':unittest.main()
