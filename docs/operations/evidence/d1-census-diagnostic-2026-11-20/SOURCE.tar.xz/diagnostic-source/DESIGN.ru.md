# Безопасная локализация отказа pre-Stop census

SOURCE ONLY. Исходный480.60с periodic5a369… завершился FAIL; полнота native остановки подтверждена отдельно. Последний сохранённый sample390с, generic `final process accounting unavailable`, затем post-stop exit1/poisoned/ended_not_exact. Capsule содержит исходники и failed record body_bytes0; фактическая первая ветка остаётся UNKNOWN. Эти posts не исправляют измерение и не разрешают одинаковый480с повтор или reconnect.

Основа — фактически собранный immutable4fcc+три existing finalizer posts (result76120c…). Никакой текущий executor, current FullNode factory или candidate FullResponder сюда не подмешивается. Tracked дерево не менялось. Все изменения — testutil/stand; measured core остаётся исходным640/b70de.

## Где исчезает причина

1. FullNode callback возвращает либо registry projection error, либо FullReceipt capture error.
2. NewRouteWireCensusWitness сворачивает ошибки callback в generic unavailable; fullwitness RPC wrapper сворачивает снова в fixed HTTP503.
3. Важно: helper использует lightweight `loadstand.RPCClient`, который сейчас игнорирует тело503 и возвращает ErrFamilyUnavailable (это НЕ core/rpc.Client с "rpc error:" текстом).
4. Helper writeRouteWireCensus сворачивает binding/clock/RPC/commit failures в CodeUnavailable без деталей; parent decoder возвращает ErrFinalAccountingUnavailable. После этого cleanup по прежнему контракту может привести к вторичным final/byte-balance ошибкам. Они не становятся primarycause.

## Минимальный фикс диагностического канала

Одна tiny stdlib-only leaf package `loadstand/censusdiag` определяет конечный enum и error wrapper. Она не создаёт owners/callbacks/transport и не тянет core/rpc в lightweight linuxhelper. Error.Unwrap сохраняет исходные errors.Is локально; Error() печатает только статическую метку, без cause.Error(). Неверный/неизвестный stage не сериализуется. Ни capability, route contents, ID, nonce, путь, аргументы, credentials или childstderr в диагностике не передаются.

FullNode маркирует ровно две исходные ветки (registry/fullReceipt). Witness передаёт только типизированную известную метку; произвольная ошибка callback сохраняет старый generic unavailable. Его собственные fixed clock/row/commit/encode ветки также получают метки. RPC wrapper передаёт known label в прежнем поле error/статусе503; успех и команда не меняются.

Lightweight RPCClient распознаёт метку только для исходной loadstandRouteWireCensus+503: bounded≤256B canonical single-field {error: exact_label}, полный whitelist equality, без trim/substring. Unknown/malformed/other-command/status возвращает прежний ErrFamilyUnavailable. Recognized label оборачивает ТОТ ЖЕ sentinel. Process сохраняет typedstage или помечает fixed transport/decode phase; неизвестный raw error текст не переносит.

Helper использует прежний linux reply, добавив optional Diagnostic closed enum ТОЛЬКО в Unavailable. Ready не может содержать это поле даже0/null. ABSENT в Unavailable — прежний generic UNKNOWN; присутствующий enum должен быть известным положительным значением. Duplicate/foreign/casefold/zero/null/unknown values отказывают. Parent сохраняет ErrFinalAccountingUnavailable и статическую метку, а при protocol defect прежний ErrLinuxOwnerProtocol. Более точная внутренняя метка не перезаписывается внешней общей.

Существующие успех/отказ, clock/nonce/window checks, helper correlation, Stop/cleanup, packet limits, original reporting/metrics/thresholds, route_probe traffic, окна и рольOff не ослабляются. Optional diagnostic не превращает Unavailable в Ready, не создаёт metric sample и не является новой admission authority. Внешний Node checkBoundary до этой цепи остаётся с прежним generic отказом: при его отказе innerstage честноUNKNOWN.

## Проверки и следующий шаг

Добавлены7 коротких Go функций с finite fault fixtures: typed/error unwrap/secret dropping; server command table; unavailable/Ready/legacy/raw0/null/duplicate; Witness clock/rows/commit faults; точное RPC503 отображение через fake RoundTripper (без TCP listener). Go пока НЕ запускался. Root может выполнить их как обычное QA после source review. Исходные unit fixtures и отрицательные проверки остаются обязательными; новые source stamps/counts вычисляются заново при будущей сборке — старый stand52e346 им не присваивается.

После QA допустим отдельный короткий component profile на двух собственных Full с10k/connect-full, чтобы получить stage или complete capture. Это диагностика, не periodic/window acceptance и не основание заявить O‑1a PASS. Профиль и сборки готовит Root отдельно. Полный480с сценарий не повторяется идентично. Candidate FullNode post разрабатывается другим агентом: позже переносить только две точечные callback annotations, не заменять его factory целым старым main.go.
