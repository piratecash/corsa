# Закрытый native responder: адресное Go QA

Изолированный снимок commit2188dfb плюс ровно26 закреплённых posts минимальной revision6.
Рабочее дерево не меняется. 164 именованных выполнения старых регрессионных
и новых constructor/F1/census тестов; пропущенный тест, FAIL или SKIP — STOP.
Используются свежие собственные файлы/OS pipes, TLS net.Pipe и loopback.
Затем Node/App test ELF и закрытый FullNode main только компилируются
Linux arm64/CGO0 с двумя диагностическими тегами; SHA/static/BuildInfo сверяются.
Результирующие Linux ELF, VM, standalone corsad и piratecashd не запускаются.

Один последовательный job: 600 секунд работы с подготовкой плюс30 очистки,
heavy-lock, минимум10GiB свободно, собственные файлы до6GiB по фазовым проверкам,
RAW до8MiB. Локальный Go1.27.4 и имеющиеся зависимости, без скачиваний;
GOMAXPROCS2/GOMEMLIMIT768MiB/-p1 — мягкие настройки. Общих host hard caps,
гарантии no-swap и жёсткой дисковой квоты нет. Sandbox запрещает сеть кроме
loopback и запись в snapshot; входы и полный snapshot проверяются до/после.
Ошибка/OOM/таймаут/неполные данные — STOP без автоматического повтора или
роста лимитов. UNKNOWN сохраняет точный собственный lock и контроллер.

Обычные конструкторы остаются Off. Это QA нового закрытого composition,
не включение D1, не замер О‑1а/512МБ, не полная D1/G2-приёмка или выпуск.

Persistent ownIntro hash/flags отсутствуют; реальные Ready/F1 binding сохраняются.
Runtime wire R остаётся UNKNOWN; forwarding не исполняется. Два предыдущих
FAIL source-inventory сохранены; scanner и отрицательные проверки не ослаблены.
