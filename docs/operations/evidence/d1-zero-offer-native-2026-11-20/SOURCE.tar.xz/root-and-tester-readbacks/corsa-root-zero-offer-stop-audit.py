from pathlib import Path
import sys,json,os,hashlib
R=Path('/Users/hades/Documents/repos/corsa/docs/_internal/d1-artifacts/2026-11-20/d1-o1a-zero-offer-runtime-v1');sys.path.insert(0,str(R));import verify,launch
W=Path('/private/tmp/corsa-d1-o1a-native-2c75180d2872646aa2f7201b240cb175');j=lambda p:json.loads(p.read_bytes());expected=j(W/'expected.json');receipt=j(W/'receipt.json');raw={n:(W/f).read_bytes() for n,f in [('console','console.raw'),('native','native.jsonl'),('stderr','stderr.raw')]}
rows=verify.check_lifecycle(expected,receipt,raw['console'],raw['native'],raw['stderr']);guest=verify.guest_receipt(expected,raw['console']);assert guest['state'] in ('FAIL','TEST_EXIT_ZERO_CAPSULE_EXPORTED') and guest['test']['exit'] in (0,1) and guest['test']['normal'] and guest['test']['reaped'] and guest['test']['all_children_reaped'] and not guest['test']['term_sent'] and not guest['test']['kill_sent'] and guest['export_started'] and guest['export']['normal'] and guest['export']['exit']==0 and guest['export']['reaped'] and guest['export']['all_children_reaped'] and not guest['export']['term_sent'] and not guest['export']['kill_sent']
h=j(R/'HANDOFF.json');assert hashlib.sha256((R/'HANDOFF.json').read_bytes()).hexdigest()==expected['handoff_sha256'];launch.validate(h)
for n,row in h['inputs'].items():assert launch.file_digest(Path(row['path']),launch.LIMITS[n])[0]==launch.file_digest(W/n,launch.LIMITS[n])[0]==row['sha256']
binding=j(W/'lock-binding.json');custody=launch.lock_identity();assert list(custody[0])==binding['directory_stamp'] and list(custody[1])==binding['owner_stamp'] and hashlib.sha256(custody[2]).hexdigest()==binding['owner_sha256'];owner=dict(l.split('=',1) for l in custody[2].decode().splitlines());start=j(W/'worker-start.json');pids={int(owner['pid']),start['pid']};groups={int(owner['pgid']),start['pgid']};assert start['attempt_id']==expected['attempt_id'] and start['pid']==start['pgid']==receipt['worker_pid'];assert min(pids|groups)>1 and os.getpid() not in pids and os.getpgrp() not in groups
for f,xs in [(os.kill,pids),(os.killpg,groups)]:
 for x in xs:
  try:f(x,0)
  except ProcessLookupError:pass
  else:raise RuntimeError('owned original PID/PGID exists or reused')
report={'role':'ROOT','status':'ACCEPTED_VM_STOPPED_ONLY','work':str(W),'guest_state':guest['state'],'guest_stage':guest['stage'],'original_Go_exit':guest['test']['exit'],'functional_result':'PENDING_CAPSULE_REVIEW','historical480s_inner_cause':'UNKNOWN','native_events':len(rows),'native_stop_ns':rows[-1]['elapsed_ns'],'original_pids_absent':sorted(pids),'original_groups_absent':sorted(groups),'RAW':{n:{'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()} for n,b in raw.items()},'physical_XPC_resources':'UNKNOWN','metric_admission':False}
(W/'ROOT-DATA.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
