from pathlib import Path
import importlib.util,sys,json,hashlib,os
R=Path('/Users/hades/Documents/repos/corsa');D=R/'docs/_internal/d1-artifacts/2026-11-20';P=D/'d1-o1a-zero-offer-runtime-v1';W=Path('/private/tmp/corsa-d1-o1a-native-2c75180d2872646aa2f7201b240cb175');A=Path('/private/tmp/corsa-o1a-zero-offer-private-elf-build-4ffb25a64e9d40fbad9eb0ec77f7e618')
sys.path.insert(0,str(P));sys.dont_write_bytecode=True
sp=importlib.util.spec_from_file_location('v',P/'verify.py');v=importlib.util.module_from_spec(sp);sp.loader.exec_module(v)
from support import lock_identity
def j(p):return json.loads(Path(p).read_bytes())
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb')as f:
  while b:=f.read(1024**2):h.update(b)
 return h.hexdigest()
e=j(W/'expected.json');r=j(W/'receipt.json');c=(W/'console.raw').read_bytes();n=(W/'native.jsonl').read_bytes();s=(W/'stderr.raw').read_bytes()
events=v.check_lifecycle(e,r,c,n,s);g=v.guest_receipt(e,c);assert g['state']=='FAIL'and g['export_started']and g['all_children_reaped']
for name,code in [('test',1),('export',0)]:
 child=g[name];assert child['exit']==code and all(child[k]is True for k in ['normal','reaped','all_children_reaped','log_complete'])and all(child[k]is False for k in ['term_sent','kill_sent','log_overflow'])
assert c.count(b'--- FAIL: TestLoadStandLinuxRouteWireNative (30.62s)')==1 and b'--- PASS: TestLoadStandLinuxRouteWireNative 'not in c
assert b'fixture census unavailable: stage=observer_full_send_finish_sender_false'in c
h=j(P/'HANDOFF.json');assert sha(P/'HANDOFF.json')==e['handoff_sha256']==r['handoff_sha256']
for name,row in h['inputs'].items():assert sha(row['path'])==sha(W/name)==row['sha256']==e[name+'_sha256']
b=j(W/'lock-binding.json');custody=lock_identity();assert list(custody[0])==b['directory_stamp']and list(custody[1])==b['owner_stamp']and hashlib.sha256(custody[2]).hexdigest()==b['owner_sha256'];owner=dict(line.split('=',1)for line in custody[2].decode().splitlines());assert owner['attempt_id']==e['attempt_id']and owner['grant_sha256']==e['handoff_sha256']
start=j(W/'worker-start.json');assert start['pid']==start['pgid']==r['worker_pid'];pids={int(owner['pid']),start['pid']};groups={int(owner['pgid']),start['pgid']};fresh=[]
for kind,ids,fn in [('PID',pids,os.kill),('PGID',groups,os.killpg)]:
 for i in sorted(ids):
  try:fn(i,0)
  except ProcessLookupError:fresh.append({'kind':kind,'id':i,'result':'ESRCH'})
  else:raise ValueError('PID/group remains or reused: '+str(i))
assert custody==lock_identity()
files=v.journal_capsule.decode(c,{'workload':e['workload'],'attempt_id':e['attempt_id'],'profile_sha256':v.PROFILES[e['workload']],'source_commit':v.SOURCE});assert len(files)==1351
groups_expected={'measured':('ae4710dc781e1e921f4c8e43a4c947a502eba8c69446ed532eba0276af1c4341',640),'stand':('78d671b120e64887b7a7a7c827d3c114a4d03c0fa1f4aee861fbd3fa7ce3185e',708)};source_count=0
for name,(digest,count)in groups_expected.items():
 prefix='sources/'+name+'-'+digest[:16]+'/';manifest=files[prefix+'MANIFEST.sha256'];assert hashlib.sha256(manifest).hexdigest()==digest;rows={k[len(prefix):]:body for k,body in files.items()if k.startswith(prefix)and k!=prefix+'MANIFEST.sha256'};assert len(rows)==count
 for path,body in rows.items():assert body==(A/'source'/path).read_bytes()
 source_count+=len(rows)
failed=[(name,body)for name,body in files.items()if name.endswith('.failed')];assert len(failed)==1;fname,fbytes=failed[0];lines=fbytes.splitlines();assert lines[0]==b'runjournal-record/v1';frow=json.loads(lines[1]);assert frow['outcome']=='failed'and frow['detail']=='functional member lifecycle or observation invalid';assert {(x['name'],x['stamp'])for x in frow['sources']}=={(name,digest[:16])for name,(digest,count)in groups_expected.items()}
out={'status':'ACCEPTED_VM_STOPPED_ONLY','role':'TESTER','work':str(W),'scope':'Stopped-only safety ACK; genuine Go FAIL preserved, not O1a metric PASS or physical XPC release.','receipt_sha256':sha(W/'receipt.json'),'handoff_sha256':e['handoff_sha256'],'all_three_RAW_full_retained_SHA_EOF':r['captures'],'native_events':events,'guest':g,'fresh_own_process_absence':fresh,'exact_own_lock_custody_unchanged':True,'input_original_and_owned_copy_hashes_exact':True,'capsule_files':len(files),'capsule_sources_equal_actual_compiled_tree':source_count,'failed_record':{'name':fname,'bytes':len(fbytes),'sha256':hashlib.sha256(fbytes).hexdigest(),'outcome':frow['outcome'],'detail':frow['detail'],'sources':frow['sources'],'deeper_refusal_detail':'NOT_SERIALIZED_IN_FAILED_RECORD'},'first_leaf':{'console_stage':'observer_full_send_finish_sender_false','observer_code':31,'transport_code':95,'source_conjunction':'Bound zero-offer finish reports 31 only when sentAll=false and p.send!=nil or p.next!=0; proves supplied-frame observation, not actual queue/writer acceptance.','producer_inner_reason':'UNKNOWN'},'physical_XPC_resources':'UNKNOWN','native_repeated':False,'lock_removed_by_this_reviewer':False}
t=D/'d1-o1a-zero-offer-native-actual-tester-v1';t.mkdir(exist_ok=True);(t/'REVIEW.json').write_text(json.dumps(out,indent=2,sort_keys=True)+'\n');print('REVIEW',str(t/'REVIEW.json'),sha(t/'REVIEW.json'))
