from pathlib import Path
import hashlib,json,tarfile,copy,importlib.util,sys
R=Path('/Users/hades/Documents/repos/corsa');D=R/'docs/_internal/d1-artifacts/2026-11-20';N=Path('/private/tmp/corsa-o1a-zero-offer-inputs-58d83a83fb1047ee80b323ca5b4a958f');O=Path('/private/tmp/corsa-o1a-full-send-leaf-inputs-29a5c76170dd42818facb32d2ec16e93');A=Path('/private/tmp/corsa-o1a-zero-offer-private-elf-build-4ffb25a64e9d40fbad9eb0ec77f7e618')
def h(b):return hashlib.sha256(b).hexdigest()
def j(p):return json.loads(p.read_bytes())
r=j(N/'RESULT.json');old=j(O/'RESULT.json');assert h((N/'RESULT.json').read_bytes())=='000ebeb965cb68c87de4daf49627c3c563e45eada971e4d66205cb82bd236514';assert r['four_ELF']==j(A/'result.json')['artifacts'];assert h((N/'guest-sources.tar.gz').read_bytes())==r['source_archive']['sha256']=='23b2818a3677a596683b0ebd819663f639b5e5e84abca10f35d96c6c44c976e7'
def read_tar(p):
 out={};headers={}
 with tarfile.open(p,'r:gz')as t:
  for m in t:
   assert m.name not in headers and not m.pax_headers and not m.linkname and not m.name.startswith('/')and'..'not in m.name.split('/');assert m.uid==m.gid==m.mtime==0
   headers[m.name]=(m.type,m.mode,m.uid,m.gid,m.mtime)
   if m.isdir():assert m.mode==0o755
   else:
    assert m.isfile()and m.mode==0o444 and 0<m.size<=8*1024**2;out[m.name]=t.extractfile(m).read();assert len(out[m.name])==m.size
 return out,headers
new,nh=read_tar(N/'guest-sources.tar.gz');before,oh=read_tar(O/'guest-sources.tar.gz');assert nh==oh and len(nh)==1409 and len(new)==1350
path='source/internal/core/node/loadstand_route_wire_full_send.go';changes={n for n in new if new[n]!=before[n]};assert changes=={path,'manifests/measured.manifest'}
full=j(A/'source-after.json');source={n[7:]:b for n,b in new.items()if n.startswith('source/')};assert len(source)==1348 and all(h(b)==full[n] and b==(A/'source'/n).read_bytes()for n,b in source.items());assert h(new['manifests/measured.manifest'])==r['source_groups']['measured']['sha256']=='ae4710dc781e1e921f4c8e43a4c947a502eba8c69446ed532eba0276af1c4341';assert h(new['manifests/stand.manifest'])=='78d671b120e64887b7a7a7c827d3c114a4d03c0fa1f4aee861fbd3fa7ce3185e'
for kind,row in r['helper_sources'].items():
 f=N/kind;assert h((f/'SHA256SUMS').read_bytes())==row['source_sums_sha256'];assert set(row['source_files'])==set(old['helper_sources'][kind]['source_files'])
 changed=[]
 for name,w in row['source_files'].items():
  b=(f/name).read_bytes();assert w=={'bytes':len(b),'sha256':h(b)}
  if b!=(O/kind/name).read_bytes():changed.append(name)
 assert set(changed)==set(r['helper_changed_files'][kind])
cn=(N/'pid1-source/cmd/o1a-init/config.go').read_bytes();assert cn.replace(r['source_archive']['sha256'].encode(),old['source_archive']['sha256'].encode())==(O/'pid1-source/cmd/o1a-init/config.go').read_bytes()
fn=(N/'pid1-source/cmd/o1a-init/frozen.go').read_bytes();header=(N/'capexec-source/frozen_inputs.h').read_bytes()
for name,newrow in r['four_ELF'].items():
 oldrow=old['four_ELF'][name];fn=fn.replace(f'"/bin/{name}":{{Bytes:{newrow["bytes"]},SHA256:"{newrow["sha256"]}"}}'.encode(),f'"/bin/{name}":{{Bytes:{oldrow["bytes"]},SHA256:"{oldrow["sha256"]}"}}'.encode());header=header.replace(newrow['sha256'].encode(),oldrow['sha256'].encode())
assert fn==(O/'pid1-source/cmd/o1a-init/frozen.go').read_bytes();assert header==(O/'capexec-source/frozen_inputs.h').read_bytes()
test=(N/'capexec-source/test_source_binding.py').read_bytes().replace(h((N/'capexec-source/frozen_inputs.h').read_bytes()).encode(),h((O/'capexec-source/frozen_inputs.h').read_bytes()).encode());assert test==(O/'capexec-source/test_source_binding.py').read_bytes()
t=j(N/'pid1-source/BOOT-CONFIG.TEMPLATE.json');b=j(O/'pid1-source/BOOT-CONFIG.TEMPLATE.json');fixed=copy.deepcopy(t);c=fixed['config'];c['source_archive_sha256']=b['config']['source_archive_sha256'];changedrows={n for n in c['files']if c['files'][n]!=b['config']['files'][n]};assert changedrows=={'/'+path,*('/bin/'+n for n in r['four_ELF']if r['four_ELF'][n]!=old['four_ELF'][n])}
for n in changedrows:c['files'][n]=b['config']['files'][n]
assert fixed==b
assert (N/'component.json').read_bytes()==(O/'component.json').read_bytes();assert j(N/'EXPORTER-REUSE.json')==j(O/'EXPORTER-REUSE.json');assert (N/'capexec-source/guest_policy.h').read_bytes()==(O/'capexec-source/guest_policy.h').read_bytes();assert r['runtime_ready']is False and r['resource_execution']is False
out={'status':'ACCEPTED_DATA_ONLY_ZERO_OFFER_SOURCE_ARCHIVE_AND_HELPER_PARAMETERS','role':'TESTER','result':str(N/'RESULT.json'),'result_sha256':h((N/'RESULT.json').read_bytes()),'archive_sha256':r['source_archive']['sha256'],'archive_bytes':r['source_archive']['bytes'],'full_regular_members':1350,'all_members':1409,'actual_compiled_sources_equal':1348,'member_paths_and_headers_unchanged':True,'archive_payload_delta':sorted(changes),'source_groups':r['source_groups'],'helper_parameter_delta_exact':r['helper_changed_files'],'boot_template_changed_rows':sorted(changedrows),'four_ELF_exact_actual_build':True,'linuxhelper_unchanged':True,'exporter_dependency_proof_byte_data_equal':True,'profile_policy_caps_windows_unchanged':True,'helper_build_or_VM':'NOT_RUN','historical97a9_cause':'UNKNOWN_NOT_RETROACTIVELY_FIXED','future_CPIO_expected_member_changes':7,'future_boot_expected_changed_rows':5,'future_counts_scope':'Expected from known inputs; actual archive delta must be derived after helpers and packing.'};p=D/'d1-o1a-zero-offer-inputs-actual-tester-v1';p.mkdir(exist_ok=True);(p/'REVIEW.json').write_text(json.dumps(out,indent=2,sort_keys=True)+'\n');print('REVIEW',p/'REVIEW.json',h((p/'REVIEW.json').read_bytes()))
