from pathlib import Path
import hashlib,json,gzip,stat
R=Path('/Users/hades/Documents/repos/corsa');D=R/'docs/_internal/d1-artifacts/2026-11-20';P=D/'d1-o1a-zero-offer-initrd-v1';O=D/'d1-o1a-full-send-leaf-initrd-v1';A=Path('/private/tmp/corsa-o1a-zero-offer-private-elf-build-4ffb25a64e9d40fbad9eb0ec77f7e618')
def j(p):return json.loads(Path(p).read_bytes())
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb')as f:
  while b:=f.read(1024**2):h.update(b)
 return h.hexdigest()
def stream(row):
 p=Path(row['archive']);assert p.stat().st_size==row['archive_bytes']and sha(p)==row['archive_sha256'];assert sha(row['receipt'])==row['receipt_sha256'];wanted=j(row['receipt']);rows={};boot=None;source={}
 with gzip.open(p,'rb')as f:
  def exact(n):
   b=f.read(n);assert len(b)==n;return b
  ino=1
  while True:
   header=exact(110);assert header[:6]==b'070701';v=[int(header[6+i*8:14+i*8],16)for i in range(13)];i,mode,uid,gid,nlink,mtime,size,devmaj,devmin,rmaj,rmin,namesize,check=v;assert i==ino and uid==gid==mtime==devmaj==devmin==check==0 and 1<=namesize<=1025;encoded=exact(namesize);assert encoded[-1:]==b'\0'and b'\0'not in encoded[:-1];name=encoded[:-1].decode('ascii');assert name not in rows and not name.startswith('/')and'..'not in name.split('/');assert exact((-110-namesize)%4).strip(b'\0')==b''
   if name=='TRAILER!!!':
    assert mode==size==0 and nlink==1 and rmaj==rmin==0;assert f.read(1)==b'';break
   assert name in wanted['members']and size<=96*1024**2
   if stat.S_ISDIR(mode):assert mode==stat.S_IFDIR|0o755 and nlink==2 and size==0
   elif stat.S_ISCHR(mode):assert name=='dev/console'and mode==stat.S_IFCHR|0o600 and nlink==1 and size==0 and(rmaj,rmin)==(5,1)
   else:assert stat.S_ISREG(mode)and nlink==1 and 0<size<=96*1024**2 and rmaj==rmin==0
   h=hashlib.sha256();left=size;body=[] if name=='config/boot.json'else None
   while left:
    chunk=exact(min(left,1024**2));h.update(chunk);left-=len(chunk)
    if body is not None:body.append(chunk)
   assert exact((-size)%4).strip(b'\0')==b'';record={'mode':oct(mode),'bytes':size,'sha256':h.hexdigest()};assert record==wanted['members'][name];rows[name]=record
   if name.startswith('source/')and stat.S_ISREG(mode):source[name[7:]]=record['sha256']
   if body is not None:boot=json.loads(b''.join(body));assert h.hexdigest()==row['config_sha256']
   ino+=1
 assert set(rows)==set(wanted['members'])and len(rows)==1439 and len(source)==1348
 return rows,boot,source
nr=j(P/'PACK-RESULT.json');assert nr['error']is None and not nr['unknown']and not nr['lock_retained']and len(nr['steps'])==1
for s in nr['steps']:
 assert s['exit']==0 and s['owned_group_absent']and s['pipe_threads_finished']and s['reason']is None
 assert Path(s['stderr']).stat().st_size==0 and Path(s['stdout']).stat().st_size==nr['raw_bytes']==580
nrow=nr['outputs']['reconnect'];orow=j(O/'PACK-RESULT.json')['outputs']['reconnect'];n,nb,ns=stream(nrow);old,ob,os=stream(orow);assert n.keys()==old.keys()
assert ns=={k:v for k,v in j(A/'source-after.json').items()if k in ns}
changes={k for k in n if n[k]!=old[k]};expected={'source/internal/core/node/loadstand_route_wire_full_send.go','bin/node.test','bin/loadstand-full','bin/loadstand-sdkedge','init','bin/capexec','config/boot.json'};assert changes==expected
assert all(n[k]['mode']==old[k]['mode']for k in n);assert n['bin/loadstand-linuxhelper']==old['bin/loadstand-linuxhelper'];assert nb.keys()==ob.keys();changed_top={k for k in nb if nb[k]!=ob[k]};assert changed_top=={'attempt_id','source_archive_sha256','files'};assert nb['files'].keys()==ob['files'].keys();rows_changed={k for k in nb['files']if nb['files'][k]!=ob['files'][k]};assert rows_changed=={'/source/internal/core/node/loadstand_route_wire_full_send.go','/bin/node.test','/bin/loadstand-full','/bin/loadstand-sdkedge','/bin/capexec'}
fixed=dict(nb,attempt_id=ob['attempt_id'],source_archive_sha256=ob['source_archive_sha256'],files=ob['files']);assert fixed==ob;assert nb['source_archive_sha256']=='23b2818a3677a596683b0ebd819663f639b5e5e84abca10f35d96c6c44c976e7';assert nb['profile_sha256']=='f84856cfa6f3c3d39f4f5d69487c5d968106aeea77b16f8a3d7bf864266e7369';assert nb['attempt_id']==nrow['attempt_id']
f=j(P/'PACK-FROZEN.json');assert sha(P/'PACK-FROZEN.json')=='4364d918ed155948d5e23355fd580808c064a0b87963162c6e3b0d40a508a46e'
for name,row in f['helpers'].items():
 key={'init':'init','capexec':'bin/capexec','exporter':'bin/journal-export'}[name];assert n[key]['sha256']==sha(row['path'])==row['sha256']and n[key]['bytes']==row['bytes']
for name,row in j(A/'result.json')['artifacts'].items():assert n['bin/'+name]['sha256']==row['sha256']and n['bin/'+name]['bytes']==row['bytes']
review={'status':'ACCEPTED_FULL_STREAM_CPIO_DATA_ONLY_NOT_VM_OR_METRIC','role':'TESTER','work':nr['work'],'wrapper_result_sha256':sha(Path(nr['work'])/'RESULT.json'),'PACK_FROZEN_sha256':sha(P/'PACK-FROZEN.json'),'archive':nrow,'member_headers_padding_TRAILER_EOF_all_verified':True,'members':1439,'source_payloads_exact_actual_compiled_tree':1348,'changed_members_vs_leaf97a9':sorted(changes),'changed_boot_rows':sorted(rows_changed),'changed_boot_top_fields':sorted(changed_top),'unchanged_modes_paths_policy_profile_caps_timers_exporter':True,'linuxhelper_unchanged':True,'all_actual_apps_helpers_exact':True,'wrapper_exit0_RAW580_EOF_owned_group_absent_lockgone':True,'ELF_or_VM_executed':False,'historical97a9_cause':'UNKNOWN_NOT_RETROACTIVELY_FIXED'}
t=D/'d1-o1a-zero-offer-initrd-actual-tester-v1';t.mkdir(exist_ok=True);(t/'REVIEW.json').write_text(json.dumps(review,indent=2,sort_keys=True)+'\n');print('REVIEW',t/'REVIEW.json',sha(t/'REVIEW.json'))
