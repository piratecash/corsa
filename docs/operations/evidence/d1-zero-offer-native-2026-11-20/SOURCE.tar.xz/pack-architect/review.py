from pathlib import Path
import gzip,hashlib,importlib.util,json
D=Path('/Users/hades/Documents/repos/corsa/docs/_internal/d1-artifacts/2026-11-20');P=D/'d1-o1a-zero-offer-rebind-v1';sp=importlib.util.spec_from_file_location('p',P/'prepare.py');p=importlib.util.module_from_spec(sp);sp.loader.exec_module(p)
def need(v,s):
 if not v:raise ValueError(s)
def sh(b):return hashlib.sha256(b).hexdigest()
f=json.loads((P/'FROZEN.json').read_bytes());pack=json.loads((D/'d1-o1a-zero-offer-initrd-v1/PACK-RESULT.json').read_bytes());r=pack['outputs']['reconnect'];receipt=json.loads(Path(r['receipt']).read_bytes());need(sh(Path(r['receipt']).read_bytes())==r['receipt_sha256'],'receipt');need(p.file_hash(r['archive'],128*1024**2)==r['archive_sha256'],'archive');h={'inputs':{'initrd':{'path':r['archive']}},'attempt_id':r['attempt_id'],'config_sha256':r['config_sha256']}
need(pack['status']=='OBSERVER_FIRST_FAILURE_INITRD_BYTE_VERIFIED' and not pack['error'] and not pack['unknown'] and not pack['lock_retained'] and not pack['ELF_or_VM_executed'],'pack status')
need(receipt['scope']=='DISPOSABLE_OBSERVER_FIRST_FAILURE_DIAGNOSTIC_INITRAMFS_DATA_READBACK_ONLY' and receipt['source_archive_sha256']==p.NEW_SOURCE_SHA and receipt['source_files']==1348,'source scope')
script=(D/'d1-o1a-full-send-leaf-runtime-architect-data-v1/review.py').read_text();a=script.index('# Read every actual newc');z=script.index('current=json.loads',a);exec(compile(script[a:z],'<saved-full-cpio-data-reader>','exec'))
actual_changed={n for n in seen if oldr['members'].get(n)!=receipt['members'][n]};need(actual_changed==set(p.EXPECTED_MEMBER_NAMES)|{'config/boot.json'},'actual seven changed members')
oldboot=p.boot_record(old['archive'],oldr['members']['config/boot.json']['sha256']);need({n for n in boot['files'] if boot['files'][n]!=oldboot['files'][n]}=={'/'+n for n in p.EXPECTED_MEMBER_NAMES if n!='init'},'actual five changed boot rows')
out=D/'d1-o1a-zero-offer-pack-architect-data-v1';out.mkdir(exist_ok=True);review={'status':'ACCEPTED_ARCHIVE_DATA_ONLY','scope':receipt['scope'],'archive':r['archive'],'archive_sha256':r['archive_sha256'],'attempt_id':r['attempt_id'],'members':len(seen),'payload_bytes':total,'source_files':1348,'boot_files':1366,'exact_changed_members':7,'new_paths':0,'exporter_unchanged':True,'resources_or_apps_run_by_reviewer':False};(out/'REVIEW.json').write_text(json.dumps(review,indent=2,sort_keys=True)+'\n');print(sh((out/'REVIEW.json').read_bytes()))
