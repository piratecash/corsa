package loadstand

import (
	"encoding/json"
	"errors"
	"strconv"
	"testing"

	"github.com/piratecash/corsa/internal/testutil/loadstand/censusdiag"
)

func TestRouteWireFullSendLeavesRemainUnavailableOnly(t *testing.T) {
	_, binding, expected := routeWireBoundedFixture(t, RouteWireWindowBounds{Begin: 100, End: 200})
	census, err := commitRouteWireWindow(expected, binding.RuntimeBinding().Identity)
	if err != nil {
		t.Fatal(err)
	}
	plan := PlannedRouteWireObservation{Window: expected.Window, Bounds: expected.Bounds, MaxEndpoints: len(expected.Endpoints)}
	clock := RouteWireClockDomain{BootID: "c481cc22-adf3-4d99-a4fe-de7f204e0ad6", Device: 4, Inode: 17}
	fields := []string{"0", "null", "27", "64", "98", "255", "\"81\"", "{}"}
	for code := 81; code <= 97; code++ {
		fields = append(fields, strconv.Itoa(code))
	}
	for _, ready := range []bool{false, true} {
		for _, field := range fields {
			t.Run(strconv.FormatBool(ready)+"-"+field, func(t *testing.T) {
				reply := linuxRouteWireCensusReply{Nonce: binding.launch.nonce, Code: linuxResultUnavailable}
				if ready {
					reply.Code = linuxResultReady
					reply.Census = &census
					reply.Clock = &clock
				}
				raw, e := json.Marshal(reply)
				if e != nil {
					t.Fatal(e)
				}
				raw = append(append([]byte{}, raw[:len(raw)-1]...), []byte(",\"Diagnostic\":"+field+"}")...)
				_, e = decodeLinuxRouteWireCensusReply(linuxPacket{kind: linuxRouteWireCensusResult, id: 4, ordinal: 1, body: raw}, 4, binding.launch.nonce, &plan, clock)
				code, parse := strconv.Atoi(field)
				if !ready && parse == nil && code >= 81 && code <= 97 {
					stage, ok := censusdiag.CensusDiagnostic(e)
					if !errors.Is(e, ErrFinalAccountingUnavailable) || !ok || stage != censusdiag.CensusStage(code) {
						t.Fatal("typed leaf/error identity lost", e)
					}
				} else if !errors.Is(e, ErrLinuxOwnerProtocol) {
					t.Fatal("Ready/present invalid leaf accepted", e)
				}
			})
		}
	}
}
