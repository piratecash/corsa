from pathlib import Path
import hashlib,importlib.util,json,os,tarfile
D=Path('/Users/hades/Documents/repos/corsa/docs/_internal/d1-artifacts/2026-11-20');P=D/'d1-o1a-zero-offer-input-rebind-v1';OUT=Path('/private/tmp/corsa-o1a-zero-offer-inputs-58d83a83fb1047ee80b323ca5b4a958f');W=Path('/private/tmp/corsa-d1-o1a-zero-offer-source-data-bc6c4bc531dd43ffaf054a6419b37a6e');HERE=Path(__file__).resolve().parent
s=importlib.util.spec_from_file_location('accepted_source',P/'prepare.py');p=importlib.util.module_from_spec(s);s.loader.exec_module(p)
r=p.j(OUT/'RESULT.json');need=p.need;need(r['scope']==p.PURPOSE and r['runtime_ready'] is False and r['resource_execution'] is False,'source-only purpose')
arc=OUT/'guest-sources.tar.gz';need(p.sha(arc)=='23b2818a3677a596683b0ebd819663f639b5e5e84abca10f35d96c6c44c976e7'==r['source_archive']['sha256'],'exact actual archive')
full=p.j(p.ACTUAL/'source-after.json');seen=set();source={};manifests={};payload=0
with tarfile.open(arc,'r:gz') as t:
 for m in t:
  need(m.name not in seen and len(seen)<1600 and not m.linkname and m.uid==m.gid==0 and m.mtime==0,'tar metadata');seen.add(m.name)
  if m.isdir():need(m.mode==0o755,'dir mode');continue
  need(m.isfile() and m.mode==0o444 and 0<m.size<=2*1024**2,'tar file mode/bound');raw=t.extractfile(m).read(m.size+1);need(len(raw)==m.size,'tar payload');payload+=len(raw);need(payload<=32*1024**2,'payload bound')
  if m.name.startswith('source/'):n=m.name[7:];need(p.h(raw)==full[n],'compiled source');source[n]=raw
  else:manifests[m.name]=raw
need(len(seen)==1409 and len(source)==1348 and set(manifests)=={'manifests/measured.manifest','manifests/stand.manifest'},'exact old member paths/counts')
old_template=p.j(p.GO/'BOOT-CONFIG.TEMPLATE.json');sr={n:{'bytes':len(raw),'sha256':p.h(raw)} for n,raw in source.items()};need(set(sr)=={n[8:] for n in old_template['config']['files'] if n.startswith('/source/')},'no new source paths')
changed={n for n,row in sr.items() if row!=old_template['config']['files']['/source/'+n]};need(changed==set(p.production_posts()),'exact1 source change')
for group in ('measured','stand'):need(p.h(manifests['manifests/'+group+'.manifest'])==r['fresh_original_Go_API']['groups'][group]['sha256'],'fresh canonical manifests')
old=p.j(p.DATA/'RESULT.json')['four_ELF'];new=p.j(p.ACTUAL/'result.json')['artifacts'];need(r['four_ELF']==new,'fouractualELF');f=p.helpers();go={};all_changed={}
for kind,folder in [('pid1-source',p.GO),('capexec-source',p.C)]:
 rows=r['helper_sources'][kind]['source_files'];need(set(rows)==set(f[kind]['source_files']),'same helper source paths');changed=[]
 for n,row in rows.items():
  raw=p.read(OUT/kind/n);need(p.h(raw)==row['sha256'] and len(raw)==row['bytes'],'all actual helper bytes')
  if raw!=p.read(folder/n):changed.append(n)
 need(p.sha(OUT/kind/'SHA256SUMS')==r['helper_sources'][kind]['source_sums_sha256'],'helper sums');all_changed[kind]=changed
need(set(all_changed['pid1-source'])=={'cmd/o1a-init/config.go','cmd/o1a-init/frozen.go','BOOT-CONFIG.TEMPLATE.json'} and set(all_changed['capexec-source'])=={'frozen_inputs.h','test_source_binding.py'},'exact helper parameter changes')
c,fr=p.go_bind(p.read(p.GO/'cmd/o1a-init/config.go'),p.read(p.GO/'cmd/o1a-init/frozen.go'),old,new,r['source_archive']['sha256']);need(c==p.read(OUT/'pid1-source/cmd/o1a-init/config.go') and fr==p.read(OUT/'pid1-source/cmd/o1a-init/frozen.go'),'exact PID1data')
need(p.template_bind(old_template,sr,old,new,r['source_archive']['sha256'])==p.j(OUT/'pid1-source/BOOT-CONFIG.TEMPLATE.json'),'full template delta')
need(p.c_bind(p.read(p.C/'frozen_inputs.h'),old,new)==p.read(OUT/'capexec-source/frozen_inputs.h'),'exact Cheader')
proof=p.exporter_proof(f['pid1-source']['source_files'],r['helper_sources']['pid1-source']['source_files']);need(proof==r['reused_exporter']==p.j(OUT/'EXPORTER-REUSE.json'),'actual unchanged exporter closure/proof')
w=p.j(W/'RESULT.json');need(w['error'] is None and not w['unknown'] and not w['lock_retained'] and len(w['steps'])==1,'known data job closure');step=w['steps'][0];need(step['exit']==0 and step['pipe_threads_finished'] and step['owned_group_absent'],'normal output/group')
for n in (step['pid'],-step['pid']):
 try:os.kill(n,0)
 except ProcessLookupError:pass
 else:raise ValueError('original PID/group observable/reused')
raw=sum(Path(step[k]).stat().st_size for k in ('stdout','stderr'));need(raw==w['raw_bytes']==349 and Path(step['stderr']).stat().st_size==0,'RAW completeness')
review={'status':'ACCEPTED_DISPOSABLE_SOURCE_DATA_ONLY','scope':p.PURPOSE,'result_sha256':p.sha(OUT/'RESULT.json'),'archive_sha256':p.sha(arc),'archive_members':len(seen),'source_files':len(source),'payload_bytes':payload,'source_changed':sorted(changed),'helper_changed_files':all_changed,'canonical_fresh_source_groups':r['source_groups'],'exporter_reused_sha256':p.EXPORTER,'source_exporter_closure_verified':True,'data_job_RAW_bytes':raw,'fresh_recorded_PID_PGID_absent':True,'runtime_ready':False,'resource_execution_by_reviewer':False}
# Correct source-change inventory (helper loop variable is intentionally separate).
review['source_changed']=sorted(set(p.production_posts()))
(HERE/'REVIEW.json').write_text(json.dumps(review,indent=2,sort_keys=True)+'\n');print(p.sha(HERE/'REVIEW.json'))
