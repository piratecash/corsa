# Zero-offer initrd: SOURCE only, helpers pending

Минимальный клон принятого leaf packer. `pack_job.py` побайтово сохранён; assemble меняет только точные source archive/data/4-ELF пути и размер архива. Это data-only упаковка, не Go/C сборка и не запуск ELF/VM.

Фактический DATA58d83 проверен: архив23b2818a, те же1348 source paths и Stand70878d671; Core640ae471. Единственный новый исходник — private leaf full_send. Linuxhelper4a1bd9c2 побайтово прежний, изменились только три остальные test/stand ELF. Exporter7ef3/profilef848/nft closure/policy/caps/права/кодек/таймеры и purpose сохраняются.

Новые init/capexec и их build receipts строго NULL. Read-only `pack_job.check(PACK-FROZEN)` отказывает до привязки фактических helper results. Не запускать main/child до неё. Root выполнит последующие ресурсоёмкие шаги; здесь только три pure Python проверки source-архива, tiny CPIO и pending refusal.

После фактических helper builds и упаковки ожидается семь изменённых CPIO members относительно прежнего leaf97a9: один source, три app ELF, init, capexec, boot. В boot files ожидаются пять изменённых строк (source + три app + capexec); init не ссылается сам на себя. Это ожидание, а не замена полного actual byte diff. Новых путей не допускается. Причина прежнего97a9 остаётся UNKNOWN, O1a metric PASS не заявлен.
