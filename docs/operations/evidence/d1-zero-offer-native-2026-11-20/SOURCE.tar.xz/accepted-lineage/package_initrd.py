"""Offline Full512 initramfs packing and byte readback."""

import argparse
import gzip
import hashlib
import json
from pathlib import Path
import stat
import struct


FILE_MEMBERS = (
    ("init", stat.S_IFREG | 0o755, 16 * 1024**2),
    ("guest-supervisor", stat.S_IFREG | 0o755, 16 * 1024**2),
    ("node.test", stat.S_IFREG | 0o755, 96 * 1024**2),
    ("guest-hosts", stat.S_IFREG | 0o400, 64 * 1024),
)
MEMBERS = (
    ("dev", stat.S_IFDIR | 0o755, 0),
    ("dev/console", stat.S_IFCHR | 0o600, 0),
    ("dev/null", stat.S_IFCHR | 0o666, 0),
    *FILE_MEMBERS,
)
TRAILER = "TRAILER!!!"
HEADER = 110


def digest(data):
    return hashlib.sha256(data).hexdigest()


def exact_file(path, expected, limit):
    if path.is_symlink() or not path.is_file():
        raise ValueError(f"expected a regular input file: {path}")
    with path.open("rb") as stream:
        content = stream.read(limit + 1)
    if not 0 < len(content) <= limit or digest(content) != expected:
        raise ValueError(f"input size or SHA-256 mismatch: {path}")
    return content


def require_static_arm64(elf):
    if len(elf) < 64 or elf[:7] != b"\x7fELF\x02\x01\x01" or struct.unpack_from("<HH", elf, 16) != (2, 183):
        raise ValueError("expected a Linux ARM64 ELF executable")
    phoff, = struct.unpack_from("<Q", elf, 32)
    phsize, phcount = struct.unpack_from("<HH", elf, 54)
    if phsize != 56 or phoff < 64 or not 0 < phcount <= 128 or phoff + phsize * phcount > len(elf):
        raise ValueError("malformed ELF program headers")
    types = {struct.unpack_from("<I", elf, phoff + i * phsize)[0] for i in range(phcount)}
    if 1 not in types or 3 in types:
        raise ValueError("expected a static ELF with a load segment")


def padded(size):
    return (-size) % 4


def header(name, ino, mode, length):
    # All archive metadata is fixed. The guest owns its root and runtime files.
    major, minor = {"dev/console": (5, 1), "dev/null": (1, 3)}.get(name, (0, 0))
    links = 2 if name == "dev" else 1
    fields = (ino, mode, 0, 0, links, 0, length, 0, 0, major, minor, len(name) + 1, 0)
    return ("070701" + "".join(f"{value:08x}" for value in fields)).encode("ascii")


def write_member(stream, name, ino, mode, content):
    encoded = name.encode("ascii") + b"\0"
    stream.write(header(name, ino, mode, len(content)))
    stream.write(encoded)
    stream.write(b"\0" * padded(HEADER + len(encoded)))
    stream.write(content)
    stream.write(b"\0" * padded(len(content)))


def read_exact(stream, count):
    value = stream.read(count)
    if len(value) != count:
        raise ValueError("truncated initramfs")
    return value


def verify_archive(path, manifest):
    if set(manifest) != {name for name, _, _ in MEMBERS}:
        raise ValueError("unexpected initramfs member manifest")
    rows = []
    with gzip.open(path, "rb") as stream:
        for ino, (name, mode, limit) in enumerate((*MEMBERS, (TRAILER, 0, 0)), 1):
            expected = manifest.get(name, {"bytes": 0, "sha256": digest(b"")})
            size = expected["bytes"]
            minimum = 0 if limit == 0 else 1
            if expected.keys() != {"bytes", "sha256"} or type(size) is not int or not minimum <= size <= limit:
                raise ValueError(f"invalid expected member size: {name}")
            encoded = name.encode("ascii") + b"\0"
            if read_exact(stream, HEADER) != header(name, ino, mode, size):
                raise ValueError(f"unexpected initramfs metadata: {name}")
            if read_exact(stream, len(encoded)) != encoded:
                raise ValueError(f"unexpected initramfs path: {name}")
            if read_exact(stream, padded(HEADER + len(encoded))).strip(b"\0"):
                raise ValueError("invalid initramfs header padding")
            content = read_exact(stream, size)
            if digest(content) != expected["sha256"]:
                raise ValueError(f"initramfs content differs: {name}")
            if read_exact(stream, padded(size)).strip(b"\0"):
                raise ValueError("invalid initramfs data padding")
            if name != TRAILER:
                rows.append({"path": name, "mode": f"{mode & 0o777:04o}", **expected})
        if stream.read(1):
            raise ValueError("unexpected data after the initramfs trailer")
    return rows


def pack(output, inputs):
    if set(inputs) != {name for name, _, _ in FILE_MEMBERS}:
        raise ValueError("expected exactly the declared initramfs inputs")
    content = {"dev": b"", "dev/console": b"", "dev/null": b""}
    for name, _, limit in FILE_MEMBERS:
        path, expected = inputs[name]
        data = exact_file(path, expected, limit)
        if name != "guest-hosts":
            require_static_arm64(data)
        content[name] = data
    if content["init"] == content["guest-supervisor"]:
        raise ValueError("PID 1 and guest supervisor must be separate executables")
    manifest = {name: {"bytes": len(data), "sha256": digest(data)} for name, data in content.items()}
    with output.open("xb") as target:
        with gzip.GzipFile(fileobj=target, mode="wb", filename="", mtime=0) as stream:
            for ino, (name, mode, _) in enumerate(MEMBERS, 1):
                write_member(stream, name, ino, mode, content[name])
            write_member(stream, TRAILER, len(MEMBERS) + 1, 0, b"")
    rows = verify_archive(output, manifest)
    archive_hash = hashlib.sha256()
    with output.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            archive_hash.update(chunk)
    return {"scope": "initramfs-byte-readback", "archive_sha256": archive_hash.hexdigest(), "members": rows}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("init", "supervisor", "node", "plan"):
        parser.add_argument("--" + name, required=True, type=Path)
        parser.add_argument("--" + name + "-sha", required=True)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    inputs = {
        "init": (args.init, args.init_sha),
        "guest-supervisor": (args.supervisor, args.supervisor_sha),
        "node.test": (args.node, args.node_sha),
        "guest-hosts": (args.plan, args.plan_sha),
    }
    print(json.dumps(pack(args.output, inputs), sort_keys=True, indent=2))
