"""Pack the exact baseline source files consumed by the native O-1a journal."""

import argparse
import gzip
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import tarfile

HERE = Path(__file__).resolve().parent
BUILD = HERE.parents[1] / "2026-11-17/d1-o1a-v2672-build"
COMMIT = "4fcc2f7245095fc43d2225f0f0065f4ce3b26113"
REQUEST_SHA = "745eefbb111b761e76556cc51e02dd735d0baa88779a23237bc336f8aeef30a8"
MIB = 1024**2


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def file_sha(path):
    if path.is_symlink() or not path.is_file():
        raise ValueError("input is not a regular file")
    h = hashlib.sha256()
    with path.open("rb") as source:
        for raw in iter(lambda: source.read(MIB), b""):
            h.update(raw)
    return h.hexdigest()


def groups(name):
    path = PurePosixPath(name)
    if path.suffix != ".go":
        return ()
    measured = name.startswith("internal/core/") and not name.endswith("_test.go")
    stand = (path.parent.as_posix() == "internal/core/node" and name.endswith("_test.go")) or \
        name.startswith("internal/testutil/loadstand/") or name.startswith("sdk/")
    return tuple(g for g, wanted in (("measured", measured), ("stand", stand)) if wanted)


def safe_name(raw):
    name = raw.rstrip("/")
    path = PurePosixPath(name)
    if not name or name != path.as_posix() or path.is_absolute() or ".." in path.parts or \
            any(c in name for c in "\\\r\n\x00"):
        raise ValueError("invalid source archive path")
    return name


def load_sources(path, expected_sha, commit):
    if file_sha(path) != expected_sha:
        raise ValueError("source archive SHA differs from the build request")
    files, seen, selected_bytes = {}, set(), 0
    with tarfile.open(path, "r:gz") as archive:
        for member in archive:
            name = safe_name(member.name)
            if archive.pax_headers.get("comment") != commit:
                raise ValueError("Git archive commit differs")
            if name in seen or len(seen) >= 10000 or not (member.isdir() or member.isfile()):
                raise ValueError("duplicate or irregular source archive member")
            seen.add(name)
            if not groups(name):
                continue
            if not member.isfile() or not 0 <= member.size <= 4 * MIB:
                raise ValueError("selected source is not a bounded ordinary file")
            selected_bytes += member.size
            if selected_bytes > 64 * MIB:
                raise ValueError("selected sources exceed the input budget")
            with archive.extractfile(member) as source:
                raw = source.read(member.size + 1)
            if len(raw) != member.size:
                raise ValueError("truncated source")
            files[name] = raw
    if any(not any(g in groups(name) for name in files) for g in ("measured", "stand")):
        raise ValueError("missing original journal source group")
    return files


def manifests(files):
    result = {}
    for group in ("measured", "stand"):
        rows = [f"{sha(raw)}  {name}\n" for name, raw in sorted(files.items()) if group in groups(name)]
        result[group] = (f"runjournal-sources/v1\nname {group}\n" + "".join(rows)).encode()
    return result


def archive_members(files):
    content = {"source/" + name: raw for name, raw in files.items()}
    content.update({f"manifests/{group}.manifest": raw for group, raw in manifests(files).items()})
    directories = {p.as_posix() for name in content for p in PurePosixPath(name).parents if p.as_posix() != "."}
    return content, directories


def verify(output, files):
    content, directories = archive_members(files)
    wanted = [(n, True) for n in sorted(directories)] + [(n, False) for n in sorted(content)]
    with tarfile.open(output, "r:gz") as archive:
        for name, is_dir in wanted:
            member = archive.next()
            if member is None or member.name != name or member.isdir() != is_dir or \
                    (not is_dir and not member.isfile()) or member.uid != 0 or member.gid != 0 or \
                    member.mtime != 0 or member.mode != (0o755 if is_dir else 0o444) or \
                    member.size != (0 if is_dir else len(content[name])):
                raise ValueError("guest source archive metadata differs")
            if not is_dir:
                with archive.extractfile(member) as source:
                    if source.read(member.size + 1) != content[name]:
                        raise ValueError("guest source archive content differs")
        if archive.next() is not None:
            raise ValueError("unexpected guest source archive member")


def pack(output, files):
    content, directories = archive_members(files)
    with output.open("xb") as target:
        with gzip.GzipFile(fileobj=target, mode="wb", filename="", mtime=0) as compressed:
            with tarfile.open(fileobj=compressed, mode="w", format=tarfile.USTAR_FORMAT) as archive:
                for name in sorted(directories) + sorted(content):
                    member = tarfile.TarInfo(name)
                    is_dir = name in directories
                    member.type = tarfile.DIRTYPE if is_dir else tarfile.REGTYPE
                    member.mode = 0o755 if is_dir else 0o444
                    member.size = 0 if is_dir else len(content[name])
                    archive.addfile(member, None if is_dir else io.BytesIO(content[name]))
    verify(output, files)
    return {
        "status": "SOURCE_INPUTS_PACKED_WITHOUT_EXECUTION",
        "commit": COMMIT, "build_request_sha256": REQUEST_SHA,
        "archive_sha256": file_sha(output), "archive_bytes": output.stat().st_size,
        "guest_cwd": "/source/internal/core/node",
        "files": {name: {"sha256": sha(raw), "bytes": len(raw)} for name, raw in sorted(files.items())},
        "source_groups": {group: {"sha256": sha(raw), "stamp": sha(raw)[:16],
                                   "files": sum(group in groups(n) for n in files)}
                          for group, raw in manifests(files).items()},
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    request = BUILD / "REQUEST.json"
    if file_sha(request) != REQUEST_SHA:
        parser.error("original build request changed")
    bound = json.loads(request.read_bytes())
    source = BUILD / "source.tar.gz"
    if bound["commit"] != COMMIT:
        parser.error("original baseline commit changed")
    files = load_sources(source, bound["files"][str(source)], COMMIT)
    print(json.dumps(pack(args.output, files), indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
