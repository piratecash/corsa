import json,tempfile,unittest
from pathlib import Path
from unittest import mock
import common,qa
class Tests(unittest.TestCase):
 def test_actual_artifact_and_QA_source_maps_are_separate(self):
  base=json.loads(qa.BASE_MANIFEST.read_bytes());m=json.loads((qa.SUBJECT/'MANIFEST.json').read_bytes());a,q=qa.expected_maps(base,m)
  self.assertEqual((len(a),len(q)),(2450,2457));self.assertEqual(set(q)-set(a),set(m['QA_only_files']))
  bad=dict(base);bad.pop(next(iter(m['files'])))
  with self.assertRaises((RuntimeError,KeyError)):qa.expected_maps(bad,m)
 def test_event_parser_refuses_fail_skip_missing_and_wrong_children(self):
  rows=[{'Action':'pass','Test':'A'},{'Action':'pass','Test':'A/child'},{'Action':'pass'}];raw=lambda r:b'\n'.join(json.dumps(x).encode() for x in r)
  qa.check_events(raw(rows),['A'],1)
  for values,expected,kids in [(rows+[{'Action':'fail'}],['A'],1),(rows+[{'Action':'skip'}],['A'],1),(rows,[],1),(rows,['A'],2)]:
   with self.assertRaises(RuntimeError):qa.check_events(raw(values),expected,kids)
 def test_only_legacy_loopback_policy_and_group_unknown(self):
  p=Path('/private/tmp/source-fixture')
  self.assertNotIn('allow network-',qa.policy(p,False));self.assertIn('localhost:*',qa.policy(p,True));self.assertIn('deny network*',qa.policy(p,True))
  for error,want in [(ProcessLookupError(),True),(PermissionError(),False),(OSError(),False)]:
   with mock.patch.object(common.os,'killpg',side_effect=error):self.assertIs(common.Job.group_absent(123),want)
 def test_overlay_of_fresh_readonly_copy_without_input_mutation(self):
  with tempfile.TemporaryDirectory() as t:
   root=Path(t);subject=root/'subject';src=root/'source';(subject/'posts').mkdir(parents=True);src.mkdir();(subject/'posts/a.go').write_bytes(b'new');(src/'a.go').write_bytes(b'old');(src/'a.go').chmod(0o444)
   m={'files':{'a.go':{'after_sha256':common.sha(subject/'posts/a.go')}},'QA_only_files':{}}
   with mock.patch.object(qa,'SUBJECT',subject):qa.apply_posts(src,m)
   self.assertEqual((src/'a.go').read_bytes(),b'new');self.assertEqual((src/'a.go').stat().st_mode&0o777,0o444);self.assertEqual((subject/'posts/a.go').read_bytes(),b'new')
if __name__=='__main__':unittest.main()
