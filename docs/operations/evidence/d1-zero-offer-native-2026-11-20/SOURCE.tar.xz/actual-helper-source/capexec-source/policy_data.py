"""Read/evaluate dumped ACTUAL C-factory cBPF, never build or install a filter."""
from pathlib import Path
import hashlib
import json
import struct
import sys

MAGIC=b'O1ABPF1\n'
ALLOW=0x7fff0000
KILL=0x80000000
EPERM=0x00050001
ENOSYS=0x00050026
ARCH=0xc00000b7
NR={'read':63,'write':64,'execve':221,'execveat':281,'clone':220,'clone3':435,'unshare':97,'setns':268,'socket':198,'mount':40,'umount2':39,'reboot':142,'bpf':280,'ptrace':117,'io_uring_setup':425,'perf_event_open':241,'sethostname':161,'keyctl':219}
NEWNET=0x40000000
NAMESPACES=(0x00020000,0x02000000,0x04000000,0x08000000,0x10000000,0x20000000,NEWNET)

def need(ok,why):
    if not ok:raise ValueError(why)

def parse(raw):
    need(type(raw) is bytes and 12<=len(raw)<=12+256*8 and raw[:8]==MAGIC,'BPF data framing')
    count,=struct.unpack_from('<I',raw,8);need(0<count<=256 and len(raw)==12+8*count,'BPF exact count')
    code=[struct.unpack_from('<HBBI',raw,12+8*i) for i in range(count)]
    for pc,(op,jt,jf,k) in enumerate(code):
        need(op in (0x20,0x54,0x15,0x45,0x06),'unsupported cBPF opcode')
        if op in (0x15,0x45):need(pc+1+jt<count and pc+1+jf<count,'jump beyond program')
        else:need(jt==jf==0,'nonjump branch bytes')
        if op==0x20:need(k in (0,4) or (16<=k<=60 and k%4==0),'read outside seccomp fields')
        if op==0x06:need(k in (ALLOW,KILL,EPERM,ENOSYS),'unexpected filter verdict')
    need(code[-1][0]==0x06,'program must terminate');return tuple(code)

def evaluate(code,nr,args=(),arch=ARCH):
    need(type(nr) is int and 0<=nr<2**32 and type(arch) is int and 0<=arch<2**32,'seccomp scalar')
    need(type(args) in (tuple,list) and len(args)<=6 and all(type(v) is int and 0<=v<2**64 for v in args),'seccomp arguments')
    data=struct.pack('<IIQ6Q',nr,arch,0,*(list(args)+[0]*(6-len(args))))
    pc=0;a=0
    for _ in range(len(code)):
        need(0<=pc<len(code),'execution outside program');op,jt,jf,k=code[pc]
        if op==0x20:a,=struct.unpack_from('<I',data,k)
        elif op==0x54:a&=k
        elif op==0x15:pc+=jt if a==k else jf
        elif op==0x45:pc+=jt if a&k else jf
        elif op==0x06:return k
        else:raise ValueError('unparsed opcode')
        pc+=1
    raise ValueError('BPF did not return within instruction bound')

def qualify(raw):
    code=parse(raw);cases=[]
    def check(name,nr,args,wanted,arch=ARCH):
        got=evaluate(code,nr,args,arch);need(got==wanted,'actual factory verdict: '+name)
        cases.append({'name':name,'nr':nr,'args':list(args),'arch':arch,'verdict':got})
    for name in ('read','write','execve','execveat'):check('ordinary-'+name,NR[name],(),ALLOW)
    check('foreign-architecture',NR['read'],(),KILL,0xc000003e)
    check('ordinary-clone',NR['clone'],(0x00000100|0x00010000,),ALLOW)
    for flags in NAMESPACES:check('clone-namespace-'+hex(flags),NR['clone'],(flags,),EPERM)
    check('clone-high-bits',NR['clone'],(1<<32,),EPERM)
    check('clone3-fallback',NR['clone3'],(),ENOSYS)
    for name,argindex in (('unshare',0),('setns',1)):
        def args(flags):return (flags,) if argindex==0 else (0xffffffff,flags)
        check(name+'-newnet',NR[name],args(NEWNET),ALLOW)
        for flags in (0,0x20000,NEWNET|0x20000,(1<<32)|NEWNET):check(name+'-refuse-'+hex(flags),NR[name],args(flags),EPERM)
    for domain,kind,protocol in ((1,5,0),(16,3,0),(16,3,12),(2,1,0),(2,1,6),(2,2,0),(2,2,17),(10,1,6),(10,2,17)):
        check('socket-allow-'+str((domain,kind,protocol)),NR['socket'],(domain,kind,protocol),ALLOW)
    for args in ((17,3,0),(2,3,0),(2,1,17),(2,2,6),(16,3,9),(16,3,(1<<32)|12),((1<<32)|2,1,6),(2,(1<<32)|1,6),(2,1,(1<<32)|6)):
        check('socket-refuse-'+str(args),NR['socket'],args,EPERM)
    for name in ('mount','umount2','reboot','bpf','ptrace','io_uring_setup','perf_event_open','sethostname','keyctl'):check('forbidden-'+name,NR[name],(),EPERM)
    return {'scope':'ACTUAL_C_FACTORY_BYTECODE_DATA_AND_USERSPACE_EVALUATION_ONLY','instruction_count':len(code),'dump_sha256':hashlib.sha256(raw).hexdigest(),'controls':cases,'control_count':len(cases),'filter_installed':False,'guest_or_app_executed':False}

if __name__=='__main__':
    need(len(sys.argv)==2,'one pure dump input required')
    with Path(sys.argv[1]).open('rb') as stream:raw=stream.read(12+256*8+1)
    print(json.dumps(qualify(raw),sort_keys=True,indent=2))
