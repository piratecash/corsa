/* Pure actual-factory bytecode export. No seccomp install, application or VM. */
#define _GNU_SOURCE
#include "guest_policy.h"
#include <stdio.h>
#include <unistd.h>
static int byte(unsigned int value) {return putchar((int)(value&255U))==EOF?-1:0;}
static int little(unsigned int value,unsigned int bytes) {
    for(unsigned int n=0;n<bytes;n++)if(byte(value>>(8U*n)))return -1;
    return 0;
}
int main(void) {
    struct guest_policy p=guest_policy();
    if(!p.count||p.count>256)return 2;
    if(fwrite("O1ABPF1\n",1,8,stdout)!=8||little(p.count,4))return 3;
    for(unsigned int n=0;n<p.count;n++) {
        struct sock_filter x=p.code[n];
        if(little(x.code,2)||byte(x.jt)||byte(x.jf)||little(x.k,4))return 4;
    }
    return fflush(stdout)||ferror(stdout)?5:0;
}
