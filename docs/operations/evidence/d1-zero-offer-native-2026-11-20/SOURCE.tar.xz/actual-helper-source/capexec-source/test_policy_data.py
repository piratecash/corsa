import struct
import unittest
import policy_data as p

def wire(code):return p.MAGIC+struct.pack('<I',len(code))+b''.join(struct.pack('<HBBI',*row) for row in code)

class Tests(unittest.TestCase):
    def test_exact_framing_and_terminal(self):
        raw=wire([(6,0,0,p.ALLOW)]);self.assertEqual(p.evaluate(p.parse(raw),63),p.ALLOW)
        for bad in (b'',raw+b'0',raw[:-1],b'BADMAGIC'+raw[8:],p.MAGIC+struct.pack('<I',257)+bytes(257*8),wire([(0x20,0,0,0)])):
            with self.subTest(length=len(bad)),self.assertRaises(ValueError):p.parse(bad)
    def test_jump_and_field_and_opcode_bounds(self):
        for code in ([(0x15,1,0,0),(6,0,0,p.ALLOW)],[(0x20,0,0,8),(6,0,0,p.ALLOW)],[(0x20,0,0,61),(6,0,0,p.ALLOW)],[(6,1,0,p.ALLOW)],[(6,0,0,123)],[(0x99,0,0,0),(6,0,0,p.ALLOW)]):
            with self.subTest(code=code),self.assertRaises(ValueError):p.parse(wire(code))
    def test_conditional_real_field_endianness_and_highword(self):
        code=p.parse(wire([(0x20,0,0,20),(0x15,0,1,1),(6,0,0,p.EPERM),(6,0,0,p.ALLOW)]))
        self.assertEqual(p.evaluate(code,63,(1<<32,)),p.EPERM);self.assertEqual(p.evaluate(code,63,(1,)),p.ALLOW)
        code=p.parse(wire([(0x20,0,0,0),(0x45,0,1,32),(6,0,0,p.EPERM),(6,0,0,p.ALLOW)]))
        self.assertEqual(p.evaluate(code,63),p.EPERM);self.assertEqual(p.evaluate(code,64),p.ALLOW)
    def test_allow_all_and_deny_all_do_not_qualify(self):
        for verdict in (p.ALLOW,p.EPERM):
            with self.subTest(verdict=verdict),self.assertRaises(ValueError):p.qualify(wire([(6,0,0,verdict)]))
    def test_input_arguments_are_bounded(self):
        code=p.parse(wire([(6,0,0,p.ALLOW)]))
        for nr,args,arch in ((-1,(),p.ARCH),(63,(-1,),p.ARCH),(63,(2**64,),p.ARCH),(63,(1,)*7,p.ARCH),(True,(),p.ARCH),(63,(),2**32)):
            with self.assertRaises(ValueError):p.evaluate(code,nr,args,arch)

if __name__=='__main__':unittest.main()
