#ifndef CORSA_GUEST_POLICY_H
#define CORSA_GUEST_POLICY_H
#if !defined(__linux__) || !defined(__aarch64__)
#error fixed Linux AArch64 guest policy only
#endif
/* Fixed AArch64 guest-only restriction. Not a Docker-policy equivalence claim. */
#include <errno.h>
#include <stddef.h>
#include <stdint.h>
#include <linux/audit.h>
#include <linux/filter.h>
#include <linux/seccomp.h>
#include <linux/sched.h>
#include <asm/unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <linux/netlink.h>

struct guest_policy { struct sock_filter code[256]; unsigned short count; };
static void gp_put(struct guest_policy *p, unsigned short code, unsigned char t,
                   unsigned char f, unsigned int k) {
    p->code[p->count++] = (struct sock_filter){code,t,f,k};
}
#define GP_ST(p,c,k) gp_put((p),(c),0,0,(k))
#define GP_JP(p,c,k,t,f) gp_put((p),(c),(t),(f),(k))
#define GP_ARG(p,n,hi) GP_ST((p),BPF_LD|BPF_W|BPF_ABS,offsetof(struct seccomp_data,args)+(n)*8+(hi)*4)
#define GP_ALLOW(p) GP_ST((p),BPF_RET|BPF_K,SECCOMP_RET_ALLOW)
#define GP_DENY(p) GP_ST((p),BPF_RET|BPF_K,SECCOMP_RET_ERRNO|EPERM)
static void gp_deny_syscall(struct guest_policy *p, unsigned int nr) {
    GP_JP(p,BPF_JMP|BPF_JEQ|BPF_K,nr,0,1); GP_DENY(p);
}
/* Every conditional block returns, so later cases still see syscall nr. */
static unsigned short gp_case(struct guest_policy *p, unsigned int nr) {
    unsigned short at=p->count;
    GP_JP(p,BPF_JMP|BPF_JEQ|BPF_K,nr,0,0); return at;
}
static void gp_end(struct guest_policy *p, unsigned short at) {
    p->code[at].jf=(unsigned char)(p->count-at-1);
}
static void gp_high_zero(struct guest_policy *p, unsigned int argument) {
    GP_ARG(p,argument,1); GP_JP(p,BPF_JMP|BPF_JEQ|BPF_K,0,1,0); GP_DENY(p);
}
static void gp_ip_protocol(struct guest_policy *p,unsigned int protocol) {
    gp_high_zero(p,2); GP_ARG(p,2,0);
    GP_JP(p,BPF_JMP|BPF_JEQ|BPF_K,0,1,0);
    GP_JP(p,BPF_JMP|BPF_JEQ|BPF_K,protocol,0,1);
    GP_ALLOW(p); GP_DENY(p);
}
static struct guest_policy guest_policy(void) {
    struct guest_policy p={0}; unsigned short at;
    GP_ST(&p,BPF_LD|BPF_W|BPF_ABS,offsetof(struct seccomp_data,arch));
    GP_JP(&p,BPF_JMP|BPF_JEQ|BPF_K,AUDIT_ARCH_AARCH64,1,0);
    GP_ST(&p,BPF_RET|BPF_K,SECCOMP_RET_KILL_PROCESS);
    GP_ST(&p,BPF_LD|BPF_W|BPF_ABS,offsetof(struct seccomp_data,nr));
    /* Keep Go thread creation, but never create another namespace class. */
    at=gp_case(&p,__NR_clone);
    gp_high_zero(&p,0); GP_ARG(&p,0,0);
    GP_JP(&p,BPF_JMP|BPF_JSET|BPF_K,
        CLONE_NEWNS|CLONE_NEWCGROUP|CLONE_NEWUTS|CLONE_NEWIPC|
        CLONE_NEWUSER|CLONE_NEWPID|CLONE_NEWNET,0,1);
    GP_DENY(&p); GP_ALLOW(&p); gp_end(&p,at);
    /* clone3 flags are behind a pointer: force documented clone fallback. */
    GP_JP(&p,BPF_JMP|BPF_JEQ|BPF_K,__NR_clone3,0,1);
    GP_ST(&p,BPF_RET|BPF_K,SECCOMP_RET_ERRNO|ENOSYS);
    at=gp_case(&p,__NR_unshare);
    gp_high_zero(&p,0); GP_ARG(&p,0,0);
    GP_JP(&p,BPF_JMP|BPF_JEQ|BPF_K,CLONE_NEWNET,1,0);
    GP_DENY(&p); GP_ALLOW(&p); gp_end(&p,at);
    at=gp_case(&p,__NR_setns);
    gp_high_zero(&p,1); GP_ARG(&p,1,0);
    GP_JP(&p,BPF_JMP|BPF_JEQ|BPF_K,CLONE_NEWNET,1,0);
    GP_DENY(&p); GP_ALLOW(&p); gp_end(&p,at);
    at=gp_case(&p,__NR_socket);
    gp_high_zero(&p,0); GP_ARG(&p,0,0);
    /* AF_UNIX is needed for original seqpacket lifecycle/work channels. */
    GP_JP(&p,BPF_JMP|BPF_JEQ|BPF_K,AF_UNIX,0,1); GP_ALLOW(&p);
    GP_JP(&p,BPF_JMP|BPF_JEQ|BPF_K,AF_NETLINK,0,8);
    gp_high_zero(&p,2); GP_ARG(&p,2,0);
    GP_JP(&p,BPF_JMP|BPF_JEQ|BPF_K,NETLINK_ROUTE,1,0);
    GP_JP(&p,BPF_JMP|BPF_JEQ|BPF_K,NETLINK_NETFILTER,0,1);
    GP_ALLOW(&p); GP_DENY(&p);
    /* Only TCP/UDP socket kinds in the original IPv4/IPv6 domains. */
    GP_JP(&p,BPF_JMP|BPF_JEQ|BPF_K,AF_INET,1,0);
    unsigned short inet6=p.count;
    GP_JP(&p,BPF_JMP|BPF_JEQ|BPF_K,AF_INET6,0,0);
    gp_high_zero(&p,1); GP_ARG(&p,1,0);
    GP_ST(&p,BPF_ALU|BPF_AND|BPF_K,0xf);
    GP_JP(&p,BPF_JMP|BPF_JEQ|BPF_K,SOCK_STREAM,0,8);
    gp_ip_protocol(&p,IPPROTO_TCP);
    GP_JP(&p,BPF_JMP|BPF_JEQ|BPF_K,SOCK_DGRAM,0,8);
    gp_ip_protocol(&p,IPPROTO_UDP);
    p.code[inet6].jf=(unsigned char)(p.count-inet6-1);
    GP_DENY(&p); gp_end(&p,at);
    /* Effective security restrictions beyond capability checks: no mounts,
       module/policy injection, tracing, alternate async IO or host lifecycle. */
#define GP_BLOCK(n) gp_deny_syscall(&p,__NR_##n)
    GP_BLOCK(mount); GP_BLOCK(umount2); GP_BLOCK(pivot_root); GP_BLOCK(chroot);
    GP_BLOCK(fsopen); GP_BLOCK(fsconfig); GP_BLOCK(fsmount); GP_BLOCK(move_mount);
    GP_BLOCK(open_tree); GP_BLOCK(mount_setattr);
    GP_BLOCK(init_module); GP_BLOCK(finit_module); GP_BLOCK(delete_module);
    GP_BLOCK(kexec_load); GP_BLOCK(kexec_file_load); GP_BLOCK(reboot);
    GP_BLOCK(ptrace); GP_BLOCK(process_vm_readv); GP_BLOCK(process_vm_writev);
    GP_BLOCK(bpf); GP_BLOCK(perf_event_open); GP_BLOCK(userfaultfd);
    GP_BLOCK(io_uring_setup); GP_BLOCK(io_uring_enter); GP_BLOCK(io_uring_register);
    GP_BLOCK(open_by_handle_at); GP_BLOCK(name_to_handle_at); GP_BLOCK(fanotify_init);
    GP_BLOCK(add_key); GP_BLOCK(request_key); GP_BLOCK(keyctl);
    GP_BLOCK(swapon); GP_BLOCK(swapoff); GP_BLOCK(acct); GP_BLOCK(syslog);
    GP_BLOCK(sethostname); GP_BLOCK(setdomainname);
#undef GP_BLOCK
    /* Ordinary Go, filesystem/RPC, netlink, nft and helper lifecycle syscalls
       remain kernel/cap/UID checked. This is a deny policy, not hermetic IO. */
    GP_ALLOW(&p); return p;
}
#endif
