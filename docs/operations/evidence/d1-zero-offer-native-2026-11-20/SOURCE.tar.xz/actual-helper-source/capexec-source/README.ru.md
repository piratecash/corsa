# SOURCE ONLY: исходная seccomp-политика в capexec

Новый snapshot от принятого `d1-o1a-capexec-no-pie-v1/source/capexec.c`.
`guest_policy.h` восстановлен побайтно и совпал с историческим Member4
HANDOFF: SHA699c0a05…/5496B. Никакого нового ALLOW-all фильтра нет.

Неизменны четыре capabilities, NNP/core0, закрытый workload selector,
исходные ELF/env/profile pins и точные Go argv/timeouts. PID1 не меняется и
остаётся без фильтра, чтобы штатный и независимый poweroff оставались доступны.

Перед Go exec и отдельно через закрытый `--policy-controls` capexec проверяет:
single-thread/root и исходный ceiling; mode0/filter-count0; `unshare(0)==0`;
`setns(-1,0)==-1/EBADF`; устанавливает настоящую историческую factory;
mode2/filter-count1; оба вызова теперь EPERM; AF_UNIX seqpacket разрешён,
его FD закрыт и EBADF подтверждён; netns dev/inode прежние; NNP/core0 и
capabilities прежние. Все прочие открываемые для чтения FILE закрываются.
Исходный entry FD остаётся CLOEXEC и используется прежним fexecve.
`--probe` сохраняет read-only семантику, вывод дополняется seccomp/count.

`policy_dump.c` не устанавливает фильтр: только вызывает **ту же factory** и
пишет ограниченный LE cBPF record `O1ABPF1\n` + u32count + count*8 байт.
`policy_data.py` проверяет framing/opcodes/forward-jumps/offsets/verdicts,
затем оценивает фактические bytes на фиксированных allow/refusal controls.
Он не пересоздаёт политику. Числа syscall закреплены Linux AArch64
asm-generic ABI (Linux6.18.63 UAPI), не host ABI.

Здесь исполняются только маленькие Python fixture-тесты. Actual C factory
dump/control результат и native mode/effect **NOT_RUN** до действий Root.
Успех pure evaluator не доказывает установку фильтра или O1a PASS.
