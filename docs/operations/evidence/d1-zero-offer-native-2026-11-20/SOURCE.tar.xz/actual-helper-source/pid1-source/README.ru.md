# О‑1а: capexec и статический экспорт journal (исходники)

**SOURCE_ONLY_NOT_COMPILED_NOT_RUNTIME_READY.** Здесь нет новой app/kernel/ELF
сборки. Go, C-компилятор, Docker/VM и ELF не запускались. Продуктовые исходники,
ядро и четыре готовых baseline ELF не менялись.

## capexec.c

Отдельный single-threaded статический Linux wrapper с фиксированным entry
`/bin/node.test`, cwd `/source/internal/core/node` и единственным test selector
`^TestLoadStandLinuxRouteWireNative$`, count1/verbose. Параметр — только
`periodic` или `reconnect`; Go timeout570/255 с соответственно. `--probe`
только читает текущие uid/gid/Threads/capabilities/NNP и завершает0; права не меняет.
Нельзя передать shell, другой executable или произвольные test arguments.

Перед exec проверяет root/single thread, наличие effective SETPCAP и допустимых
capabilities, regular/nlink1/no-symlink/no-setid AArch64 ELF entry. `fexecve`
использует открытый fd. SHA самого node.test всё ещё должен проверить PID1 по
manifest; имя NODE_SHA в header — закреплённый ожидаемый вход, C wrapper не
содержит самостоятельной SHA-реализации.

Сначала core hard/soft0 и ambient clear; затем drop bounding **всех** capabilities,
кроме SETGID/SETUID/NET_ADMIN/SYS_ADMIN, пока SETPCAP ещё effective. Потом capset
exact effective/permitted `0x2010c0`, inheritable0; NNP1. Обязателен readback
/proc/self/status: exact Eff/Prm/Bnd, Inh/Amb0, Threads1/NNP1; core повторно читается.
Это состояние перед exec; исходный planned backend дополнительно проверит
фактическое состояние самого Go coordinator.

Inherited environment заменяется whitelist: фиксированные PATH/LC_ALL,
GOMAXPROCS2/HOME/TMPDIR и13 исходных LOADSTAND-полей. Пути и SHA helper/full/sdk/nft,
нативный флаг и **точные bytes выбранного frozen profile** сверяются с header.
Production/fallback/IPv6 targets проверяет исходный Go netip parser; wrapper
не подставляет фиктивные адреса и не меняет критерии изоляции. Secrets отсутствуют.
Статическая сборка обязательна, чтобы loader environment не сработал до main.

`frozen_inputs.h` сгенерирован как source data из существующих frozen profiles и
INPUT-MANIFEST; Go baseline `4fcc2f7245095fc43d2225f0f0065f4ce3b26113`.
Предлагаемая будущая C-команда: `cc -std=c11 -static -O2 -Wall -Wextra -Werror
-o capexec capexec.c`. Она здесь **не выполнялась**; ещё нужны compile/CODE и
реальный capability probe/readback в госте.

## Go exporter

`capsule/capsule.go` — stdlib-only pure pack/frame/canonical JSON; Go tests в
`capsule_test.go`. Linux fd-based inventory — `inventory_linux.go`, отдельный
Linux test. `cmd/journal-export` — фиксированный guest entry:
`/bin/journal-export periodic|reconnect`, читает только
`/config/<workload>.binding.json` и `/profiles/o1a-<workload>-journal`, пишет capsule
в stdout. Binding strict: ровно четыре уникальных поля; fresh32hex attempt_id,
точные workload/profileSHA/sourcecommit. Никаких шаблонных defaults.

Формат совпадает с принятым Python reference:
`corsa-o1a-journal-capsule/v1`, BEGIN/CHUNK/END prefix, canonical ASCII JSON,
manifest per-file SHA/size, deterministic USTAR + gzip6, base64 chunks48 KiB.
Gzip/tar байты Go и Python могут различаться; schema/metadata/байты файлов и
hash каждого конкретного архива должны проверяться исходным Python decoder.
Лимиты: content64MiB/file8MiB/files4096/dirs4096/depth32/manifest1MiB,
tar72MiB/gzip16MiB/console32MiB. Go package не допускает поднятия этих пределов.

Экспорт допустим **только после доказанного reap Go и всех потомков**, когда
журнал quiescent. Проверки inode/stat и O_NOFOLLOW помогают обнаружить изменения,
но не доказывают отсутствие concurrent writers. Fresh attempt_id не заменяет
проверку runjournal nonce/source snapshots. Decode PASS — только транспорт.

## Cross-language fixtures и честный статус QA

В `fixtures/` три маленьких файла, Python-generated gzip/console и canonical
Unicode/control-character JSON. `python3 -B check_cross_language.py` уже выполнил
Python decode/equality: **PYTHON_FIXTURES_ONLY_PASS**. Go исходники/Go тесты пока
**NOT_RUN**: здесь не выполнялись Go test, gofmt или компиляция.

После разрешённой Root сборки можно исполнить pure package tests с переменной
`O1A_GO_VECTOR_OUTPUT=/absolute/fresh/go.console`, затем проверить именно этот
результат: `python3 -B check_cross_language.py --go-console /absolute/fresh/go.console`.
Без `--go-console` проверка явно не заявляет межъязыковой Go PASS. Linux inventory
проверяется отдельно в Linux, а pure Pack/Frame тесты можно выполнить на macOS.
Исходный Python reference SHA записан в RESULT; output от предыдущего шага не
подменять новым с одинаковым именем.

## PID1/supervisor: следующий конкретный шаг

Конкретный PID1/supervisor теперь реализован в `cmd/o1a-init/` как source-only code;
он ещё НЕ компилировался и НЕ исполнялся. Pure config tests также NOT_RUN.
Реализация использует mount/reap/poweroff без topology1026/aliases,
стартовый netns ровно{lo}; исходный planned backend создаёт свою topology.
Initrd должен иметь /proc,/sys,/dev,/tmp,/profiles, source pack в/source и точные
четыре ELF/nft closure. Сверить все SHA до capexec; immutable input paths не
отдавать дочерним writers. /dev без block devices. Не подделывать UTC.

Один selected workload на свежую VM,2vCPU/1536MiB/noNIC/disks/hostsharing.
Исходные periodic Timeout540/StartupLead90/Duration390/window120..360 и reconnect
Timeout225/StartupLead90/Duration75/window5..60/disconnect15 неизменны.
StartupLead уже входит в Timeout. Guest абсолютные work600/kill610/reap620,
затем export≤30/poweroff≤650 от PID1 entry; host660/680/698/700 от launch entry.
Нужно доказать normal reap, отдельный VM stopped и полный console capture32MiB.
При Go FAIL тоже экспортировать доступный журнал, сохранив FAIL; при incomplete
или неизвестном завершении PASS/cleanup не утверждать.

Без PID1/lifecycle integration, compile, cross-language Go decode, runtime caps
и реального О‑1а запуска этот пакет не закрывает baseline/S6/D1/512MB или выпуск.


## Добавленный PID1: что именно делает source implementation

* Boot flags требуют ровно `corsa.o1a=1`, selected workload, fresh32hex attempt и
  SHA256 `/config/boot.json`; unknown/duplicate O1a flags и JSON keys отвергаются.
* Boot-config закрепляет source commit/archive SHA, точные profiles/4ELF/nft,
  compiled-helper hashes и полную inventory1345 исходных Go-файлов. До дочернего
  старта сверяет ≤256MiB входов, один файл≤96MiB; streaming directory inventory
  отвергает symlink/special/unlisted paths. Входы root-owned и не writable others.
* `BOOT-CONFIG.TEMPLATE.json` содержит1363 file entries из существующих manifests,
  но **неисполняемую обёртку**: attempt/probes и два новых compiled helpers ещё NULL.
  Три numeric isolation probes должен закрепить host handoff. Тестовые RFC5737/
  RFC3849 literals есть только в Go parser fixtures, они не runtime defaults.
* Strict интерфейсы ровно{lo}; ioctl включает lo без адресных aliases; readback
  требует только127.0.0.1/8 и::1/128. NoNIC подтверждается также host native config.
* /proc и/sys read-only; /dev — отдельный1MiB tmpfs с пятью только character nodes.
  Стандартные null/zero/random/urandom0666 нужны UID65532; console0600.
  /tmp128MiB sticky1777; /profiles512MiB0755 — новый собственный tmpfs.
  Mode0755 нужен исходному `openLinuxProfileAncestor`: тот требует world-traverse
  и сам создаёт root-owned sticky audited parents. Эти tmpfs входят в1536MiB гостя.
* PID1 единолично вызывает wait4(-1), без конкурирующего exec.Cmd.Wait. После
  main exit требует ECHILD, фактически reap-ит adopted descendants. Неожиданные
  оставшиеся descendants получают TERM/затем KILL; это исключает Normal success.
  Main work timeout: TERM600/KILL610/reap620. Logs≤4MiB до stdout console-budget32MiB.
* Только после подтверждённого all-children reap запускает отдельный exporter.
  Весь exporter-slot≤30с и не позже650с; последние2с зарезервированы под TERM,
  KILL/reap/drain. Exporter writes проходят через общий bounded console writer.
* Сохраняет отдельные test/export outcomes, timings и факт PoweroffAttempt.
  При Go FAIL экспортируется имеющийся journal; при unknown child tree экспорт
  запрещён. `TEST_EXIT_ZERO_CAPSULE_EXPORTED` не является О‑1а PASS: Root ещё обязан
  проверить decoder, rates/snapshots/nonce, no SKIP и независимый VM stopped.
* Финальный poweroff выполняется и после FAIL/refusal. Fence650с пытается KILL/
  poweroff, не повышая неизвестный результат до успеха. Kernel FS/console/syscall
  могут зависнуть: гарантии физического срока эта source implementation не даёт;
  host660/680/698/700 и UNKNOWN recovery остаются обязательными.

Оставшиеся действия: CODE-review всех новых PID1 paths, реальные Go/C compile,
unit tests (включая config failures), Go→Python vector decode, helper/native hashes,
точная упаковка initrd и отдельный runtime результат. `go.mod` имеет только stdlib.

CODE-review критика принят для offline compile/pure QA после исправлений:
explicit safeName component rejection и независимый650с fence выполняет Reboot
до любого blocking console output. Это не runtime/physical-stop PASS.
Final assembler обязан получить1345 source records из точного f228fb… архива;
config count/hash не заменяют доказательство происхождения source archive.
Runtime verifier проверяет все поля receipt, logs, capsule и provenance, не State alone.
