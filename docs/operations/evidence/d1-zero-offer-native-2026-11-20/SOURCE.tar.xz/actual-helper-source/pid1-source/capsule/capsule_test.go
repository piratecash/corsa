package capsule

import (
 "archive/tar"
 "bytes"
 "compress/gzip"
 "encoding/base64"
 "encoding/json"
 "io"
 "os"
 "path/filepath"
 "strings"
 "testing"
)

type vector struct { Binding Binding `json:"binding"`; Files map[string]string `json:"files"` }
func fixture(t *testing.T)(Binding,map[string][]byte){t.Helper();raw,e:=os.ReadFile("../fixtures/vector.json");if e!=nil{t.Fatal(e)};var v vector;if e=json.Unmarshal(raw,&v);e!=nil{t.Fatal(e)};files:=map[string][]byte{};for name,text:=range v.Files{raw,e:=base64.StdEncoding.DecodeString(text);if e!=nil{t.Fatal(e)};files[name]=raw};return v.Binding,files}
func unpackTest(t *testing.T,archive []byte,b Binding,want map[string][]byte){t.Helper();gz,e:=gzip.NewReader(bytes.NewReader(archive));if e!=nil{t.Fatal(e)};defer gz.Close();tr:=tar.NewReader(gz);first,e:=tr.Next();if e!=nil||first.Name!="CAPSULE.json"{t.Fatal("missing manifest",e)};manifest,e:=io.ReadAll(tr);if e!=nil{t.Fatal(e)};var decoded map[string]any;if e=json.Unmarshal(manifest,&decoded);e!=nil{t.Fatal(e)};if decoded["format"]!=Format{t.Fatal("format")};metadata:=decoded["metadata"].(map[string]any);for key,value:=range b.Map(){if metadata[key]!=value{t.Fatal("binding",key)}};seen:=map[string]bool{};for {h,e:=tr.Next();if e==io.EOF{break};if e!=nil{t.Fatal(e)};name:=strings.TrimPrefix(h.Name,"journal/");raw,e:=io.ReadAll(tr);if e!=nil||!bytes.Equal(raw,want[name]){t.Fatal("file mismatch",name,e)};if h.Mode!=0600||h.Uid!=0||h.Gid!=0||h.Typeflag!=tar.TypeReg{t.Fatal("header metadata")};seen[name]=true};if len(seen)!=len(want){t.Fatal("inventory mismatch")}}
func TestPackAndFrameWithPythonFixture(t *testing.T){b,files:=fixture(t);archive,e:=Pack(files,b,Default);if e!=nil{t.Fatal(e)};unpackTest(t,archive,b,files);again,e:=Pack(files,b,Default);if e!=nil||!bytes.Equal(archive,again){t.Fatal("nondeterministic archive")};frames,e:=Frame(archive,b,Default);if e!=nil{t.Fatal(e)};rows:=bytes.Split(bytes.TrimSuffix(frames,[]byte{'\n'}),[]byte{'\n'});if len(rows)<3{t.Fatal("missing frames")};var recovered []byte;for i,line:=range rows{if !bytes.HasPrefix(line,[]byte(Prefix)){t.Fatal("prefix")};var row map[string]any;if e=json.Unmarshal(line[len(Prefix):],&row);e!=nil{t.Fatal(e)};if i==0||i==len(rows)-1{if row["sha256"]!=Hash(archive){t.Fatal("archive hash")};continue};if int(row["index"].(float64))!=i-1{t.Fatal("chunk index")};part,e:=base64.StdEncoding.DecodeString(row["data"].(string));if e!=nil{t.Fatal(e)};recovered=append(recovered,part...)};if !bytes.Equal(recovered,archive){t.Fatal("frame bytes")}
 // ROOT may request a fresh cross-language output and validate it with Python.
 if out:=os.Getenv("O1A_GO_VECTOR_OUTPUT");out!=""{if !filepath.IsAbs(out){t.Fatal("absolute output required")};f,e:=os.OpenFile(out,os.O_WRONLY|os.O_CREATE|os.O_EXCL,0600);if e!=nil{t.Fatal(e)};if _,e=f.Write(frames);e!=nil{f.Close();t.Fatal(e)};if e=f.Close();e!=nil{t.Fatal(e)}}
}
func TestPythonArchiveAcceptedAsSameInventory(t *testing.T){b,files:=fixture(t);raw,e:=os.ReadFile("../fixtures/python.archive.gz");if e!=nil{t.Fatal(e)};unpackTest(t,raw,b,files)}
func TestExactPythonCanonicalJSON(t *testing.T){want,e:=os.ReadFile("../fixtures/canonical.json");if e!=nil{t.Fatal(e)};got,e:=Canonical(map[string]any{"ascii":"a<>/&\x7f\x00","unicode":"é😊","z":1});if e!=nil||!bytes.Equal(got,bytes.TrimSuffix(want,[]byte{'\n'})){t.Fatalf("canonical differs %q %q %v",got,want,e)}}
func TestInvalidAndDuplicateBindingsRefused(t *testing.T){b,_:=fixture(t);raw,e:=Canonical(b.Map());if e!=nil{t.Fatal(e)};if _,e=ParseBinding(raw);e!=nil{t.Fatal(e)};for _,raw:=range []string{`{}`,`{"workload":"periodic","workload":"periodic"}`,`{"unknown":"field"}`,string(raw)+" true"}{if _,e=ParseBinding([]byte(raw));e==nil{t.Fatal("accepted invalid binding")}};b.AttemptID="UPPER";if _,e=Frame([]byte("x"),b,Default);e==nil{t.Fatal("invalid attempt accepted")}}
func TestBoundsPathsAndMultichunk(t *testing.T){b,files:=fixture(t);for _,name:=range []string{".","..","../escape","/absolute","a//b","a\\b",strings.Repeat("x/",33)+"z"}{if _,e:=Pack(map[string][]byte{name:[]byte("x")},b,Default);e==nil{t.Fatal("unsafe name",name)}};cases:=[]Limits{Default,Default,Default,Default,Default,Default};cases[0].Content=1;cases[1].Files=1;cases[2].File=1;cases[3].Manifest=1;cases[4].Tar=1;cases[5].Archive=1;for _,l:=range cases{if _,e:=Pack(files,b,l);e==nil{t.Fatal("accepted overflow",l)}};archive,e:=Pack(files,b,Default);if e!=nil{t.Fatal(e)};l:=Default;l.Chunk=128;frames,e:=Frame(archive,b,l);if e!=nil||bytes.Count(frames,[]byte(Prefix))<4{t.Fatal("missing multichunk",e)};l.Console=1;if _,e=Frame(archive,b,l);e==nil{t.Fatal("console overflow")}}
