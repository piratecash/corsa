//go:build linux

package capsule

import ("errors";"fmt";"io";"os";"path/filepath";"syscall")

func statStamp(s *syscall.Stat_t) string {return fmt.Sprintf("%d:%d:%d:%d:%d:%d:%d:%d:%d",s.Dev,s.Ino,s.Mode,s.Size,s.Mtim.Sec,s.Mtim.Nsec,s.Ctim.Sec,s.Ctim.Nsec,s.Nlink)}
func statFD(fd int)(*syscall.Stat_t,error){s:=new(syscall.Stat_t);err:=syscall.Fstat(fd,s);return s,err}

// ReadQuiescent requires caller-proven child/descendant reap and a private root.
// It uses fd-relative O_NOFOLLOW traversal; mutation observed during reading fails.
func ReadQuiescent(root string,l Limits)(map[string][]byte,error){if !validLimits(l)||!filepath.IsAbs(root)||filepath.Clean(root)!=root{return nil,errors.New("canonical absolute root required")};canonical,err:=filepath.EvalSymlinks(root);if err!=nil||canonical!=root{return nil,errors.New("aliased journal root")};fd,err:=syscall.Open(root,syscall.O_RDONLY|syscall.O_DIRECTORY|syscall.O_NOFOLLOW|syscall.O_CLOEXEC,0);if err!=nil{return nil,err};defer syscall.Close(fd);files:=map[string][]byte{};total,dirs:=0,0
 var scan func(int,string)error
 scan=func(folder int,prefix string)error{duplicate,err:=syscall.Dup(folder);if err!=nil{return err};directory:=os.NewFile(uintptr(duplicate),"journal-directory");defer directory.Close()
  for {names,e:=directory.Readdirnames(1);if e!=nil&&e!=io.EOF{return e};if len(names)==0{return nil};name:=names[0];relative:=prefix+name;if !safeName(relative,l){return errors.New("inventory path bound")};child,err:=syscall.Openat(folder,name,syscall.O_RDONLY|syscall.O_NOFOLLOW|syscall.O_NONBLOCK|syscall.O_CLOEXEC,0);if err!=nil{return err};before,err:=statFD(child);if err!=nil{syscall.Close(child);return err};kind:=before.Mode&syscall.S_IFMT
   if kind==syscall.S_IFDIR {dirs++;if dirs>l.Directories{syscall.Close(child);return errors.New("directory bound")};err=scan(child,relative+"/");after,e2:=statFD(child);syscall.Close(child);if err!=nil{return err};if e2!=nil||statStamp(before)!=statStamp(after){return errors.New("directory changed")};continue}
   if kind!=syscall.S_IFREG||before.Nlink!=1||before.Size<0||before.Size>int64(l.File)||len(files)>=l.Files {syscall.Close(child);return errors.New("irregular or oversized journal file")};file:=os.NewFile(uintptr(child),"journal-file");raw,e2:=io.ReadAll(io.LimitReader(file,int64(l.File)+1));after,e3:=statFD(child);closeErr:=file.Close();if e2!=nil||e3!=nil||closeErr!=nil||int64(len(raw))!=before.Size||statStamp(before)!=statStamp(after){return errors.New("file changed during export")};if len(raw)>l.Content-total{return errors.New("content bound")};total+=len(raw);files[relative]=raw
  }}
 before,err:=statFD(fd);if err!=nil{return nil,err};if err=scan(fd,"");err!=nil{return nil,err};after,err:=statFD(fd);if err!=nil||statStamp(before)!=statStamp(after){return nil,errors.New("root changed during export")};if len(files)==0{return nil,errors.New("empty journal")};return files,nil
}
