// Package capsule exports an already quiescent journal to bounded console frames.
// Transport completeness is independent of Go outcome, source provenance and VM stop.
package capsule

import (
 "archive/tar"
 "bytes"
 "compress/gzip"
 "crypto/sha256"
 "encoding/base64"
 "encoding/hex"
 "encoding/json"
 "errors"
 "fmt"
 "io"
 "path"
 "regexp"
 "sort"
 "strings"
 "time"
 "unicode/utf16"
 "unicode/utf8"
)

const Prefix = "O1A_JOURNAL_CAPSULE_V1 "
const Format = "corsa-o1a-journal-capsule/v1"
const MiB = 1024*1024

type Limits struct { Console, Archive, Tar, Content, File, Files, Directories, Depth, Manifest, Chunk int }
var Default = Limits{32*MiB,16*MiB,72*MiB,64*MiB,8*MiB,4096,4096,32,MiB,48*1024}
type Binding struct { Workload string `json:"workload"`; ProfileSHA256 string `json:"profile_sha256"`; SourceCommit string `json:"source_commit"`; AttemptID string `json:"attempt_id"` }
var hex64=regexp.MustCompile(`^[0-9a-f]{64}$`)
var hex40=regexp.MustCompile(`^[0-9a-f]{40}$`)
var hex32=regexp.MustCompile(`^[0-9a-f]{32}$`)
func (b Binding) Validate() error { if (b.Workload!="periodic"&&b.Workload!="reconnect")||!hex64.MatchString(b.ProfileSHA256)||!hex40.MatchString(b.SourceCommit)||!hex32.MatchString(b.AttemptID) {return errors.New("invalid exact runtime binding")};return nil }
// ParseBinding refuses unknown and duplicate fields, unlike json.Unmarshal.
func ParseBinding(raw []byte)(Binding,error){d:=json.NewDecoder(bytes.NewReader(raw));t,err:=d.Token();if err!=nil||t!=json.Delim('{'){return Binding{},errors.New("binding object required")};values:=map[string]string{};for d.More(){key,e:=d.Token();if e!=nil{return Binding{},e};name,ok:=key.(string);if !ok{return Binding{},errors.New("binding field")};if _,exists:=values[name];exists{return Binding{},errors.New("duplicate binding field")};switch name{case "workload","profile_sha256","source_commit","attempt_id":default:return Binding{},errors.New("unknown binding field")};var value string;if e=d.Decode(&value);e!=nil{return Binding{},e};values[name]=value};if _,err=d.Token();err!=nil{return Binding{},err};if _,err=d.Token();err!=io.EOF{return Binding{},errors.New("binding trailing bytes")};b:=Binding{values["workload"],values["profile_sha256"],values["source_commit"],values["attempt_id"]};return b,b.Validate()}
func (b Binding) Map() map[string]any {return map[string]any{"workload":b.Workload,"profile_sha256":b.ProfileSHA256,"source_commit":b.SourceCommit,"attempt_id":b.AttemptID}}
func Hash(raw []byte) string { sum:=sha256.Sum256(raw); return hex.EncodeToString(sum[:]) }
func validLimits(l Limits) bool {return l.Console>0&&l.Console<=Default.Console&&l.Archive>0&&l.Archive<=Default.Archive&&l.Tar>0&&l.Tar<=Default.Tar&&l.Content>0&&l.Content<=Default.Content&&l.File>0&&l.File<=Default.File&&l.Files>0&&l.Files<=Default.Files&&l.Directories>0&&l.Directories<=Default.Directories&&l.Depth>0&&l.Depth<=Default.Depth&&l.Manifest>0&&l.Manifest<=Default.Manifest&&l.Chunk>0&&l.Chunk<=Default.Chunk}
func safeName(name string,l Limits) bool {if !utf8.ValidString(name)||len(name)==0||len(name)>512||strings.HasPrefix(name,"/")||path.Clean(name)!=name||strings.ContainsAny(name,"\\\r\n\x00"){return false};parts:=strings.Split(name,"/");if len(parts)>l.Depth{return false};for _,part:=range parts{if part==""||part=="."||part==".."{return false}};return true}

// Canonical implements Python json.dumps(sort_keys=True,separators=(',',':'),
// ensure_ascii=True), with only the JSON types used by the capsule schema.
func Canonical(value any) ([]byte,error) {var out bytes.Buffer; if err:=writeJSON(&out,value);err!=nil{return nil,err};return out.Bytes(),nil}
func quoted(out *bytes.Buffer,s string) error {if !utf8.ValidString(s){return errors.New("invalid UTF-8")};out.WriteByte('"');for _,r:=range s {switch r {case '"','\\':out.WriteByte('\\');out.WriteRune(r);case '\b':out.WriteString(`\b`);case '\f':out.WriteString(`\f`);case '\n':out.WriteString(`\n`);case '\r':out.WriteString(`\r`);case '\t':out.WriteString(`\t`);default:if r<0x20||r>0x7e {if r<=0xffff {fmt.Fprintf(out,`\u%04x`,r)}else{a,b:=utf16.EncodeRune(r);fmt.Fprintf(out,`\u%04x\u%04x`,a,b)}}else{out.WriteRune(r)}}};out.WriteByte('"');return nil}
func writeJSON(out *bytes.Buffer,v any) error {switch x:=v.(type) {case string:return quoted(out,x);case int:fmt.Fprint(out,x);case map[string]any:keys:=make([]string,0,len(x));for k:=range x{keys=append(keys,k)};sort.Strings(keys);out.WriteByte('{');for i,k:=range keys{if i>0{out.WriteByte(',')};if err:=quoted(out,k);err!=nil{return err};out.WriteByte(':');if err:=writeJSON(out,x[k]);err!=nil{return err}};out.WriteByte('}');case []any:out.WriteByte('[');for i,a:=range x{if i>0{out.WriteByte(',')};if err:=writeJSON(out,a);err!=nil{return err}};out.WriteByte(']');default:return fmt.Errorf("unsupported JSON type %T",v)};return nil}

type limitedBuffer struct { bytes.Buffer; Limit int }
func (b *limitedBuffer) Write(raw []byte)(int,error){if len(raw)>b.Limit-b.Len(){return 0,errors.New("output bound exceeded")};return b.Buffer.Write(raw)}

// Pack accepts complete immutable file bytes (not a partial on-disk inventory).
func Pack(files map[string][]byte,b Binding,l Limits)([]byte,error){
 if err:=b.Validate();err!=nil{return nil,err};if !validLimits(l)||len(files)==0||len(files)>l.Files{return nil,errors.New("invalid bounds or file count")}
 names:=make([]string,0,len(files));manifestFiles:=map[string]any{};dirs:=map[string]bool{};total:=0
 for name,raw:=range files {if !safeName(name,l)||len(raw)>l.File||len(raw)>l.Content-total{return nil,errors.New("file path/content bound")};total+=len(raw);names=append(names,name);manifestFiles[name]=map[string]any{"bytes":len(raw),"sha256":Hash(raw)};parts:=strings.Split(name,"/");for n:=1;n<len(parts);n++{dirs[strings.Join(parts[:n],"/")]=true;if len(dirs)>l.Directories{return nil,errors.New("directory bound")}}}
 sort.Strings(names)
 manifest,err:=Canonical(map[string]any{"format":Format,"metadata":b.Map(),"files":manifestFiles});if err!=nil{return nil,err};if len(manifest)>l.Manifest{return nil,errors.New("manifest bound")}
 rawTar:=&limitedBuffer{Limit:l.Tar};tw:=tar.NewWriter(rawTar)
 add:=func(name string,raw []byte)error{h:=&tar.Header{Name:name,Mode:0600,Uid:0,Gid:0,Size:int64(len(raw)),ModTime:time.Unix(0,0),Typeflag:tar.TypeReg,Format:tar.FormatUSTAR};if err:=tw.WriteHeader(h);err!=nil{return err};_,err:=tw.Write(raw);return err}
 if err=add("CAPSULE.json",manifest);err!=nil{return nil,err};for _,name:=range names{if err=add("journal/"+name,files[name]);err!=nil{return nil,err}};if err=tw.Close();err!=nil{return nil,err}
 zipped:=&limitedBuffer{Limit:l.Archive};gz,err:=gzip.NewWriterLevel(zipped,6);if err!=nil{return nil,err};gz.Header.ModTime=time.Time{};gz.Header.OS=255
 if _,err=gz.Write(rawTar.Bytes());err!=nil{return nil,err};if err=gz.Close();err!=nil{return nil,err};return append([]byte(nil),zipped.Bytes()...),nil
}

// Frame uses the exact Python decoder schema, with no partial success marker.
func Frame(archive []byte,b Binding,l Limits)([]byte,error){if err:=b.Validate();err!=nil{return nil,err};if !validLimits(l)||len(archive)==0||len(archive)>l.Archive{return nil,errors.New("archive bound")};count:=(len(archive)+l.Chunk-1)/l.Chunk;out:=&limitedBuffer{Limit:l.Console}
 row:=func(v map[string]any)error{raw,err:=Canonical(v);if err!=nil{return err};if _,err=out.Write([]byte(Prefix));err!=nil{return err};if _,err=out.Write(raw);err!=nil{return err};_,err=out.Write([]byte{'\n'});return err}
 summary:=func(kind string)map[string]any{return map[string]any{"kind":kind,"bytes":len(archive),"chunks":count,"sha256":Hash(archive),"metadata":b.Map()}}
 if err:=row(summary("begin"));err!=nil{return nil,err};for off,index:=0,0;off<len(archive);off,index=off+l.Chunk,index+1{end:=off+l.Chunk;if end>len(archive){end=len(archive)};if err:=row(map[string]any{"kind":"chunk","index":index,"data":base64.StdEncoding.EncodeToString(archive[off:end])});err!=nil{return nil,err}};if err:=row(summary("end"));err!=nil{return nil,err};return append([]byte(nil),out.Bytes()...),nil}

