//go:build linux

package capsule

import("os";"path/filepath";"testing")
func TestQuiescentInventoryRejectsLinksAndBounds(t *testing.T){root:=t.TempDir();if e:=os.WriteFile(filepath.Join(root,"record.json"),[]byte("record"),0600);e!=nil{t.Fatal(e)};files,e:=ReadQuiescent(root,Default);if e!=nil||string(files["record.json"])!="record"{t.Fatal(e)};for _,hard:=range []bool{false,true}{alias:=filepath.Join(root,"alias");if hard{e=os.Link(filepath.Join(root,"record.json"),alias)}else{e=os.Symlink("record.json",alias)};if e!=nil{t.Fatal(e)};if _,e=ReadQuiescent(root,Default);e==nil{t.Fatal("accepted linked journal")};if e=os.Remove(alias);e!=nil{t.Fatal(e)}};l:=Default;l.File=1;if _,e=ReadQuiescent(root,l);e==nil{t.Fatal("file overflow")}}
