package main

import("errors";"reflect";"testing")

func TestDeviceModesRecoverInheritedUmask(t *testing.T){
 for _,name:=range []string{"console","null","zero","random","urandom"}{
  t.Run(name,func(t *testing.T){want:=deviceMode(name);actual:=uint32(0020000)|(want&^0022);calls:=[]string{}
   err:=ensureDeviceMode(name,func(mode uint32)error{calls=append(calls,"chmod");actual=(actual&0170000)|mode;return nil},func()(uint32,error){calls=append(calls,"read");return actual,nil})
   if err!=nil||actual&07777!=want||!reflect.DeepEqual(calls,[]string{"chmod","read"}){t.Fatal("exact mode recovery",actual,calls,err)}
  })
 }
}
func TestDeviceModesRejectWrongTypeAndPermissions(t *testing.T){
 for _,actual:=range []uint32{0100666,0060666,0020644,0024666}{
  if ensureDeviceMode("null",func(uint32)error{return nil},func()(uint32,error){return actual,nil})==nil{t.Fatal("invalid mode accepted",actual)}
 }
 if ensureDeviceMode("foreign",func(uint32)error{t.Fatal("unknown chmod called");return nil},func()(uint32,error){t.Fatal("unknown read called");return 0,nil})==nil{t.Fatal("unknown node accepted")}
}
func TestDeviceModesPropagateSetAndReadFailures(t *testing.T){
 fail:=errors.New("fixture")
 if !errors.Is(ensureDeviceMode("null",func(uint32)error{return fail},func()(uint32,error){t.Fatal("read after failed chmod");return 0,nil}),fail){t.Fatal("chmod failure lost")}
 if !errors.Is(ensureDeviceMode("null",func(uint32)error{return nil},func()(uint32,error){return 0,fail}),fail){t.Fatal("read failure lost")}
}
