//go:build linux

package main

import (
 "fmt"
 "io"
 "os"
 "syscall"
 "corsa.local/o1aguesthelpers/capsule"
)

func fail(stage string) {fmt.Fprintln(os.Stderr,"O1A_CAPSULE_FAIL stage="+stage);os.Exit(125)}
func main(){
 if len(os.Args)!=2||(os.Args[1]!="periodic"&&os.Args[1]!="reconnect"){fail("arguments")};workload:=os.Args[1]
 name:="/config/"+workload+".binding.json";fd,err:=syscall.Open(name,syscall.O_RDONLY|syscall.O_NOFOLLOW|syscall.O_CLOEXEC|syscall.O_NONBLOCK,0);if err!=nil{fail("binding-open")};f:=os.NewFile(uintptr(fd),"binding");var st syscall.Stat_t;if syscall.Fstat(fd,&st)!=nil||st.Mode&syscall.S_IFMT!=syscall.S_IFREG||st.Nlink!=1||st.Size<=0||st.Size>4096{f.Close();fail("binding-file")};raw,err:=io.ReadAll(io.LimitReader(f,4097));closeErr:=f.Close();if err!=nil||closeErr!=nil||int64(len(raw))!=st.Size{fail("binding-read")}
 binding,err:=capsule.ParseBinding(raw);if err!=nil||binding.Workload!=workload||binding.SourceCommit!="4fcc2f7245095fc43d2225f0f0065f4ce3b26113"{fail("binding-values")};want:="28e76a342c9b28b8a2e1495f181f2463b35c04d64a268c705b55d789edd7791d";if workload=="reconnect"{want="f84856cfa6f3c3d39f4f5d69487c5d968106aeea77b16f8a3d7bf864266e7369"};if binding.ProfileSHA256!=want{fail("binding-profile")}
 files,err:=capsule.ReadQuiescent("/profiles/o1a-"+workload+"-journal",capsule.Default);if err!=nil{fail("inventory")};archive,err:=capsule.Pack(files,binding,capsule.Default);if err!=nil{fail("archive")};frames,err:=capsule.Frame(archive,binding,capsule.Default);if err!=nil{fail("frames")};n,err:=os.Stdout.Write(frames);if err!=nil||n!=len(frames){fail("console-write")}
}
