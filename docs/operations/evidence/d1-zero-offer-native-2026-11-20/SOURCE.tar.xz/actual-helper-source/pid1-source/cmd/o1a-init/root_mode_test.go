package main

import (
	"errors"
	"testing"
)

func TestRootModeRepairsStickyDefault(t *testing.T) {
	mode := uint32(0041777) // Actual diagnostic guest root, not a host mutation.
	calls := 0
	err := ensureRootMode(func(want uint32) error {
		calls++
		if want != 0755 {
			t.Fatalf("root requested mode %o", want)
		}
		mode = 0040000 | want
		return nil
	}, func() (uint32, uint32, uint32, error) { return mode, 0, 0, nil })
	if err != nil || calls != 1 || mode != 0040755 {
		t.Fatalf("root readback mode=%o calls=%d error=%v", mode, calls, err)
	}
}

func TestRootModeRejectsWrongMetadata(t *testing.T) {
	for _, row := range []struct{ mode, uid, gid uint32 }{
		{0041777, 0, 0}, {0040777, 0, 0}, {0040700, 0, 0},
		{0100755, 0, 0}, {0120755, 0, 0}, {0040755, 65532, 0}, {0040755, 0, 65532},
	} {
		err := ensureRootMode(func(uint32) error { return nil }, func() (uint32, uint32, uint32, error) {
			return row.mode, row.uid, row.gid, nil
		})
		if err == nil {
			t.Fatalf("accepted metadata %+v", row)
		}
	}
}

func TestRootModePropagatesSetAndReadFailures(t *testing.T) {
	failure := errors.New("fixture refusal")
	readCalled := false
	err := ensureRootMode(func(uint32) error { return failure }, func() (uint32, uint32, uint32, error) {
		readCalled = true
		return 0040755, 0, 0, nil
	})
	if !errors.Is(err, failure) || readCalled {
		t.Fatalf("failed chmod continued: %v read=%v", err, readCalled)
	}
	err = ensureRootMode(func(uint32) error { return nil }, func() (uint32, uint32, uint32, error) {
		return 0, 0, 0, failure
	})
	if !errors.Is(err, failure) {
		t.Fatalf("lost read failure: %v", err)
	}
}
