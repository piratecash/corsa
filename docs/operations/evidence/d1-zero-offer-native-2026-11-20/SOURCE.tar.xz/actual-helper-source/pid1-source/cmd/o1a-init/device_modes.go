package main

import "errors"

// Linux raw mode bits, independent of the host used for pure policy tests.
func deviceMode(name string) uint32 {
 switch name {
 case "console": return 0600
 case "null", "zero", "random", "urandom": return 0666
 default: return 0
 }
}

// chmod is required because mknod permissions are filtered by inherited umask.
// Readback is mandatory; an intended mode is never treated as the actual mode.
func ensureDeviceMode(name string, chmod func(uint32) error, readMode func()(uint32,error)) error {
 want:=deviceMode(name)
 if want==0{return errors.New("unknown character device")}
 if err:=chmod(want);err!=nil{return err}
 actual,err:=readMode();if err!=nil{return err}
 if actual&0170000!=0020000||actual&07777!=want{return errors.New("character device mode readback")}
 return nil
}
