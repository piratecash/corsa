package main

import "errors"

// This private PID1 owns the fresh initramfs before any application starts.
// Rootfs defaults are not a substitute for its exact safe ancestor contract.
func ensureRootMode(set func(uint32) error, read func() (mode, uid, gid uint32, err error)) error {
	if err := set(0755); err != nil {
		return err
	}
	mode, uid, gid, err := read()
	if err != nil {
		return err
	}
	if mode != 0040755 || uid != 0 || gid != 0 {
		return errors.New("guest root directory metadata readback")
	}
	return nil
}
