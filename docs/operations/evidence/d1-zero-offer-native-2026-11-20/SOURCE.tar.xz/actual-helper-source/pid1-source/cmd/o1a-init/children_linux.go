//go:build linux && arm64

package main

import("io";"os";"syscall";"time")

type PipeReceipt struct{Complete,Overflow bool}
// PID1 owns all wait4 calls; exec.Cmd.Wait is deliberately not used concurrently.
func reapAvailable(target int,result *ChildResult)(bool,error){for{var status syscall.WaitStatus;pid,e:=syscall.Wait4(-1,&status,syscall.WNOHANG,nil);if e==syscall.EINTR{continue};if e==syscall.ECHILD{return true,nil};if e!=nil{return false,e};if pid==0{return false,nil};if pid==target&&result!=nil{result.Reaped=true;result.Exit=-1;if status.Exited(){result.Exit=status.ExitStatus()}}}}
func drainUntil(deadline time.Time)bool{for time.Now().Before(deadline){all,e:=reapAvailable(0,nil);if e!=nil{return false};if all{return true};time.Sleep(10*time.Millisecond)};all,e:=reapAvailable(0,nil);return e==nil&&all}
func child(name string,argv,env []string,work,kill,reap time.Time,outputLimit int,console *Console)(result ChildResult){result.Exit=-1;if !time.Now().Before(work)||!work.Before(kill)||!kill.Before(reap){return result};read,write,e:=os.Pipe();if e!=nil{return result};null,e:=os.OpenFile("/dev/null",os.O_RDONLY,0);if e!=nil{read.Close();write.Close();return result}
 logs:=make(chan PipeReceipt,1);fault:=make(chan struct{},1)
 go func(){defer read.Close();total:=0;receipt:=PipeReceipt{};var buffer [32768]byte;for{n,e:=read.Read(buffer[:]);if n>0{if n>outputLimit-total{receipt.Overflow=true;select{case fault<-struct{}{}:default:};logs<-receipt;return};total+=n;if _,e=console.Write(buffer[:n]);e!=nil{select{case fault<-struct{}{}:default:};logs<-receipt;return}};if e!=nil{receipt.Complete=e==io.EOF;logs<-receipt;return}}}()
 pid,e:=syscall.ForkExec(name,argv,&syscall.ProcAttr{Dir:"/source/internal/core/node",Env:env,Files:[]uintptr{null.Fd(),write.Fd(),write.Fd()},Sys:&syscall.SysProcAttr{Setpgid:true}});write.Close();null.Close();if e!=nil{read.Close();return result};result.PID=pid;cleanupStart:=time.Time{};mainAt:=time.Time{};pipeDone:=false
 for{all,e:=reapAvailable(pid,&result);if e!=nil{break};now:=time.Now();if result.Reaped&&mainAt.IsZero(){mainAt=now};result.AllChildrenReaped=all
  select{case p:=<-logs:result.LogComplete=p.Complete;result.LogOverflow=p.Overflow;pipeDone=true;default:}
  if result.Reaped&&all&&pipeDone{result.Normal=result.Exit>=0&&mainAt.Before(work)&&!result.TermSent&&!result.KillSent&&result.LogComplete&&!result.LogOverflow;return result}
  select{case <-fault:if !result.TermSent{_=syscall.Kill(-1,syscall.SIGTERM);result.TermSent=true;cleanupStart=now};default:}
  // A normal primary exit must also leave no adopted descendants. If it does,
  // cleanup is explicit and this result cannot be called normal success.
  if result.Reaped&&!all&&cleanupStart.IsZero(){_=syscall.Kill(-1,syscall.SIGTERM);result.TermSent=true;cleanupStart=now}
  if !now.Before(work)&&!result.TermSent{_=syscall.Kill(-1,syscall.SIGTERM);result.TermSent=true}
  if (!now.Before(kill)||(!cleanupStart.IsZero()&&!now.Before(cleanupStart.Add(2*time.Second))))&&!result.KillSent{_=syscall.Kill(-1,syscall.SIGKILL);result.KillSent=true}
  if !now.Before(reap){break};time.Sleep(10*time.Millisecond)
 }
 _=syscall.Kill(-1,syscall.SIGKILL);result.KillSent=true;all,e:=reapAvailable(pid,&result);result.AllChildrenReaped=e==nil&&all;read.Close();select{case p:=<-logs:result.LogComplete=p.Complete;result.LogOverflow=p.Overflow;default:};return result
}
