package main

var FrozenProfiles=map[string]string{
"periodic":"{\n  \"Plan\": {\n    \"Seed\": 13,\n    \"FullNodes\": 2,\n    \"Hubs\": 2,\n    \"EdgeUplinks\": 1,\n    \"Duration\": 390000000000,\n    \"SampleInterval\": 15000000000,\n    \"Churn\": {\"Profile\": \"quiet\"}\n  },\n  \"Limits\": {\n    \"RouteReady\": 35000000000,\n    \"Readiness\": 30000000000,\n    \"Action\": 8000000000,\n    \"Cleanup\": 20000000000,\n    \"ReceiptDrain\": 8000000000,\n    \"AllowedLateness\": 8000000000,\n    \"MaxActions\": 128,\n    \"MaxSamples\": 96,\n    \"MaxTraceBytes\": 4194304\n  },\n  \"Timeout\": 540000000000,\n  \"StartupLead\": 90000000000,\n  \"Begin\": 120000000000,\n  \"End\": 360000000000,\n  \"MaxEndpoints\": 4,\n  \"FullReceiptRouteBudget\": 10000,\n  \"RequiredFullRoutes\": 10000,\n  \"SeedFullRoutes\": true,\n  \"RequiredFullSource\": \"periodic\",\n  \"SingleInitiator\": true,\n  \"JournalDir\": \"/profiles/o1a-periodic-journal\"\n}\n",
"reconnect":"{\n  \"Plan\": {\n    \"Seed\": 13,\n    \"FullNodes\": 2,\n    \"Hubs\": 2,\n    \"EdgeUplinks\": 1,\n    \"Duration\": 20000000000,\n    \"SampleInterval\": 5000000000,\n    \"Churn\": {\n      \"Profile\": \"quiet\"\n    }\n  },\n  \"Limits\": {\n    \"RouteReady\": 35000000000,\n    \"Readiness\": 30000000000,\n    \"Action\": 8000000000,\n    \"Cleanup\": 20000000000,\n    \"ReceiptDrain\": 8000000000,\n    \"AllowedLateness\": 8000000000,\n    \"MaxActions\": 128,\n    \"MaxSamples\": 96,\n    \"MaxTraceBytes\": 4194304\n  },\n  \"Timeout\": 90000000000,\n  \"StartupLead\": 10000000000,\n  \"Begin\": 2000000000,\n  \"End\": 15000000000,\n  \"MaxEndpoints\": 4,\n  \"FullReceiptRouteBudget\": 10000,\n  \"RequiredFullRoutes\": 10000,\n  \"SeedFullRoutes\": true,\n  \"RequiredFullSource\": \"connect\",\n  \"SingleInitiator\": true,\n  \"RequireReconnect\": true,\n  \"DisconnectAt\": 6000000000,\n  \"JournalDir\": \"/profiles/o1a-reconnect-journal\"\n}\n",
}
var FrozenArtifacts=map[string]Artifact{
"/bin/node.test":{Bytes:68933152,SHA256:"b117db44d4212365abcb5c418b9896a1ced8896a790435ada5325e7325b35399"},
"/bin/loadstand-full":{Bytes:30917397,SHA256:"e0bc42145d7d2a3ad8f2ff892f38b69a4f36b35a5d59085142c912754f03372e"},
"/bin/loadstand-sdkedge":{Bytes:33520035,SHA256:"d6b8da29107111e4120ba4fef69eaab12f9af18e403eb2eb022a5c4bf0c0e1cb"},
"/bin/loadstand-linuxhelper":{Bytes:10832482,SHA256:"4a1bd9c2cefa7b44449399c225d745d0825495a0285cf5b0293046d4c10d2ce3"},
"/usr/sbin/nft":{Bytes:67544,SHA256:"db01c7e0de5d39a0ca4947f7bc413af3bd004f61511fba9be659d0f1793dc55b"},
"/config/periodic.json":{Bytes:798,SHA256:"28e76a342c9b28b8a2e1495f181f2463b35c04d64a268c705b55d789edd7791d"},
"/config/reconnect.json":{Bytes:862,SHA256:"f84856cfa6f3c3d39f4f5d69487c5d968106aeea77b16f8a3d7bf864266e7369"},
}
