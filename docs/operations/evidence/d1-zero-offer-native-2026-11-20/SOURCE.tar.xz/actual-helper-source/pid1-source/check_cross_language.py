"""Validate small prepared fixtures and optionally a ROOT-built Go vector output."""
import argparse,base64,hashlib,importlib.util,json,sys
from pathlib import Path
HERE=Path(__file__).resolve().parent
REFERENCE=HERE.parent/'d1-o1a-guest-preparation-v1/journal_capsule.py'
spec=importlib.util.spec_from_file_location('journal_capsule',REFERENCE)
reference=importlib.util.module_from_spec(spec);sys.modules['journal_capsule']=reference;spec.loader.exec_module(reference)
parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--go-console',type=Path);args=parser.parse_args()
vector=json.loads((HERE/'fixtures/vector.json').read_text());binding=vector['binding'];expected={key:base64.b64decode(value,validate=True) for key,value in vector['files'].items()}
assert reference.decode((HERE/'fixtures/python.console').read_bytes(),binding)==expected
assert reference.canonical({'ascii':'a<>/&\x7f\0','unicode':'é😊','z':1})+b'\n'==(HERE/'fixtures/canonical.json').read_bytes()
if args.go_console:
 with args.go_console.open('rb') as stream:raw=stream.read(reference.LIMITS.console+1)
 assert reference.decode(raw,binding)==expected
print(json.dumps({'status':'GO_VECTOR_DECODE_PASS' if args.go_console else 'PYTHON_FIXTURES_ONLY_PASS','files':len(expected),'go_output_checked':bool(args.go_console),'reference_sha256':hashlib.sha256(REFERENCE.read_bytes()).hexdigest()},sort_keys=True))
