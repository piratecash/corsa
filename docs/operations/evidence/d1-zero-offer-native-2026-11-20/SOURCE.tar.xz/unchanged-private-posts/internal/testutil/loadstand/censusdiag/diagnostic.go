package censusdiag

import "errors"

// Closed fixture diagnostics only. A label never authorizes a census or changes
// its success/failure; it contains no error text, address, identity or secret.
type CensusStage uint8

const (
	CensusStageNone CensusStage = iota
	CensusStageFullRegistry
	CensusStageFullReceipt
	CensusStageWitnessClockBefore
	CensusStageWitnessRows
	CensusStageWitnessCommit
	CensusStageWitnessClockAfter
	CensusStageWitnessEncode
	CensusStageProcessBinding
	CensusStageProcessEndedBefore
	CensusStageProcessRPC
	CensusStageProcessEndedAfter
	CensusStageProcessContext
	CensusStageProcessDecode
	CensusStageHelperBinding
	CensusStageHelperClockBefore
	CensusStageHelperClockAfter
	CensusStageHelperClockMismatch
	CensusStageHelperCommitConflict
	CensusStageParentBinding
	CensusStageParentRunning
	CensusStageParentClockBefore
	CensusStageParentClockAfter
	CensusStageParentState
	CensusStageParentWrite
	CensusStageParentRead
	CensusStageParentDecode
)

func (s CensusStage) Valid() bool {
	if s > CensusStageNone && s <= CensusStageParentDecode {
		return true
	}
	switch s {
	case 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97:
		return true
	}
	return false
}

func (s CensusStage) Label() string {
	switch s {
	case CensusStageFullRegistry:
		return "full_registry"
	case CensusStageFullReceipt:
		return "full_receipt"
	case CensusStageWitnessClockBefore:
		return "witness_clock_before"
	case CensusStageWitnessRows:
		return "witness_rows"
	case CensusStageWitnessCommit:
		return "witness_commit"
	case CensusStageWitnessClockAfter:
		return "witness_clock_after"
	case CensusStageWitnessEncode:
		return "witness_encode"
	case CensusStageProcessBinding:
		return "process_binding"
	case CensusStageProcessEndedBefore:
		return "process_ended_before"
	case CensusStageProcessRPC:
		return "process_rpc"
	case CensusStageProcessEndedAfter:
		return "process_ended_after"
	case CensusStageProcessContext:
		return "process_context"
	case CensusStageProcessDecode:
		return "process_decode"
	case CensusStageHelperBinding:
		return "helper_binding"
	case CensusStageHelperClockBefore:
		return "helper_clock_before"
	case CensusStageHelperClockAfter:
		return "helper_clock_after"
	case CensusStageHelperClockMismatch:
		return "helper_clock_mismatch"
	case CensusStageHelperCommitConflict:
		return "helper_commit_conflict"
	case CensusStageParentBinding:
		return "parent_binding"
	case CensusStageParentRunning:
		return "parent_running"
	case CensusStageParentClockBefore:
		return "parent_clock_before"
	case CensusStageParentClockAfter:
		return "parent_clock_after"
	case CensusStageParentState:
		return "parent_state"
	case CensusStageParentWrite:
		return "parent_write"
	case CensusStageParentRead:
		return "parent_read"
	case CensusStageParentDecode:
		return "parent_decode"
	case 65:
		return "observer_unknown"
	case 66:
		return "observer_read_origin"
	case 67:
		return "observer_frame_shape"
	case 68:
		return "observer_window_crossing"
	case 69:
		return "observer_clock"
	case 70:
		return "observer_connection_admission"
	case 71:
		return "observer_queue_write"
	case 72:
		return "observer_full_send"
	case 73:
		return "observer_receive_metadata_stability"
	case 74:
		return "observer_receive_global_budget"
	case 75:
		return "observer_receive_connection_limit"
	case 76:
		return "observer_receipt_snapshot_missing_peer"
	case 77:
		return "observer_receipt_field_mismatch"
	case 78:
		return "observer_receipt_withdrawn_expired"
	case 79:
		return "observer_capture_window"
	case 80:
		return "observer_capture_pending"
	case 81:
		return "observer_full_send_start_sealed"
	case 82:
		return "observer_full_send_start_clock"
	case 83:
		return "observer_full_send_start_metadata"
	case 84:
		return "observer_full_send_entry"
	case 85:
		return "observer_full_send_duplicate"
	case 86:
		return "observer_full_send_frame_binding"
	case 87:
		return "observer_full_send_frame_claims"
	case 88:
		return "observer_full_send_projection_active"
	case 89:
		return "observer_full_send_projection_change"
	case 90:
		return "observer_full_send_projection_epoch"
	case 91:
		return "observer_full_send_finish_sealed"
	case 92:
		return "observer_full_send_finish_clock"
	case 93:
		return "observer_full_send_finish_begin_boundary"
	case 94:
		return "observer_full_send_finish_end_boundary"
	case 95:
		return "observer_full_send_finish_sender_false"
	case 96:
		return "observer_full_send_finish_no_frame"
	case 97:
		return "observer_full_send_finish_partial"
	default:
		return "unknown"
	}
}

type censusFailure struct {
	stage CensusStage
	cause error
}

func (e *censusFailure) Error() string {
	if e == nil || !e.stage.Valid() {
		return "fixture census unavailable"
	}
	return "fixture census unavailable: stage=" + e.stage.Label()
}
func (e *censusFailure) Unwrap() error {
	if e == nil {
		return nil
	}
	return e.cause
}

// Unwrap retains errors.Is locally. Formatting never includes cause.Error().
func CensusFailure(stage CensusStage, cause error) error {
	return &censusFailure{stage: stage, cause: cause}
}

func CensusDiagnostic(err error) (CensusStage, bool) {
	var e *censusFailure
	if errors.As(err, &e) && e != nil && e.stage.Valid() {
		return e.stage, true
	}
	return CensusStageNone, false
}

func CensusRPCMessage(stage CensusStage) string {
	if !stage.Valid() {
		return "fixture registry witness unavailable"
	}
	return "fixture registry witness unavailable: census_stage=" + stage.Label()
}

// Only the exact fixed server error-message is mapped. The caller separately
// verifies the authenticated launch-bound client, HTTP503, command and schema.
func CensusDiagnosticFromRPCMessage(raw string) (CensusStage, bool) {
	if len(raw) > 96 {
		return CensusStageNone, false
	}
	for s := CensusStageFullRegistry; s <= 97; s++ {
		if s.Valid() && raw == CensusRPCMessage(s) {
			return s, true
		}
	}
	return CensusStageNone, false
}

// Private disposable observer build only. No named Service/product API.
// A raw error cause or unknown structural code never becomes a label.
func CensusDiagnosticFromObserver(err error) (CensusStage, bool) {
	var readout interface{ RouteWireDiagnosticCode() uint8 }
	if !errors.As(err, &readout) || readout == nil {
		return CensusStageNone, false
	}
	code := readout.RouteWireDiagnosticCode()
	switch code {
	case 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33:
		return CensusStage(64 + code), true
	}
	return CensusStageNone, false
}
