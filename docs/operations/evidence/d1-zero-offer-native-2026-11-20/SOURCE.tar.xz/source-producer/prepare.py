"""DATA-only private observer source/archive/helper parameter rebind; no compiler/app."""
from pathlib import Path
import argparse,copy,difflib,hashlib,importlib.util,json,os,re,stat,sys,uuid
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent;DAY=HERE.parent
BINDING=json.loads((HERE/'ARTIFACT-BINDING.json').read_bytes())
ACTUAL=Path(BINDING['work']) if isinstance(BINDING.get('work'),str) else Path('/private/tmp/CORSA_UNBOUND_ZERO_OFFER_INPUTS')
ACTUAL_SHA=BINDING.get('result_sha256')
DATA=Path('/private/tmp/corsa-o1a-full-send-leaf-inputs-29a5c76170dd42818facb32d2ec16e93')
GOB=DAY/'d1-o1a-full-send-leaf-pid1-build-v1';CB=DAY/'d1-o1a-full-send-leaf-capexec-build-v1'
GO=DATA/'pid1-source';C=DATA/'capexec-source'
OLD_GO_BUILD=Path('/private/tmp/corsa-d1-o1a-census-component-go-helpers-248b094982094786a05f30c6ae505f70/RESULT.json')
SUBJECT=DAY/'d1-o1a-zero-offer-private-source-v2'
PACKER=DAY.parent/'2026-11-18/d1-o1a-guest-source-inputs/prepare_sources.py'
OLD_ARCHIVE='aaa268a9e05b73eb0494bde5baf06cf77b8ef7b223062dcda1de04b951f27686'
PROFILE='f84856cfa6f3c3d39f4f5d69487c5d968106aeea77b16f8a3d7bf864266e7369'
EXPORTER='7ef3b4a1edce0481408af11ab33d77c50d894215becc0e9142877016583abfb2'
DEPENDENCIES=('go.mod','cmd/journal-export/main.go','capsule/capsule.go','capsule/inventory_linux.go')
MACROS={'node.test':'NODE_SHA','loadstand-full':'FULL_SHA','loadstand-linuxhelper':'HELPER_SHA','loadstand-sdkedge':'TARGET_SHA'}
PURPOSE='DISPOSABLE_OBSERVER_FIRST_FAILURE_DIAGNOSTIC'
def need(v,s):
 if not v:raise ValueError(s)
def h(b):return hashlib.sha256(b).hexdigest()
def read(p,cap=2*1024**2):
 s=p.lstat();need(stat.S_ISREG(s.st_mode) and 0<=s.st_size<=cap,'bounded regular input')
 with p.open('rb') as f:r=f.read(s.st_size+1)
 need(len(r)==s.st_size,'changed length');return r
def sha(p,cap=96*1024**2):
 s=p.lstat();need(stat.S_ISREG(s.st_mode) and 0<=s.st_size<=cap,'bounded regular hash input');left=s.st_size;d=hashlib.sha256()
 with p.open('rb') as f:
  while left:
   b=f.read(min(left,1024**2));need(b,'short input');d.update(b);left-=len(b)
  need(not f.read(1),'growing input')
 key=lambda x:(x.st_dev,x.st_ino,x.st_uid,x.st_gid,x.st_mode,x.st_nlink,x.st_size,x.st_mtime_ns,x.st_ctime_ns)
 need(key(s)==key(p.lstat()),'input identity changed');return d.hexdigest()
def j(p):return json.loads(read(p))
def one(raw,a,z):need(raw.count(a)==1,'literal missing/ambiguous');return raw.replace(a,z)
def production_posts():return {n:r for n,r in j(SUBJECT/'MANIFEST.json')['files'].items() if not n.endswith('_test.go')}
def helpers():return j(DATA/'RESULT.json')['helper_sources']
def exporter_proof(go_rows,after_rows):
 need(all(go_rows[n]==after_rows[n] for n in DEPENDENCIES),'exporter dependency source changed')
 known={n for n in go_rows if n.startswith('capsule/') and n.endswith('.go') and not n.endswith('_test.go')}
 need(known=={'capsule/capsule.go','capsule/inventory_linux.go'},'exporter local package closure changed')
 need(all(sha(OLD_GO_BUILD.parent/'source'/n)==go_rows[n]['sha256'] for n in DEPENDENCIES),'actual compiled exporter dependency bytes')
 actual=j(OLD_GO_BUILD);build=next(x for x in actual['steps'] if x['phase']=='journal-export-build');meta=next(x for x in actual['steps'] if x['phase']=='journal-export-metadata');flags=['-mod=readonly','-buildvcs=false','-p=1','-trimpath','-ldflags=-buildid=']
 need(build['exit']==meta['exit']==0 and all(flag in build['argv'] for flag in flags),'actual exporter compiler flags')
 metadata=read(Path(meta['stdout'])).decode();need(all(token in metadata for token in ('go1.27.4','GOOS=linux','GOARCH=arm64','GOARM64=v8.0','CGO_ENABLED=0','-trimpath=true')) and '\tdep\t' not in metadata,'actual exporter module/target closure')
 main=read(GO/'cmd/journal-export/main.go');need(PROFILE.encode() in main and b'corsa.local/o1aguesthelpers/capsule' in main and b'o1a-init' not in main and b'SourceArchiveSHA' not in main,'exporter entry dependency boundary')
 return {'scope':'EXACT_REUSED_BINARY_APPLICABILITY_NOT_A_NEW_BUILD','artifact':j(OLD_GO_BUILD)['artifacts']['journal-export'],'original_build_result':{'path':str(OLD_GO_BUILD),'sha256':sha(OLD_GO_BUILD)},'source_dependencies':{n:go_rows[n] for n in DEPENDENCIES},'actual_compiled_source_dependencies_equal':True,'actual_metadata':{'path':meta['stdout'],'sha256':sha(Path(meta['stdout']))},'actual_build_argv':build['argv'],'source_inputs_independent_of_PID1_constants':True,'profile_sha256':PROFILE,'source_commit':'4fcc2f7245095fc43d2225f0f0065f4ce3b26113','compiler_flags':['-mod=readonly','-buildvcs=false','-p=1','-trimpath','-ldflags=-buildid='],'target':{'GOOS':'linux','GOARCH':'arm64','GOARM64':'v8.0','CGO_ENABLED':'0'},'toolchain_files':j(GOB/'FROZEN.json')['toolchain_files']}
def go_bind(config,frozen,old,new,archive):
 config=one(config,OLD_ARCHIVE.encode(),archive.encode());need(b'const SourceFiles=1348' in config,'same source count')
 for n in MACROS:
  a=f'"/bin/{n}":{{Bytes:{old[n]["bytes"]},SHA256:"{old[n]["sha256"]}"}}'.encode();z=f'"/bin/{n}":{{Bytes:{new[n]["bytes"]},SHA256:"{new[n]["sha256"]}"}}'.encode();frozen=one(frozen,a,z)
 return config,frozen
def c_bind(header,old,new):
 for n,macro in MACROS.items():header=one(header,('#define '+macro+' "'+old[n]['sha256']+'"').encode(),('#define '+macro+' "'+new[n]['sha256']+'"').encode())
 return header
def template_bind(template,source_records,old,new,archive):
 out=copy.deepcopy(template);c=out['config'];need(out['status']=='TEMPLATE_NOT_RUNNABLE' and c['source_archive_sha256']==OLD_ARCHIVE,'old template')
 wanted={n[8:] for n in c['files'] if n.startswith('/source/')};need(len(wanted)==1348 and wanted==set(source_records),'no new source paths')
 changed={n for n,r in source_records.items() if c['files']['/source/'+n]!=r};need(changed==set(production_posts()),'exact one existing full-send source record')
 c['source_archive_sha256']=archive
 for n,row in source_records.items():c['files']['/source/'+n]=row
 for n in MACROS:need(c['files']['/bin/'+n]==old[n],'old artifact template');c['files']['/bin/'+n]=new[n]
 need(c['profile_sha256']==PROFILE and c['files']['/bin/capexec']==c['files']['/bin/journal-export']=={'bytes':None,'sha256':None},'profile/null helper template')
 return out
def inputs():
 f=helpers();paths=[HERE/'ARTIFACT-BINDING.json',HERE/'prepare.py',HERE/'test_prepare.py',HERE/'README.ru.md',ACTUAL/'result.json',ACTUAL/'source-after.json',DATA/'RESULT.json',SUBJECT/'MANIFEST.json',GOB/'FROZEN.json',CB/'FROZEN.json',OLD_GO_BUILD,PACKER,DATA/'component.json',SUBJECT/'ARTIFACT-SOURCE-MANIFEST.json',DATA/'guest-sources.tar.gz']
 paths += [ACTUAL/n for n in MACROS]
 paths += [GO/n for n in f['pid1-source']['source_files']]+[C/n for n in f['capexec-source']['source_files']]
 paths += [Path(j(OLD_GO_BUILD)['artifacts']['journal-export']['path']),*[OLD_GO_BUILD.parent/'source'/n for n in DEPENDENCIES],Path(next(x for x in j(OLD_GO_BUILD)['steps'] if x['phase']=='journal-export-metadata')['stdout'])]
 return paths
def check():
 need(BINDING.get('status')=='ACTUAL_BOUND' and isinstance(BINDING.get('work'),str) and isinstance(ACTUAL_SHA,str) and re.fullmatch('[0-9a-f]{64}',ACTUAL_SHA) and isinstance(BINDING.get('request_sha256'),str) and re.fullmatch('[0-9a-f]{64}',BINDING['request_sha256']),'four actual artifacts not bound; pending source is not runnable')
 need(j(HERE/'INPUTS.json')=={'scope':PURPOSE,'files':{str(p):{'sha256':sha(p),'bytes':p.stat().st_size} for p in inputs()}},'frozen data inputs changed')
 need(sha(ACTUAL/'result.json')==ACTUAL_SHA and sha(ACTUAL/'source-after.json')=='29950a43880d803751a6e5fd15b79e4eac785bcce9d08e8935b90d0a1388fb0f','new private four build')
 need(sha(DATA/'RESULT.json')=='c3cb6bed74caa0c18ec3818fde8a58370d398f732816d21e69facf69222f1181' and sha(DATA/'component.json')==PROFILE,'old component source/profile');need(sha(DATA/'guest-sources.tar.gz')==OLD_ARCHIVE,'old source archive')
 r=j(ACTUAL/'result.json');need(r['request']==BINDING['request_sha256'] and r['status']=='BUILT_NOT_EXECUTED' and r['fresh_original_Go_API']['groups']['measured']['sha256']=='ae4710dc781e1e921f4c8e43a4c947a502eba8c69446ed532eba0276af1c4341' and r['fresh_original_Go_API']['groups']['stand']['sha256']=='78d671b120e64887b7a7a7c827d3c114a4d03c0fa1f4aee861fbd3fa7ce3185e','fresh API provenance')
 need(len(r['commands'])==17 and all(x['returncode']==0 and x['closure']=='CONFIRMED_ABSENT' for x in r['commands']),'four build closure')
 need(set(r['artifacts'])==set(MACROS) and r['artifacts']==BINDING.get('artifacts'),'exact four actual artifact binding')
 for n,row in r['artifacts'].items():need(sha(ACTUAL/n)==row['sha256'] and (ACTUAL/n).stat().st_size==row['bytes'],'new ELF bytes')
 f=helpers()
 for kind,folder in [('pid1-source',GO),('capexec-source',C)]:
  need(sha(folder/'SHA256SUMS')==f[kind]['source_sums_sha256'],'helper source inventory')
  for n,row in f[kind]['source_files'].items():need(sha(folder/n)==row['sha256'] and (folder/n).stat().st_size==row['bytes'],'old helper source')
 old=j(OLD_GO_BUILD);e=old['artifacts']['journal-export'];need(old['error'] is None and old['unknown'] is False and old['lock_retained'] is False and e['sha256']==EXPORTER and sha(Path(e['path']))==EXPORTER and e['bytes']==4767778,'actual reusable exporter')
 return sha(HERE/'INPUTS.json')
def prepare(approved):
 need(check()==approved,'exact input hash');old=j(DATA/'RESULT.json')['four_ELF'];new=j(ACTUAL/'result.json')['artifacts'];f=helpers();full=j(ACTUAL/'source-after.json')
 spec=importlib.util.spec_from_file_location('source_packer',PACKER);p=importlib.util.module_from_spec(spec);spec.loader.exec_module(p)
 source={n:read(ACTUAL/'source'/n) for n in full if p.groups(n)};need(len(source)==1348 and all(h(raw)==full[n] for n,raw in source.items()),'same compiled1348 sources')
 for name,raw in p.manifests(source).items():need(h(raw)==j(ACTUAL/'result.json')['fresh_original_Go_API']['groups'][name]['sha256'],'actual original API manifest')
 out=Path('/private/tmp')/('corsa-o1a-zero-offer-inputs-'+uuid.uuid4().hex);out.mkdir(mode=0o700);print(json.dumps({'owned_data_output':str(out)}),flush=True)
 packed=p.pack(out/'guest-sources.tar.gz',source);archive=packed['archive_sha256'];packed['base_commit']=packed.pop('commit');packed['base_export_request']=packed.pop('build_request_sha256');packed.update(scope=PURPOSE,actual_four_build_result_sha256=ACTUAL_SHA,fresh_original_Go_API=j(ACTUAL/'result.json')['fresh_original_Go_API'],NOT_baseline=True,NOT_metric=True)
 (out/'SOURCE-ARCHIVE.json').write_text(json.dumps(packed,indent=2,sort_keys=True)+'\n')
 config,frozen=go_bind(read(GO/'cmd/o1a-init/config.go'),read(GO/'cmd/o1a-init/frozen.go'),old,new,archive);header=c_bind(read(C/'frozen_inputs.h'),old,new)
 sr={n:{'sha256':h(raw),'bytes':len(raw)} for n,raw in source.items()};template=template_bind(j(GO/'BOOT-CONFIG.TEMPLATE.json'),sr,old,new,archive)
 updates={'pid1-source':{'cmd/o1a-init/config.go':config,'cmd/o1a-init/frozen.go':frozen,'BOOT-CONFIG.TEMPLATE.json':(json.dumps(template,indent=2,sort_keys=True)+'\n').encode()},'capexec-source':{'frozen_inputs.h':header}}
 output={};changes={}
 for kind,folder in [('pid1-source',GO),('capexec-source',C)]:
  dest=out/kind;dest.mkdir(mode=0o700);rows={};delta=[];diff=[]
  for n,row in f[kind]['source_files'].items():
   before=read(folder/n);after=updates[kind].get(n,before)
   if kind=='capexec-source' and n=='test_source_binding.py':
    oldpin=f[kind]['source_files']['frozen_inputs.h']['sha256'];after=one(before,oldpin.encode(),h(header).encode())
   target=dest/n;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(after);rows[n]={'sha256':h(after),'bytes':len(after)}
   if before!=after:delta.append(n);diff.extend(difflib.unified_diff(before.decode().splitlines(True),after.decode().splitlines(True),fromfile='before/'+n,tofile='after/'+n))
  need(set(delta)==({'cmd/o1a-init/config.go','cmd/o1a-init/frozen.go','BOOT-CONFIG.TEMPLATE.json'} if kind=='pid1-source' else {'frozen_inputs.h','test_source_binding.py'}),'exact parameter files only')
  (dest/'SHA256SUMS').write_text(''.join(row['sha256']+'  '+n+'\n' for n,row in sorted(rows.items())));output[kind]={'source_path':str(dest),'source_files':rows,'source_sums_sha256':sha(dest/'SHA256SUMS')};changes[kind]=delta;(out/(kind+'.diff')).write_text(''.join(diff))
 proof=exporter_proof(f['pid1-source']['source_files'],output['pid1-source']['source_files']);(out/'EXPORTER-REUSE.json').write_text(json.dumps(proof,indent=2,sort_keys=True)+'\n');(out/'component.json').write_bytes(read(DATA/'component.json'))
 need(check()==approved,'input changed during preparation');need(sum(p.stat().st_size for p in out.rglob('*') if p.is_file())<=64*1024**2,'own output64MiB')
 result={'scope':PURPOSE,'status':'PRIVATE_SOURCE_DATA_PREPARED_NOT_PID1_OR_CAPEXEC_BUILD','source_archive':{'path':str(out/'guest-sources.tar.gz'),'sha256':archive,'bytes':packed['archive_bytes']},'source_groups':packed['source_groups'],'four_ELF':new,'helper_sources':output,'helper_changed_files':changes,'reused_exporter':proof,'fresh_original_Go_API':j(ACTUAL/'result.json')['fresh_original_Go_API'],'profile':{'sha256':PROFILE,'path':str(out/'component.json'),'bytes':862},'runtime_ready':False,'resource_execution':False,'Core_changed_NOT_baseline_NOT_metric_NO512':True,'zero_offer_only_not_historical_native_cause_proof':True,'input_sha256':approved}
 (out/'RESULT.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n');print(json.dumps({'result':str(out/'RESULT.json'),'source_archive_sha256':archive,'scope':PURPOSE}))
if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--execute');a=p.parse_args()
 if a.execute:prepare(a.execute)
 else:print(check())
