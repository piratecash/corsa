import copy,json,unittest,hashlib
from unittest.mock import patch
from pathlib import Path
import prepare as p
class Tests(unittest.TestCase):
 def setUp(self):
  self.old=p.j(p.DATA/'RESULT.json')['four_ELF'];self.new={n:{'bytes':r['bytes']+1,'sha256':hashlib.sha256(('UNIT_FIXTURE_ONLY_'+n).encode()).hexdigest()} for n,r in self.old.items()}
 def test_PID1_only_archive_and_four_artifact_parameters(self):
  c=p.read(p.GO/'cmd/o1a-init/config.go');f=p.read(p.GO/'cmd/o1a-init/frozen.go');cc,ff=p.go_bind(c,f,self.old,self.new,'a'*64)
  self.assertEqual(cc.replace(b'a'*64,p.OLD_ARCHIVE.encode()),c);self.assertIn(b'const SourceFiles=1348',cc);self.assertNotEqual(ff,f)
  restored=ff
  for n in p.MACROS:
   old=self.old[n];new=self.new[n];restored=restored.replace(f'"/bin/{n}":{{Bytes:{new["bytes"]},SHA256:"{new["sha256"]}"}}'.encode(),f'"/bin/{n}":{{Bytes:{old["bytes"]},SHA256:"{old["sha256"]}"}}'.encode())
  self.assertEqual(restored,f);self.assertIn(b'want=int64(90*time.Second);window=int64(13*time.Second);lead=int64(10*time.Second)',p.read(p.GO/'cmd/o1a-init/config_test.go'))
 def test_C_changes_only_four_header_hashes_not_policy_timeout(self):
  before=p.read(p.C/'frozen_inputs.h');after=p.c_bind(before,self.old,self.new)
  for n in p.MACROS:after=after.replace(self.new[n]['sha256'].encode(),self.old[n]['sha256'].encode())
  self.assertEqual(after,before);self.assertIn(b'"-test.timeout=120s"',p.read(p.C/'capexec.c'));self.assertEqual(p.sha(p.C/'guest_policy.h'),'699c0a05f15cdf93c620326a2bc1112b53932f06dc08bd6a343076b22416162c')
 def test_template_same_paths_exact_one_source_update_unknown_helpers(self):
  before=p.j(p.GO/'BOOT-CONFIG.TEMPLATE.json');records={n[8:]:r for n,r in before['config']['files'].items() if n.startswith('/source/')};records=copy.deepcopy(records)
  for n,r in p.production_posts().items():records[n]={'sha256':r['after_sha256'],'bytes':(p.SUBJECT/'posts'/n).stat().st_size}
  after=p.template_bind(before,records,self.old,self.new,'a'*64);self.assertEqual(set(after['config']['files']),set(before['config']['files']));self.assertEqual(after['config']['profile_sha256'],p.PROFILE)
  bad=dict(records);bad['foreign.go']={'bytes':1,'sha256':'b'*64}
  with self.assertRaises(ValueError):p.template_bind(before,bad,self.old,self.new,'a'*64)
 def test_exporter_exact_dependency_closure_and_changed_dependency_refusal(self):
  rows=p.helpers()['pid1-source']['source_files'];proof=p.exporter_proof(rows,copy.deepcopy(rows));self.assertEqual(proof['artifact']['sha256'],p.EXPORTER);self.assertEqual(set(proof['source_dependencies']),set(p.DEPENDENCIES))
  bad=copy.deepcopy(rows);bad['capsule/capsule.go']['sha256']='a'*64
  with self.assertRaises(ValueError):p.exporter_proof(rows,bad)
 def test_pending_artifacts_refused_before_any_data_write(self):
  if p.BINDING['status']=='PENDING_NOT_RUNNABLE':
   with self.assertRaisesRegex(ValueError,'not bound'):p.check()
 def test_false_actual_label_with_NULL_paths_still_refused(self):
  with patch.dict(p.BINDING,{'status':'ACTUAL_BOUND'}):
   with self.assertRaisesRegex(ValueError,'not bound'):p.check()
if __name__=='__main__':unittest.main()
