# Zero-offer: минимальная подготовка входов, SOURCE only

Это узкий клон принятого `d1-o1a-full-send-leaf-input-rebind-v1/prepare.py`, а не новый runner. База — фактический DATA `29a5c761…`, архив `aaa268a9…` и исходные helper inventories `acd74f30…` / `bd3d2e1e…`.

Ожидается ровно одна новая строка исходника `loadstand_route_wire_full_send.go` в тех же 1348 гостевых путях: private leaf finish с тем же zero-supplied-frame исправлением. Core640 меняет канонический manifest на `ae4710dc…`, Stand708 остаётся `78d671b1…`. Семь QA-only файлов не попадают в четыре ELF и архив. Обычная Root-реализация и disposable private leaf — разные предметы.

Будущие четыре ELF, work/result/request пока NULL. `check()` отказывает до любых записей; статус ACTUAL_BOUND сам по себе недостаточен. После настоящей сборки Root свяжет точный result/request и четыре строки ELF, затем сформирует `INPUTS.json` из `inputs()` и заново заморозит метаданные. Предсказанные бинарные хеши не используются.

DATA producer меняет только архив/четыре ELF-параметра и одну строку `/source/` в BOOT template; PID1 код, capexec/policy147/52, профиль f848, таймауты/окна/права/caps сохраняются. Exporter7ef3 повторно используется только при точном прежнем dependency closure. NODE_SHA в C header остаётся provenance pin; реальная Node ELF проверка — у PID1 FrozenArtifacts.

`python3 -B -m unittest discover -s <этот каталог> -p test_prepare.py` — только шесть лёгких Python-проверок буквальных замен/отказов. Здесь нет Go, Docker, приложений, VM или нового разрешения выпуска. Причина прежнего 97a9 остаётся UNKNOWN; никакого O1a metric PASS не утверждается.
