"""Saved source/archive-only runtime binding audit; no resources or signals."""
from pathlib import Path
import gzip,hashlib,importlib.util,json
D=Path('/Users/hades/Documents/repos/corsa/docs/_internal/d1-artifacts/2026-11-20');R=D/'d1-o1a-zero-offer-runtime-v1';P=D/'d1-o1a-zero-offer-rebind-v1';HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('source_binder',P/'prepare.py');p=importlib.util.module_from_spec(spec);spec.loader.exec_module(p)
def need(v,s):
 if not v:raise ValueError(s)
def sh(raw):return hashlib.sha256(raw).hexdigest()
hraw=(R/'HANDOFF.json').read_bytes();h=json.loads(hraw);f=json.loads((P/'FROZEN.json').read_bytes());need(f['status']=='ACTUAL_HELPERS_BOUND_NOT_RUNTIME','actual frozen helpers')
need(h['purpose']==p.PURPOSE and h['workload']=='reconnect' and h['profile']=='d1-o1a-native-v1','component purpose/transport')
source=p.runtime_sources()
for n,raw in source.items():need((R/n).read_bytes()==raw,'exact generated source: '+n)
for n in ('launch.py','support.py','verify.py'):need(sh((R/n).read_bytes())==h['files'][n],'own source HANDOFF hash')
for n,root in [('capture_worker.py',D/'d1-o1a-host-capture-v1'),('journal_capsule.py',D/'d1-o1a-guest-preparation-v1')]:need(sh((root/n).read_bytes())==h['files'][n],'unchanged captured/reference source')
for n,row in h['inputs'].items():need(p.file_hash(row['path'],{'kernel':96,'initrd':128,'launcher':16}[n]*1024**2)==row['sha256'],'input data bytes')
receipt=p.record(h['assembly']['path']);need(p.file_hash(h['assembly']['path'],2*1024**2)==h['assembly']['sha256'],'assembly receipt')
need(receipt['scope']=='DISPOSABLE_OBSERVER_FIRST_FAILURE_DIAGNOSTIC_INITRAMFS_DATA_READBACK_ONLY' and receipt['source_files']==1348 and receipt['source_archive_sha256']==p.NEW_SOURCE_SHA,'component source assembly')
for n in ('attempt_id','config_sha256','workload'):need(receipt[n]==h[n],'same fresh receipt binding')
# Read every actual newc header and payload against the accepted assembly receipt.
seen=set();total=0;boot=None
with gzip.open(h['inputs']['initrd']['path'],'rb') as s:
 def read(n):
  raw=s.read(n);need(len(raw)==n,'truncated newc');return raw
 for unused in range(4097):
  raw=read(110);need(raw[:6]==b'070701','newc magic');v=[int(raw[i:i+8],16) for i in range(6,110,8)];size=v[6];nn=v[11];need(1<nn<=1024 and size<=96*1024**2,'newc bounds');name=read(nn);need(name.endswith(b'\0') and b'\0' not in name[:-1],'name');name=name[:-1].decode('ascii');need(read((-110-nn)%4).strip(b'\0')==b'','name padding')
  if name=='TRAILER!!!':need(size==0 and s.read(1)==b'','trailer/EOF');break
  need(name not in seen and name in receipt['members'],'exact member set');seen.add(name);row=receipt['members'][name]
  need(v[1]==int(row['mode'],8) and v[2]==v[3]==v[5]==v[7]==v[8]==v[12]==0 and v[4]==(2 if v[1]&0o170000==0o040000 else 1),'canonical mode/owner/newc header');need((v[9],v[10])==((5,1) if name=='dev/console' else (0,0)),'device numbers')
  digest=hashlib.sha256();left=size;keep=bytearray() if name=='config/boot.json' else None
  while left:
   b=read(min(left,1024**2));digest.update(b);left-=len(b)
   if keep is not None:need(size<=1024**2,'boot bound');keep.extend(b)
  need(row['bytes']==size and digest.hexdigest()==row['sha256'],'all payload bytes/hash');need(read((-size)%4).strip(b'\0')==b'','payload padding');total+=size;need(total<=256*1024**2,'newc total bound')
  if keep is not None:boot=json.loads(keep)
 else:raise ValueError('member count')
need(len(seen)==1439 and set(receipt['members'])==seen and boot is not None,'complete newc')
old=f['baseline_assemblies']['reconnect'];oldr=p.record(old['path']);p.exact_member_delta(oldr['members'],receipt['members'],f['expected_members']);p.exact_boot_delta(p.boot_record(old['archive'],oldr['members']['config/boot.json']['sha256']),boot,h['attempt_id'],f['expected_members'])
need(len(boot['files'])==1366 and sum(n.startswith('/source/') for n in boot['files'])==1348,'full boot/source inventory')
need(boot['profile_sha256']==p.COMPONENT_PROFILE and sh(json.dumps(boot,sort_keys=True,separators=(',',':')).encode()+b'\n')==h['config_sha256'],'canonical component boot/config hash')
need({n for n in seen if oldr['members'][n]!=receipt['members'][n]}==set(p.EXPECTED_MEMBER_NAMES)|{'config/boot.json'},'exact seven actual changedmembers')
oldboot=p.boot_record(old['archive'],oldr['members']['config/boot.json']['sha256']);need({n for n in boot['files'] if boot['files'][n]!=oldboot['files'][n]}=={'/'+n for n in p.EXPECTED_MEMBER_NAMES if n!='init'},'exact five actual changedbootrows')
current=json.loads((R/'HANDOFF.json').read_bytes());snapshot=dict(h);snapshot.pop('readiness');now=dict(current);now.pop('readiness');need(snapshot==now,'input/source HANDOFF changed during readback')
review={'status':'ACCEPTED_SOURCE_ARCHIVE_DATA_ONLY','purpose':p.PURPOSE,'prepared_handoff_sha256':sh(hraw),'readiness_at_snapshot':h['readiness'],'current_readiness':current['readiness'],'attempt_id':h['attempt_id'],'archive_sha256':h['inputs']['initrd']['sha256'],'archive_members':len(seen),'archive_payload_bytes':total,'source_files':1348,'boot_files':1366,'exact_changed_members':len(p.EXPECTED_MEMBER_NAMES)+1,'config_sha256':h['config_sha256'],'unchanged_kernel_worker_support_ACK_and_lifecycle':True,'runtime_or_cause_or_metric_outcome':'NOT_CLAIMED','resource_execution_by_reviewer':False}
(HERE/'REVIEW.json').write_text(json.dumps(review,indent=2,sort_keys=True)+'\n');print(json.dumps({'status':review['status'],'review_sha256':sh((HERE/'REVIEW.json').read_bytes()),'members':len(seen),'payload_bytes':total}))
