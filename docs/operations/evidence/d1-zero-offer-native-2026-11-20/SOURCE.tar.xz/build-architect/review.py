from pathlib import Path
import hashlib,importlib.util,json,os
D=Path('/Users/hades/Documents/repos/corsa/docs/_internal/d1-artifacts/2026-11-20');W=Path('/private/tmp/corsa-o1a-zero-offer-private-elf-build-4ffb25a64e9d40fbad9eb0ec77f7e618');P=D/'d1-o1a-zero-offer-private-elf-build-v1';HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('checked_builder',P/'build.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
def need(x,s):
 if not x:raise ValueError(s)
r=json.loads((W/'result.json').read_bytes());need(b.digest(W/'result.json')=='7938e3a9e0aaf51b35c59400920de5041a6380aac3ebcf18a1415a1ab9c725e7','actual result')
need(r['status']=='BUILT_NOT_EXECUTED' and r['request']=='3a0e2538beba5a392d34126de5ec50376a72e9d7547df0c5cc48d75ef90702c7' and len(r['commands'])==17,'actual request/17commands')
a=json.loads(b.TESTED_SOURCE.read_bytes());need(len(a)==2450 and json.loads((W/'source-before.json').read_bytes())==json.loads((W/'source-after.json').read_bytes())==a,'artifact2450')
need(b.inventory(W/'source')==a,'actual entire2450 source bytes')
subject=json.loads((b.QA/'MANIFEST.json').read_bytes());need(not set(subject['QA_only_files'])&set(a),'all7QA excluded')
expected={k:v['expected_semantic_graph'] for k,v in json.loads((P/'GRAPH-EXPECTATIONS.json').read_bytes()).items()};elf={}
for key,name,op,target,package in b.STAGES:
 p=W/name;row=r['artifacts'][name];need(p.stat().st_size==row['bytes'] and b.digest(p)==row['sha256'],'ELF identity');b.require_static_arm64(p.read_bytes());b.buildinfo_matches((W/'raw'/(key+'-metadata.stdout')).read_text(),package,expected[key]['modules'])
 for side in ('before','after'):need(b.graph_matches(b.summarize(W/'raw'/(key+'-'+side+'.stdout'),W/'source',W/'cache'),expected[key]),'complete semantic graph')
 elf[name]=row
api=json.loads((W/'raw/original-source-api.stdout').read_bytes());need(api==r['fresh_original_Go_API'] and api['status']=='ORIGINAL_GO_SOURCE_API_MATCH' and api['service_or_ELF_execution'] is False,'actual fresh API')
need(api['groups']==r['source_groups_original_Go_API'] and api['groups']['measured']['sha256']=='ae4710dc781e1e921f4c8e43a4c947a502eba8c69446ed532eba0276af1c4341' and api['groups']['stand']['sha256']=='78d671b120e64887b7a7a7c827d3c114a4d03c0fa1f4aee861fbd3fa7ce3185e' and all(x['manifest_bytes_equal'] and x['verify_tree']=='PASS' for x in api['groups'].values()),'fresh changedCore readback')
for row in r['commands']:
 need(row['returncode']==0 and row['closure']=='CONFIRMED_ABSENT' and row['pid']==row['pgid'],'normal own commands')
 for n in (row['pid'],-row['pid']):
  try:os.kill(n,0)
  except ProcessLookupError:pass
  else:raise ValueError('recorded process/group observable/reused')
raw={p.name:{'sha256':b.digest(p),'bytes':p.stat().st_size} for p in (W/'raw').glob('*') if p.is_file()};need(all(x['bytes']==0 for n,x in raw.items() if n.endswith('.stderr')),'stderr')
need(len(raw)==51,'all51RAW files');need(b.inventory(W/'source-api-module')==b.inventory(P/'source-api-module'),'exact API module bytes')
old=json.loads(Path('/private/tmp/corsa-o1a-full-send-leaf-elf-build-1f50c1e8b0cb41bb9fec0dd1a81fc4bf/result.json').read_bytes())
need(r['artifacts']['loadstand-linuxhelper']==old['artifacts']['loadstand-linuxhelper'],'helper must remain byte-identical')
need({n for n in elf if elf[n]!=old['artifacts'][n]}=={'node.test','loadstand-full','loadstand-sdkedge'},'exact three changed ELF payloads')
need(not Path('/private/tmp/corsa-heavy-run.lock').exists(),'heavy lock remains')
review={'status':'ACCEPTED_FOUR_PRIVATE_ELF_DATA_ONLY','scope':'CHANGED_CORE_NOT_BASELINE_NOT_METRIC_NO512','result_sha256':b.digest(W/'result.json'),'request_sha256':r['request'],'artifacts':elf,'artifact_source_files':2450,'artifact_manifest_sha256':b.digest(W/'source-after.json'),'fresh_original_Go_API':api,'commands_normal':17,'fresh_recorded_PIDs_PGIDs_absent':True,'RAW_bytes':sum(x['bytes'] for x in raw.values()),'RAW':raw,'Linux_app_ELF_executed':False,'resource_execution_by_reviewer':False}
(HERE/'REVIEW.json').write_text(json.dumps(review,indent=2,sort_keys=True)+'\n');print(b.digest(HERE/'REVIEW.json'))
