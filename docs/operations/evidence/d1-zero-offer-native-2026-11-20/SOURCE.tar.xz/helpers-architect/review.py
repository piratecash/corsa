import hashlib,json,os,struct
from pathlib import Path
D=Path('/Users/hades/Documents/repos/corsa/docs/_internal/d1-artifacts/2026-11-20')
roots=[Path('/private/tmp/corsa-d1-o1a-zero-offer-pid1-b36d6869ef424c418ed85bcb3bb26ffa'),Path('/private/tmp/corsa-d1-o1a-zero-offer-capexec-40bb2671bf2747c7857498a17708597c')]
rows=[]
for i,w in enumerate(roots):
 r=json.loads((w/'RESULT.json').read_bytes());assert not r['error'] and not r['unknown'] and not r['lock_retained'];total=0
 for s in r['steps']:
  assert s['exit']==0 and s['owned_group_absent'] and s['pipe_threads_finished'] and s['reason'] is None
  for field in ['stdout','stderr']:total+=Path(s[field]).stat().st_size
  assert not Path(s['stderr']).read_bytes()
  for f in (os.kill,os.killpg):
   try:f(s['pid'],0)
   except ProcessLookupError:pass
   else:raise AssertionError('live PID/PGID')
 assert total==r['raw_bytes'];a=r['artifact'] if i else r['artifacts']['o1a-init'];b=Path(a['path']).read_bytes();assert len(b)==a['bytes'] and hashlib.sha256(b).hexdigest()==a['sha256'];assert b[:6]==b'\x7fELF\x02\x01' and struct.unpack_from('<HH',b,16)==(2,183)
 off=struct.unpack_from('<Q',b,32)[0];ents,n=struct.unpack_from('<HH',b,54);assert all(struct.unpack_from('<I',b,off+j*ents)[0] not in (2,3) for j in range(n))
 p=D/('d1-o1a-zero-offer-capexec-build-v1' if i else 'd1-o1a-zero-offer-pid1-build-v1');frozen=json.loads((p/'FROZEN.json').read_bytes())
 # Every original manifest file is unchanged in actual build work.
 src=w/('input' if i else 'source'); source=p/'source'
 for line in (source/'SHA256SUMS').read_text().splitlines():
  sha,name=line.split('  ',1);assert hashlib.sha256((source/name).read_bytes()).hexdigest()==sha
  if not i or (src/name).exists():assert hashlib.sha256((src/name).read_bytes()).hexdigest()==sha
 if i:
  assert r['owned_container_removed'] and not Path(r['steps'][-1]['stdout']).read_bytes().strip();assert r['policy_data']['instruction_count']==147 and r['policy_data']['control_count']==52 and not r['policy_data']['filter_installed'];assert r['policy_data']['dump_sha256']=='08ede40f120c35a843f44e21b8c8b0425f5e1f28e9dbb89c2a00b7c35e92da2d'
 else:
  events=[json.loads(x) for x in Path(r['steps'][1]['stdout']).read_text().splitlines()];passes=[x['Test'] for x in events if x.get('Action')=='pass' and 'Test'in x];assert len([x for x in passes if '/'not in x])==10 and len(passes)==15;assert not any(x.get('Action')=='fail' for x in events)
 rows.append({'result':str(w/'RESULT.json'),'result_sha256':hashlib.sha256((w/'RESULT.json').read_bytes()).hexdigest(),'artifact':a,'raw_bytes':total,'commands':len(r['steps']),'source_manifest_verified':True,'fresh_pid_pgid_absent':True})
out=D/'d1-o1a-zero-offer-helper-architect-data-v1';out.mkdir(exist_ok=True);(out/'REVIEW.json').write_text(json.dumps({'status':'ACCEPTED_BUILD_DATA_ONLY','scope':'DISPOSABLE_OBSERVER_FIRST_FAILURE_DIAGNOSTIC_NOT_RUNTIME','reviews':rows,'exporter_rebuilt':False,'VM_or_helper_executed_by_reviewer':False},indent=2,sort_keys=True)+'\n');print(hashlib.sha256((out/'REVIEW.json').read_bytes()).hexdigest())
